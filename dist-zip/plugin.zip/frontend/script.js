function XL(a, o) {
  for (var u = 0; u < o.length; u++) {
    const s = o[u];
    if (typeof s != "string" && !Array.isArray(s)) {
      for (const d in s)
        if (d !== "default" && !(d in a)) {
          const v = Object.getOwnPropertyDescriptor(s, d);
          v && Object.defineProperty(a, d, v.get ? v : {
            enumerable: !0,
            get: () => s[d]
          });
        }
    }
  }
  return Object.freeze(Object.defineProperty(a, Symbol.toStringTag, { value: "Module" }));
}
function Ay(a) {
  return a && a.__esModule && Object.prototype.hasOwnProperty.call(a, "default") ? a.default : a;
}
var QR = { exports: {} }, Sd = {}, ZR = { exports: {} }, xd = { exports: {} };
xd.exports;
(function(a, o) {
  /**
   * @license React
   * react.development.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  (function() {
    typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(new Error());
    var u = "18.3.1", s = Symbol.for("react.element"), d = Symbol.for("react.portal"), v = Symbol.for("react.fragment"), c = Symbol.for("react.strict_mode"), g = Symbol.for("react.profiler"), b = Symbol.for("react.provider"), S = Symbol.for("react.context"), R = Symbol.for("react.forward_ref"), E = Symbol.for("react.suspense"), x = Symbol.for("react.suspense_list"), T = Symbol.for("react.memo"), M = Symbol.for("react.lazy"), L = Symbol.for("react.offscreen"), $ = Symbol.iterator, U = "@@iterator";
    function F(y) {
      if (y === null || typeof y != "object")
        return null;
      var D = $ && y[$] || y[U];
      return typeof D == "function" ? D : null;
    }
    var Y = {
      /**
       * @internal
       * @type {ReactComponent}
       */
      current: null
    }, X = {
      transition: null
    }, W = {
      current: null,
      // Used to reproduce behavior of `batchedUpdates` in legacy mode.
      isBatchingLegacy: !1,
      didScheduleLegacyUpdate: !1
    }, ne = {
      /**
       * @internal
       * @type {ReactComponent}
       */
      current: null
    }, Z = {}, ve = null;
    function me(y) {
      ve = y;
    }
    Z.setExtraStackFrame = function(y) {
      ve = y;
    }, Z.getCurrentStack = null, Z.getStackAddendum = function() {
      var y = "";
      ve && (y += ve);
      var D = Z.getCurrentStack;
      return D && (y += D() || ""), y;
    };
    var he = !1, Ee = !1, Xe = !1, fe = !1, ge = !1, Ie = {
      ReactCurrentDispatcher: Y,
      ReactCurrentBatchConfig: X,
      ReactCurrentOwner: ne
    };
    Ie.ReactDebugCurrentFrame = Z, Ie.ReactCurrentActQueue = W;
    function De(y) {
      {
        for (var D = arguments.length, z = new Array(D > 1 ? D - 1 : 0), I = 1; I < D; I++)
          z[I - 1] = arguments[I];
        Se("warn", y, z);
      }
    }
    function de(y) {
      {
        for (var D = arguments.length, z = new Array(D > 1 ? D - 1 : 0), I = 1; I < D; I++)
          z[I - 1] = arguments[I];
        Se("error", y, z);
      }
    }
    function Se(y, D, z) {
      {
        var I = Ie.ReactDebugCurrentFrame, ee = I.getStackAddendum();
        ee !== "" && (D += "%s", z = z.concat([ee]));
        var _e = z.map(function(pe) {
          return String(pe);
        });
        _e.unshift("Warning: " + D), Function.prototype.apply.call(console[y], console, _e);
      }
    }
    var se = {};
    function Ke(y, D) {
      {
        var z = y.constructor, I = z && (z.displayName || z.name) || "ReactClass", ee = I + "." + D;
        if (se[ee])
          return;
        de("Can't call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `this.state` directly or define a `state = {};` class property with the desired state in the %s component.", D, I), se[ee] = !0;
      }
    }
    var dt = {
      /**
       * Checks whether or not this composite component is mounted.
       * @param {ReactClass} publicInstance The instance we want to test.
       * @return {boolean} True if mounted, false otherwise.
       * @protected
       * @final
       */
      isMounted: function(y) {
        return !1;
      },
      /**
       * Forces an update. This should only be invoked when it is known with
       * certainty that we are **not** in a DOM transaction.
       *
       * You may want to call this when you know that some deeper aspect of the
       * component's state has changed but `setState` was not called.
       *
       * This will not invoke `shouldComponentUpdate`, but it will invoke
       * `componentWillUpdate` and `componentDidUpdate`.
       *
       * @param {ReactClass} publicInstance The instance that should rerender.
       * @param {?function} callback Called after component is updated.
       * @param {?string} callerName name of the calling function in the public API.
       * @internal
       */
      enqueueForceUpdate: function(y, D, z) {
        Ke(y, "forceUpdate");
      },
      /**
       * Replaces all of the state. Always use this or `setState` to mutate state.
       * You should treat `this.state` as immutable.
       *
       * There is no guarantee that `this.state` will be immediately updated, so
       * accessing `this.state` after calling this method may return the old value.
       *
       * @param {ReactClass} publicInstance The instance that should rerender.
       * @param {object} completeState Next state.
       * @param {?function} callback Called after component is updated.
       * @param {?string} callerName name of the calling function in the public API.
       * @internal
       */
      enqueueReplaceState: function(y, D, z, I) {
        Ke(y, "replaceState");
      },
      /**
       * Sets a subset of the state. This only exists because _pendingState is
       * internal. This provides a merging strategy that is not available to deep
       * properties which is confusing. TODO: Expose pendingState or don't use it
       * during the merge.
       *
       * @param {ReactClass} publicInstance The instance that should rerender.
       * @param {object} partialState Next partial state to be merged with state.
       * @param {?function} callback Called after component is updated.
       * @param {?string} Name of the calling function in the public API.
       * @internal
       */
      enqueueSetState: function(y, D, z, I) {
        Ke(y, "setState");
      }
    }, ft = Object.assign, Ft = {};
    Object.freeze(Ft);
    function Yt(y, D, z) {
      this.props = y, this.context = D, this.refs = Ft, this.updater = z || dt;
    }
    Yt.prototype.isReactComponent = {}, Yt.prototype.setState = function(y, D) {
      if (typeof y != "object" && typeof y != "function" && y != null)
        throw new Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
      this.updater.enqueueSetState(this, y, D, "setState");
    }, Yt.prototype.forceUpdate = function(y) {
      this.updater.enqueueForceUpdate(this, y, "forceUpdate");
    };
    {
      var Pn = {
        isMounted: ["isMounted", "Instead, make sure to clean up subscriptions and pending requests in componentWillUnmount to prevent memory leaks."],
        replaceState: ["replaceState", "Refactor your code to use setState instead (see https://github.com/facebook/react/issues/3236)."]
      }, Wt = function(y, D) {
        Object.defineProperty(Yt.prototype, y, {
          get: function() {
            De("%s(...) is deprecated in plain JavaScript React classes. %s", D[0], D[1]);
          }
        });
      };
      for (var Nt in Pn)
        Pn.hasOwnProperty(Nt) && Wt(Nt, Pn[Nt]);
    }
    function an() {
    }
    an.prototype = Yt.prototype;
    function at(y, D, z) {
      this.props = y, this.context = D, this.refs = Ft, this.updater = z || dt;
    }
    var zt = at.prototype = new an();
    zt.constructor = at, ft(zt, Yt.prototype), zt.isPureReactComponent = !0;
    function wn() {
      var y = {
        current: null
      };
      return Object.seal(y), y;
    }
    var xn = Array.isArray;
    function yt(y) {
      return xn(y);
    }
    function Gt(y) {
      {
        var D = typeof Symbol == "function" && Symbol.toStringTag, z = D && y[Symbol.toStringTag] || y.constructor.name || "Object";
        return z;
      }
    }
    function Ht(y) {
      try {
        return Lt(y), !1;
      } catch {
        return !0;
      }
    }
    function Lt(y) {
      return "" + y;
    }
    function kt(y) {
      if (Ht(y))
        return de("The provided key is an unsupported type %s. This value must be coerced to a string before before using it here.", Gt(y)), Lt(y);
    }
    function Un(y, D, z) {
      var I = y.displayName;
      if (I)
        return I;
      var ee = D.displayName || D.name || "";
      return ee !== "" ? z + "(" + ee + ")" : z;
    }
    function pn(y) {
      return y.displayName || "Context";
    }
    function Wn(y) {
      if (y == null)
        return null;
      if (typeof y.tag == "number" && de("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), typeof y == "function")
        return y.displayName || y.name || null;
      if (typeof y == "string")
        return y;
      switch (y) {
        case v:
          return "Fragment";
        case d:
          return "Portal";
        case g:
          return "Profiler";
        case c:
          return "StrictMode";
        case E:
          return "Suspense";
        case x:
          return "SuspenseList";
      }
      if (typeof y == "object")
        switch (y.$$typeof) {
          case S:
            var D = y;
            return pn(D) + ".Consumer";
          case b:
            var z = y;
            return pn(z._context) + ".Provider";
          case R:
            return Un(y, y.render, "ForwardRef");
          case T:
            var I = y.displayName || null;
            return I !== null ? I : Wn(y.type) || "Memo";
          case M: {
            var ee = y, _e = ee._payload, pe = ee._init;
            try {
              return Wn(pe(_e));
            } catch {
              return null;
            }
          }
        }
      return null;
    }
    var Ar = Object.prototype.hasOwnProperty, yr = {
      key: !0,
      ref: !0,
      __self: !0,
      __source: !0
    }, jn, gr, Tn;
    Tn = {};
    function tr(y) {
      if (Ar.call(y, "ref")) {
        var D = Object.getOwnPropertyDescriptor(y, "ref").get;
        if (D && D.isReactWarning)
          return !1;
      }
      return y.ref !== void 0;
    }
    function Pt(y) {
      if (Ar.call(y, "key")) {
        var D = Object.getOwnPropertyDescriptor(y, "key").get;
        if (D && D.isReactWarning)
          return !1;
      }
      return y.key !== void 0;
    }
    function br(y, D) {
      var z = function() {
        jn || (jn = !0, de("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", D));
      };
      z.isReactWarning = !0, Object.defineProperty(y, "key", {
        get: z,
        configurable: !0
      });
    }
    function Ca(y, D) {
      var z = function() {
        gr || (gr = !0, de("%s: `ref` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", D));
      };
      z.isReactWarning = !0, Object.defineProperty(y, "ref", {
        get: z,
        configurable: !0
      });
    }
    function Ea(y) {
      if (typeof y.ref == "string" && ne.current && y.__self && ne.current.stateNode !== y.__self) {
        var D = Wn(ne.current.type);
        Tn[D] || (de('Component "%s" contains the string ref "%s". Support for string refs will be removed in a future major release. This case cannot be automatically converted to an arrow function. We ask you to manually fix this case by using useRef() or createRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref', D, y.ref), Tn[D] = !0);
      }
    }
    var re = function(y, D, z, I, ee, _e, pe) {
      var Ae = {
        // This tag allows us to uniquely identify this as a React Element
        $$typeof: s,
        // Built-in properties that belong on the element
        type: y,
        key: D,
        ref: z,
        props: pe,
        // Record the component responsible for creating this element.
        _owner: _e
      };
      return Ae._store = {}, Object.defineProperty(Ae._store, "validated", {
        configurable: !1,
        enumerable: !1,
        writable: !0,
        value: !1
      }), Object.defineProperty(Ae, "_self", {
        configurable: !1,
        enumerable: !1,
        writable: !1,
        value: I
      }), Object.defineProperty(Ae, "_source", {
        configurable: !1,
        enumerable: !1,
        writable: !1,
        value: ee
      }), Object.freeze && (Object.freeze(Ae.props), Object.freeze(Ae)), Ae;
    };
    function be(y, D, z) {
      var I, ee = {}, _e = null, pe = null, Ae = null, Ve = null;
      if (D != null) {
        tr(D) && (pe = D.ref, Ea(D)), Pt(D) && (kt(D.key), _e = "" + D.key), Ae = D.__self === void 0 ? null : D.__self, Ve = D.__source === void 0 ? null : D.__source;
        for (I in D)
          Ar.call(D, I) && !yr.hasOwnProperty(I) && (ee[I] = D[I]);
      }
      var lt = arguments.length - 2;
      if (lt === 1)
        ee.children = z;
      else if (lt > 1) {
        for (var vt = Array(lt), ht = 0; ht < lt; ht++)
          vt[ht] = arguments[ht + 2];
        Object.freeze && Object.freeze(vt), ee.children = vt;
      }
      if (y && y.defaultProps) {
        var Rt = y.defaultProps;
        for (I in Rt)
          ee[I] === void 0 && (ee[I] = Rt[I]);
      }
      if (_e || pe) {
        var _t = typeof y == "function" ? y.displayName || y.name || "Unknown" : y;
        _e && br(ee, _t), pe && Ca(ee, _t);
      }
      return re(y, _e, pe, Ae, Ve, ne.current, ee);
    }
    function Fe(y, D) {
      var z = re(y.type, D, y.ref, y._self, y._source, y._owner, y.props);
      return z;
    }
    function it(y, D, z) {
      if (y == null)
        throw new Error("React.cloneElement(...): The argument must be a React element, but you passed " + y + ".");
      var I, ee = ft({}, y.props), _e = y.key, pe = y.ref, Ae = y._self, Ve = y._source, lt = y._owner;
      if (D != null) {
        tr(D) && (pe = D.ref, lt = ne.current), Pt(D) && (kt(D.key), _e = "" + D.key);
        var vt;
        y.type && y.type.defaultProps && (vt = y.type.defaultProps);
        for (I in D)
          Ar.call(D, I) && !yr.hasOwnProperty(I) && (D[I] === void 0 && vt !== void 0 ? ee[I] = vt[I] : ee[I] = D[I]);
      }
      var ht = arguments.length - 2;
      if (ht === 1)
        ee.children = z;
      else if (ht > 1) {
        for (var Rt = Array(ht), _t = 0; _t < ht; _t++)
          Rt[_t] = arguments[_t + 2];
        ee.children = Rt;
      }
      return re(y.type, _e, pe, Ae, Ve, lt, ee);
    }
    function ot(y) {
      return typeof y == "object" && y !== null && y.$$typeof === s;
    }
    var Xt = ".", Ut = ":";
    function Gn(y) {
      var D = /[=:]/g, z = {
        "=": "=0",
        ":": "=2"
      }, I = y.replace(D, function(ee) {
        return z[ee];
      });
      return "$" + I;
    }
    var pt = !1, nr = /\/+/g;
    function Ct(y) {
      return y.replace(nr, "$&/");
    }
    function Et(y, D) {
      return typeof y == "object" && y !== null && y.key != null ? (kt(y.key), Gn("" + y.key)) : D.toString(36);
    }
    function Jr(y, D, z, I, ee) {
      var _e = typeof y;
      (_e === "undefined" || _e === "boolean") && (y = null);
      var pe = !1;
      if (y === null)
        pe = !0;
      else
        switch (_e) {
          case "string":
          case "number":
            pe = !0;
            break;
          case "object":
            switch (y.$$typeof) {
              case s:
              case d:
                pe = !0;
            }
        }
      if (pe) {
        var Ae = y, Ve = ee(Ae), lt = I === "" ? Xt + Et(Ae, 0) : I;
        if (yt(Ve)) {
          var vt = "";
          lt != null && (vt = Ct(lt) + "/"), Jr(Ve, D, vt, "", function(ap) {
            return ap;
          });
        } else
          Ve != null && (ot(Ve) && (Ve.key && (!Ae || Ae.key !== Ve.key) && kt(Ve.key), Ve = Fe(
            Ve,
            // Keep both the (mapped) and old keys if they differ, just as
            // traverseAllChildren used to do for objects as children
            z + // $FlowFixMe Flow incorrectly thinks React.Portal doesn't have a key
            (Ve.key && (!Ae || Ae.key !== Ve.key) ? (
              // $FlowFixMe Flow incorrectly thinks existing element's key can be a number
              // eslint-disable-next-line react-internal/safe-string-coercion
              Ct("" + Ve.key) + "/"
            ) : "") + lt
          )), D.push(Ve));
        return 1;
      }
      var ht, Rt, _t = 0, tt = I === "" ? Xt : I + Ut;
      if (yt(y))
        for (var li = 0; li < y.length; li++)
          ht = y[li], Rt = tt + Et(ht, li), _t += Jr(ht, D, z, Rt, ee);
      else {
        var jo = F(y);
        if (typeof jo == "function") {
          var ru = y;
          jo === ru.entries && (pt || De("Using Maps as children is not supported. Use an array of keyed ReactElements instead."), pt = !0);
          for (var rp = jo.call(ru), Da, au = 0; !(Da = rp.next()).done; )
            ht = Da.value, Rt = tt + Et(ht, au++), _t += Jr(ht, D, z, Rt, ee);
        } else if (_e === "object") {
          var iu = String(y);
          throw new Error("Objects are not valid as a React child (found: " + (iu === "[object Object]" ? "object with keys {" + Object.keys(y).join(", ") + "}" : iu) + "). If you meant to render a collection of children, use an array instead.");
        }
      }
      return _t;
    }
    function Nr(y, D, z) {
      if (y == null)
        return y;
      var I = [], ee = 0;
      return Jr(y, I, "", "", function(_e) {
        return D.call(z, _e, ee++);
      }), I;
    }
    function Hi(y) {
      var D = 0;
      return Nr(y, function() {
        D++;
      }), D;
    }
    function Ao(y, D, z) {
      Nr(y, function() {
        D.apply(this, arguments);
      }, z);
    }
    function Bl(y) {
      return Nr(y, function(D) {
        return D;
      }) || [];
    }
    function $i(y) {
      if (!ot(y))
        throw new Error("React.Children.only expected to receive a single React element child.");
      return y;
    }
    function Ii(y) {
      var D = {
        $$typeof: S,
        // As a workaround to support multiple concurrent renderers, we categorize
        // some renderers as primary and others as secondary. We only expect
        // there to be two concurrent renderers at most: React Native (primary) and
        // Fabric (secondary); React DOM (primary) and React ART (secondary).
        // Secondary renderers store their context values on separate fields.
        _currentValue: y,
        _currentValue2: y,
        // Used to track how many concurrent renderers this context currently
        // supports within in a single renderer. Such as parallel server rendering.
        _threadCount: 0,
        // These are circular
        Provider: null,
        Consumer: null,
        // Add these to use same hidden class in VM as ServerContext
        _defaultValue: null,
        _globalName: null
      };
      D.Provider = {
        $$typeof: b,
        _context: D
      };
      var z = !1, I = !1, ee = !1;
      {
        var _e = {
          $$typeof: S,
          _context: D
        };
        Object.defineProperties(_e, {
          Provider: {
            get: function() {
              return I || (I = !0, de("Rendering <Context.Consumer.Provider> is not supported and will be removed in a future major release. Did you mean to render <Context.Provider> instead?")), D.Provider;
            },
            set: function(pe) {
              D.Provider = pe;
            }
          },
          _currentValue: {
            get: function() {
              return D._currentValue;
            },
            set: function(pe) {
              D._currentValue = pe;
            }
          },
          _currentValue2: {
            get: function() {
              return D._currentValue2;
            },
            set: function(pe) {
              D._currentValue2 = pe;
            }
          },
          _threadCount: {
            get: function() {
              return D._threadCount;
            },
            set: function(pe) {
              D._threadCount = pe;
            }
          },
          Consumer: {
            get: function() {
              return z || (z = !0, de("Rendering <Context.Consumer.Consumer> is not supported and will be removed in a future major release. Did you mean to render <Context.Consumer> instead?")), D.Consumer;
            }
          },
          displayName: {
            get: function() {
              return D.displayName;
            },
            set: function(pe) {
              ee || (De("Setting `displayName` on Context.Consumer has no effect. You should set it directly on the context with Context.displayName = '%s'.", pe), ee = !0);
            }
          }
        }), D.Consumer = _e;
      }
      return D._currentRenderer = null, D._currentRenderer2 = null, D;
    }
    var Ra = -1, Za = 0, wa = 1, Lr = 2;
    function kr(y) {
      if (y._status === Ra) {
        var D = y._result, z = D();
        if (z.then(function(_e) {
          if (y._status === Za || y._status === Ra) {
            var pe = y;
            pe._status = wa, pe._result = _e;
          }
        }, function(_e) {
          if (y._status === Za || y._status === Ra) {
            var pe = y;
            pe._status = Lr, pe._result = _e;
          }
        }), y._status === Ra) {
          var I = y;
          I._status = Za, I._result = z;
        }
      }
      if (y._status === wa) {
        var ee = y._result;
        return ee === void 0 && de(`lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))

Did you accidentally put curly braces around the import?`, ee), "default" in ee || de(`lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))`, ee), ee.default;
      } else
        throw y._result;
    }
    function ea(y) {
      var D = {
        // We use these fields to store the result.
        _status: Ra,
        _result: y
      }, z = {
        $$typeof: M,
        _payload: D,
        _init: kr
      };
      {
        var I, ee;
        Object.defineProperties(z, {
          defaultProps: {
            configurable: !0,
            get: function() {
              return I;
            },
            set: function(_e) {
              de("React.lazy(...): It is not supported to assign `defaultProps` to a lazy component import. Either specify them where the component is defined, or create a wrapping component around it."), I = _e, Object.defineProperty(z, "defaultProps", {
                enumerable: !0
              });
            }
          },
          propTypes: {
            configurable: !0,
            get: function() {
              return ee;
            },
            set: function(_e) {
              de("React.lazy(...): It is not supported to assign `propTypes` to a lazy component import. Either specify them where the component is defined, or create a wrapping component around it."), ee = _e, Object.defineProperty(z, "propTypes", {
                enumerable: !0
              });
            }
          }
        });
      }
      return z;
    }
    function Bi(y) {
      y != null && y.$$typeof === T ? de("forwardRef requires a render function but received a `memo` component. Instead of forwardRef(memo(...)), use memo(forwardRef(...)).") : typeof y != "function" ? de("forwardRef requires a render function but was given %s.", y === null ? "null" : typeof y) : y.length !== 0 && y.length !== 2 && de("forwardRef render functions accept exactly two parameters: props and ref. %s", y.length === 1 ? "Did you forget to use the ref parameter?" : "Any additional parameter will be undefined."), y != null && (y.defaultProps != null || y.propTypes != null) && de("forwardRef render functions do not support propTypes or defaultProps. Did you accidentally pass a React component?");
      var D = {
        $$typeof: R,
        render: y
      };
      {
        var z;
        Object.defineProperty(D, "displayName", {
          enumerable: !1,
          configurable: !0,
          get: function() {
            return z;
          },
          set: function(I) {
            z = I, !y.name && !y.displayName && (y.displayName = I);
          }
        });
      }
      return D;
    }
    var Ja;
    Ja = Symbol.for("react.module.reference");
    function _(y) {
      return !!(typeof y == "string" || typeof y == "function" || y === v || y === g || ge || y === c || y === E || y === x || fe || y === L || he || Ee || Xe || typeof y == "object" && y !== null && (y.$$typeof === M || y.$$typeof === T || y.$$typeof === b || y.$$typeof === S || y.$$typeof === R || // This needs to include all possible module reference object
      // types supported by any Flight configuration anywhere since
      // we don't know which Flight build this will end up being used
      // with.
      y.$$typeof === Ja || y.getModuleId !== void 0));
    }
    function q(y, D) {
      _(y) || de("memo: The first argument must be a component. Instead received: %s", y === null ? "null" : typeof y);
      var z = {
        $$typeof: T,
        type: y,
        compare: D === void 0 ? null : D
      };
      {
        var I;
        Object.defineProperty(z, "displayName", {
          enumerable: !1,
          configurable: !0,
          get: function() {
            return I;
          },
          set: function(ee) {
            I = ee, !y.name && !y.displayName && (y.displayName = ee);
          }
        });
      }
      return z;
    }
    function J() {
      var y = Y.current;
      return y === null && de(`Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:
1. You might have mismatching versions of React and the renderer (such as React DOM)
2. You might be breaking the Rules of Hooks
3. You might have more than one copy of React in the same app
See https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.`), y;
    }
    function we(y) {
      var D = J();
      if (y._context !== void 0) {
        var z = y._context;
        z.Consumer === y ? de("Calling useContext(Context.Consumer) is not supported, may cause bugs, and will be removed in a future major release. Did you mean to call useContext(Context) instead?") : z.Provider === y && de("Calling useContext(Context.Provider) is not supported. Did you mean to call useContext(Context) instead?");
      }
      return D.useContext(y);
    }
    function Be(y) {
      var D = J();
      return D.useState(y);
    }
    function Qe(y, D, z) {
      var I = J();
      return I.useReducer(y, D, z);
    }
    function xe(y) {
      var D = J();
      return D.useRef(y);
    }
    function ze(y, D) {
      var z = J();
      return z.useEffect(y, D);
    }
    function Kt(y, D) {
      var z = J();
      return z.useInsertionEffect(y, D);
    }
    function gt(y, D) {
      var z = J();
      return z.useLayoutEffect(y, D);
    }
    function xt(y, D) {
      var z = J();
      return z.useCallback(y, D);
    }
    function Dn(y, D) {
      var z = J();
      return z.useMemo(y, D);
    }
    function ta(y, D, z) {
      var I = J();
      return I.useImperativeHandle(y, D, z);
    }
    function Sr(y, D) {
      {
        var z = J();
        return z.useDebugValue(y, D);
      }
    }
    function on() {
      var y = J();
      return y.useTransition();
    }
    function rr(y) {
      var D = J();
      return D.useDeferredValue(y);
    }
    function He() {
      var y = J();
      return y.useId();
    }
    function xa(y, D, z) {
      var I = J();
      return I.useSyncExternalStore(y, D, z);
    }
    var ei = 0, Vl, Yl, Wl, Gl, Xl, Kl, ql;
    function ec() {
    }
    ec.__reactDisabledLog = !0;
    function ep() {
      {
        if (ei === 0) {
          Vl = console.log, Yl = console.info, Wl = console.warn, Gl = console.error, Xl = console.group, Kl = console.groupCollapsed, ql = console.groupEnd;
          var y = {
            configurable: !0,
            enumerable: !0,
            value: ec,
            writable: !0
          };
          Object.defineProperties(console, {
            info: y,
            log: y,
            warn: y,
            error: y,
            group: y,
            groupCollapsed: y,
            groupEnd: y
          });
        }
        ei++;
      }
    }
    function Ql() {
      {
        if (ei--, ei === 0) {
          var y = {
            configurable: !0,
            enumerable: !0,
            writable: !0
          };
          Object.defineProperties(console, {
            log: ft({}, y, {
              value: Vl
            }),
            info: ft({}, y, {
              value: Yl
            }),
            warn: ft({}, y, {
              value: Wl
            }),
            error: ft({}, y, {
              value: Gl
            }),
            group: ft({}, y, {
              value: Xl
            }),
            groupCollapsed: ft({}, y, {
              value: Kl
            }),
            groupEnd: ft({}, y, {
              value: ql
            })
          });
        }
        ei < 0 && de("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
      }
    }
    var Vi = Ie.ReactCurrentDispatcher, Cr;
    function ti(y, D, z) {
      {
        if (Cr === void 0)
          try {
            throw Error();
          } catch (ee) {
            var I = ee.stack.trim().match(/\n( *(at )?)/);
            Cr = I && I[1] || "";
          }
        return `
` + Cr + y;
      }
    }
    var ni = !1, No;
    {
      var Zl = typeof WeakMap == "function" ? WeakMap : Map;
      No = new Zl();
    }
    function tc(y, D) {
      if (!y || ni)
        return "";
      {
        var z = No.get(y);
        if (z !== void 0)
          return z;
      }
      var I;
      ni = !0;
      var ee = Error.prepareStackTrace;
      Error.prepareStackTrace = void 0;
      var _e;
      _e = Vi.current, Vi.current = null, ep();
      try {
        if (D) {
          var pe = function() {
            throw Error();
          };
          if (Object.defineProperty(pe.prototype, "props", {
            set: function() {
              throw Error();
            }
          }), typeof Reflect == "object" && Reflect.construct) {
            try {
              Reflect.construct(pe, []);
            } catch (tt) {
              I = tt;
            }
            Reflect.construct(y, [], pe);
          } else {
            try {
              pe.call();
            } catch (tt) {
              I = tt;
            }
            y.call(pe.prototype);
          }
        } else {
          try {
            throw Error();
          } catch (tt) {
            I = tt;
          }
          y();
        }
      } catch (tt) {
        if (tt && I && typeof tt.stack == "string") {
          for (var Ae = tt.stack.split(`
`), Ve = I.stack.split(`
`), lt = Ae.length - 1, vt = Ve.length - 1; lt >= 1 && vt >= 0 && Ae[lt] !== Ve[vt]; )
            vt--;
          for (; lt >= 1 && vt >= 0; lt--, vt--)
            if (Ae[lt] !== Ve[vt]) {
              if (lt !== 1 || vt !== 1)
                do
                  if (lt--, vt--, vt < 0 || Ae[lt] !== Ve[vt]) {
                    var ht = `
` + Ae[lt].replace(" at new ", " at ");
                    return y.displayName && ht.includes("<anonymous>") && (ht = ht.replace("<anonymous>", y.displayName)), typeof y == "function" && No.set(y, ht), ht;
                  }
                while (lt >= 1 && vt >= 0);
              break;
            }
        }
      } finally {
        ni = !1, Vi.current = _e, Ql(), Error.prepareStackTrace = ee;
      }
      var Rt = y ? y.displayName || y.name : "", _t = Rt ? ti(Rt) : "";
      return typeof y == "function" && No.set(y, _t), _t;
    }
    function Jl(y, D, z) {
      return tc(y, !1);
    }
    function tp(y) {
      var D = y.prototype;
      return !!(D && D.isReactComponent);
    }
    function ri(y, D, z) {
      if (y == null)
        return "";
      if (typeof y == "function")
        return tc(y, tp(y));
      if (typeof y == "string")
        return ti(y);
      switch (y) {
        case E:
          return ti("Suspense");
        case x:
          return ti("SuspenseList");
      }
      if (typeof y == "object")
        switch (y.$$typeof) {
          case R:
            return Jl(y.render);
          case T:
            return ri(y.type, D, z);
          case M: {
            var I = y, ee = I._payload, _e = I._init;
            try {
              return ri(_e(ee), D, z);
            } catch {
            }
          }
        }
      return "";
    }
    var nc = {}, eu = Ie.ReactDebugCurrentFrame;
    function Lo(y) {
      if (y) {
        var D = y._owner, z = ri(y.type, y._source, D ? D.type : null);
        eu.setExtraStackFrame(z);
      } else
        eu.setExtraStackFrame(null);
    }
    function rc(y, D, z, I, ee) {
      {
        var _e = Function.call.bind(Ar);
        for (var pe in y)
          if (_e(y, pe)) {
            var Ae = void 0;
            try {
              if (typeof y[pe] != "function") {
                var Ve = Error((I || "React class") + ": " + z + " type `" + pe + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof y[pe] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.");
                throw Ve.name = "Invariant Violation", Ve;
              }
              Ae = y[pe](D, pe, I, z, null, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
            } catch (lt) {
              Ae = lt;
            }
            Ae && !(Ae instanceof Error) && (Lo(ee), de("%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", I || "React class", z, pe, typeof Ae), Lo(null)), Ae instanceof Error && !(Ae.message in nc) && (nc[Ae.message] = !0, Lo(ee), de("Failed %s type: %s", z, Ae.message), Lo(null));
          }
      }
    }
    function Ze(y) {
      if (y) {
        var D = y._owner, z = ri(y.type, y._source, D ? D.type : null);
        me(z);
      } else
        me(null);
    }
    var tu;
    tu = !1;
    function nu() {
      if (ne.current) {
        var y = Wn(ne.current.type);
        if (y)
          return `

Check the render method of \`` + y + "`.";
      }
      return "";
    }
    function Pe(y) {
      if (y !== void 0) {
        var D = y.fileName.replace(/^.*[\\\/]/, ""), z = y.lineNumber;
        return `

Check your code at ` + D + ":" + z + ".";
      }
      return "";
    }
    function ac(y) {
      return y != null ? Pe(y.__source) : "";
    }
    var _n = {};
    function Yi(y) {
      var D = nu();
      if (!D) {
        var z = typeof y == "string" ? y : y.displayName || y.name;
        z && (D = `

Check the top-level render call using <` + z + ">.");
      }
      return D;
    }
    function ai(y, D) {
      if (!(!y._store || y._store.validated || y.key != null)) {
        y._store.validated = !0;
        var z = Yi(D);
        if (!_n[z]) {
          _n[z] = !0;
          var I = "";
          y && y._owner && y._owner !== ne.current && (I = " It was passed a child from " + Wn(y._owner.type) + "."), Ze(y), de('Each child in a list should have a unique "key" prop.%s%s See https://reactjs.org/link/warning-keys for more information.', z, I), Ze(null);
        }
      }
    }
    function ic(y, D) {
      if (typeof y == "object") {
        if (yt(y))
          for (var z = 0; z < y.length; z++) {
            var I = y[z];
            ot(I) && ai(I, D);
          }
        else if (ot(y))
          y._store && (y._store.validated = !0);
        else if (y) {
          var ee = F(y);
          if (typeof ee == "function" && ee !== y.entries)
            for (var _e = ee.call(y), pe; !(pe = _e.next()).done; )
              ot(pe.value) && ai(pe.value, D);
        }
      }
    }
    function ln(y) {
      {
        var D = y.type;
        if (D == null || typeof D == "string")
          return;
        var z;
        if (typeof D == "function")
          z = D.propTypes;
        else if (typeof D == "object" && (D.$$typeof === R || // Note: Memo only checks outer props here.
        // Inner props are checked in the reconciler.
        D.$$typeof === T))
          z = D.propTypes;
        else
          return;
        if (z) {
          var I = Wn(D);
          rc(z, y.props, "prop", I, y);
        } else if (D.PropTypes !== void 0 && !tu) {
          tu = !0;
          var ee = Wn(D);
          de("Component %s declared `PropTypes` instead of `propTypes`. Did you misspell the property assignment?", ee || "Unknown");
        }
        typeof D.getDefaultProps == "function" && !D.getDefaultProps.isReactClassApproved && de("getDefaultProps is only used on classic React.createClass definitions. Use a static property named `defaultProps` instead.");
      }
    }
    function Tt(y) {
      {
        for (var D = Object.keys(y.props), z = 0; z < D.length; z++) {
          var I = D[z];
          if (I !== "children" && I !== "key") {
            Ze(y), de("Invalid prop `%s` supplied to `React.Fragment`. React.Fragment can only have `key` and `children` props.", I), Ze(null);
            break;
          }
        }
        y.ref !== null && (Ze(y), de("Invalid attribute `ref` supplied to `React.Fragment`."), Ze(null));
      }
    }
    function oc(y, D, z) {
      var I = _(y);
      if (!I) {
        var ee = "";
        (y === void 0 || typeof y == "object" && y !== null && Object.keys(y).length === 0) && (ee += " You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports.");
        var _e = ac(D);
        _e ? ee += _e : ee += nu();
        var pe;
        y === null ? pe = "null" : yt(y) ? pe = "array" : y !== void 0 && y.$$typeof === s ? (pe = "<" + (Wn(y.type) || "Unknown") + " />", ee = " Did you accidentally export a JSX literal instead of a component?") : pe = typeof y, de("React.createElement: type is invalid -- expected a string (for built-in components) or a class/function (for composite components) but got: %s.%s", pe, ee);
      }
      var Ae = be.apply(this, arguments);
      if (Ae == null)
        return Ae;
      if (I)
        for (var Ve = 2; Ve < arguments.length; Ve++)
          ic(arguments[Ve], y);
      return y === v ? Tt(Ae) : ln(Ae), Ae;
    }
    var ar = !1;
    function Xn(y) {
      var D = oc.bind(null, y);
      return D.type = y, ar || (ar = !0, De("React.createFactory() is deprecated and will be removed in a future major release. Consider using JSX or use React.createElement() directly instead.")), Object.defineProperty(D, "type", {
        enumerable: !1,
        get: function() {
          return De("Factory.type is deprecated. Access the class directly before passing it to createFactory."), Object.defineProperty(this, "type", {
            value: y
          }), y;
        }
      }), D;
    }
    function na(y, D, z) {
      for (var I = it.apply(this, arguments), ee = 2; ee < arguments.length; ee++)
        ic(arguments[ee], I.type);
      return ln(I), I;
    }
    function np(y, D) {
      var z = X.transition;
      X.transition = {};
      var I = X.transition;
      X.transition._updatedFibers = /* @__PURE__ */ new Set();
      try {
        y();
      } finally {
        if (X.transition = z, z === null && I._updatedFibers) {
          var ee = I._updatedFibers.size;
          ee > 10 && De("Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table."), I._updatedFibers.clear();
        }
      }
    }
    var ko = !1, Wi = null;
    function lc(y) {
      if (Wi === null)
        try {
          var D = ("require" + Math.random()).slice(0, 7), z = a && a[D];
          Wi = z.call(a, "timers").setImmediate;
        } catch {
          Wi = function(ee) {
            ko === !1 && (ko = !0, typeof MessageChannel > "u" && de("This browser does not have a MessageChannel implementation, so enqueuing tasks via await act(async () => ...) will fail. Please file an issue at https://github.com/facebook/react/issues if you encounter this warning."));
            var _e = new MessageChannel();
            _e.port1.onmessage = ee, _e.port2.postMessage(void 0);
          };
        }
      return Wi(y);
    }
    var ii = 0, uc = !1;
    function sc(y) {
      {
        var D = ii;
        ii++, W.current === null && (W.current = []);
        var z = W.isBatchingLegacy, I;
        try {
          if (W.isBatchingLegacy = !0, I = y(), !z && W.didScheduleLegacyUpdate) {
            var ee = W.current;
            ee !== null && (W.didScheduleLegacyUpdate = !1, Uo(ee));
          }
        } catch (Rt) {
          throw Ta(D), Rt;
        } finally {
          W.isBatchingLegacy = z;
        }
        if (I !== null && typeof I == "object" && typeof I.then == "function") {
          var _e = I, pe = !1, Ae = {
            then: function(Rt, _t) {
              pe = !0, _e.then(function(tt) {
                Ta(D), ii === 0 ? Po(tt, Rt, _t) : Rt(tt);
              }, function(tt) {
                Ta(D), _t(tt);
              });
            }
          };
          return !uc && typeof Promise < "u" && Promise.resolve().then(function() {
          }).then(function() {
            pe || (uc = !0, de("You called act(async () => ...) without await. This could lead to unexpected testing behaviour, interleaving multiple act calls and mixing their scopes. You should - await act(async () => ...);"));
          }), Ae;
        } else {
          var Ve = I;
          if (Ta(D), ii === 0) {
            var lt = W.current;
            lt !== null && (Uo(lt), W.current = null);
            var vt = {
              then: function(Rt, _t) {
                W.current === null ? (W.current = [], Po(Ve, Rt, _t)) : Rt(Ve);
              }
            };
            return vt;
          } else {
            var ht = {
              then: function(Rt, _t) {
                Rt(Ve);
              }
            };
            return ht;
          }
        }
      }
    }
    function Ta(y) {
      y !== ii - 1 && de("You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. "), ii = y;
    }
    function Po(y, D, z) {
      {
        var I = W.current;
        if (I !== null)
          try {
            Uo(I), lc(function() {
              I.length === 0 ? (W.current = null, D(y)) : Po(y, D, z);
            });
          } catch (ee) {
            z(ee);
          }
        else
          D(y);
      }
    }
    var oi = !1;
    function Uo(y) {
      if (!oi) {
        oi = !0;
        var D = 0;
        try {
          for (; D < y.length; D++) {
            var z = y[D];
            do
              z = z(!0);
            while (z !== null);
          }
          y.length = 0;
        } catch (I) {
          throw y = y.slice(D + 1), I;
        } finally {
          oi = !1;
        }
      }
    }
    var cc = oc, fc = na, dc = Xn, pc = {
      map: Nr,
      forEach: Ao,
      count: Hi,
      toArray: Bl,
      only: $i
    };
    o.Children = pc, o.Component = Yt, o.Fragment = v, o.Profiler = g, o.PureComponent = at, o.StrictMode = c, o.Suspense = E, o.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Ie, o.act = sc, o.cloneElement = fc, o.createContext = Ii, o.createElement = cc, o.createFactory = dc, o.createRef = wn, o.forwardRef = Bi, o.isValidElement = ot, o.lazy = ea, o.memo = q, o.startTransition = np, o.unstable_act = sc, o.useCallback = xt, o.useContext = we, o.useDebugValue = Sr, o.useDeferredValue = rr, o.useEffect = ze, o.useId = He, o.useImperativeHandle = ta, o.useInsertionEffect = Kt, o.useLayoutEffect = gt, o.useMemo = Dn, o.useReducer = Qe, o.useRef = xe, o.useState = Be, o.useSyncExternalStore = xa, o.useTransition = on, o.version = u, typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(new Error());
  })();
})(xd, xd.exports);
var KL = xd.exports;
ZR.exports = KL;
var h = ZR.exports;
const Vt = /* @__PURE__ */ Ay(h), qL = /* @__PURE__ */ XL({
  __proto__: null,
  default: Vt
}, [h]);
/**
 * @license React
 * react-jsx-runtime.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
(function() {
  var a = h, o = Symbol.for("react.element"), u = Symbol.for("react.portal"), s = Symbol.for("react.fragment"), d = Symbol.for("react.strict_mode"), v = Symbol.for("react.profiler"), c = Symbol.for("react.provider"), g = Symbol.for("react.context"), b = Symbol.for("react.forward_ref"), S = Symbol.for("react.suspense"), R = Symbol.for("react.suspense_list"), E = Symbol.for("react.memo"), x = Symbol.for("react.lazy"), T = Symbol.for("react.offscreen"), M = Symbol.iterator, L = "@@iterator";
  function $(_) {
    if (_ === null || typeof _ != "object")
      return null;
    var q = M && _[M] || _[L];
    return typeof q == "function" ? q : null;
  }
  var U = a.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
  function F(_) {
    {
      for (var q = arguments.length, J = new Array(q > 1 ? q - 1 : 0), we = 1; we < q; we++)
        J[we - 1] = arguments[we];
      Y("error", _, J);
    }
  }
  function Y(_, q, J) {
    {
      var we = U.ReactDebugCurrentFrame, Be = we.getStackAddendum();
      Be !== "" && (q += "%s", J = J.concat([Be]));
      var Qe = J.map(function(xe) {
        return String(xe);
      });
      Qe.unshift("Warning: " + q), Function.prototype.apply.call(console[_], console, Qe);
    }
  }
  var X = !1, W = !1, ne = !1, Z = !1, ve = !1, me;
  me = Symbol.for("react.module.reference");
  function he(_) {
    return !!(typeof _ == "string" || typeof _ == "function" || _ === s || _ === v || ve || _ === d || _ === S || _ === R || Z || _ === T || X || W || ne || typeof _ == "object" && _ !== null && (_.$$typeof === x || _.$$typeof === E || _.$$typeof === c || _.$$typeof === g || _.$$typeof === b || // This needs to include all possible module reference object
    // types supported by any Flight configuration anywhere since
    // we don't know which Flight build this will end up being used
    // with.
    _.$$typeof === me || _.getModuleId !== void 0));
  }
  function Ee(_, q, J) {
    var we = _.displayName;
    if (we)
      return we;
    var Be = q.displayName || q.name || "";
    return Be !== "" ? J + "(" + Be + ")" : J;
  }
  function Xe(_) {
    return _.displayName || "Context";
  }
  function fe(_) {
    if (_ == null)
      return null;
    if (typeof _.tag == "number" && F("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), typeof _ == "function")
      return _.displayName || _.name || null;
    if (typeof _ == "string")
      return _;
    switch (_) {
      case s:
        return "Fragment";
      case u:
        return "Portal";
      case v:
        return "Profiler";
      case d:
        return "StrictMode";
      case S:
        return "Suspense";
      case R:
        return "SuspenseList";
    }
    if (typeof _ == "object")
      switch (_.$$typeof) {
        case g:
          var q = _;
          return Xe(q) + ".Consumer";
        case c:
          var J = _;
          return Xe(J._context) + ".Provider";
        case b:
          return Ee(_, _.render, "ForwardRef");
        case E:
          var we = _.displayName || null;
          return we !== null ? we : fe(_.type) || "Memo";
        case x: {
          var Be = _, Qe = Be._payload, xe = Be._init;
          try {
            return fe(xe(Qe));
          } catch {
            return null;
          }
        }
      }
    return null;
  }
  var ge = Object.assign, Ie = 0, De, de, Se, se, Ke, dt, ft;
  function Ft() {
  }
  Ft.__reactDisabledLog = !0;
  function Yt() {
    {
      if (Ie === 0) {
        De = console.log, de = console.info, Se = console.warn, se = console.error, Ke = console.group, dt = console.groupCollapsed, ft = console.groupEnd;
        var _ = {
          configurable: !0,
          enumerable: !0,
          value: Ft,
          writable: !0
        };
        Object.defineProperties(console, {
          info: _,
          log: _,
          warn: _,
          error: _,
          group: _,
          groupCollapsed: _,
          groupEnd: _
        });
      }
      Ie++;
    }
  }
  function Pn() {
    {
      if (Ie--, Ie === 0) {
        var _ = {
          configurable: !0,
          enumerable: !0,
          writable: !0
        };
        Object.defineProperties(console, {
          log: ge({}, _, {
            value: De
          }),
          info: ge({}, _, {
            value: de
          }),
          warn: ge({}, _, {
            value: Se
          }),
          error: ge({}, _, {
            value: se
          }),
          group: ge({}, _, {
            value: Ke
          }),
          groupCollapsed: ge({}, _, {
            value: dt
          }),
          groupEnd: ge({}, _, {
            value: ft
          })
        });
      }
      Ie < 0 && F("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
    }
  }
  var Wt = U.ReactCurrentDispatcher, Nt;
  function an(_, q, J) {
    {
      if (Nt === void 0)
        try {
          throw Error();
        } catch (Be) {
          var we = Be.stack.trim().match(/\n( *(at )?)/);
          Nt = we && we[1] || "";
        }
      return `
` + Nt + _;
    }
  }
  var at = !1, zt;
  {
    var wn = typeof WeakMap == "function" ? WeakMap : Map;
    zt = new wn();
  }
  function xn(_, q) {
    if (!_ || at)
      return "";
    {
      var J = zt.get(_);
      if (J !== void 0)
        return J;
    }
    var we;
    at = !0;
    var Be = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    var Qe;
    Qe = Wt.current, Wt.current = null, Yt();
    try {
      if (q) {
        var xe = function() {
          throw Error();
        };
        if (Object.defineProperty(xe.prototype, "props", {
          set: function() {
            throw Error();
          }
        }), typeof Reflect == "object" && Reflect.construct) {
          try {
            Reflect.construct(xe, []);
          } catch (on) {
            we = on;
          }
          Reflect.construct(_, [], xe);
        } else {
          try {
            xe.call();
          } catch (on) {
            we = on;
          }
          _.call(xe.prototype);
        }
      } else {
        try {
          throw Error();
        } catch (on) {
          we = on;
        }
        _();
      }
    } catch (on) {
      if (on && we && typeof on.stack == "string") {
        for (var ze = on.stack.split(`
`), Kt = we.stack.split(`
`), gt = ze.length - 1, xt = Kt.length - 1; gt >= 1 && xt >= 0 && ze[gt] !== Kt[xt]; )
          xt--;
        for (; gt >= 1 && xt >= 0; gt--, xt--)
          if (ze[gt] !== Kt[xt]) {
            if (gt !== 1 || xt !== 1)
              do
                if (gt--, xt--, xt < 0 || ze[gt] !== Kt[xt]) {
                  var Dn = `
` + ze[gt].replace(" at new ", " at ");
                  return _.displayName && Dn.includes("<anonymous>") && (Dn = Dn.replace("<anonymous>", _.displayName)), typeof _ == "function" && zt.set(_, Dn), Dn;
                }
              while (gt >= 1 && xt >= 0);
            break;
          }
      }
    } finally {
      at = !1, Wt.current = Qe, Pn(), Error.prepareStackTrace = Be;
    }
    var ta = _ ? _.displayName || _.name : "", Sr = ta ? an(ta) : "";
    return typeof _ == "function" && zt.set(_, Sr), Sr;
  }
  function yt(_, q, J) {
    return xn(_, !1);
  }
  function Gt(_) {
    var q = _.prototype;
    return !!(q && q.isReactComponent);
  }
  function Ht(_, q, J) {
    if (_ == null)
      return "";
    if (typeof _ == "function")
      return xn(_, Gt(_));
    if (typeof _ == "string")
      return an(_);
    switch (_) {
      case S:
        return an("Suspense");
      case R:
        return an("SuspenseList");
    }
    if (typeof _ == "object")
      switch (_.$$typeof) {
        case b:
          return yt(_.render);
        case E:
          return Ht(_.type, q, J);
        case x: {
          var we = _, Be = we._payload, Qe = we._init;
          try {
            return Ht(Qe(Be), q, J);
          } catch {
          }
        }
      }
    return "";
  }
  var Lt = Object.prototype.hasOwnProperty, kt = {}, Un = U.ReactDebugCurrentFrame;
  function pn(_) {
    if (_) {
      var q = _._owner, J = Ht(_.type, _._source, q ? q.type : null);
      Un.setExtraStackFrame(J);
    } else
      Un.setExtraStackFrame(null);
  }
  function Wn(_, q, J, we, Be) {
    {
      var Qe = Function.call.bind(Lt);
      for (var xe in _)
        if (Qe(_, xe)) {
          var ze = void 0;
          try {
            if (typeof _[xe] != "function") {
              var Kt = Error((we || "React class") + ": " + J + " type `" + xe + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof _[xe] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.");
              throw Kt.name = "Invariant Violation", Kt;
            }
            ze = _[xe](q, xe, we, J, null, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
          } catch (gt) {
            ze = gt;
          }
          ze && !(ze instanceof Error) && (pn(Be), F("%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", we || "React class", J, xe, typeof ze), pn(null)), ze instanceof Error && !(ze.message in kt) && (kt[ze.message] = !0, pn(Be), F("Failed %s type: %s", J, ze.message), pn(null));
        }
    }
  }
  var Ar = Array.isArray;
  function yr(_) {
    return Ar(_);
  }
  function jn(_) {
    {
      var q = typeof Symbol == "function" && Symbol.toStringTag, J = q && _[Symbol.toStringTag] || _.constructor.name || "Object";
      return J;
    }
  }
  function gr(_) {
    try {
      return Tn(_), !1;
    } catch {
      return !0;
    }
  }
  function Tn(_) {
    return "" + _;
  }
  function tr(_) {
    if (gr(_))
      return F("The provided key is an unsupported type %s. This value must be coerced to a string before before using it here.", jn(_)), Tn(_);
  }
  var Pt = U.ReactCurrentOwner, br = {
    key: !0,
    ref: !0,
    __self: !0,
    __source: !0
  }, Ca, Ea, re;
  re = {};
  function be(_) {
    if (Lt.call(_, "ref")) {
      var q = Object.getOwnPropertyDescriptor(_, "ref").get;
      if (q && q.isReactWarning)
        return !1;
    }
    return _.ref !== void 0;
  }
  function Fe(_) {
    if (Lt.call(_, "key")) {
      var q = Object.getOwnPropertyDescriptor(_, "key").get;
      if (q && q.isReactWarning)
        return !1;
    }
    return _.key !== void 0;
  }
  function it(_, q) {
    if (typeof _.ref == "string" && Pt.current && q && Pt.current.stateNode !== q) {
      var J = fe(Pt.current.type);
      re[J] || (F('Component "%s" contains the string ref "%s". Support for string refs will be removed in a future major release. This case cannot be automatically converted to an arrow function. We ask you to manually fix this case by using useRef() or createRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref', fe(Pt.current.type), _.ref), re[J] = !0);
    }
  }
  function ot(_, q) {
    {
      var J = function() {
        Ca || (Ca = !0, F("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", q));
      };
      J.isReactWarning = !0, Object.defineProperty(_, "key", {
        get: J,
        configurable: !0
      });
    }
  }
  function Xt(_, q) {
    {
      var J = function() {
        Ea || (Ea = !0, F("%s: `ref` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", q));
      };
      J.isReactWarning = !0, Object.defineProperty(_, "ref", {
        get: J,
        configurable: !0
      });
    }
  }
  var Ut = function(_, q, J, we, Be, Qe, xe) {
    var ze = {
      // This tag allows us to uniquely identify this as a React Element
      $$typeof: o,
      // Built-in properties that belong on the element
      type: _,
      key: q,
      ref: J,
      props: xe,
      // Record the component responsible for creating this element.
      _owner: Qe
    };
    return ze._store = {}, Object.defineProperty(ze._store, "validated", {
      configurable: !1,
      enumerable: !1,
      writable: !0,
      value: !1
    }), Object.defineProperty(ze, "_self", {
      configurable: !1,
      enumerable: !1,
      writable: !1,
      value: we
    }), Object.defineProperty(ze, "_source", {
      configurable: !1,
      enumerable: !1,
      writable: !1,
      value: Be
    }), Object.freeze && (Object.freeze(ze.props), Object.freeze(ze)), ze;
  };
  function Gn(_, q, J, we, Be) {
    {
      var Qe, xe = {}, ze = null, Kt = null;
      J !== void 0 && (tr(J), ze = "" + J), Fe(q) && (tr(q.key), ze = "" + q.key), be(q) && (Kt = q.ref, it(q, Be));
      for (Qe in q)
        Lt.call(q, Qe) && !br.hasOwnProperty(Qe) && (xe[Qe] = q[Qe]);
      if (_ && _.defaultProps) {
        var gt = _.defaultProps;
        for (Qe in gt)
          xe[Qe] === void 0 && (xe[Qe] = gt[Qe]);
      }
      if (ze || Kt) {
        var xt = typeof _ == "function" ? _.displayName || _.name || "Unknown" : _;
        ze && ot(xe, xt), Kt && Xt(xe, xt);
      }
      return Ut(_, ze, Kt, Be, we, Pt.current, xe);
    }
  }
  var pt = U.ReactCurrentOwner, nr = U.ReactDebugCurrentFrame;
  function Ct(_) {
    if (_) {
      var q = _._owner, J = Ht(_.type, _._source, q ? q.type : null);
      nr.setExtraStackFrame(J);
    } else
      nr.setExtraStackFrame(null);
  }
  var Et;
  Et = !1;
  function Jr(_) {
    return typeof _ == "object" && _ !== null && _.$$typeof === o;
  }
  function Nr() {
    {
      if (pt.current) {
        var _ = fe(pt.current.type);
        if (_)
          return `

Check the render method of \`` + _ + "`.";
      }
      return "";
    }
  }
  function Hi(_) {
    return "";
  }
  var Ao = {};
  function Bl(_) {
    {
      var q = Nr();
      if (!q) {
        var J = typeof _ == "string" ? _ : _.displayName || _.name;
        J && (q = `

Check the top-level render call using <` + J + ">.");
      }
      return q;
    }
  }
  function $i(_, q) {
    {
      if (!_._store || _._store.validated || _.key != null)
        return;
      _._store.validated = !0;
      var J = Bl(q);
      if (Ao[J])
        return;
      Ao[J] = !0;
      var we = "";
      _ && _._owner && _._owner !== pt.current && (we = " It was passed a child from " + fe(_._owner.type) + "."), Ct(_), F('Each child in a list should have a unique "key" prop.%s%s See https://reactjs.org/link/warning-keys for more information.', J, we), Ct(null);
    }
  }
  function Ii(_, q) {
    {
      if (typeof _ != "object")
        return;
      if (yr(_))
        for (var J = 0; J < _.length; J++) {
          var we = _[J];
          Jr(we) && $i(we, q);
        }
      else if (Jr(_))
        _._store && (_._store.validated = !0);
      else if (_) {
        var Be = $(_);
        if (typeof Be == "function" && Be !== _.entries)
          for (var Qe = Be.call(_), xe; !(xe = Qe.next()).done; )
            Jr(xe.value) && $i(xe.value, q);
      }
    }
  }
  function Ra(_) {
    {
      var q = _.type;
      if (q == null || typeof q == "string")
        return;
      var J;
      if (typeof q == "function")
        J = q.propTypes;
      else if (typeof q == "object" && (q.$$typeof === b || // Note: Memo only checks outer props here.
      // Inner props are checked in the reconciler.
      q.$$typeof === E))
        J = q.propTypes;
      else
        return;
      if (J) {
        var we = fe(q);
        Wn(J, _.props, "prop", we, _);
      } else if (q.PropTypes !== void 0 && !Et) {
        Et = !0;
        var Be = fe(q);
        F("Component %s declared `PropTypes` instead of `propTypes`. Did you misspell the property assignment?", Be || "Unknown");
      }
      typeof q.getDefaultProps == "function" && !q.getDefaultProps.isReactClassApproved && F("getDefaultProps is only used on classic React.createClass definitions. Use a static property named `defaultProps` instead.");
    }
  }
  function Za(_) {
    {
      for (var q = Object.keys(_.props), J = 0; J < q.length; J++) {
        var we = q[J];
        if (we !== "children" && we !== "key") {
          Ct(_), F("Invalid prop `%s` supplied to `React.Fragment`. React.Fragment can only have `key` and `children` props.", we), Ct(null);
          break;
        }
      }
      _.ref !== null && (Ct(_), F("Invalid attribute `ref` supplied to `React.Fragment`."), Ct(null));
    }
  }
  var wa = {};
  function Lr(_, q, J, we, Be, Qe) {
    {
      var xe = he(_);
      if (!xe) {
        var ze = "";
        (_ === void 0 || typeof _ == "object" && _ !== null && Object.keys(_).length === 0) && (ze += " You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports.");
        var Kt = Hi();
        Kt ? ze += Kt : ze += Nr();
        var gt;
        _ === null ? gt = "null" : yr(_) ? gt = "array" : _ !== void 0 && _.$$typeof === o ? (gt = "<" + (fe(_.type) || "Unknown") + " />", ze = " Did you accidentally export a JSX literal instead of a component?") : gt = typeof _, F("React.jsx: type is invalid -- expected a string (for built-in components) or a class/function (for composite components) but got: %s.%s", gt, ze);
      }
      var xt = Gn(_, q, J, Be, Qe);
      if (xt == null)
        return xt;
      if (xe) {
        var Dn = q.children;
        if (Dn !== void 0)
          if (we)
            if (yr(Dn)) {
              for (var ta = 0; ta < Dn.length; ta++)
                Ii(Dn[ta], _);
              Object.freeze && Object.freeze(Dn);
            } else
              F("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
          else
            Ii(Dn, _);
      }
      if (Lt.call(q, "key")) {
        var Sr = fe(_), on = Object.keys(q).filter(function(xa) {
          return xa !== "key";
        }), rr = on.length > 0 ? "{key: someKey, " + on.join(": ..., ") + ": ...}" : "{key: someKey}";
        if (!wa[Sr + rr]) {
          var He = on.length > 0 ? "{" + on.join(": ..., ") + ": ...}" : "{}";
          F(`A props object containing a "key" prop is being spread into JSX:
  let props = %s;
  <%s {...props} />
React keys must be passed directly to JSX without using spread:
  let props = %s;
  <%s key={someKey} {...props} />`, rr, Sr, He, Sr), wa[Sr + rr] = !0;
        }
      }
      return _ === s ? Za(xt) : Ra(xt), xt;
    }
  }
  function kr(_, q, J) {
    return Lr(_, q, J, !0);
  }
  function ea(_, q, J) {
    return Lr(_, q, J, !1);
  }
  var Bi = ea, Ja = kr;
  Sd.Fragment = s, Sd.jsx = Bi, Sd.jsxs = Ja;
})();
QR.exports = Sd;
var O = QR.exports, JR = { exports: {} }, pr = {}, e0 = { exports: {} }, t0 = {};
(function(a) {
  /**
   * @license React
   * scheduler.development.js
   *
   * Copyright (c) Facebook, Inc. and its affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  (function() {
    typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(new Error());
    var o = !1, u = !1, s = 5;
    function d(re, be) {
      var Fe = re.length;
      re.push(be), g(re, be, Fe);
    }
    function v(re) {
      return re.length === 0 ? null : re[0];
    }
    function c(re) {
      if (re.length === 0)
        return null;
      var be = re[0], Fe = re.pop();
      return Fe !== be && (re[0] = Fe, b(re, Fe, 0)), be;
    }
    function g(re, be, Fe) {
      for (var it = Fe; it > 0; ) {
        var ot = it - 1 >>> 1, Xt = re[ot];
        if (S(Xt, be) > 0)
          re[ot] = be, re[it] = Xt, it = ot;
        else
          return;
      }
    }
    function b(re, be, Fe) {
      for (var it = Fe, ot = re.length, Xt = ot >>> 1; it < Xt; ) {
        var Ut = (it + 1) * 2 - 1, Gn = re[Ut], pt = Ut + 1, nr = re[pt];
        if (S(Gn, be) < 0)
          pt < ot && S(nr, Gn) < 0 ? (re[it] = nr, re[pt] = be, it = pt) : (re[it] = Gn, re[Ut] = be, it = Ut);
        else if (pt < ot && S(nr, be) < 0)
          re[it] = nr, re[pt] = be, it = pt;
        else
          return;
      }
    }
    function S(re, be) {
      var Fe = re.sortIndex - be.sortIndex;
      return Fe !== 0 ? Fe : re.id - be.id;
    }
    var R = 1, E = 2, x = 3, T = 4, M = 5;
    function L(re, be) {
    }
    var $ = typeof performance == "object" && typeof performance.now == "function";
    if ($) {
      var U = performance;
      a.unstable_now = function() {
        return U.now();
      };
    } else {
      var F = Date, Y = F.now();
      a.unstable_now = function() {
        return F.now() - Y;
      };
    }
    var X = 1073741823, W = -1, ne = 250, Z = 5e3, ve = 1e4, me = X, he = [], Ee = [], Xe = 1, fe = null, ge = x, Ie = !1, De = !1, de = !1, Se = typeof setTimeout == "function" ? setTimeout : null, se = typeof clearTimeout == "function" ? clearTimeout : null, Ke = typeof setImmediate < "u" ? setImmediate : null;
    typeof navigator < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);
    function dt(re) {
      for (var be = v(Ee); be !== null; ) {
        if (be.callback === null)
          c(Ee);
        else if (be.startTime <= re)
          c(Ee), be.sortIndex = be.expirationTime, d(he, be);
        else
          return;
        be = v(Ee);
      }
    }
    function ft(re) {
      if (de = !1, dt(re), !De)
        if (v(he) !== null)
          De = !0, tr(Ft);
        else {
          var be = v(Ee);
          be !== null && Pt(ft, be.startTime - re);
        }
    }
    function Ft(re, be) {
      De = !1, de && (de = !1, br()), Ie = !0;
      var Fe = ge;
      try {
        var it;
        if (!u)
          return Yt(re, be);
      } finally {
        fe = null, ge = Fe, Ie = !1;
      }
    }
    function Yt(re, be) {
      var Fe = be;
      for (dt(Fe), fe = v(he); fe !== null && !o && !(fe.expirationTime > Fe && (!re || pn())); ) {
        var it = fe.callback;
        if (typeof it == "function") {
          fe.callback = null, ge = fe.priorityLevel;
          var ot = fe.expirationTime <= Fe, Xt = it(ot);
          Fe = a.unstable_now(), typeof Xt == "function" ? fe.callback = Xt : fe === v(he) && c(he), dt(Fe);
        } else
          c(he);
        fe = v(he);
      }
      if (fe !== null)
        return !0;
      var Ut = v(Ee);
      return Ut !== null && Pt(ft, Ut.startTime - Fe), !1;
    }
    function Pn(re, be) {
      switch (re) {
        case R:
        case E:
        case x:
        case T:
        case M:
          break;
        default:
          re = x;
      }
      var Fe = ge;
      ge = re;
      try {
        return be();
      } finally {
        ge = Fe;
      }
    }
    function Wt(re) {
      var be;
      switch (ge) {
        case R:
        case E:
        case x:
          be = x;
          break;
        default:
          be = ge;
          break;
      }
      var Fe = ge;
      ge = be;
      try {
        return re();
      } finally {
        ge = Fe;
      }
    }
    function Nt(re) {
      var be = ge;
      return function() {
        var Fe = ge;
        ge = be;
        try {
          return re.apply(this, arguments);
        } finally {
          ge = Fe;
        }
      };
    }
    function an(re, be, Fe) {
      var it = a.unstable_now(), ot;
      if (typeof Fe == "object" && Fe !== null) {
        var Xt = Fe.delay;
        typeof Xt == "number" && Xt > 0 ? ot = it + Xt : ot = it;
      } else
        ot = it;
      var Ut;
      switch (re) {
        case R:
          Ut = W;
          break;
        case E:
          Ut = ne;
          break;
        case M:
          Ut = me;
          break;
        case T:
          Ut = ve;
          break;
        case x:
        default:
          Ut = Z;
          break;
      }
      var Gn = ot + Ut, pt = {
        id: Xe++,
        callback: be,
        priorityLevel: re,
        startTime: ot,
        expirationTime: Gn,
        sortIndex: -1
      };
      return ot > it ? (pt.sortIndex = ot, d(Ee, pt), v(he) === null && pt === v(Ee) && (de ? br() : de = !0, Pt(ft, ot - it))) : (pt.sortIndex = Gn, d(he, pt), !De && !Ie && (De = !0, tr(Ft))), pt;
    }
    function at() {
    }
    function zt() {
      !De && !Ie && (De = !0, tr(Ft));
    }
    function wn() {
      return v(he);
    }
    function xn(re) {
      re.callback = null;
    }
    function yt() {
      return ge;
    }
    var Gt = !1, Ht = null, Lt = -1, kt = s, Un = -1;
    function pn() {
      var re = a.unstable_now() - Un;
      return !(re < kt);
    }
    function Wn() {
    }
    function Ar(re) {
      if (re < 0 || re > 125) {
        console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported");
        return;
      }
      re > 0 ? kt = Math.floor(1e3 / re) : kt = s;
    }
    var yr = function() {
      if (Ht !== null) {
        var re = a.unstable_now();
        Un = re;
        var be = !0, Fe = !0;
        try {
          Fe = Ht(be, re);
        } finally {
          Fe ? jn() : (Gt = !1, Ht = null);
        }
      } else
        Gt = !1;
    }, jn;
    if (typeof Ke == "function")
      jn = function() {
        Ke(yr);
      };
    else if (typeof MessageChannel < "u") {
      var gr = new MessageChannel(), Tn = gr.port2;
      gr.port1.onmessage = yr, jn = function() {
        Tn.postMessage(null);
      };
    } else
      jn = function() {
        Se(yr, 0);
      };
    function tr(re) {
      Ht = re, Gt || (Gt = !0, jn());
    }
    function Pt(re, be) {
      Lt = Se(function() {
        re(a.unstable_now());
      }, be);
    }
    function br() {
      se(Lt), Lt = -1;
    }
    var Ca = Wn, Ea = null;
    a.unstable_IdlePriority = M, a.unstable_ImmediatePriority = R, a.unstable_LowPriority = T, a.unstable_NormalPriority = x, a.unstable_Profiling = Ea, a.unstable_UserBlockingPriority = E, a.unstable_cancelCallback = xn, a.unstable_continueExecution = zt, a.unstable_forceFrameRate = Ar, a.unstable_getCurrentPriorityLevel = yt, a.unstable_getFirstCallbackNode = wn, a.unstable_next = Wt, a.unstable_pauseExecution = at, a.unstable_requestPaint = Ca, a.unstable_runWithPriority = Pn, a.unstable_scheduleCallback = an, a.unstable_shouldYield = pn, a.unstable_wrapCallback = Nt, typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(new Error());
  })();
})(t0);
e0.exports = t0;
var QL = e0.exports;
/**
 * @license React
 * react-dom.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
(function() {
  typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(new Error());
  var a = h, o = QL, u = a.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED, s = !1;
  function d(e) {
    s = e;
  }
  function v(e) {
    if (!s) {
      for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++)
        n[r - 1] = arguments[r];
      g("warn", e, n);
    }
  }
  function c(e) {
    if (!s) {
      for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++)
        n[r - 1] = arguments[r];
      g("error", e, n);
    }
  }
  function g(e, t, n) {
    {
      var r = u.ReactDebugCurrentFrame, i = r.getStackAddendum();
      i !== "" && (t += "%s", n = n.concat([i]));
      var l = n.map(function(f) {
        return String(f);
      });
      l.unshift("Warning: " + t), Function.prototype.apply.call(console[e], console, l);
    }
  }
  var b = 0, S = 1, R = 2, E = 3, x = 4, T = 5, M = 6, L = 7, $ = 8, U = 9, F = 10, Y = 11, X = 12, W = 13, ne = 14, Z = 15, ve = 16, me = 17, he = 18, Ee = 19, Xe = 21, fe = 22, ge = 23, Ie = 24, De = 25, de = !0, Se = !1, se = !1, Ke = !1, dt = !1, ft = !0, Ft = !1, Yt = !0, Pn = !0, Wt = !0, Nt = !0, an = /* @__PURE__ */ new Set(), at = {}, zt = {};
  function wn(e, t) {
    xn(e, t), xn(e + "Capture", t);
  }
  function xn(e, t) {
    at[e] && c("EventRegistry: More than one plugin attempted to publish the same registration name, `%s`.", e), at[e] = t;
    {
      var n = e.toLowerCase();
      zt[n] = e, e === "onDoubleClick" && (zt.ondblclick = e);
    }
    for (var r = 0; r < t.length; r++)
      an.add(t[r]);
  }
  var yt = typeof window < "u" && typeof window.document < "u" && typeof window.document.createElement < "u", Gt = Object.prototype.hasOwnProperty;
  function Ht(e) {
    {
      var t = typeof Symbol == "function" && Symbol.toStringTag, n = t && e[Symbol.toStringTag] || e.constructor.name || "Object";
      return n;
    }
  }
  function Lt(e) {
    try {
      return kt(e), !1;
    } catch {
      return !0;
    }
  }
  function kt(e) {
    return "" + e;
  }
  function Un(e, t) {
    if (Lt(e))
      return c("The provided `%s` attribute is an unsupported type %s. This value must be coerced to a string before before using it here.", t, Ht(e)), kt(e);
  }
  function pn(e) {
    if (Lt(e))
      return c("The provided key is an unsupported type %s. This value must be coerced to a string before before using it here.", Ht(e)), kt(e);
  }
  function Wn(e, t) {
    if (Lt(e))
      return c("The provided `%s` prop is an unsupported type %s. This value must be coerced to a string before before using it here.", t, Ht(e)), kt(e);
  }
  function Ar(e, t) {
    if (Lt(e))
      return c("The provided `%s` CSS property is an unsupported type %s. This value must be coerced to a string before before using it here.", t, Ht(e)), kt(e);
  }
  function yr(e) {
    if (Lt(e))
      return c("The provided HTML markup uses a value of unsupported type %s. This value must be coerced to a string before before using it here.", Ht(e)), kt(e);
  }
  function jn(e) {
    if (Lt(e))
      return c("Form field values (value, checked, defaultValue, or defaultChecked props) must be strings, not %s. This value must be coerced to a string before before using it here.", Ht(e)), kt(e);
  }
  var gr = 0, Tn = 1, tr = 2, Pt = 3, br = 4, Ca = 5, Ea = 6, re = ":A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD", be = re + "\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040", Fe = new RegExp("^[" + re + "][" + be + "]*$"), it = {}, ot = {};
  function Xt(e) {
    return Gt.call(ot, e) ? !0 : Gt.call(it, e) ? !1 : Fe.test(e) ? (ot[e] = !0, !0) : (it[e] = !0, c("Invalid attribute name: `%s`", e), !1);
  }
  function Ut(e, t, n) {
    return t !== null ? t.type === gr : n ? !1 : e.length > 2 && (e[0] === "o" || e[0] === "O") && (e[1] === "n" || e[1] === "N");
  }
  function Gn(e, t, n, r) {
    if (n !== null && n.type === gr)
      return !1;
    switch (typeof t) {
      case "function":
      case "symbol":
        return !0;
      case "boolean": {
        if (r)
          return !1;
        if (n !== null)
          return !n.acceptsBooleans;
        var i = e.toLowerCase().slice(0, 5);
        return i !== "data-" && i !== "aria-";
      }
      default:
        return !1;
    }
  }
  function pt(e, t, n, r) {
    if (t === null || typeof t > "u" || Gn(e, t, n, r))
      return !0;
    if (r)
      return !1;
    if (n !== null)
      switch (n.type) {
        case Pt:
          return !t;
        case br:
          return t === !1;
        case Ca:
          return isNaN(t);
        case Ea:
          return isNaN(t) || t < 1;
      }
    return !1;
  }
  function nr(e) {
    return Et.hasOwnProperty(e) ? Et[e] : null;
  }
  function Ct(e, t, n, r, i, l, f) {
    this.acceptsBooleans = t === tr || t === Pt || t === br, this.attributeName = r, this.attributeNamespace = i, this.mustUseProperty = n, this.propertyName = e, this.type = t, this.sanitizeURL = l, this.removeEmptyString = f;
  }
  var Et = {}, Jr = [
    "children",
    "dangerouslySetInnerHTML",
    // TODO: This prevents the assignment of defaultValue to regular
    // elements (not just inputs). Now that ReactDOMInput assigns to the
    // defaultValue property -- do we need this?
    "defaultValue",
    "defaultChecked",
    "innerHTML",
    "suppressContentEditableWarning",
    "suppressHydrationWarning",
    "style"
  ];
  Jr.forEach(function(e) {
    Et[e] = new Ct(
      e,
      gr,
      !1,
      // mustUseProperty
      e,
      // attributeName
      null,
      // attributeNamespace
      !1,
      // sanitizeURL
      !1
    );
  }), [["acceptCharset", "accept-charset"], ["className", "class"], ["htmlFor", "for"], ["httpEquiv", "http-equiv"]].forEach(function(e) {
    var t = e[0], n = e[1];
    Et[t] = new Ct(
      t,
      Tn,
      !1,
      // mustUseProperty
      n,
      // attributeName
      null,
      // attributeNamespace
      !1,
      // sanitizeURL
      !1
    );
  }), ["contentEditable", "draggable", "spellCheck", "value"].forEach(function(e) {
    Et[e] = new Ct(
      e,
      tr,
      !1,
      // mustUseProperty
      e.toLowerCase(),
      // attributeName
      null,
      // attributeNamespace
      !1,
      // sanitizeURL
      !1
    );
  }), ["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(e) {
    Et[e] = new Ct(
      e,
      tr,
      !1,
      // mustUseProperty
      e,
      // attributeName
      null,
      // attributeNamespace
      !1,
      // sanitizeURL
      !1
    );
  }), [
    "allowFullScreen",
    "async",
    // Note: there is a special case that prevents it from being written to the DOM
    // on the client side because the browsers are inconsistent. Instead we call focus().
    "autoFocus",
    "autoPlay",
    "controls",
    "default",
    "defer",
    "disabled",
    "disablePictureInPicture",
    "disableRemotePlayback",
    "formNoValidate",
    "hidden",
    "loop",
    "noModule",
    "noValidate",
    "open",
    "playsInline",
    "readOnly",
    "required",
    "reversed",
    "scoped",
    "seamless",
    // Microdata
    "itemScope"
  ].forEach(function(e) {
    Et[e] = new Ct(
      e,
      Pt,
      !1,
      // mustUseProperty
      e.toLowerCase(),
      // attributeName
      null,
      // attributeNamespace
      !1,
      // sanitizeURL
      !1
    );
  }), [
    "checked",
    // Note: `option.selected` is not updated if `select.multiple` is
    // disabled with `removeAttribute`. We have special logic for handling this.
    "multiple",
    "muted",
    "selected"
    // NOTE: if you add a camelCased prop to this list,
    // you'll need to set attributeName to name.toLowerCase()
    // instead in the assignment below.
  ].forEach(function(e) {
    Et[e] = new Ct(
      e,
      Pt,
      !0,
      // mustUseProperty
      e,
      // attributeName
      null,
      // attributeNamespace
      !1,
      // sanitizeURL
      !1
    );
  }), [
    "capture",
    "download"
    // NOTE: if you add a camelCased prop to this list,
    // you'll need to set attributeName to name.toLowerCase()
    // instead in the assignment below.
  ].forEach(function(e) {
    Et[e] = new Ct(
      e,
      br,
      !1,
      // mustUseProperty
      e,
      // attributeName
      null,
      // attributeNamespace
      !1,
      // sanitizeURL
      !1
    );
  }), [
    "cols",
    "rows",
    "size",
    "span"
    // NOTE: if you add a camelCased prop to this list,
    // you'll need to set attributeName to name.toLowerCase()
    // instead in the assignment below.
  ].forEach(function(e) {
    Et[e] = new Ct(
      e,
      Ea,
      !1,
      // mustUseProperty
      e,
      // attributeName
      null,
      // attributeNamespace
      !1,
      // sanitizeURL
      !1
    );
  }), ["rowSpan", "start"].forEach(function(e) {
    Et[e] = new Ct(
      e,
      Ca,
      !1,
      // mustUseProperty
      e.toLowerCase(),
      // attributeName
      null,
      // attributeNamespace
      !1,
      // sanitizeURL
      !1
    );
  });
  var Nr = /[\-\:]([a-z])/g, Hi = function(e) {
    return e[1].toUpperCase();
  };
  [
    "accent-height",
    "alignment-baseline",
    "arabic-form",
    "baseline-shift",
    "cap-height",
    "clip-path",
    "clip-rule",
    "color-interpolation",
    "color-interpolation-filters",
    "color-profile",
    "color-rendering",
    "dominant-baseline",
    "enable-background",
    "fill-opacity",
    "fill-rule",
    "flood-color",
    "flood-opacity",
    "font-family",
    "font-size",
    "font-size-adjust",
    "font-stretch",
    "font-style",
    "font-variant",
    "font-weight",
    "glyph-name",
    "glyph-orientation-horizontal",
    "glyph-orientation-vertical",
    "horiz-adv-x",
    "horiz-origin-x",
    "image-rendering",
    "letter-spacing",
    "lighting-color",
    "marker-end",
    "marker-mid",
    "marker-start",
    "overline-position",
    "overline-thickness",
    "paint-order",
    "panose-1",
    "pointer-events",
    "rendering-intent",
    "shape-rendering",
    "stop-color",
    "stop-opacity",
    "strikethrough-position",
    "strikethrough-thickness",
    "stroke-dasharray",
    "stroke-dashoffset",
    "stroke-linecap",
    "stroke-linejoin",
    "stroke-miterlimit",
    "stroke-opacity",
    "stroke-width",
    "text-anchor",
    "text-decoration",
    "text-rendering",
    "underline-position",
    "underline-thickness",
    "unicode-bidi",
    "unicode-range",
    "units-per-em",
    "v-alphabetic",
    "v-hanging",
    "v-ideographic",
    "v-mathematical",
    "vector-effect",
    "vert-adv-y",
    "vert-origin-x",
    "vert-origin-y",
    "word-spacing",
    "writing-mode",
    "xmlns:xlink",
    "x-height"
    // NOTE: if you add a camelCased prop to this list,
    // you'll need to set attributeName to name.toLowerCase()
    // instead in the assignment below.
  ].forEach(function(e) {
    var t = e.replace(Nr, Hi);
    Et[t] = new Ct(
      t,
      Tn,
      !1,
      // mustUseProperty
      e,
      null,
      // attributeNamespace
      !1,
      // sanitizeURL
      !1
    );
  }), [
    "xlink:actuate",
    "xlink:arcrole",
    "xlink:role",
    "xlink:show",
    "xlink:title",
    "xlink:type"
    // NOTE: if you add a camelCased prop to this list,
    // you'll need to set attributeName to name.toLowerCase()
    // instead in the assignment below.
  ].forEach(function(e) {
    var t = e.replace(Nr, Hi);
    Et[t] = new Ct(
      t,
      Tn,
      !1,
      // mustUseProperty
      e,
      "http://www.w3.org/1999/xlink",
      !1,
      // sanitizeURL
      !1
    );
  }), [
    "xml:base",
    "xml:lang",
    "xml:space"
    // NOTE: if you add a camelCased prop to this list,
    // you'll need to set attributeName to name.toLowerCase()
    // instead in the assignment below.
  ].forEach(function(e) {
    var t = e.replace(Nr, Hi);
    Et[t] = new Ct(
      t,
      Tn,
      !1,
      // mustUseProperty
      e,
      "http://www.w3.org/XML/1998/namespace",
      !1,
      // sanitizeURL
      !1
    );
  }), ["tabIndex", "crossOrigin"].forEach(function(e) {
    Et[e] = new Ct(
      e,
      Tn,
      !1,
      // mustUseProperty
      e.toLowerCase(),
      // attributeName
      null,
      // attributeNamespace
      !1,
      // sanitizeURL
      !1
    );
  });
  var Ao = "xlinkHref";
  Et[Ao] = new Ct(
    "xlinkHref",
    Tn,
    !1,
    // mustUseProperty
    "xlink:href",
    "http://www.w3.org/1999/xlink",
    !0,
    // sanitizeURL
    !1
  ), ["src", "href", "action", "formAction"].forEach(function(e) {
    Et[e] = new Ct(
      e,
      Tn,
      !1,
      // mustUseProperty
      e.toLowerCase(),
      // attributeName
      null,
      // attributeNamespace
      !0,
      // sanitizeURL
      !0
    );
  });
  var Bl = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*\:/i, $i = !1;
  function Ii(e) {
    !$i && Bl.test(e) && ($i = !0, c("A future version of React will block javascript: URLs as a security precaution. Use event handlers instead if you can. If you need to generate unsafe HTML try using dangerouslySetInnerHTML instead. React was passed %s.", JSON.stringify(e)));
  }
  function Ra(e, t, n, r) {
    if (r.mustUseProperty) {
      var i = r.propertyName;
      return e[i];
    } else {
      Un(n, t), r.sanitizeURL && Ii("" + n);
      var l = r.attributeName, f = null;
      if (r.type === br) {
        if (e.hasAttribute(l)) {
          var p = e.getAttribute(l);
          return p === "" ? !0 : pt(t, n, r, !1) ? p : p === "" + n ? n : p;
        }
      } else if (e.hasAttribute(l)) {
        if (pt(t, n, r, !1))
          return e.getAttribute(l);
        if (r.type === Pt)
          return n;
        f = e.getAttribute(l);
      }
      return pt(t, n, r, !1) ? f === null ? n : f : f === "" + n ? n : f;
    }
  }
  function Za(e, t, n, r) {
    {
      if (!Xt(t))
        return;
      if (!e.hasAttribute(t))
        return n === void 0 ? void 0 : null;
      var i = e.getAttribute(t);
      return Un(n, t), i === "" + n ? n : i;
    }
  }
  function wa(e, t, n, r) {
    var i = nr(t);
    if (!Ut(t, i, r)) {
      if (pt(t, n, i, r) && (n = null), r || i === null) {
        if (Xt(t)) {
          var l = t;
          n === null ? e.removeAttribute(l) : (Un(n, t), e.setAttribute(l, "" + n));
        }
        return;
      }
      var f = i.mustUseProperty;
      if (f) {
        var p = i.propertyName;
        if (n === null) {
          var m = i.type;
          e[p] = m === Pt ? !1 : "";
        } else
          e[p] = n;
        return;
      }
      var C = i.attributeName, w = i.attributeNamespace;
      if (n === null)
        e.removeAttribute(C);
      else {
        var N = i.type, A;
        N === Pt || N === br && n === !0 ? A = "" : (Un(n, C), A = "" + n, i.sanitizeURL && Ii(A.toString())), w ? e.setAttributeNS(w, C, A) : e.setAttribute(C, A);
      }
    }
  }
  var Lr = Symbol.for("react.element"), kr = Symbol.for("react.portal"), ea = Symbol.for("react.fragment"), Bi = Symbol.for("react.strict_mode"), Ja = Symbol.for("react.profiler"), _ = Symbol.for("react.provider"), q = Symbol.for("react.context"), J = Symbol.for("react.forward_ref"), we = Symbol.for("react.suspense"), Be = Symbol.for("react.suspense_list"), Qe = Symbol.for("react.memo"), xe = Symbol.for("react.lazy"), ze = Symbol.for("react.scope"), Kt = Symbol.for("react.debug_trace_mode"), gt = Symbol.for("react.offscreen"), xt = Symbol.for("react.legacy_hidden"), Dn = Symbol.for("react.cache"), ta = Symbol.for("react.tracing_marker"), Sr = Symbol.iterator, on = "@@iterator";
  function rr(e) {
    if (e === null || typeof e != "object")
      return null;
    var t = Sr && e[Sr] || e[on];
    return typeof t == "function" ? t : null;
  }
  var He = Object.assign, xa = 0, ei, Vl, Yl, Wl, Gl, Xl, Kl;
  function ql() {
  }
  ql.__reactDisabledLog = !0;
  function ec() {
    {
      if (xa === 0) {
        ei = console.log, Vl = console.info, Yl = console.warn, Wl = console.error, Gl = console.group, Xl = console.groupCollapsed, Kl = console.groupEnd;
        var e = {
          configurable: !0,
          enumerable: !0,
          value: ql,
          writable: !0
        };
        Object.defineProperties(console, {
          info: e,
          log: e,
          warn: e,
          error: e,
          group: e,
          groupCollapsed: e,
          groupEnd: e
        });
      }
      xa++;
    }
  }
  function ep() {
    {
      if (xa--, xa === 0) {
        var e = {
          configurable: !0,
          enumerable: !0,
          writable: !0
        };
        Object.defineProperties(console, {
          log: He({}, e, {
            value: ei
          }),
          info: He({}, e, {
            value: Vl
          }),
          warn: He({}, e, {
            value: Yl
          }),
          error: He({}, e, {
            value: Wl
          }),
          group: He({}, e, {
            value: Gl
          }),
          groupCollapsed: He({}, e, {
            value: Xl
          }),
          groupEnd: He({}, e, {
            value: Kl
          })
        });
      }
      xa < 0 && c("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
    }
  }
  var Ql = u.ReactCurrentDispatcher, Vi;
  function Cr(e, t, n) {
    {
      if (Vi === void 0)
        try {
          throw Error();
        } catch (i) {
          var r = i.stack.trim().match(/\n( *(at )?)/);
          Vi = r && r[1] || "";
        }
      return `
` + Vi + e;
    }
  }
  var ti = !1, ni;
  {
    var No = typeof WeakMap == "function" ? WeakMap : Map;
    ni = new No();
  }
  function Zl(e, t) {
    if (!e || ti)
      return "";
    {
      var n = ni.get(e);
      if (n !== void 0)
        return n;
    }
    var r;
    ti = !0;
    var i = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    var l;
    l = Ql.current, Ql.current = null, ec();
    try {
      if (t) {
        var f = function() {
          throw Error();
        };
        if (Object.defineProperty(f.prototype, "props", {
          set: function() {
            throw Error();
          }
        }), typeof Reflect == "object" && Reflect.construct) {
          try {
            Reflect.construct(f, []);
          } catch (H) {
            r = H;
          }
          Reflect.construct(e, [], f);
        } else {
          try {
            f.call();
          } catch (H) {
            r = H;
          }
          e.call(f.prototype);
        }
      } else {
        try {
          throw Error();
        } catch (H) {
          r = H;
        }
        e();
      }
    } catch (H) {
      if (H && r && typeof H.stack == "string") {
        for (var p = H.stack.split(`
`), m = r.stack.split(`
`), C = p.length - 1, w = m.length - 1; C >= 1 && w >= 0 && p[C] !== m[w]; )
          w--;
        for (; C >= 1 && w >= 0; C--, w--)
          if (p[C] !== m[w]) {
            if (C !== 1 || w !== 1)
              do
                if (C--, w--, w < 0 || p[C] !== m[w]) {
                  var N = `
` + p[C].replace(" at new ", " at ");
                  return e.displayName && N.includes("<anonymous>") && (N = N.replace("<anonymous>", e.displayName)), typeof e == "function" && ni.set(e, N), N;
                }
              while (C >= 1 && w >= 0);
            break;
          }
      }
    } finally {
      ti = !1, Ql.current = l, ep(), Error.prepareStackTrace = i;
    }
    var A = e ? e.displayName || e.name : "", j = A ? Cr(A) : "";
    return typeof e == "function" && ni.set(e, j), j;
  }
  function tc(e, t, n) {
    return Zl(e, !0);
  }
  function Jl(e, t, n) {
    return Zl(e, !1);
  }
  function tp(e) {
    var t = e.prototype;
    return !!(t && t.isReactComponent);
  }
  function ri(e, t, n) {
    if (e == null)
      return "";
    if (typeof e == "function")
      return Zl(e, tp(e));
    if (typeof e == "string")
      return Cr(e);
    switch (e) {
      case we:
        return Cr("Suspense");
      case Be:
        return Cr("SuspenseList");
    }
    if (typeof e == "object")
      switch (e.$$typeof) {
        case J:
          return Jl(e.render);
        case Qe:
          return ri(e.type, t, n);
        case xe: {
          var r = e, i = r._payload, l = r._init;
          try {
            return ri(l(i), t, n);
          } catch {
          }
        }
      }
    return "";
  }
  function nc(e) {
    switch (e._debugOwner && e._debugOwner.type, e._debugSource, e.tag) {
      case T:
        return Cr(e.type);
      case ve:
        return Cr("Lazy");
      case W:
        return Cr("Suspense");
      case Ee:
        return Cr("SuspenseList");
      case b:
      case R:
      case Z:
        return Jl(e.type);
      case Y:
        return Jl(e.type.render);
      case S:
        return tc(e.type);
      default:
        return "";
    }
  }
  function eu(e) {
    try {
      var t = "", n = e;
      do
        t += nc(n), n = n.return;
      while (n);
      return t;
    } catch (r) {
      return `
Error generating stack: ` + r.message + `
` + r.stack;
    }
  }
  function Lo(e, t, n) {
    var r = e.displayName;
    if (r)
      return r;
    var i = t.displayName || t.name || "";
    return i !== "" ? n + "(" + i + ")" : n;
  }
  function rc(e) {
    return e.displayName || "Context";
  }
  function Ze(e) {
    if (e == null)
      return null;
    if (typeof e.tag == "number" && c("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), typeof e == "function")
      return e.displayName || e.name || null;
    if (typeof e == "string")
      return e;
    switch (e) {
      case ea:
        return "Fragment";
      case kr:
        return "Portal";
      case Ja:
        return "Profiler";
      case Bi:
        return "StrictMode";
      case we:
        return "Suspense";
      case Be:
        return "SuspenseList";
    }
    if (typeof e == "object")
      switch (e.$$typeof) {
        case q:
          var t = e;
          return rc(t) + ".Consumer";
        case _:
          var n = e;
          return rc(n._context) + ".Provider";
        case J:
          return Lo(e, e.render, "ForwardRef");
        case Qe:
          var r = e.displayName || null;
          return r !== null ? r : Ze(e.type) || "Memo";
        case xe: {
          var i = e, l = i._payload, f = i._init;
          try {
            return Ze(f(l));
          } catch {
            return null;
          }
        }
      }
    return null;
  }
  function tu(e, t, n) {
    var r = t.displayName || t.name || "";
    return e.displayName || (r !== "" ? n + "(" + r + ")" : n);
  }
  function nu(e) {
    return e.displayName || "Context";
  }
  function Pe(e) {
    var t = e.tag, n = e.type;
    switch (t) {
      case Ie:
        return "Cache";
      case U:
        var r = n;
        return nu(r) + ".Consumer";
      case F:
        var i = n;
        return nu(i._context) + ".Provider";
      case he:
        return "DehydratedFragment";
      case Y:
        return tu(n, n.render, "ForwardRef");
      case L:
        return "Fragment";
      case T:
        return n;
      case x:
        return "Portal";
      case E:
        return "Root";
      case M:
        return "Text";
      case ve:
        return Ze(n);
      case $:
        return n === Bi ? "StrictMode" : "Mode";
      case fe:
        return "Offscreen";
      case X:
        return "Profiler";
      case Xe:
        return "Scope";
      case W:
        return "Suspense";
      case Ee:
        return "SuspenseList";
      case De:
        return "TracingMarker";
      case S:
      case b:
      case me:
      case R:
      case ne:
      case Z:
        if (typeof n == "function")
          return n.displayName || n.name || null;
        if (typeof n == "string")
          return n;
        break;
    }
    return null;
  }
  var ac = u.ReactDebugCurrentFrame, _n = null, Yi = !1;
  function ai() {
    {
      if (_n === null)
        return null;
      var e = _n._debugOwner;
      if (e !== null && typeof e < "u")
        return Pe(e);
    }
    return null;
  }
  function ic() {
    return _n === null ? "" : eu(_n);
  }
  function ln() {
    ac.getCurrentStack = null, _n = null, Yi = !1;
  }
  function Tt(e) {
    ac.getCurrentStack = e === null ? null : ic, _n = e, Yi = !1;
  }
  function oc() {
    return _n;
  }
  function ar(e) {
    Yi = e;
  }
  function Xn(e) {
    return "" + e;
  }
  function na(e) {
    switch (typeof e) {
      case "boolean":
      case "number":
      case "string":
      case "undefined":
        return e;
      case "object":
        return jn(e), e;
      default:
        return "";
    }
  }
  var np = {
    button: !0,
    checkbox: !0,
    image: !0,
    hidden: !0,
    radio: !0,
    reset: !0,
    submit: !0
  };
  function ko(e, t) {
    np[t.type] || t.onChange || t.onInput || t.readOnly || t.disabled || t.value == null || c("You provided a `value` prop to a form field without an `onChange` handler. This will render a read-only field. If the field should be mutable use `defaultValue`. Otherwise, set either `onChange` or `readOnly`."), t.onChange || t.readOnly || t.disabled || t.checked == null || c("You provided a `checked` prop to a form field without an `onChange` handler. This will render a read-only field. If the field should be mutable use `defaultChecked`. Otherwise, set either `onChange` or `readOnly`.");
  }
  function Wi(e) {
    var t = e.type, n = e.nodeName;
    return n && n.toLowerCase() === "input" && (t === "checkbox" || t === "radio");
  }
  function lc(e) {
    return e._valueTracker;
  }
  function ii(e) {
    e._valueTracker = null;
  }
  function uc(e) {
    var t = "";
    return e && (Wi(e) ? t = e.checked ? "true" : "false" : t = e.value), t;
  }
  function sc(e) {
    var t = Wi(e) ? "checked" : "value", n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t);
    jn(e[t]);
    var r = "" + e[t];
    if (!(e.hasOwnProperty(t) || typeof n > "u" || typeof n.get != "function" || typeof n.set != "function")) {
      var i = n.get, l = n.set;
      Object.defineProperty(e, t, {
        configurable: !0,
        get: function() {
          return i.call(this);
        },
        set: function(p) {
          jn(p), r = "" + p, l.call(this, p);
        }
      }), Object.defineProperty(e, t, {
        enumerable: n.enumerable
      });
      var f = {
        getValue: function() {
          return r;
        },
        setValue: function(p) {
          jn(p), r = "" + p;
        },
        stopTracking: function() {
          ii(e), delete e[t];
        }
      };
      return f;
    }
  }
  function Ta(e) {
    lc(e) || (e._valueTracker = sc(e));
  }
  function Po(e) {
    if (!e)
      return !1;
    var t = lc(e);
    if (!t)
      return !0;
    var n = t.getValue(), r = uc(e);
    return r !== n ? (t.setValue(r), !0) : !1;
  }
  function oi(e) {
    if (e = e || (typeof document < "u" ? document : void 0), typeof e > "u")
      return null;
    try {
      return e.activeElement || e.body;
    } catch {
      return e.body;
    }
  }
  var Uo = !1, cc = !1, fc = !1, dc = !1;
  function pc(e) {
    var t = e.type === "checkbox" || e.type === "radio";
    return t ? e.checked != null : e.value != null;
  }
  function y(e, t) {
    var n = e, r = t.checked, i = He({}, t, {
      defaultChecked: void 0,
      defaultValue: void 0,
      value: void 0,
      checked: r ?? n._wrapperState.initialChecked
    });
    return i;
  }
  function D(e, t) {
    ko("input", t), t.checked !== void 0 && t.defaultChecked !== void 0 && !cc && (c("%s contains an input of type %s with both checked and defaultChecked props. Input elements must be either controlled or uncontrolled (specify either the checked prop, or the defaultChecked prop, but not both). Decide between using a controlled or uncontrolled input element and remove one of these props. More info: https://reactjs.org/link/controlled-components", ai() || "A component", t.type), cc = !0), t.value !== void 0 && t.defaultValue !== void 0 && !Uo && (c("%s contains an input of type %s with both value and defaultValue props. Input elements must be either controlled or uncontrolled (specify either the value prop, or the defaultValue prop, but not both). Decide between using a controlled or uncontrolled input element and remove one of these props. More info: https://reactjs.org/link/controlled-components", ai() || "A component", t.type), Uo = !0);
    var n = e, r = t.defaultValue == null ? "" : t.defaultValue;
    n._wrapperState = {
      initialChecked: t.checked != null ? t.checked : t.defaultChecked,
      initialValue: na(t.value != null ? t.value : r),
      controlled: pc(t)
    };
  }
  function z(e, t) {
    var n = e, r = t.checked;
    r != null && wa(n, "checked", r, !1);
  }
  function I(e, t) {
    var n = e;
    {
      var r = pc(t);
      !n._wrapperState.controlled && r && !dc && (c("A component is changing an uncontrolled input to be controlled. This is likely caused by the value changing from undefined to a defined value, which should not happen. Decide between using a controlled or uncontrolled input element for the lifetime of the component. More info: https://reactjs.org/link/controlled-components"), dc = !0), n._wrapperState.controlled && !r && !fc && (c("A component is changing a controlled input to be uncontrolled. This is likely caused by the value changing from a defined to undefined, which should not happen. Decide between using a controlled or uncontrolled input element for the lifetime of the component. More info: https://reactjs.org/link/controlled-components"), fc = !0);
    }
    z(e, t);
    var i = na(t.value), l = t.type;
    if (i != null)
      l === "number" ? (i === 0 && n.value === "" || // We explicitly want to coerce to number here if possible.
      // eslint-disable-next-line
      n.value != i) && (n.value = Xn(i)) : n.value !== Xn(i) && (n.value = Xn(i));
    else if (l === "submit" || l === "reset") {
      n.removeAttribute("value");
      return;
    }
    t.hasOwnProperty("value") ? Ae(n, t.type, i) : t.hasOwnProperty("defaultValue") && Ae(n, t.type, na(t.defaultValue)), t.checked == null && t.defaultChecked != null && (n.defaultChecked = !!t.defaultChecked);
  }
  function ee(e, t, n) {
    var r = e;
    if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
      var i = t.type, l = i === "submit" || i === "reset";
      if (l && (t.value === void 0 || t.value === null))
        return;
      var f = Xn(r._wrapperState.initialValue);
      n || f !== r.value && (r.value = f), r.defaultValue = f;
    }
    var p = r.name;
    p !== "" && (r.name = ""), r.defaultChecked = !r.defaultChecked, r.defaultChecked = !!r._wrapperState.initialChecked, p !== "" && (r.name = p);
  }
  function _e(e, t) {
    var n = e;
    I(n, t), pe(n, t);
  }
  function pe(e, t) {
    var n = t.name;
    if (t.type === "radio" && n != null) {
      for (var r = e; r.parentNode; )
        r = r.parentNode;
      Un(n, "name");
      for (var i = r.querySelectorAll("input[name=" + JSON.stringify("" + n) + '][type="radio"]'), l = 0; l < i.length; l++) {
        var f = i[l];
        if (!(f === e || f.form !== e.form)) {
          var p = Jc(f);
          if (!p)
            throw new Error("ReactDOMInput: Mixing React and non-React radio inputs with the same `name` is not supported.");
          Po(f), I(f, p);
        }
      }
    }
  }
  function Ae(e, t, n) {
    // Focused number inputs synchronize on blur. See ChangeEventPlugin.js
    (t !== "number" || oi(e.ownerDocument) !== e) && (n == null ? e.defaultValue = Xn(e._wrapperState.initialValue) : e.defaultValue !== Xn(n) && (e.defaultValue = Xn(n)));
  }
  var Ve = !1, lt = !1, vt = !1;
  function ht(e, t) {
    t.value == null && (typeof t.children == "object" && t.children !== null ? a.Children.forEach(t.children, function(n) {
      n != null && (typeof n == "string" || typeof n == "number" || lt || (lt = !0, c("Cannot infer the option value of complex children. Pass a `value` prop or use a plain string as children to <option>.")));
    }) : t.dangerouslySetInnerHTML != null && (vt || (vt = !0, c("Pass a `value` prop if you set dangerouslyInnerHTML so React knows which value should be selected.")))), t.selected != null && !Ve && (c("Use the `defaultValue` or `value` props on <select> instead of setting `selected` on <option>."), Ve = !0);
  }
  function Rt(e, t) {
    t.value != null && e.setAttribute("value", Xn(na(t.value)));
  }
  var _t = Array.isArray;
  function tt(e) {
    return _t(e);
  }
  var li;
  li = !1;
  function jo() {
    var e = ai();
    return e ? `

Check the render method of \`` + e + "`." : "";
  }
  var ru = ["value", "defaultValue"];
  function rp(e) {
    {
      ko("select", e);
      for (var t = 0; t < ru.length; t++) {
        var n = ru[t];
        if (e[n] != null) {
          var r = tt(e[n]);
          e.multiple && !r ? c("The `%s` prop supplied to <select> must be an array if `multiple` is true.%s", n, jo()) : !e.multiple && r && c("The `%s` prop supplied to <select> must be a scalar value if `multiple` is false.%s", n, jo());
        }
      }
    }
  }
  function Da(e, t, n, r) {
    var i = e.options;
    if (t) {
      for (var l = n, f = {}, p = 0; p < l.length; p++)
        f["$" + l[p]] = !0;
      for (var m = 0; m < i.length; m++) {
        var C = f.hasOwnProperty("$" + i[m].value);
        i[m].selected !== C && (i[m].selected = C), C && r && (i[m].defaultSelected = !0);
      }
    } else {
      for (var w = Xn(na(n)), N = null, A = 0; A < i.length; A++) {
        if (i[A].value === w) {
          i[A].selected = !0, r && (i[A].defaultSelected = !0);
          return;
        }
        N === null && !i[A].disabled && (N = i[A]);
      }
      N !== null && (N.selected = !0);
    }
  }
  function au(e, t) {
    return He({}, t, {
      value: void 0
    });
  }
  function iu(e, t) {
    var n = e;
    rp(t), n._wrapperState = {
      wasMultiple: !!t.multiple
    }, t.value !== void 0 && t.defaultValue !== void 0 && !li && (c("Select elements must be either controlled or uncontrolled (specify either the value prop, or the defaultValue prop, but not both). Decide between using a controlled or uncontrolled select element and remove one of these props. More info: https://reactjs.org/link/controlled-components"), li = !0);
  }
  function ap(e, t) {
    var n = e;
    n.multiple = !!t.multiple;
    var r = t.value;
    r != null ? Da(n, !!t.multiple, r, !1) : t.defaultValue != null && Da(n, !!t.multiple, t.defaultValue, !0);
  }
  function Nx(e, t) {
    var n = e, r = n._wrapperState.wasMultiple;
    n._wrapperState.wasMultiple = !!t.multiple;
    var i = t.value;
    i != null ? Da(n, !!t.multiple, i, !1) : r !== !!t.multiple && (t.defaultValue != null ? Da(n, !!t.multiple, t.defaultValue, !0) : Da(n, !!t.multiple, t.multiple ? [] : "", !1));
  }
  function Lx(e, t) {
    var n = e, r = t.value;
    r != null && Da(n, !!t.multiple, r, !1);
  }
  var vg = !1;
  function ip(e, t) {
    var n = e;
    if (t.dangerouslySetInnerHTML != null)
      throw new Error("`dangerouslySetInnerHTML` does not make sense on <textarea>.");
    var r = He({}, t, {
      value: void 0,
      defaultValue: void 0,
      children: Xn(n._wrapperState.initialValue)
    });
    return r;
  }
  function hg(e, t) {
    var n = e;
    ko("textarea", t), t.value !== void 0 && t.defaultValue !== void 0 && !vg && (c("%s contains a textarea with both value and defaultValue props. Textarea elements must be either controlled or uncontrolled (specify either the value prop, or the defaultValue prop, but not both). Decide between using a controlled or uncontrolled textarea and remove one of these props. More info: https://reactjs.org/link/controlled-components", ai() || "A component"), vg = !0);
    var r = t.value;
    if (r == null) {
      var i = t.children, l = t.defaultValue;
      if (i != null) {
        c("Use the `defaultValue` or `value` props instead of setting children on <textarea>.");
        {
          if (l != null)
            throw new Error("If you supply `defaultValue` on a <textarea>, do not pass children.");
          if (tt(i)) {
            if (i.length > 1)
              throw new Error("<textarea> can only have at most one child.");
            i = i[0];
          }
          l = i;
        }
      }
      l == null && (l = ""), r = l;
    }
    n._wrapperState = {
      initialValue: na(r)
    };
  }
  function mg(e, t) {
    var n = e, r = na(t.value), i = na(t.defaultValue);
    if (r != null) {
      var l = Xn(r);
      l !== n.value && (n.value = l), t.defaultValue == null && n.defaultValue !== l && (n.defaultValue = l);
    }
    i != null && (n.defaultValue = Xn(i));
  }
  function yg(e, t) {
    var n = e, r = n.textContent;
    r === n._wrapperState.initialValue && r !== "" && r !== null && (n.value = r);
  }
  function kx(e, t) {
    mg(e, t);
  }
  var _a = "http://www.w3.org/1999/xhtml", Px = "http://www.w3.org/1998/Math/MathML", op = "http://www.w3.org/2000/svg";
  function lp(e) {
    switch (e) {
      case "svg":
        return op;
      case "math":
        return Px;
      default:
        return _a;
    }
  }
  function up(e, t) {
    return e == null || e === _a ? lp(t) : e === op && t === "foreignObject" ? _a : e;
  }
  var Ux = function(e) {
    return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction ? function(t, n, r, i) {
      MSApp.execUnsafeLocalFunction(function() {
        return e(t, n, r, i);
      });
    } : e;
  }, vc, gg = Ux(function(e, t) {
    if (e.namespaceURI === op && !("innerHTML" in e)) {
      vc = vc || document.createElement("div"), vc.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>";
      for (var n = vc.firstChild; e.firstChild; )
        e.removeChild(e.firstChild);
      for (; n.firstChild; )
        e.appendChild(n.firstChild);
      return;
    }
    e.innerHTML = t;
  }), Kn = 1, Ma = 3, $t = 8, Oa = 9, sp = 11, hc = function(e, t) {
    if (t) {
      var n = e.firstChild;
      if (n && n === e.lastChild && n.nodeType === Ma) {
        n.nodeValue = t;
        return;
      }
    }
    e.textContent = t;
  }, jx = {
    animation: ["animationDelay", "animationDirection", "animationDuration", "animationFillMode", "animationIterationCount", "animationName", "animationPlayState", "animationTimingFunction"],
    background: ["backgroundAttachment", "backgroundClip", "backgroundColor", "backgroundImage", "backgroundOrigin", "backgroundPositionX", "backgroundPositionY", "backgroundRepeat", "backgroundSize"],
    backgroundPosition: ["backgroundPositionX", "backgroundPositionY"],
    border: ["borderBottomColor", "borderBottomStyle", "borderBottomWidth", "borderImageOutset", "borderImageRepeat", "borderImageSlice", "borderImageSource", "borderImageWidth", "borderLeftColor", "borderLeftStyle", "borderLeftWidth", "borderRightColor", "borderRightStyle", "borderRightWidth", "borderTopColor", "borderTopStyle", "borderTopWidth"],
    borderBlockEnd: ["borderBlockEndColor", "borderBlockEndStyle", "borderBlockEndWidth"],
    borderBlockStart: ["borderBlockStartColor", "borderBlockStartStyle", "borderBlockStartWidth"],
    borderBottom: ["borderBottomColor", "borderBottomStyle", "borderBottomWidth"],
    borderColor: ["borderBottomColor", "borderLeftColor", "borderRightColor", "borderTopColor"],
    borderImage: ["borderImageOutset", "borderImageRepeat", "borderImageSlice", "borderImageSource", "borderImageWidth"],
    borderInlineEnd: ["borderInlineEndColor", "borderInlineEndStyle", "borderInlineEndWidth"],
    borderInlineStart: ["borderInlineStartColor", "borderInlineStartStyle", "borderInlineStartWidth"],
    borderLeft: ["borderLeftColor", "borderLeftStyle", "borderLeftWidth"],
    borderRadius: ["borderBottomLeftRadius", "borderBottomRightRadius", "borderTopLeftRadius", "borderTopRightRadius"],
    borderRight: ["borderRightColor", "borderRightStyle", "borderRightWidth"],
    borderStyle: ["borderBottomStyle", "borderLeftStyle", "borderRightStyle", "borderTopStyle"],
    borderTop: ["borderTopColor", "borderTopStyle", "borderTopWidth"],
    borderWidth: ["borderBottomWidth", "borderLeftWidth", "borderRightWidth", "borderTopWidth"],
    columnRule: ["columnRuleColor", "columnRuleStyle", "columnRuleWidth"],
    columns: ["columnCount", "columnWidth"],
    flex: ["flexBasis", "flexGrow", "flexShrink"],
    flexFlow: ["flexDirection", "flexWrap"],
    font: ["fontFamily", "fontFeatureSettings", "fontKerning", "fontLanguageOverride", "fontSize", "fontSizeAdjust", "fontStretch", "fontStyle", "fontVariant", "fontVariantAlternates", "fontVariantCaps", "fontVariantEastAsian", "fontVariantLigatures", "fontVariantNumeric", "fontVariantPosition", "fontWeight", "lineHeight"],
    fontVariant: ["fontVariantAlternates", "fontVariantCaps", "fontVariantEastAsian", "fontVariantLigatures", "fontVariantNumeric", "fontVariantPosition"],
    gap: ["columnGap", "rowGap"],
    grid: ["gridAutoColumns", "gridAutoFlow", "gridAutoRows", "gridTemplateAreas", "gridTemplateColumns", "gridTemplateRows"],
    gridArea: ["gridColumnEnd", "gridColumnStart", "gridRowEnd", "gridRowStart"],
    gridColumn: ["gridColumnEnd", "gridColumnStart"],
    gridColumnGap: ["columnGap"],
    gridGap: ["columnGap", "rowGap"],
    gridRow: ["gridRowEnd", "gridRowStart"],
    gridRowGap: ["rowGap"],
    gridTemplate: ["gridTemplateAreas", "gridTemplateColumns", "gridTemplateRows"],
    listStyle: ["listStyleImage", "listStylePosition", "listStyleType"],
    margin: ["marginBottom", "marginLeft", "marginRight", "marginTop"],
    marker: ["markerEnd", "markerMid", "markerStart"],
    mask: ["maskClip", "maskComposite", "maskImage", "maskMode", "maskOrigin", "maskPositionX", "maskPositionY", "maskRepeat", "maskSize"],
    maskPosition: ["maskPositionX", "maskPositionY"],
    outline: ["outlineColor", "outlineStyle", "outlineWidth"],
    overflow: ["overflowX", "overflowY"],
    padding: ["paddingBottom", "paddingLeft", "paddingRight", "paddingTop"],
    placeContent: ["alignContent", "justifyContent"],
    placeItems: ["alignItems", "justifyItems"],
    placeSelf: ["alignSelf", "justifySelf"],
    textDecoration: ["textDecorationColor", "textDecorationLine", "textDecorationStyle"],
    textEmphasis: ["textEmphasisColor", "textEmphasisStyle"],
    transition: ["transitionDelay", "transitionDuration", "transitionProperty", "transitionTimingFunction"],
    wordWrap: ["overflowWrap"]
  }, ou = {
    animationIterationCount: !0,
    aspectRatio: !0,
    borderImageOutset: !0,
    borderImageSlice: !0,
    borderImageWidth: !0,
    boxFlex: !0,
    boxFlexGroup: !0,
    boxOrdinalGroup: !0,
    columnCount: !0,
    columns: !0,
    flex: !0,
    flexGrow: !0,
    flexPositive: !0,
    flexShrink: !0,
    flexNegative: !0,
    flexOrder: !0,
    gridArea: !0,
    gridRow: !0,
    gridRowEnd: !0,
    gridRowSpan: !0,
    gridRowStart: !0,
    gridColumn: !0,
    gridColumnEnd: !0,
    gridColumnSpan: !0,
    gridColumnStart: !0,
    fontWeight: !0,
    lineClamp: !0,
    lineHeight: !0,
    opacity: !0,
    order: !0,
    orphans: !0,
    tabSize: !0,
    widows: !0,
    zIndex: !0,
    zoom: !0,
    // SVG-related properties
    fillOpacity: !0,
    floodOpacity: !0,
    stopOpacity: !0,
    strokeDasharray: !0,
    strokeDashoffset: !0,
    strokeMiterlimit: !0,
    strokeOpacity: !0,
    strokeWidth: !0
  };
  function Fx(e, t) {
    return e + t.charAt(0).toUpperCase() + t.substring(1);
  }
  var zx = ["Webkit", "ms", "Moz", "O"];
  Object.keys(ou).forEach(function(e) {
    zx.forEach(function(t) {
      ou[Fx(t, e)] = ou[e];
    });
  });
  function cp(e, t, n) {
    var r = t == null || typeof t == "boolean" || t === "";
    return r ? "" : !n && typeof t == "number" && t !== 0 && !(ou.hasOwnProperty(e) && ou[e]) ? t + "px" : (Ar(t, e), ("" + t).trim());
  }
  var Hx = /([A-Z])/g, $x = /^ms-/;
  function Ix(e) {
    return e.replace(Hx, "-$1").toLowerCase().replace($x, "-ms-");
  }
  var bg = function() {
  };
  {
    var Bx = /^(?:webkit|moz|o)[A-Z]/, Vx = /^-ms-/, Yx = /-(.)/g, Sg = /;\s*$/, Fo = {}, fp = {}, Cg = !1, Eg = !1, Wx = function(e) {
      return e.replace(Yx, function(t, n) {
        return n.toUpperCase();
      });
    }, Gx = function(e) {
      Fo.hasOwnProperty(e) && Fo[e] || (Fo[e] = !0, c(
        "Unsupported style property %s. Did you mean %s?",
        e,
        // As Andi Smith suggests
        // (http://www.andismith.com/blog/2012/02/modernizr-prefixed/), an `-ms` prefix
        // is converted to lowercase `ms`.
        Wx(e.replace(Vx, "ms-"))
      ));
    }, Xx = function(e) {
      Fo.hasOwnProperty(e) && Fo[e] || (Fo[e] = !0, c("Unsupported vendor-prefixed style property %s. Did you mean %s?", e, e.charAt(0).toUpperCase() + e.slice(1)));
    }, Kx = function(e, t) {
      fp.hasOwnProperty(t) && fp[t] || (fp[t] = !0, c(`Style property values shouldn't contain a semicolon. Try "%s: %s" instead.`, e, t.replace(Sg, "")));
    }, qx = function(e, t) {
      Cg || (Cg = !0, c("`NaN` is an invalid value for the `%s` css style property.", e));
    }, Qx = function(e, t) {
      Eg || (Eg = !0, c("`Infinity` is an invalid value for the `%s` css style property.", e));
    };
    bg = function(e, t) {
      e.indexOf("-") > -1 ? Gx(e) : Bx.test(e) ? Xx(e) : Sg.test(t) && Kx(e, t), typeof t == "number" && (isNaN(t) ? qx(e, t) : isFinite(t) || Qx(e, t));
    };
  }
  var Zx = bg;
  function Jx(e) {
    {
      var t = "", n = "";
      for (var r in e)
        if (e.hasOwnProperty(r)) {
          var i = e[r];
          if (i != null) {
            var l = r.indexOf("--") === 0;
            t += n + (l ? r : Ix(r)) + ":", t += cp(r, i, l), n = ";";
          }
        }
      return t || null;
    }
  }
  function Rg(e, t) {
    var n = e.style;
    for (var r in t)
      if (t.hasOwnProperty(r)) {
        var i = r.indexOf("--") === 0;
        i || Zx(r, t[r]);
        var l = cp(r, t[r], i);
        r === "float" && (r = "cssFloat"), i ? n.setProperty(r, l) : n[r] = l;
      }
  }
  function eT(e) {
    return e == null || typeof e == "boolean" || e === "";
  }
  function wg(e) {
    var t = {};
    for (var n in e)
      for (var r = jx[n] || [n], i = 0; i < r.length; i++)
        t[r[i]] = n;
    return t;
  }
  function tT(e, t) {
    {
      if (!t)
        return;
      var n = wg(e), r = wg(t), i = {};
      for (var l in n) {
        var f = n[l], p = r[l];
        if (p && f !== p) {
          var m = f + "," + p;
          if (i[m])
            continue;
          i[m] = !0, c("%s a style property during rerender (%s) when a conflicting property is set (%s) can lead to styling bugs. To avoid this, don't mix shorthand and non-shorthand properties for the same value; instead, replace the shorthand with separate values.", eT(e[f]) ? "Removing" : "Updating", f, p);
        }
      }
    }
  }
  var nT = {
    area: !0,
    base: !0,
    br: !0,
    col: !0,
    embed: !0,
    hr: !0,
    img: !0,
    input: !0,
    keygen: !0,
    link: !0,
    meta: !0,
    param: !0,
    source: !0,
    track: !0,
    wbr: !0
    // NOTE: menuitem's close tag should be omitted, but that causes problems.
  }, rT = He({
    menuitem: !0
  }, nT), aT = "__html";
  function dp(e, t) {
    if (t) {
      if (rT[e] && (t.children != null || t.dangerouslySetInnerHTML != null))
        throw new Error(e + " is a void element tag and must neither have `children` nor use `dangerouslySetInnerHTML`.");
      if (t.dangerouslySetInnerHTML != null) {
        if (t.children != null)
          throw new Error("Can only set one of `children` or `props.dangerouslySetInnerHTML`.");
        if (typeof t.dangerouslySetInnerHTML != "object" || !(aT in t.dangerouslySetInnerHTML))
          throw new Error("`props.dangerouslySetInnerHTML` must be in the form `{__html: ...}`. Please visit https://reactjs.org/link/dangerously-set-inner-html for more information.");
      }
      if (!t.suppressContentEditableWarning && t.contentEditable && t.children != null && c("A component is `contentEditable` and contains `children` managed by React. It is now your responsibility to guarantee that none of those nodes are unexpectedly modified or duplicated. This is probably not intentional."), t.style != null && typeof t.style != "object")
        throw new Error("The `style` prop expects a mapping from style properties to values, not a string. For example, style={{marginRight: spacing + 'em'}} when using JSX.");
    }
  }
  function Gi(e, t) {
    if (e.indexOf("-") === -1)
      return typeof t.is == "string";
    switch (e) {
      case "annotation-xml":
      case "color-profile":
      case "font-face":
      case "font-face-src":
      case "font-face-uri":
      case "font-face-format":
      case "font-face-name":
      case "missing-glyph":
        return !1;
      default:
        return !0;
    }
  }
  var mc = {
    // HTML
    accept: "accept",
    acceptcharset: "acceptCharset",
    "accept-charset": "acceptCharset",
    accesskey: "accessKey",
    action: "action",
    allowfullscreen: "allowFullScreen",
    alt: "alt",
    as: "as",
    async: "async",
    autocapitalize: "autoCapitalize",
    autocomplete: "autoComplete",
    autocorrect: "autoCorrect",
    autofocus: "autoFocus",
    autoplay: "autoPlay",
    autosave: "autoSave",
    capture: "capture",
    cellpadding: "cellPadding",
    cellspacing: "cellSpacing",
    challenge: "challenge",
    charset: "charSet",
    checked: "checked",
    children: "children",
    cite: "cite",
    class: "className",
    classid: "classID",
    classname: "className",
    cols: "cols",
    colspan: "colSpan",
    content: "content",
    contenteditable: "contentEditable",
    contextmenu: "contextMenu",
    controls: "controls",
    controlslist: "controlsList",
    coords: "coords",
    crossorigin: "crossOrigin",
    dangerouslysetinnerhtml: "dangerouslySetInnerHTML",
    data: "data",
    datetime: "dateTime",
    default: "default",
    defaultchecked: "defaultChecked",
    defaultvalue: "defaultValue",
    defer: "defer",
    dir: "dir",
    disabled: "disabled",
    disablepictureinpicture: "disablePictureInPicture",
    disableremoteplayback: "disableRemotePlayback",
    download: "download",
    draggable: "draggable",
    enctype: "encType",
    enterkeyhint: "enterKeyHint",
    for: "htmlFor",
    form: "form",
    formmethod: "formMethod",
    formaction: "formAction",
    formenctype: "formEncType",
    formnovalidate: "formNoValidate",
    formtarget: "formTarget",
    frameborder: "frameBorder",
    headers: "headers",
    height: "height",
    hidden: "hidden",
    high: "high",
    href: "href",
    hreflang: "hrefLang",
    htmlfor: "htmlFor",
    httpequiv: "httpEquiv",
    "http-equiv": "httpEquiv",
    icon: "icon",
    id: "id",
    imagesizes: "imageSizes",
    imagesrcset: "imageSrcSet",
    innerhtml: "innerHTML",
    inputmode: "inputMode",
    integrity: "integrity",
    is: "is",
    itemid: "itemID",
    itemprop: "itemProp",
    itemref: "itemRef",
    itemscope: "itemScope",
    itemtype: "itemType",
    keyparams: "keyParams",
    keytype: "keyType",
    kind: "kind",
    label: "label",
    lang: "lang",
    list: "list",
    loop: "loop",
    low: "low",
    manifest: "manifest",
    marginwidth: "marginWidth",
    marginheight: "marginHeight",
    max: "max",
    maxlength: "maxLength",
    media: "media",
    mediagroup: "mediaGroup",
    method: "method",
    min: "min",
    minlength: "minLength",
    multiple: "multiple",
    muted: "muted",
    name: "name",
    nomodule: "noModule",
    nonce: "nonce",
    novalidate: "noValidate",
    open: "open",
    optimum: "optimum",
    pattern: "pattern",
    placeholder: "placeholder",
    playsinline: "playsInline",
    poster: "poster",
    preload: "preload",
    profile: "profile",
    radiogroup: "radioGroup",
    readonly: "readOnly",
    referrerpolicy: "referrerPolicy",
    rel: "rel",
    required: "required",
    reversed: "reversed",
    role: "role",
    rows: "rows",
    rowspan: "rowSpan",
    sandbox: "sandbox",
    scope: "scope",
    scoped: "scoped",
    scrolling: "scrolling",
    seamless: "seamless",
    selected: "selected",
    shape: "shape",
    size: "size",
    sizes: "sizes",
    span: "span",
    spellcheck: "spellCheck",
    src: "src",
    srcdoc: "srcDoc",
    srclang: "srcLang",
    srcset: "srcSet",
    start: "start",
    step: "step",
    style: "style",
    summary: "summary",
    tabindex: "tabIndex",
    target: "target",
    title: "title",
    type: "type",
    usemap: "useMap",
    value: "value",
    width: "width",
    wmode: "wmode",
    wrap: "wrap",
    // SVG
    about: "about",
    accentheight: "accentHeight",
    "accent-height": "accentHeight",
    accumulate: "accumulate",
    additive: "additive",
    alignmentbaseline: "alignmentBaseline",
    "alignment-baseline": "alignmentBaseline",
    allowreorder: "allowReorder",
    alphabetic: "alphabetic",
    amplitude: "amplitude",
    arabicform: "arabicForm",
    "arabic-form": "arabicForm",
    ascent: "ascent",
    attributename: "attributeName",
    attributetype: "attributeType",
    autoreverse: "autoReverse",
    azimuth: "azimuth",
    basefrequency: "baseFrequency",
    baselineshift: "baselineShift",
    "baseline-shift": "baselineShift",
    baseprofile: "baseProfile",
    bbox: "bbox",
    begin: "begin",
    bias: "bias",
    by: "by",
    calcmode: "calcMode",
    capheight: "capHeight",
    "cap-height": "capHeight",
    clip: "clip",
    clippath: "clipPath",
    "clip-path": "clipPath",
    clippathunits: "clipPathUnits",
    cliprule: "clipRule",
    "clip-rule": "clipRule",
    color: "color",
    colorinterpolation: "colorInterpolation",
    "color-interpolation": "colorInterpolation",
    colorinterpolationfilters: "colorInterpolationFilters",
    "color-interpolation-filters": "colorInterpolationFilters",
    colorprofile: "colorProfile",
    "color-profile": "colorProfile",
    colorrendering: "colorRendering",
    "color-rendering": "colorRendering",
    contentscripttype: "contentScriptType",
    contentstyletype: "contentStyleType",
    cursor: "cursor",
    cx: "cx",
    cy: "cy",
    d: "d",
    datatype: "datatype",
    decelerate: "decelerate",
    descent: "descent",
    diffuseconstant: "diffuseConstant",
    direction: "direction",
    display: "display",
    divisor: "divisor",
    dominantbaseline: "dominantBaseline",
    "dominant-baseline": "dominantBaseline",
    dur: "dur",
    dx: "dx",
    dy: "dy",
    edgemode: "edgeMode",
    elevation: "elevation",
    enablebackground: "enableBackground",
    "enable-background": "enableBackground",
    end: "end",
    exponent: "exponent",
    externalresourcesrequired: "externalResourcesRequired",
    fill: "fill",
    fillopacity: "fillOpacity",
    "fill-opacity": "fillOpacity",
    fillrule: "fillRule",
    "fill-rule": "fillRule",
    filter: "filter",
    filterres: "filterRes",
    filterunits: "filterUnits",
    floodopacity: "floodOpacity",
    "flood-opacity": "floodOpacity",
    floodcolor: "floodColor",
    "flood-color": "floodColor",
    focusable: "focusable",
    fontfamily: "fontFamily",
    "font-family": "fontFamily",
    fontsize: "fontSize",
    "font-size": "fontSize",
    fontsizeadjust: "fontSizeAdjust",
    "font-size-adjust": "fontSizeAdjust",
    fontstretch: "fontStretch",
    "font-stretch": "fontStretch",
    fontstyle: "fontStyle",
    "font-style": "fontStyle",
    fontvariant: "fontVariant",
    "font-variant": "fontVariant",
    fontweight: "fontWeight",
    "font-weight": "fontWeight",
    format: "format",
    from: "from",
    fx: "fx",
    fy: "fy",
    g1: "g1",
    g2: "g2",
    glyphname: "glyphName",
    "glyph-name": "glyphName",
    glyphorientationhorizontal: "glyphOrientationHorizontal",
    "glyph-orientation-horizontal": "glyphOrientationHorizontal",
    glyphorientationvertical: "glyphOrientationVertical",
    "glyph-orientation-vertical": "glyphOrientationVertical",
    glyphref: "glyphRef",
    gradienttransform: "gradientTransform",
    gradientunits: "gradientUnits",
    hanging: "hanging",
    horizadvx: "horizAdvX",
    "horiz-adv-x": "horizAdvX",
    horizoriginx: "horizOriginX",
    "horiz-origin-x": "horizOriginX",
    ideographic: "ideographic",
    imagerendering: "imageRendering",
    "image-rendering": "imageRendering",
    in2: "in2",
    in: "in",
    inlist: "inlist",
    intercept: "intercept",
    k1: "k1",
    k2: "k2",
    k3: "k3",
    k4: "k4",
    k: "k",
    kernelmatrix: "kernelMatrix",
    kernelunitlength: "kernelUnitLength",
    kerning: "kerning",
    keypoints: "keyPoints",
    keysplines: "keySplines",
    keytimes: "keyTimes",
    lengthadjust: "lengthAdjust",
    letterspacing: "letterSpacing",
    "letter-spacing": "letterSpacing",
    lightingcolor: "lightingColor",
    "lighting-color": "lightingColor",
    limitingconeangle: "limitingConeAngle",
    local: "local",
    markerend: "markerEnd",
    "marker-end": "markerEnd",
    markerheight: "markerHeight",
    markermid: "markerMid",
    "marker-mid": "markerMid",
    markerstart: "markerStart",
    "marker-start": "markerStart",
    markerunits: "markerUnits",
    markerwidth: "markerWidth",
    mask: "mask",
    maskcontentunits: "maskContentUnits",
    maskunits: "maskUnits",
    mathematical: "mathematical",
    mode: "mode",
    numoctaves: "numOctaves",
    offset: "offset",
    opacity: "opacity",
    operator: "operator",
    order: "order",
    orient: "orient",
    orientation: "orientation",
    origin: "origin",
    overflow: "overflow",
    overlineposition: "overlinePosition",
    "overline-position": "overlinePosition",
    overlinethickness: "overlineThickness",
    "overline-thickness": "overlineThickness",
    paintorder: "paintOrder",
    "paint-order": "paintOrder",
    panose1: "panose1",
    "panose-1": "panose1",
    pathlength: "pathLength",
    patterncontentunits: "patternContentUnits",
    patterntransform: "patternTransform",
    patternunits: "patternUnits",
    pointerevents: "pointerEvents",
    "pointer-events": "pointerEvents",
    points: "points",
    pointsatx: "pointsAtX",
    pointsaty: "pointsAtY",
    pointsatz: "pointsAtZ",
    prefix: "prefix",
    preservealpha: "preserveAlpha",
    preserveaspectratio: "preserveAspectRatio",
    primitiveunits: "primitiveUnits",
    property: "property",
    r: "r",
    radius: "radius",
    refx: "refX",
    refy: "refY",
    renderingintent: "renderingIntent",
    "rendering-intent": "renderingIntent",
    repeatcount: "repeatCount",
    repeatdur: "repeatDur",
    requiredextensions: "requiredExtensions",
    requiredfeatures: "requiredFeatures",
    resource: "resource",
    restart: "restart",
    result: "result",
    results: "results",
    rotate: "rotate",
    rx: "rx",
    ry: "ry",
    scale: "scale",
    security: "security",
    seed: "seed",
    shaperendering: "shapeRendering",
    "shape-rendering": "shapeRendering",
    slope: "slope",
    spacing: "spacing",
    specularconstant: "specularConstant",
    specularexponent: "specularExponent",
    speed: "speed",
    spreadmethod: "spreadMethod",
    startoffset: "startOffset",
    stddeviation: "stdDeviation",
    stemh: "stemh",
    stemv: "stemv",
    stitchtiles: "stitchTiles",
    stopcolor: "stopColor",
    "stop-color": "stopColor",
    stopopacity: "stopOpacity",
    "stop-opacity": "stopOpacity",
    strikethroughposition: "strikethroughPosition",
    "strikethrough-position": "strikethroughPosition",
    strikethroughthickness: "strikethroughThickness",
    "strikethrough-thickness": "strikethroughThickness",
    string: "string",
    stroke: "stroke",
    strokedasharray: "strokeDasharray",
    "stroke-dasharray": "strokeDasharray",
    strokedashoffset: "strokeDashoffset",
    "stroke-dashoffset": "strokeDashoffset",
    strokelinecap: "strokeLinecap",
    "stroke-linecap": "strokeLinecap",
    strokelinejoin: "strokeLinejoin",
    "stroke-linejoin": "strokeLinejoin",
    strokemiterlimit: "strokeMiterlimit",
    "stroke-miterlimit": "strokeMiterlimit",
    strokewidth: "strokeWidth",
    "stroke-width": "strokeWidth",
    strokeopacity: "strokeOpacity",
    "stroke-opacity": "strokeOpacity",
    suppresscontenteditablewarning: "suppressContentEditableWarning",
    suppresshydrationwarning: "suppressHydrationWarning",
    surfacescale: "surfaceScale",
    systemlanguage: "systemLanguage",
    tablevalues: "tableValues",
    targetx: "targetX",
    targety: "targetY",
    textanchor: "textAnchor",
    "text-anchor": "textAnchor",
    textdecoration: "textDecoration",
    "text-decoration": "textDecoration",
    textlength: "textLength",
    textrendering: "textRendering",
    "text-rendering": "textRendering",
    to: "to",
    transform: "transform",
    typeof: "typeof",
    u1: "u1",
    u2: "u2",
    underlineposition: "underlinePosition",
    "underline-position": "underlinePosition",
    underlinethickness: "underlineThickness",
    "underline-thickness": "underlineThickness",
    unicode: "unicode",
    unicodebidi: "unicodeBidi",
    "unicode-bidi": "unicodeBidi",
    unicoderange: "unicodeRange",
    "unicode-range": "unicodeRange",
    unitsperem: "unitsPerEm",
    "units-per-em": "unitsPerEm",
    unselectable: "unselectable",
    valphabetic: "vAlphabetic",
    "v-alphabetic": "vAlphabetic",
    values: "values",
    vectoreffect: "vectorEffect",
    "vector-effect": "vectorEffect",
    version: "version",
    vertadvy: "vertAdvY",
    "vert-adv-y": "vertAdvY",
    vertoriginx: "vertOriginX",
    "vert-origin-x": "vertOriginX",
    vertoriginy: "vertOriginY",
    "vert-origin-y": "vertOriginY",
    vhanging: "vHanging",
    "v-hanging": "vHanging",
    videographic: "vIdeographic",
    "v-ideographic": "vIdeographic",
    viewbox: "viewBox",
    viewtarget: "viewTarget",
    visibility: "visibility",
    vmathematical: "vMathematical",
    "v-mathematical": "vMathematical",
    vocab: "vocab",
    widths: "widths",
    wordspacing: "wordSpacing",
    "word-spacing": "wordSpacing",
    writingmode: "writingMode",
    "writing-mode": "writingMode",
    x1: "x1",
    x2: "x2",
    x: "x",
    xchannelselector: "xChannelSelector",
    xheight: "xHeight",
    "x-height": "xHeight",
    xlinkactuate: "xlinkActuate",
    "xlink:actuate": "xlinkActuate",
    xlinkarcrole: "xlinkArcrole",
    "xlink:arcrole": "xlinkArcrole",
    xlinkhref: "xlinkHref",
    "xlink:href": "xlinkHref",
    xlinkrole: "xlinkRole",
    "xlink:role": "xlinkRole",
    xlinkshow: "xlinkShow",
    "xlink:show": "xlinkShow",
    xlinktitle: "xlinkTitle",
    "xlink:title": "xlinkTitle",
    xlinktype: "xlinkType",
    "xlink:type": "xlinkType",
    xmlbase: "xmlBase",
    "xml:base": "xmlBase",
    xmllang: "xmlLang",
    "xml:lang": "xmlLang",
    xmlns: "xmlns",
    "xml:space": "xmlSpace",
    xmlnsxlink: "xmlnsXlink",
    "xmlns:xlink": "xmlnsXlink",
    xmlspace: "xmlSpace",
    y1: "y1",
    y2: "y2",
    y: "y",
    ychannelselector: "yChannelSelector",
    z: "z",
    zoomandpan: "zoomAndPan"
  }, xg = {
    "aria-current": 0,
    // state
    "aria-description": 0,
    "aria-details": 0,
    "aria-disabled": 0,
    // state
    "aria-hidden": 0,
    // state
    "aria-invalid": 0,
    // state
    "aria-keyshortcuts": 0,
    "aria-label": 0,
    "aria-roledescription": 0,
    // Widget Attributes
    "aria-autocomplete": 0,
    "aria-checked": 0,
    "aria-expanded": 0,
    "aria-haspopup": 0,
    "aria-level": 0,
    "aria-modal": 0,
    "aria-multiline": 0,
    "aria-multiselectable": 0,
    "aria-orientation": 0,
    "aria-placeholder": 0,
    "aria-pressed": 0,
    "aria-readonly": 0,
    "aria-required": 0,
    "aria-selected": 0,
    "aria-sort": 0,
    "aria-valuemax": 0,
    "aria-valuemin": 0,
    "aria-valuenow": 0,
    "aria-valuetext": 0,
    // Live Region Attributes
    "aria-atomic": 0,
    "aria-busy": 0,
    "aria-live": 0,
    "aria-relevant": 0,
    // Drag-and-Drop Attributes
    "aria-dropeffect": 0,
    "aria-grabbed": 0,
    // Relationship Attributes
    "aria-activedescendant": 0,
    "aria-colcount": 0,
    "aria-colindex": 0,
    "aria-colspan": 0,
    "aria-controls": 0,
    "aria-describedby": 0,
    "aria-errormessage": 0,
    "aria-flowto": 0,
    "aria-labelledby": 0,
    "aria-owns": 0,
    "aria-posinset": 0,
    "aria-rowcount": 0,
    "aria-rowindex": 0,
    "aria-rowspan": 0,
    "aria-setsize": 0
  }, zo = {}, iT = new RegExp("^(aria)-[" + be + "]*$"), oT = new RegExp("^(aria)[A-Z][" + be + "]*$");
  function lT(e, t) {
    {
      if (Gt.call(zo, t) && zo[t])
        return !0;
      if (oT.test(t)) {
        var n = "aria-" + t.slice(4).toLowerCase(), r = xg.hasOwnProperty(n) ? n : null;
        if (r == null)
          return c("Invalid ARIA attribute `%s`. ARIA attributes follow the pattern aria-* and must be lowercase.", t), zo[t] = !0, !0;
        if (t !== r)
          return c("Invalid ARIA attribute `%s`. Did you mean `%s`?", t, r), zo[t] = !0, !0;
      }
      if (iT.test(t)) {
        var i = t.toLowerCase(), l = xg.hasOwnProperty(i) ? i : null;
        if (l == null)
          return zo[t] = !0, !1;
        if (t !== l)
          return c("Unknown ARIA attribute `%s`. Did you mean `%s`?", t, l), zo[t] = !0, !0;
      }
    }
    return !0;
  }
  function uT(e, t) {
    {
      var n = [];
      for (var r in t) {
        var i = lT(e, r);
        i || n.push(r);
      }
      var l = n.map(function(f) {
        return "`" + f + "`";
      }).join(", ");
      n.length === 1 ? c("Invalid aria prop %s on <%s> tag. For details, see https://reactjs.org/link/invalid-aria-props", l, e) : n.length > 1 && c("Invalid aria props %s on <%s> tag. For details, see https://reactjs.org/link/invalid-aria-props", l, e);
    }
  }
  function sT(e, t) {
    Gi(e, t) || uT(e, t);
  }
  var Tg = !1;
  function cT(e, t) {
    {
      if (e !== "input" && e !== "textarea" && e !== "select")
        return;
      t != null && t.value === null && !Tg && (Tg = !0, e === "select" && t.multiple ? c("`value` prop on `%s` should not be null. Consider using an empty array when `multiple` is set to `true` to clear the component or `undefined` for uncontrolled components.", e) : c("`value` prop on `%s` should not be null. Consider using an empty string to clear the component or `undefined` for uncontrolled components.", e));
    }
  }
  var Dg = function() {
  };
  {
    var Fn = {}, _g = /^on./, fT = /^on[^A-Z]/, dT = new RegExp("^(aria)-[" + be + "]*$"), pT = new RegExp("^(aria)[A-Z][" + be + "]*$");
    Dg = function(e, t, n, r) {
      if (Gt.call(Fn, t) && Fn[t])
        return !0;
      var i = t.toLowerCase();
      if (i === "onfocusin" || i === "onfocusout")
        return c("React uses onFocus and onBlur instead of onFocusIn and onFocusOut. All React events are normalized to bubble, so onFocusIn and onFocusOut are not needed/supported by React."), Fn[t] = !0, !0;
      if (r != null) {
        var l = r.registrationNameDependencies, f = r.possibleRegistrationNames;
        if (l.hasOwnProperty(t))
          return !0;
        var p = f.hasOwnProperty(i) ? f[i] : null;
        if (p != null)
          return c("Invalid event handler property `%s`. Did you mean `%s`?", t, p), Fn[t] = !0, !0;
        if (_g.test(t))
          return c("Unknown event handler property `%s`. It will be ignored.", t), Fn[t] = !0, !0;
      } else if (_g.test(t))
        return fT.test(t) && c("Invalid event handler property `%s`. React events use the camelCase naming convention, for example `onClick`.", t), Fn[t] = !0, !0;
      if (dT.test(t) || pT.test(t))
        return !0;
      if (i === "innerhtml")
        return c("Directly setting property `innerHTML` is not permitted. For more information, lookup documentation on `dangerouslySetInnerHTML`."), Fn[t] = !0, !0;
      if (i === "aria")
        return c("The `aria` attribute is reserved for future use in React. Pass individual `aria-` attributes instead."), Fn[t] = !0, !0;
      if (i === "is" && n !== null && n !== void 0 && typeof n != "string")
        return c("Received a `%s` for a string attribute `is`. If this is expected, cast the value to a string.", typeof n), Fn[t] = !0, !0;
      if (typeof n == "number" && isNaN(n))
        return c("Received NaN for the `%s` attribute. If this is expected, cast the value to a string.", t), Fn[t] = !0, !0;
      var m = nr(t), C = m !== null && m.type === gr;
      if (mc.hasOwnProperty(i)) {
        var w = mc[i];
        if (w !== t)
          return c("Invalid DOM property `%s`. Did you mean `%s`?", t, w), Fn[t] = !0, !0;
      } else if (!C && t !== i)
        return c("React does not recognize the `%s` prop on a DOM element. If you intentionally want it to appear in the DOM as a custom attribute, spell it as lowercase `%s` instead. If you accidentally passed it from a parent component, remove it from the DOM element.", t, i), Fn[t] = !0, !0;
      return typeof n == "boolean" && Gn(t, n, m, !1) ? (n ? c('Received `%s` for a non-boolean attribute `%s`.\n\nIf you want to write it to the DOM, pass a string instead: %s="%s" or %s={value.toString()}.', n, t, t, n, t) : c('Received `%s` for a non-boolean attribute `%s`.\n\nIf you want to write it to the DOM, pass a string instead: %s="%s" or %s={value.toString()}.\n\nIf you used to conditionally omit it with %s={condition && value}, pass %s={condition ? value : undefined} instead.', n, t, t, n, t, t, t), Fn[t] = !0, !0) : C ? !0 : Gn(t, n, m, !1) ? (Fn[t] = !0, !1) : ((n === "false" || n === "true") && m !== null && m.type === Pt && (c("Received the string `%s` for the boolean attribute `%s`. %s Did you mean %s={%s}?", n, t, n === "false" ? "The browser will interpret it as a truthy value." : 'Although this works, it will not work as expected if you pass the string "false".', t, n), Fn[t] = !0), !0);
    };
  }
  var vT = function(e, t, n) {
    {
      var r = [];
      for (var i in t) {
        var l = Dg(e, i, t[i], n);
        l || r.push(i);
      }
      var f = r.map(function(p) {
        return "`" + p + "`";
      }).join(", ");
      r.length === 1 ? c("Invalid value for prop %s on <%s> tag. Either remove it from the element, or pass a string or number value to keep it in the DOM. For details, see https://reactjs.org/link/attribute-behavior ", f, e) : r.length > 1 && c("Invalid values for props %s on <%s> tag. Either remove them from the element, or pass a string or number value to keep them in the DOM. For details, see https://reactjs.org/link/attribute-behavior ", f, e);
    }
  };
  function hT(e, t, n) {
    Gi(e, t) || vT(e, t, n);
  }
  var Mg = 1, pp = 2, lu = 4, mT = Mg | pp | lu, uu = null;
  function yT(e) {
    uu !== null && c("Expected currently replaying event to be null. This error is likely caused by a bug in React. Please file an issue."), uu = e;
  }
  function gT() {
    uu === null && c("Expected currently replaying event to not be null. This error is likely caused by a bug in React. Please file an issue."), uu = null;
  }
  function bT(e) {
    return e === uu;
  }
  function vp(e) {
    var t = e.target || e.srcElement || window;
    return t.correspondingUseElement && (t = t.correspondingUseElement), t.nodeType === Ma ? t.parentNode : t;
  }
  var hp = null, Ho = null, $o = null;
  function Og(e) {
    var t = hi(e);
    if (t) {
      if (typeof hp != "function")
        throw new Error("setRestoreImplementation() needs to be called to handle a target for controlled events. This error is likely caused by a bug in React. Please file an issue.");
      var n = t.stateNode;
      if (n) {
        var r = Jc(n);
        hp(t.stateNode, t.type, r);
      }
    }
  }
  function ST(e) {
    hp = e;
  }
  function Ag(e) {
    Ho ? $o ? $o.push(e) : $o = [e] : Ho = e;
  }
  function CT() {
    return Ho !== null || $o !== null;
  }
  function Ng() {
    if (Ho) {
      var e = Ho, t = $o;
      if (Ho = null, $o = null, Og(e), t)
        for (var n = 0; n < t.length; n++)
          Og(t[n]);
    }
  }
  var Lg = function(e, t) {
    return e(t);
  }, kg = function() {
  }, mp = !1;
  function ET() {
    var e = CT();
    e && (kg(), Ng());
  }
  function Pg(e, t, n) {
    if (mp)
      return e(t, n);
    mp = !0;
    try {
      return Lg(e, t, n);
    } finally {
      mp = !1, ET();
    }
  }
  function RT(e, t, n) {
    Lg = e, kg = n;
  }
  function wT(e) {
    return e === "button" || e === "input" || e === "select" || e === "textarea";
  }
  function xT(e, t, n) {
    switch (e) {
      case "onClick":
      case "onClickCapture":
      case "onDoubleClick":
      case "onDoubleClickCapture":
      case "onMouseDown":
      case "onMouseDownCapture":
      case "onMouseMove":
      case "onMouseMoveCapture":
      case "onMouseUp":
      case "onMouseUpCapture":
      case "onMouseEnter":
        return !!(n.disabled && wT(t));
      default:
        return !1;
    }
  }
  function su(e, t) {
    var n = e.stateNode;
    if (n === null)
      return null;
    var r = Jc(n);
    if (r === null)
      return null;
    var i = r[t];
    if (xT(t, e.type, r))
      return null;
    if (i && typeof i != "function")
      throw new Error("Expected `" + t + "` listener to be a function, instead got a value of `" + typeof i + "` type.");
    return i;
  }
  var yp = !1;
  if (yt)
    try {
      var cu = {};
      Object.defineProperty(cu, "passive", {
        get: function() {
          yp = !0;
        }
      }), window.addEventListener("test", cu, cu), window.removeEventListener("test", cu, cu);
    } catch {
      yp = !1;
    }
  function Ug(e, t, n, r, i, l, f, p, m) {
    var C = Array.prototype.slice.call(arguments, 3);
    try {
      t.apply(n, C);
    } catch (w) {
      this.onError(w);
    }
  }
  var jg = Ug;
  if (typeof window < "u" && typeof window.dispatchEvent == "function" && typeof document < "u" && typeof document.createEvent == "function") {
    var gp = document.createElement("react");
    jg = function(t, n, r, i, l, f, p, m, C) {
      if (typeof document > "u" || document === null)
        throw new Error("The `document` global was defined when React was initialized, but is not defined anymore. This can happen in a test environment if a component schedules an update from an asynchronous callback, but the test has already finished running. To solve this, you can either unmount the component at the end of your test (and ensure that any asynchronous operations get canceled in `componentWillUnmount`), or you can change the test itself to be asynchronous.");
      var w = document.createEvent("Event"), N = !1, A = !0, j = window.event, H = Object.getOwnPropertyDescriptor(window, "event");
      function B() {
        gp.removeEventListener(V, Ce, !1), typeof window.event < "u" && window.hasOwnProperty("event") && (window.event = j);
      }
      var ae = Array.prototype.slice.call(arguments, 3);
      function Ce() {
        N = !0, B(), n.apply(r, ae), A = !1;
      }
      var ye, Ge = !1, $e = !1;
      function k(P) {
        if (ye = P.error, Ge = !0, ye === null && P.colno === 0 && P.lineno === 0 && ($e = !0), P.defaultPrevented && ye != null && typeof ye == "object")
          try {
            ye._suppressLogging = !0;
          } catch {
          }
      }
      var V = "react-" + (t || "invokeguardedcallback");
      if (window.addEventListener("error", k), gp.addEventListener(V, Ce, !1), w.initEvent(V, !1, !1), gp.dispatchEvent(w), H && Object.defineProperty(window, "event", H), N && A && (Ge ? $e && (ye = new Error("A cross-origin error was thrown. React doesn't have access to the actual error object in development. See https://reactjs.org/link/crossorigin-error for more information.")) : ye = new Error(`An error was thrown inside one of your components, but React doesn't know what it was. This is likely due to browser flakiness. React does its best to preserve the "Pause on exceptions" behavior of the DevTools, which requires some DEV-mode only tricks. It's possible that these don't work in your browser. Try triggering the error in production mode, or switching to a modern browser. If you suspect that this is actually an issue with React, please file an issue.`), this.onError(ye)), window.removeEventListener("error", k), !N)
        return B(), Ug.apply(this, arguments);
    };
  }
  var TT = jg, Io = !1, yc = null, gc = !1, bp = null, DT = {
    onError: function(e) {
      Io = !0, yc = e;
    }
  };
  function Sp(e, t, n, r, i, l, f, p, m) {
    Io = !1, yc = null, TT.apply(DT, arguments);
  }
  function _T(e, t, n, r, i, l, f, p, m) {
    if (Sp.apply(this, arguments), Io) {
      var C = Cp();
      gc || (gc = !0, bp = C);
    }
  }
  function MT() {
    if (gc) {
      var e = bp;
      throw gc = !1, bp = null, e;
    }
  }
  function OT() {
    return Io;
  }
  function Cp() {
    if (Io) {
      var e = yc;
      return Io = !1, yc = null, e;
    } else
      throw new Error("clearCaughtError was called but no error was captured. This error is likely caused by a bug in React. Please file an issue.");
  }
  function Bo(e) {
    return e._reactInternals;
  }
  function AT(e) {
    return e._reactInternals !== void 0;
  }
  function NT(e, t) {
    e._reactInternals = t;
  }
  var Te = (
    /*                      */
    0
  ), Vo = (
    /*                */
    1
  ), It = (
    /*                    */
    2
  ), qe = (
    /*                       */
    4
  ), Xi = (
    /*                */
    16
  ), fu = (
    /*                 */
    32
  ), Ep = (
    /*                     */
    64
  ), nt = (
    /*                   */
    128
  ), Aa = (
    /*            */
    256
  ), ui = (
    /*                          */
    512
  ), Ki = (
    /*                     */
    1024
  ), Pr = (
    /*                      */
    2048
  ), Na = (
    /*                    */
    4096
  ), qi = (
    /*                   */
    8192
  ), bc = (
    /*             */
    16384
  ), LT = Pr | qe | Ep | ui | Ki | bc, kT = (
    /*               */
    32767
  ), du = (
    /*                   */
    32768
  ), zn = (
    /*                */
    65536
  ), Rp = (
    /* */
    131072
  ), Fg = (
    /*                       */
    1048576
  ), wp = (
    /*                    */
    2097152
  ), Qi = (
    /*                 */
    4194304
  ), xp = (
    /*                */
    8388608
  ), La = (
    /*               */
    16777216
  ), Sc = (
    /*              */
    33554432
  ), Tp = (
    // TODO: Remove Update flag from before mutation phase by re-landing Visibility
    // flag logic (see #20043)
    qe | Ki | 0
  ), Dp = It | qe | Xi | fu | ui | Na | qi, pu = qe | Ep | ui | qi, Yo = Pr | Xi, ka = Qi | xp | wp, PT = u.ReactCurrentOwner;
  function Zi(e) {
    var t = e, n = e;
    if (e.alternate)
      for (; t.return; )
        t = t.return;
    else {
      var r = t;
      do
        t = r, (t.flags & (It | Na)) !== Te && (n = t.return), r = t.return;
      while (r);
    }
    return t.tag === E ? n : null;
  }
  function zg(e) {
    if (e.tag === W) {
      var t = e.memoizedState;
      if (t === null) {
        var n = e.alternate;
        n !== null && (t = n.memoizedState);
      }
      if (t !== null)
        return t.dehydrated;
    }
    return null;
  }
  function Hg(e) {
    return e.tag === E ? e.stateNode.containerInfo : null;
  }
  function UT(e) {
    return Zi(e) === e;
  }
  function jT(e) {
    {
      var t = PT.current;
      if (t !== null && t.tag === S) {
        var n = t, r = n.stateNode;
        r._warnedAboutRefsInRender || c("%s is accessing isMounted inside its render() function. render() should be a pure function of props and state. It should never access something that requires stale data from the previous render, such as refs. Move this logic to componentDidMount and componentDidUpdate instead.", Pe(n) || "A component"), r._warnedAboutRefsInRender = !0;
      }
    }
    var i = Bo(e);
    return i ? Zi(i) === i : !1;
  }
  function $g(e) {
    if (Zi(e) !== e)
      throw new Error("Unable to find node on an unmounted component.");
  }
  function Ig(e) {
    var t = e.alternate;
    if (!t) {
      var n = Zi(e);
      if (n === null)
        throw new Error("Unable to find node on an unmounted component.");
      return n !== e ? null : e;
    }
    for (var r = e, i = t; ; ) {
      var l = r.return;
      if (l === null)
        break;
      var f = l.alternate;
      if (f === null) {
        var p = l.return;
        if (p !== null) {
          r = i = p;
          continue;
        }
        break;
      }
      if (l.child === f.child) {
        for (var m = l.child; m; ) {
          if (m === r)
            return $g(l), e;
          if (m === i)
            return $g(l), t;
          m = m.sibling;
        }
        throw new Error("Unable to find node on an unmounted component.");
      }
      if (r.return !== i.return)
        r = l, i = f;
      else {
        for (var C = !1, w = l.child; w; ) {
          if (w === r) {
            C = !0, r = l, i = f;
            break;
          }
          if (w === i) {
            C = !0, i = l, r = f;
            break;
          }
          w = w.sibling;
        }
        if (!C) {
          for (w = f.child; w; ) {
            if (w === r) {
              C = !0, r = f, i = l;
              break;
            }
            if (w === i) {
              C = !0, i = f, r = l;
              break;
            }
            w = w.sibling;
          }
          if (!C)
            throw new Error("Child was not found in either parent set. This indicates a bug in React related to the return pointer. Please file an issue.");
        }
      }
      if (r.alternate !== i)
        throw new Error("Return fibers should always be each others' alternates. This error is likely caused by a bug in React. Please file an issue.");
    }
    if (r.tag !== E)
      throw new Error("Unable to find node on an unmounted component.");
    return r.stateNode.current === r ? e : t;
  }
  function Bg(e) {
    var t = Ig(e);
    return t !== null ? Vg(t) : null;
  }
  function Vg(e) {
    if (e.tag === T || e.tag === M)
      return e;
    for (var t = e.child; t !== null; ) {
      var n = Vg(t);
      if (n !== null)
        return n;
      t = t.sibling;
    }
    return null;
  }
  function FT(e) {
    var t = Ig(e);
    return t !== null ? Yg(t) : null;
  }
  function Yg(e) {
    if (e.tag === T || e.tag === M)
      return e;
    for (var t = e.child; t !== null; ) {
      if (t.tag !== x) {
        var n = Yg(t);
        if (n !== null)
          return n;
      }
      t = t.sibling;
    }
    return null;
  }
  var Wg = o.unstable_scheduleCallback, zT = o.unstable_cancelCallback, HT = o.unstable_shouldYield, $T = o.unstable_requestPaint, un = o.unstable_now, IT = o.unstable_getCurrentPriorityLevel, Cc = o.unstable_ImmediatePriority, _p = o.unstable_UserBlockingPriority, Ji = o.unstable_NormalPriority, BT = o.unstable_LowPriority, Mp = o.unstable_IdlePriority, VT = o.unstable_yieldValue, YT = o.unstable_setDisableYieldValue, Wo = null, Mn = null, oe = null, ra = !1, Ur = typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u";
  function WT(e) {
    if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u")
      return !1;
    var t = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (t.isDisabled)
      return !0;
    if (!t.supportsFiber)
      return c("The installed version of React DevTools is too old and will not work with the current version of React. Please update React DevTools. https://reactjs.org/link/react-devtools"), !0;
    try {
      Pn && (e = He({}, e, {
        getLaneLabelMap: ZT,
        injectProfilingHooks: QT
      })), Wo = t.inject(e), Mn = t;
    } catch (n) {
      c("React instrumentation encountered an error: %s.", n);
    }
    return !!t.checkDCE;
  }
  function GT(e, t) {
    if (Mn && typeof Mn.onScheduleFiberRoot == "function")
      try {
        Mn.onScheduleFiberRoot(Wo, e, t);
      } catch (n) {
        ra || (ra = !0, c("React instrumentation encountered an error: %s", n));
      }
  }
  function XT(e, t) {
    if (Mn && typeof Mn.onCommitFiberRoot == "function")
      try {
        var n = (e.current.flags & nt) === nt;
        if (Wt) {
          var r;
          switch (t) {
            case lr:
              r = Cc;
              break;
            case Ua:
              r = _p;
              break;
            case ja:
              r = Ji;
              break;
            case _c:
              r = Mp;
              break;
            default:
              r = Ji;
              break;
          }
          Mn.onCommitFiberRoot(Wo, e, r, n);
        }
      } catch (i) {
        ra || (ra = !0, c("React instrumentation encountered an error: %s", i));
      }
  }
  function KT(e) {
    if (Mn && typeof Mn.onPostCommitFiberRoot == "function")
      try {
        Mn.onPostCommitFiberRoot(Wo, e);
      } catch (t) {
        ra || (ra = !0, c("React instrumentation encountered an error: %s", t));
      }
  }
  function qT(e) {
    if (Mn && typeof Mn.onCommitFiberUnmount == "function")
      try {
        Mn.onCommitFiberUnmount(Wo, e);
      } catch (t) {
        ra || (ra = !0, c("React instrumentation encountered an error: %s", t));
      }
  }
  function sn(e) {
    if (typeof VT == "function" && (YT(e), d(e)), Mn && typeof Mn.setStrictMode == "function")
      try {
        Mn.setStrictMode(Wo, e);
      } catch (t) {
        ra || (ra = !0, c("React instrumentation encountered an error: %s", t));
      }
  }
  function QT(e) {
    oe = e;
  }
  function ZT() {
    {
      for (var e = /* @__PURE__ */ new Map(), t = 1, n = 0; n < Ap; n++) {
        var r = g1(t);
        e.set(t, r), t *= 2;
      }
      return e;
    }
  }
  function JT(e) {
    oe !== null && typeof oe.markCommitStarted == "function" && oe.markCommitStarted(e);
  }
  function Gg() {
    oe !== null && typeof oe.markCommitStopped == "function" && oe.markCommitStopped();
  }
  function vu(e) {
    oe !== null && typeof oe.markComponentRenderStarted == "function" && oe.markComponentRenderStarted(e);
  }
  function Go() {
    oe !== null && typeof oe.markComponentRenderStopped == "function" && oe.markComponentRenderStopped();
  }
  function e1(e) {
    oe !== null && typeof oe.markComponentPassiveEffectMountStarted == "function" && oe.markComponentPassiveEffectMountStarted(e);
  }
  function t1() {
    oe !== null && typeof oe.markComponentPassiveEffectMountStopped == "function" && oe.markComponentPassiveEffectMountStopped();
  }
  function n1(e) {
    oe !== null && typeof oe.markComponentPassiveEffectUnmountStarted == "function" && oe.markComponentPassiveEffectUnmountStarted(e);
  }
  function r1() {
    oe !== null && typeof oe.markComponentPassiveEffectUnmountStopped == "function" && oe.markComponentPassiveEffectUnmountStopped();
  }
  function a1(e) {
    oe !== null && typeof oe.markComponentLayoutEffectMountStarted == "function" && oe.markComponentLayoutEffectMountStarted(e);
  }
  function i1() {
    oe !== null && typeof oe.markComponentLayoutEffectMountStopped == "function" && oe.markComponentLayoutEffectMountStopped();
  }
  function Xg(e) {
    oe !== null && typeof oe.markComponentLayoutEffectUnmountStarted == "function" && oe.markComponentLayoutEffectUnmountStarted(e);
  }
  function Kg() {
    oe !== null && typeof oe.markComponentLayoutEffectUnmountStopped == "function" && oe.markComponentLayoutEffectUnmountStopped();
  }
  function o1(e, t, n) {
    oe !== null && typeof oe.markComponentErrored == "function" && oe.markComponentErrored(e, t, n);
  }
  function l1(e, t, n) {
    oe !== null && typeof oe.markComponentSuspended == "function" && oe.markComponentSuspended(e, t, n);
  }
  function u1(e) {
    oe !== null && typeof oe.markLayoutEffectsStarted == "function" && oe.markLayoutEffectsStarted(e);
  }
  function s1() {
    oe !== null && typeof oe.markLayoutEffectsStopped == "function" && oe.markLayoutEffectsStopped();
  }
  function c1(e) {
    oe !== null && typeof oe.markPassiveEffectsStarted == "function" && oe.markPassiveEffectsStarted(e);
  }
  function f1() {
    oe !== null && typeof oe.markPassiveEffectsStopped == "function" && oe.markPassiveEffectsStopped();
  }
  function qg(e) {
    oe !== null && typeof oe.markRenderStarted == "function" && oe.markRenderStarted(e);
  }
  function d1() {
    oe !== null && typeof oe.markRenderYielded == "function" && oe.markRenderYielded();
  }
  function Qg() {
    oe !== null && typeof oe.markRenderStopped == "function" && oe.markRenderStopped();
  }
  function p1(e) {
    oe !== null && typeof oe.markRenderScheduled == "function" && oe.markRenderScheduled(e);
  }
  function v1(e, t) {
    oe !== null && typeof oe.markForceUpdateScheduled == "function" && oe.markForceUpdateScheduled(e, t);
  }
  function Op(e, t) {
    oe !== null && typeof oe.markStateUpdateScheduled == "function" && oe.markStateUpdateScheduled(e, t);
  }
  var Re = (
    /*                         */
    0
  ), Ye = (
    /*                 */
    1
  ), ut = (
    /*                    */
    2
  ), Mt = (
    /*               */
    8
  ), aa = (
    /*              */
    16
  ), Zg = Math.clz32 ? Math.clz32 : y1, h1 = Math.log, m1 = Math.LN2;
  function y1(e) {
    var t = e >>> 0;
    return t === 0 ? 32 : 31 - (h1(t) / m1 | 0) | 0;
  }
  var Ap = 31, K = (
    /*                        */
    0
  ), cn = (
    /*                          */
    0
  ), Ne = (
    /*                        */
    1
  ), Xo = (
    /*    */
    2
  ), Pa = (
    /*             */
    4
  ), eo = (
    /*            */
    8
  ), ia = (
    /*                     */
    16
  ), hu = (
    /*                */
    32
  ), Ko = (
    /*                       */
    4194240
  ), mu = (
    /*                        */
    64
  ), Np = (
    /*                        */
    128
  ), Lp = (
    /*                        */
    256
  ), kp = (
    /*                        */
    512
  ), Pp = (
    /*                        */
    1024
  ), Up = (
    /*                        */
    2048
  ), jp = (
    /*                        */
    4096
  ), Fp = (
    /*                        */
    8192
  ), zp = (
    /*                        */
    16384
  ), Hp = (
    /*                       */
    32768
  ), $p = (
    /*                       */
    65536
  ), Ip = (
    /*                       */
    131072
  ), Bp = (
    /*                       */
    262144
  ), Vp = (
    /*                       */
    524288
  ), Yp = (
    /*                       */
    1048576
  ), Wp = (
    /*                       */
    2097152
  ), Ec = (
    /*                            */
    130023424
  ), qo = (
    /*                             */
    4194304
  ), Gp = (
    /*                             */
    8388608
  ), Xp = (
    /*                             */
    16777216
  ), Kp = (
    /*                             */
    33554432
  ), qp = (
    /*                             */
    67108864
  ), Jg = qo, yu = (
    /*          */
    134217728
  ), eb = (
    /*                          */
    268435455
  ), gu = (
    /*               */
    268435456
  ), to = (
    /*                        */
    536870912
  ), ir = (
    /*                   */
    1073741824
  );
  function g1(e) {
    {
      if (e & Ne)
        return "Sync";
      if (e & Xo)
        return "InputContinuousHydration";
      if (e & Pa)
        return "InputContinuous";
      if (e & eo)
        return "DefaultHydration";
      if (e & ia)
        return "Default";
      if (e & hu)
        return "TransitionHydration";
      if (e & Ko)
        return "Transition";
      if (e & Ec)
        return "Retry";
      if (e & yu)
        return "SelectiveHydration";
      if (e & gu)
        return "IdleHydration";
      if (e & to)
        return "Idle";
      if (e & ir)
        return "Offscreen";
    }
  }
  var bt = -1, Rc = mu, wc = qo;
  function bu(e) {
    switch (no(e)) {
      case Ne:
        return Ne;
      case Xo:
        return Xo;
      case Pa:
        return Pa;
      case eo:
        return eo;
      case ia:
        return ia;
      case hu:
        return hu;
      case mu:
      case Np:
      case Lp:
      case kp:
      case Pp:
      case Up:
      case jp:
      case Fp:
      case zp:
      case Hp:
      case $p:
      case Ip:
      case Bp:
      case Vp:
      case Yp:
      case Wp:
        return e & Ko;
      case qo:
      case Gp:
      case Xp:
      case Kp:
      case qp:
        return e & Ec;
      case yu:
        return yu;
      case gu:
        return gu;
      case to:
        return to;
      case ir:
        return ir;
      default:
        return c("Should have found matching lanes. This is a bug in React."), e;
    }
  }
  function xc(e, t) {
    var n = e.pendingLanes;
    if (n === K)
      return K;
    var r = K, i = e.suspendedLanes, l = e.pingedLanes, f = n & eb;
    if (f !== K) {
      var p = f & ~i;
      if (p !== K)
        r = bu(p);
      else {
        var m = f & l;
        m !== K && (r = bu(m));
      }
    } else {
      var C = n & ~i;
      C !== K ? r = bu(C) : l !== K && (r = bu(l));
    }
    if (r === K)
      return K;
    if (t !== K && t !== r && // If we already suspended with a delay, then interrupting is fine. Don't
    // bother waiting until the root is complete.
    (t & i) === K) {
      var w = no(r), N = no(t);
      if (
        // Tests whether the next lane is equal or lower priority than the wip
        // one. This works because the bits decrease in priority as you go left.
        w >= N || // Default priority updates should not interrupt transition updates. The
        // only difference between default updates and transition updates is that
        // default updates do not support refresh transitions.
        w === ia && (N & Ko) !== K
      )
        return t;
    }
    (r & Pa) !== K && (r |= n & ia);
    var A = e.entangledLanes;
    if (A !== K)
      for (var j = e.entanglements, H = r & A; H > 0; ) {
        var B = ro(H), ae = 1 << B;
        r |= j[B], H &= ~ae;
      }
    return r;
  }
  function b1(e, t) {
    for (var n = e.eventTimes, r = bt; t > 0; ) {
      var i = ro(t), l = 1 << i, f = n[i];
      f > r && (r = f), t &= ~l;
    }
    return r;
  }
  function S1(e, t) {
    switch (e) {
      case Ne:
      case Xo:
      case Pa:
        return t + 250;
      case eo:
      case ia:
      case hu:
      case mu:
      case Np:
      case Lp:
      case kp:
      case Pp:
      case Up:
      case jp:
      case Fp:
      case zp:
      case Hp:
      case $p:
      case Ip:
      case Bp:
      case Vp:
      case Yp:
      case Wp:
        return t + 5e3;
      case qo:
      case Gp:
      case Xp:
      case Kp:
      case qp:
        return bt;
      case yu:
      case gu:
      case to:
      case ir:
        return bt;
      default:
        return c("Should have found matching lanes. This is a bug in React."), bt;
    }
  }
  function C1(e, t) {
    for (var n = e.pendingLanes, r = e.suspendedLanes, i = e.pingedLanes, l = e.expirationTimes, f = n; f > 0; ) {
      var p = ro(f), m = 1 << p, C = l[p];
      C === bt ? ((m & r) === K || (m & i) !== K) && (l[p] = S1(m, t)) : C <= t && (e.expiredLanes |= m), f &= ~m;
    }
  }
  function E1(e) {
    return bu(e.pendingLanes);
  }
  function Qp(e) {
    var t = e.pendingLanes & ~ir;
    return t !== K ? t : t & ir ? ir : K;
  }
  function R1(e) {
    return (e & Ne) !== K;
  }
  function Zp(e) {
    return (e & eb) !== K;
  }
  function tb(e) {
    return (e & Ec) === e;
  }
  function w1(e) {
    var t = Ne | Pa | ia;
    return (e & t) === K;
  }
  function x1(e) {
    return (e & Ko) === e;
  }
  function Tc(e, t) {
    var n = Xo | Pa | eo | ia;
    return (t & n) !== K;
  }
  function T1(e, t) {
    return (t & e.expiredLanes) !== K;
  }
  function nb(e) {
    return (e & Ko) !== K;
  }
  function rb() {
    var e = Rc;
    return Rc <<= 1, (Rc & Ko) === K && (Rc = mu), e;
  }
  function D1() {
    var e = wc;
    return wc <<= 1, (wc & Ec) === K && (wc = qo), e;
  }
  function no(e) {
    return e & -e;
  }
  function Su(e) {
    return no(e);
  }
  function ro(e) {
    return 31 - Zg(e);
  }
  function Jp(e) {
    return ro(e);
  }
  function or(e, t) {
    return (e & t) !== K;
  }
  function Qo(e, t) {
    return (e & t) === t;
  }
  function Ue(e, t) {
    return e | t;
  }
  function Dc(e, t) {
    return e & ~t;
  }
  function ab(e, t) {
    return e & t;
  }
  function g3(e) {
    return e;
  }
  function _1(e, t) {
    return e !== cn && e < t ? e : t;
  }
  function ev(e) {
    for (var t = [], n = 0; n < Ap; n++)
      t.push(e);
    return t;
  }
  function Cu(e, t, n) {
    e.pendingLanes |= t, t !== to && (e.suspendedLanes = K, e.pingedLanes = K);
    var r = e.eventTimes, i = Jp(t);
    r[i] = n;
  }
  function M1(e, t) {
    e.suspendedLanes |= t, e.pingedLanes &= ~t;
    for (var n = e.expirationTimes, r = t; r > 0; ) {
      var i = ro(r), l = 1 << i;
      n[i] = bt, r &= ~l;
    }
  }
  function ib(e, t, n) {
    e.pingedLanes |= e.suspendedLanes & t;
  }
  function O1(e, t) {
    var n = e.pendingLanes & ~t;
    e.pendingLanes = t, e.suspendedLanes = K, e.pingedLanes = K, e.expiredLanes &= t, e.mutableReadLanes &= t, e.entangledLanes &= t;
    for (var r = e.entanglements, i = e.eventTimes, l = e.expirationTimes, f = n; f > 0; ) {
      var p = ro(f), m = 1 << p;
      r[p] = K, i[p] = bt, l[p] = bt, f &= ~m;
    }
  }
  function tv(e, t) {
    for (var n = e.entangledLanes |= t, r = e.entanglements, i = n; i; ) {
      var l = ro(i), f = 1 << l;
      // Is this one of the newly entangled lanes?
      f & t | // Is this lane transitively entangled with the newly entangled lanes?
      r[l] & t && (r[l] |= t), i &= ~f;
    }
  }
  function A1(e, t) {
    var n = no(t), r;
    switch (n) {
      case Pa:
        r = Xo;
        break;
      case ia:
        r = eo;
        break;
      case mu:
      case Np:
      case Lp:
      case kp:
      case Pp:
      case Up:
      case jp:
      case Fp:
      case zp:
      case Hp:
      case $p:
      case Ip:
      case Bp:
      case Vp:
      case Yp:
      case Wp:
      case qo:
      case Gp:
      case Xp:
      case Kp:
      case qp:
        r = hu;
        break;
      case to:
        r = gu;
        break;
      default:
        r = cn;
        break;
    }
    return (r & (e.suspendedLanes | t)) !== cn ? cn : r;
  }
  function ob(e, t, n) {
    if (Ur)
      for (var r = e.pendingUpdatersLaneMap; n > 0; ) {
        var i = Jp(n), l = 1 << i, f = r[i];
        f.add(t), n &= ~l;
      }
  }
  function lb(e, t) {
    if (Ur)
      for (var n = e.pendingUpdatersLaneMap, r = e.memoizedUpdaters; t > 0; ) {
        var i = Jp(t), l = 1 << i, f = n[i];
        f.size > 0 && (f.forEach(function(p) {
          var m = p.alternate;
          (m === null || !r.has(m)) && r.add(p);
        }), f.clear()), t &= ~l;
      }
  }
  function ub(e, t) {
    return null;
  }
  var lr = Ne, Ua = Pa, ja = ia, _c = to, Eu = cn;
  function jr() {
    return Eu;
  }
  function fn(e) {
    Eu = e;
  }
  function N1(e, t) {
    var n = Eu;
    try {
      return Eu = e, t();
    } finally {
      Eu = n;
    }
  }
  function L1(e, t) {
    return e !== 0 && e < t ? e : t;
  }
  function k1(e, t) {
    return e > t ? e : t;
  }
  function nv(e, t) {
    return e !== 0 && e < t;
  }
  function sb(e) {
    var t = no(e);
    return nv(lr, t) ? nv(Ua, t) ? Zp(t) ? ja : _c : Ua : lr;
  }
  function Mc(e) {
    var t = e.current.memoizedState;
    return t.isDehydrated;
  }
  var cb;
  function P1(e) {
    cb = e;
  }
  function U1(e) {
    cb(e);
  }
  var rv;
  function j1(e) {
    rv = e;
  }
  var fb;
  function F1(e) {
    fb = e;
  }
  var db;
  function z1(e) {
    db = e;
  }
  var pb;
  function H1(e) {
    pb = e;
  }
  var av = !1, Oc = [], si = null, ci = null, fi = null, Ru = /* @__PURE__ */ new Map(), wu = /* @__PURE__ */ new Map(), di = [], $1 = [
    "mousedown",
    "mouseup",
    "touchcancel",
    "touchend",
    "touchstart",
    "auxclick",
    "dblclick",
    "pointercancel",
    "pointerdown",
    "pointerup",
    "dragend",
    "dragstart",
    "drop",
    "compositionend",
    "compositionstart",
    "keydown",
    "keypress",
    "keyup",
    "input",
    "textInput",
    // Intentionally camelCase
    "copy",
    "cut",
    "paste",
    "click",
    "change",
    "contextmenu",
    "reset",
    "submit"
  ];
  function I1(e) {
    return $1.indexOf(e) > -1;
  }
  function B1(e, t, n, r, i) {
    return {
      blockedOn: e,
      domEventName: t,
      eventSystemFlags: n,
      nativeEvent: i,
      targetContainers: [r]
    };
  }
  function vb(e, t) {
    switch (e) {
      case "focusin":
      case "focusout":
        si = null;
        break;
      case "dragenter":
      case "dragleave":
        ci = null;
        break;
      case "mouseover":
      case "mouseout":
        fi = null;
        break;
      case "pointerover":
      case "pointerout": {
        var n = t.pointerId;
        Ru.delete(n);
        break;
      }
      case "gotpointercapture":
      case "lostpointercapture": {
        var r = t.pointerId;
        wu.delete(r);
        break;
      }
    }
  }
  function xu(e, t, n, r, i, l) {
    if (e === null || e.nativeEvent !== l) {
      var f = B1(t, n, r, i, l);
      if (t !== null) {
        var p = hi(t);
        p !== null && rv(p);
      }
      return f;
    }
    e.eventSystemFlags |= r;
    var m = e.targetContainers;
    return i !== null && m.indexOf(i) === -1 && m.push(i), e;
  }
  function V1(e, t, n, r, i) {
    switch (t) {
      case "focusin": {
        var l = i;
        return si = xu(si, e, t, n, r, l), !0;
      }
      case "dragenter": {
        var f = i;
        return ci = xu(ci, e, t, n, r, f), !0;
      }
      case "mouseover": {
        var p = i;
        return fi = xu(fi, e, t, n, r, p), !0;
      }
      case "pointerover": {
        var m = i, C = m.pointerId;
        return Ru.set(C, xu(Ru.get(C) || null, e, t, n, r, m)), !0;
      }
      case "gotpointercapture": {
        var w = i, N = w.pointerId;
        return wu.set(N, xu(wu.get(N) || null, e, t, n, r, w)), !0;
      }
    }
    return !1;
  }
  function hb(e) {
    var t = oo(e.target);
    if (t !== null) {
      var n = Zi(t);
      if (n !== null) {
        var r = n.tag;
        if (r === W) {
          var i = zg(n);
          if (i !== null) {
            e.blockedOn = i, pb(e.priority, function() {
              fb(n);
            });
            return;
          }
        } else if (r === E) {
          var l = n.stateNode;
          if (Mc(l)) {
            e.blockedOn = Hg(n);
            return;
          }
        }
      }
    }
    e.blockedOn = null;
  }
  function Y1(e) {
    for (var t = db(), n = {
      blockedOn: null,
      target: e,
      priority: t
    }, r = 0; r < di.length && nv(t, di[r].priority); r++)
      ;
    di.splice(r, 0, n), r === 0 && hb(n);
  }
  function Ac(e) {
    if (e.blockedOn !== null)
      return !1;
    for (var t = e.targetContainers; t.length > 0; ) {
      var n = t[0], r = lv(e.domEventName, e.eventSystemFlags, n, e.nativeEvent);
      if (r === null) {
        var i = e.nativeEvent, l = new i.constructor(i.type, i);
        yT(l), i.target.dispatchEvent(l), gT();
      } else {
        var f = hi(r);
        return f !== null && rv(f), e.blockedOn = r, !1;
      }
      t.shift();
    }
    return !0;
  }
  function mb(e, t, n) {
    Ac(e) && n.delete(t);
  }
  function W1() {
    av = !1, si !== null && Ac(si) && (si = null), ci !== null && Ac(ci) && (ci = null), fi !== null && Ac(fi) && (fi = null), Ru.forEach(mb), wu.forEach(mb);
  }
  function Tu(e, t) {
    e.blockedOn === t && (e.blockedOn = null, av || (av = !0, o.unstable_scheduleCallback(o.unstable_NormalPriority, W1)));
  }
  function Du(e) {
    if (Oc.length > 0) {
      Tu(Oc[0], e);
      for (var t = 1; t < Oc.length; t++) {
        var n = Oc[t];
        n.blockedOn === e && (n.blockedOn = null);
      }
    }
    si !== null && Tu(si, e), ci !== null && Tu(ci, e), fi !== null && Tu(fi, e);
    var r = function(p) {
      return Tu(p, e);
    };
    Ru.forEach(r), wu.forEach(r);
    for (var i = 0; i < di.length; i++) {
      var l = di[i];
      l.blockedOn === e && (l.blockedOn = null);
    }
    for (; di.length > 0; ) {
      var f = di[0];
      if (f.blockedOn !== null)
        break;
      hb(f), f.blockedOn === null && di.shift();
    }
  }
  var Zo = u.ReactCurrentBatchConfig, iv = !0;
  function yb(e) {
    iv = !!e;
  }
  function G1() {
    return iv;
  }
  function X1(e, t, n) {
    var r = gb(t), i;
    switch (r) {
      case lr:
        i = K1;
        break;
      case Ua:
        i = q1;
        break;
      case ja:
      default:
        i = ov;
        break;
    }
    return i.bind(null, t, n, e);
  }
  function K1(e, t, n, r) {
    var i = jr(), l = Zo.transition;
    Zo.transition = null;
    try {
      fn(lr), ov(e, t, n, r);
    } finally {
      fn(i), Zo.transition = l;
    }
  }
  function q1(e, t, n, r) {
    var i = jr(), l = Zo.transition;
    Zo.transition = null;
    try {
      fn(Ua), ov(e, t, n, r);
    } finally {
      fn(i), Zo.transition = l;
    }
  }
  function ov(e, t, n, r) {
    iv && Q1(e, t, n, r);
  }
  function Q1(e, t, n, r) {
    var i = lv(e, t, n, r);
    if (i === null) {
      Cv(e, t, r, Nc, n), vb(e, r);
      return;
    }
    if (V1(i, e, t, n, r)) {
      r.stopPropagation();
      return;
    }
    if (vb(e, r), t & lu && I1(e)) {
      for (; i !== null; ) {
        var l = hi(i);
        l !== null && U1(l);
        var f = lv(e, t, n, r);
        if (f === null && Cv(e, t, r, Nc, n), f === i)
          break;
        i = f;
      }
      i !== null && r.stopPropagation();
      return;
    }
    Cv(e, t, r, null, n);
  }
  var Nc = null;
  function lv(e, t, n, r) {
    Nc = null;
    var i = vp(r), l = oo(i);
    if (l !== null) {
      var f = Zi(l);
      if (f === null)
        l = null;
      else {
        var p = f.tag;
        if (p === W) {
          var m = zg(f);
          if (m !== null)
            return m;
          l = null;
        } else if (p === E) {
          var C = f.stateNode;
          if (Mc(C))
            return Hg(f);
          l = null;
        } else
          f !== l && (l = null);
      }
    }
    return Nc = l, null;
  }
  function gb(e) {
    switch (e) {
      case "cancel":
      case "click":
      case "close":
      case "contextmenu":
      case "copy":
      case "cut":
      case "auxclick":
      case "dblclick":
      case "dragend":
      case "dragstart":
      case "drop":
      case "focusin":
      case "focusout":
      case "input":
      case "invalid":
      case "keydown":
      case "keypress":
      case "keyup":
      case "mousedown":
      case "mouseup":
      case "paste":
      case "pause":
      case "play":
      case "pointercancel":
      case "pointerdown":
      case "pointerup":
      case "ratechange":
      case "reset":
      case "resize":
      case "seeked":
      case "submit":
      case "touchcancel":
      case "touchend":
      case "touchstart":
      case "volumechange":
      case "change":
      case "selectionchange":
      case "textInput":
      case "compositionstart":
      case "compositionend":
      case "compositionupdate":
      case "beforeblur":
      case "afterblur":
      case "beforeinput":
      case "blur":
      case "fullscreenchange":
      case "focus":
      case "hashchange":
      case "popstate":
      case "select":
      case "selectstart":
        return lr;
      case "drag":
      case "dragenter":
      case "dragexit":
      case "dragleave":
      case "dragover":
      case "mousemove":
      case "mouseout":
      case "mouseover":
      case "pointermove":
      case "pointerout":
      case "pointerover":
      case "scroll":
      case "toggle":
      case "touchmove":
      case "wheel":
      case "mouseenter":
      case "mouseleave":
      case "pointerenter":
      case "pointerleave":
        return Ua;
      case "message": {
        var t = IT();
        switch (t) {
          case Cc:
            return lr;
          case _p:
            return Ua;
          case Ji:
          case BT:
            return ja;
          case Mp:
            return _c;
          default:
            return ja;
        }
      }
      default:
        return ja;
    }
  }
  function Z1(e, t, n) {
    return e.addEventListener(t, n, !1), n;
  }
  function J1(e, t, n) {
    return e.addEventListener(t, n, !0), n;
  }
  function eD(e, t, n, r) {
    return e.addEventListener(t, n, {
      capture: !0,
      passive: r
    }), n;
  }
  function tD(e, t, n, r) {
    return e.addEventListener(t, n, {
      passive: r
    }), n;
  }
  var _u = null, uv = null, Mu = null;
  function nD(e) {
    return _u = e, uv = Sb(), !0;
  }
  function rD() {
    _u = null, uv = null, Mu = null;
  }
  function bb() {
    if (Mu)
      return Mu;
    var e, t = uv, n = t.length, r, i = Sb(), l = i.length;
    for (e = 0; e < n && t[e] === i[e]; e++)
      ;
    var f = n - e;
    for (r = 1; r <= f && t[n - r] === i[l - r]; r++)
      ;
    var p = r > 1 ? 1 - r : void 0;
    return Mu = i.slice(e, p), Mu;
  }
  function Sb() {
    return "value" in _u ? _u.value : _u.textContent;
  }
  function Lc(e) {
    var t, n = e.keyCode;
    return "charCode" in e ? (t = e.charCode, t === 0 && n === 13 && (t = 13)) : t = n, t === 10 && (t = 13), t >= 32 || t === 13 ? t : 0;
  }
  function kc() {
    return !0;
  }
  function Cb() {
    return !1;
  }
  function ur(e) {
    function t(n, r, i, l, f) {
      this._reactName = n, this._targetInst = i, this.type = r, this.nativeEvent = l, this.target = f, this.currentTarget = null;
      for (var p in e)
        if (e.hasOwnProperty(p)) {
          var m = e[p];
          m ? this[p] = m(l) : this[p] = l[p];
        }
      var C = l.defaultPrevented != null ? l.defaultPrevented : l.returnValue === !1;
      return C ? this.isDefaultPrevented = kc : this.isDefaultPrevented = Cb, this.isPropagationStopped = Cb, this;
    }
    return He(t.prototype, {
      preventDefault: function() {
        this.defaultPrevented = !0;
        var n = this.nativeEvent;
        n && (n.preventDefault ? n.preventDefault() : typeof n.returnValue != "unknown" && (n.returnValue = !1), this.isDefaultPrevented = kc);
      },
      stopPropagation: function() {
        var n = this.nativeEvent;
        n && (n.stopPropagation ? n.stopPropagation() : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0), this.isPropagationStopped = kc);
      },
      /**
       * We release all dispatched `SyntheticEvent`s after each event loop, adding
       * them back into the pool. This allows a way to hold onto a reference that
       * won't be added back into the pool.
       */
      persist: function() {
      },
      /**
       * Checks if this event should be released back into the pool.
       *
       * @return {boolean} True if this should not be released, false otherwise.
       */
      isPersistent: kc
    }), t;
  }
  var Jo = {
    eventPhase: 0,
    bubbles: 0,
    cancelable: 0,
    timeStamp: function(e) {
      return e.timeStamp || Date.now();
    },
    defaultPrevented: 0,
    isTrusted: 0
  }, sv = ur(Jo), Ou = He({}, Jo, {
    view: 0,
    detail: 0
  }), aD = ur(Ou), cv, fv, Au;
  function iD(e) {
    e !== Au && (Au && e.type === "mousemove" ? (cv = e.screenX - Au.screenX, fv = e.screenY - Au.screenY) : (cv = 0, fv = 0), Au = e);
  }
  var Pc = He({}, Ou, {
    screenX: 0,
    screenY: 0,
    clientX: 0,
    clientY: 0,
    pageX: 0,
    pageY: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    getModifierState: pv,
    button: 0,
    buttons: 0,
    relatedTarget: function(e) {
      return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget;
    },
    movementX: function(e) {
      return "movementX" in e ? e.movementX : (iD(e), cv);
    },
    movementY: function(e) {
      return "movementY" in e ? e.movementY : fv;
    }
  }), Eb = ur(Pc), oD = He({}, Pc, {
    dataTransfer: 0
  }), lD = ur(oD), uD = He({}, Ou, {
    relatedTarget: 0
  }), dv = ur(uD), sD = He({}, Jo, {
    animationName: 0,
    elapsedTime: 0,
    pseudoElement: 0
  }), cD = ur(sD), fD = He({}, Jo, {
    clipboardData: function(e) {
      return "clipboardData" in e ? e.clipboardData : window.clipboardData;
    }
  }), dD = ur(fD), pD = He({}, Jo, {
    data: 0
  }), Rb = ur(pD), vD = Rb, hD = {
    Esc: "Escape",
    Spacebar: " ",
    Left: "ArrowLeft",
    Up: "ArrowUp",
    Right: "ArrowRight",
    Down: "ArrowDown",
    Del: "Delete",
    Win: "OS",
    Menu: "ContextMenu",
    Apps: "ContextMenu",
    Scroll: "ScrollLock",
    MozPrintableKey: "Unidentified"
  }, mD = {
    8: "Backspace",
    9: "Tab",
    12: "Clear",
    13: "Enter",
    16: "Shift",
    17: "Control",
    18: "Alt",
    19: "Pause",
    20: "CapsLock",
    27: "Escape",
    32: " ",
    33: "PageUp",
    34: "PageDown",
    35: "End",
    36: "Home",
    37: "ArrowLeft",
    38: "ArrowUp",
    39: "ArrowRight",
    40: "ArrowDown",
    45: "Insert",
    46: "Delete",
    112: "F1",
    113: "F2",
    114: "F3",
    115: "F4",
    116: "F5",
    117: "F6",
    118: "F7",
    119: "F8",
    120: "F9",
    121: "F10",
    122: "F11",
    123: "F12",
    144: "NumLock",
    145: "ScrollLock",
    224: "Meta"
  };
  function yD(e) {
    if (e.key) {
      var t = hD[e.key] || e.key;
      if (t !== "Unidentified")
        return t;
    }
    if (e.type === "keypress") {
      var n = Lc(e);
      return n === 13 ? "Enter" : String.fromCharCode(n);
    }
    return e.type === "keydown" || e.type === "keyup" ? mD[e.keyCode] || "Unidentified" : "";
  }
  var gD = {
    Alt: "altKey",
    Control: "ctrlKey",
    Meta: "metaKey",
    Shift: "shiftKey"
  };
  function bD(e) {
    var t = this, n = t.nativeEvent;
    if (n.getModifierState)
      return n.getModifierState(e);
    var r = gD[e];
    return r ? !!n[r] : !1;
  }
  function pv(e) {
    return bD;
  }
  var SD = He({}, Ou, {
    key: yD,
    code: 0,
    location: 0,
    ctrlKey: 0,
    shiftKey: 0,
    altKey: 0,
    metaKey: 0,
    repeat: 0,
    locale: 0,
    getModifierState: pv,
    // Legacy Interface
    charCode: function(e) {
      return e.type === "keypress" ? Lc(e) : 0;
    },
    keyCode: function(e) {
      return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
    },
    which: function(e) {
      return e.type === "keypress" ? Lc(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0;
    }
  }), CD = ur(SD), ED = He({}, Pc, {
    pointerId: 0,
    width: 0,
    height: 0,
    pressure: 0,
    tangentialPressure: 0,
    tiltX: 0,
    tiltY: 0,
    twist: 0,
    pointerType: 0,
    isPrimary: 0
  }), wb = ur(ED), RD = He({}, Ou, {
    touches: 0,
    targetTouches: 0,
    changedTouches: 0,
    altKey: 0,
    metaKey: 0,
    ctrlKey: 0,
    shiftKey: 0,
    getModifierState: pv
  }), wD = ur(RD), xD = He({}, Jo, {
    propertyName: 0,
    elapsedTime: 0,
    pseudoElement: 0
  }), TD = ur(xD), DD = He({}, Pc, {
    deltaX: function(e) {
      return "deltaX" in e ? e.deltaX : (
        // Fallback to `wheelDeltaX` for Webkit and normalize (right is positive).
        "wheelDeltaX" in e ? -e.wheelDeltaX : 0
      );
    },
    deltaY: function(e) {
      return "deltaY" in e ? e.deltaY : (
        // Fallback to `wheelDeltaY` for Webkit and normalize (down is positive).
        "wheelDeltaY" in e ? -e.wheelDeltaY : (
          // Fallback to `wheelDelta` for IE<9 and normalize (down is positive).
          "wheelDelta" in e ? -e.wheelDelta : 0
        )
      );
    },
    deltaZ: 0,
    // Browsers without "deltaMode" is reporting in raw wheel delta where one
    // notch on the scroll is always +/- 120, roughly equivalent to pixels.
    // A good approximation of DOM_DELTA_LINE (1) is 5% of viewport size or
    // ~40 pixels, for DOM_DELTA_SCREEN (2) it is 87.5% of viewport size.
    deltaMode: 0
  }), _D = ur(DD), MD = [9, 13, 27, 32], xb = 229, vv = yt && "CompositionEvent" in window, Nu = null;
  yt && "documentMode" in document && (Nu = document.documentMode);
  var OD = yt && "TextEvent" in window && !Nu, Tb = yt && (!vv || Nu && Nu > 8 && Nu <= 11), Db = 32, _b = String.fromCharCode(Db);
  function AD() {
    wn("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]), wn("onCompositionEnd", ["compositionend", "focusout", "keydown", "keypress", "keyup", "mousedown"]), wn("onCompositionStart", ["compositionstart", "focusout", "keydown", "keypress", "keyup", "mousedown"]), wn("onCompositionUpdate", ["compositionupdate", "focusout", "keydown", "keypress", "keyup", "mousedown"]);
  }
  var Mb = !1;
  function ND(e) {
    return (e.ctrlKey || e.altKey || e.metaKey) && // ctrlKey && altKey is equivalent to AltGr, and is not a command.
    !(e.ctrlKey && e.altKey);
  }
  function LD(e) {
    switch (e) {
      case "compositionstart":
        return "onCompositionStart";
      case "compositionend":
        return "onCompositionEnd";
      case "compositionupdate":
        return "onCompositionUpdate";
    }
  }
  function kD(e, t) {
    return e === "keydown" && t.keyCode === xb;
  }
  function Ob(e, t) {
    switch (e) {
      case "keyup":
        return MD.indexOf(t.keyCode) !== -1;
      case "keydown":
        return t.keyCode !== xb;
      case "keypress":
      case "mousedown":
      case "focusout":
        return !0;
      default:
        return !1;
    }
  }
  function Ab(e) {
    var t = e.detail;
    return typeof t == "object" && "data" in t ? t.data : null;
  }
  function Nb(e) {
    return e.locale === "ko";
  }
  var el = !1;
  function PD(e, t, n, r, i) {
    var l, f;
    if (vv ? l = LD(t) : el ? Ob(t, r) && (l = "onCompositionEnd") : kD(t, r) && (l = "onCompositionStart"), !l)
      return null;
    Tb && !Nb(r) && (!el && l === "onCompositionStart" ? el = nD(i) : l === "onCompositionEnd" && el && (f = bb()));
    var p = Hc(n, l);
    if (p.length > 0) {
      var m = new Rb(l, t, null, r, i);
      if (e.push({
        event: m,
        listeners: p
      }), f)
        m.data = f;
      else {
        var C = Ab(r);
        C !== null && (m.data = C);
      }
    }
  }
  function UD(e, t) {
    switch (e) {
      case "compositionend":
        return Ab(t);
      case "keypress":
        var n = t.which;
        return n !== Db ? null : (Mb = !0, _b);
      case "textInput":
        var r = t.data;
        return r === _b && Mb ? null : r;
      default:
        return null;
    }
  }
  function jD(e, t) {
    if (el) {
      if (e === "compositionend" || !vv && Ob(e, t)) {
        var n = bb();
        return rD(), el = !1, n;
      }
      return null;
    }
    switch (e) {
      case "paste":
        return null;
      case "keypress":
        if (!ND(t)) {
          if (t.char && t.char.length > 1)
            return t.char;
          if (t.which)
            return String.fromCharCode(t.which);
        }
        return null;
      case "compositionend":
        return Tb && !Nb(t) ? null : t.data;
      default:
        return null;
    }
  }
  function FD(e, t, n, r, i) {
    var l;
    if (OD ? l = UD(t, r) : l = jD(t, r), !l)
      return null;
    var f = Hc(n, "onBeforeInput");
    if (f.length > 0) {
      var p = new vD("onBeforeInput", "beforeinput", null, r, i);
      e.push({
        event: p,
        listeners: f
      }), p.data = l;
    }
  }
  function zD(e, t, n, r, i, l, f) {
    PD(e, t, n, r, i), FD(e, t, n, r, i);
  }
  var HD = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0
  };
  function Lb(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t === "input" ? !!HD[e.type] : t === "textarea";
  }
  /**
   * Checks if an event is supported in the current execution environment.
   *
   * NOTE: This will not work correctly for non-generic events such as `change`,
   * `reset`, `load`, `error`, and `select`.
   *
   * Borrows from Modernizr.
   *
   * @param {string} eventNameSuffix Event name, e.g. "click".
   * @return {boolean} True if the event is supported.
   * @internal
   * @license Modernizr 3.0.0pre (Custom Build) | MIT
   */
  function $D(e) {
    if (!yt)
      return !1;
    var t = "on" + e, n = t in document;
    if (!n) {
      var r = document.createElement("div");
      r.setAttribute(t, "return;"), n = typeof r[t] == "function";
    }
    return n;
  }
  function ID() {
    wn("onChange", ["change", "click", "focusin", "focusout", "input", "keydown", "keyup", "selectionchange"]);
  }
  function kb(e, t, n, r) {
    Ag(r);
    var i = Hc(t, "onChange");
    if (i.length > 0) {
      var l = new sv("onChange", "change", null, n, r);
      e.push({
        event: l,
        listeners: i
      });
    }
  }
  var Lu = null, ku = null;
  function BD(e) {
    var t = e.nodeName && e.nodeName.toLowerCase();
    return t === "select" || t === "input" && e.type === "file";
  }
  function VD(e) {
    var t = [];
    kb(t, ku, e, vp(e)), Pg(YD, t);
  }
  function YD(e) {
    Zb(e, 0);
  }
  function Uc(e) {
    var t = ol(e);
    if (Po(t))
      return e;
  }
  function WD(e, t) {
    if (e === "change")
      return t;
  }
  var Pb = !1;
  yt && (Pb = $D("input") && (!document.documentMode || document.documentMode > 9));
  function GD(e, t) {
    Lu = e, ku = t, Lu.attachEvent("onpropertychange", jb);
  }
  function Ub() {
    Lu && (Lu.detachEvent("onpropertychange", jb), Lu = null, ku = null);
  }
  function jb(e) {
    e.propertyName === "value" && Uc(ku) && VD(e);
  }
  function XD(e, t, n) {
    e === "focusin" ? (Ub(), GD(t, n)) : e === "focusout" && Ub();
  }
  function KD(e, t) {
    if (e === "selectionchange" || e === "keyup" || e === "keydown")
      return Uc(ku);
  }
  function qD(e) {
    var t = e.nodeName;
    return t && t.toLowerCase() === "input" && (e.type === "checkbox" || e.type === "radio");
  }
  function QD(e, t) {
    if (e === "click")
      return Uc(t);
  }
  function ZD(e, t) {
    if (e === "input" || e === "change")
      return Uc(t);
  }
  function JD(e) {
    var t = e._wrapperState;
    !t || !t.controlled || e.type !== "number" || Ae(e, "number", e.value);
  }
  function e_(e, t, n, r, i, l, f) {
    var p = n ? ol(n) : window, m, C;
    if (BD(p) ? m = WD : Lb(p) ? Pb ? m = ZD : (m = KD, C = XD) : qD(p) && (m = QD), m) {
      var w = m(t, n);
      if (w) {
        kb(e, w, r, i);
        return;
      }
    }
    C && C(t, p, n), t === "focusout" && JD(p);
  }
  function t_() {
    xn("onMouseEnter", ["mouseout", "mouseover"]), xn("onMouseLeave", ["mouseout", "mouseover"]), xn("onPointerEnter", ["pointerout", "pointerover"]), xn("onPointerLeave", ["pointerout", "pointerover"]);
  }
  function n_(e, t, n, r, i, l, f) {
    var p = t === "mouseover" || t === "pointerover", m = t === "mouseout" || t === "pointerout";
    if (p && !bT(r)) {
      var C = r.relatedTarget || r.fromElement;
      if (C && (oo(C) || Ku(C)))
        return;
    }
    if (!(!m && !p)) {
      var w;
      if (i.window === i)
        w = i;
      else {
        var N = i.ownerDocument;
        N ? w = N.defaultView || N.parentWindow : w = window;
      }
      var A, j;
      if (m) {
        var H = r.relatedTarget || r.toElement;
        if (A = n, j = H ? oo(H) : null, j !== null) {
          var B = Zi(j);
          (j !== B || j.tag !== T && j.tag !== M) && (j = null);
        }
      } else
        A = null, j = n;
      if (A !== j) {
        var ae = Eb, Ce = "onMouseLeave", ye = "onMouseEnter", Ge = "mouse";
        (t === "pointerout" || t === "pointerover") && (ae = wb, Ce = "onPointerLeave", ye = "onPointerEnter", Ge = "pointer");
        var $e = A == null ? w : ol(A), k = j == null ? w : ol(j), V = new ae(Ce, Ge + "leave", A, r, i);
        V.target = $e, V.relatedTarget = k;
        var P = null, Q = oo(i);
        if (Q === n) {
          var ue = new ae(ye, Ge + "enter", j, r, i);
          ue.target = k, ue.relatedTarget = $e, P = ue;
        }
        T_(e, V, P, A, j);
      }
    }
  }
  function r_(e, t) {
    return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t;
  }
  var sr = typeof Object.is == "function" ? Object.is : r_;
  function Pu(e, t) {
    if (sr(e, t))
      return !0;
    if (typeof e != "object" || e === null || typeof t != "object" || t === null)
      return !1;
    var n = Object.keys(e), r = Object.keys(t);
    if (n.length !== r.length)
      return !1;
    for (var i = 0; i < n.length; i++) {
      var l = n[i];
      if (!Gt.call(t, l) || !sr(e[l], t[l]))
        return !1;
    }
    return !0;
  }
  function Fb(e) {
    for (; e && e.firstChild; )
      e = e.firstChild;
    return e;
  }
  function a_(e) {
    for (; e; ) {
      if (e.nextSibling)
        return e.nextSibling;
      e = e.parentNode;
    }
  }
  function zb(e, t) {
    for (var n = Fb(e), r = 0, i = 0; n; ) {
      if (n.nodeType === Ma) {
        if (i = r + n.textContent.length, r <= t && i >= t)
          return {
            node: n,
            offset: t - r
          };
        r = i;
      }
      n = Fb(a_(n));
    }
  }
  function i_(e) {
    var t = e.ownerDocument, n = t && t.defaultView || window, r = n.getSelection && n.getSelection();
    if (!r || r.rangeCount === 0)
      return null;
    var i = r.anchorNode, l = r.anchorOffset, f = r.focusNode, p = r.focusOffset;
    try {
      i.nodeType, f.nodeType;
    } catch {
      return null;
    }
    return o_(e, i, l, f, p);
  }
  function o_(e, t, n, r, i) {
    var l = 0, f = -1, p = -1, m = 0, C = 0, w = e, N = null;
    e:
      for (; ; ) {
        for (var A = null; w === t && (n === 0 || w.nodeType === Ma) && (f = l + n), w === r && (i === 0 || w.nodeType === Ma) && (p = l + i), w.nodeType === Ma && (l += w.nodeValue.length), (A = w.firstChild) !== null; )
          N = w, w = A;
        for (; ; ) {
          if (w === e)
            break e;
          if (N === t && ++m === n && (f = l), N === r && ++C === i && (p = l), (A = w.nextSibling) !== null)
            break;
          w = N, N = w.parentNode;
        }
        w = A;
      }
    return f === -1 || p === -1 ? null : {
      start: f,
      end: p
    };
  }
  function l_(e, t) {
    var n = e.ownerDocument || document, r = n && n.defaultView || window;
    if (r.getSelection) {
      var i = r.getSelection(), l = e.textContent.length, f = Math.min(t.start, l), p = t.end === void 0 ? f : Math.min(t.end, l);
      if (!i.extend && f > p) {
        var m = p;
        p = f, f = m;
      }
      var C = zb(e, f), w = zb(e, p);
      if (C && w) {
        if (i.rangeCount === 1 && i.anchorNode === C.node && i.anchorOffset === C.offset && i.focusNode === w.node && i.focusOffset === w.offset)
          return;
        var N = n.createRange();
        N.setStart(C.node, C.offset), i.removeAllRanges(), f > p ? (i.addRange(N), i.extend(w.node, w.offset)) : (N.setEnd(w.node, w.offset), i.addRange(N));
      }
    }
  }
  function Hb(e) {
    return e && e.nodeType === Ma;
  }
  function $b(e, t) {
    return !e || !t ? !1 : e === t ? !0 : Hb(e) ? !1 : Hb(t) ? $b(e, t.parentNode) : "contains" in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1;
  }
  function u_(e) {
    return e && e.ownerDocument && $b(e.ownerDocument.documentElement, e);
  }
  function s_(e) {
    try {
      return typeof e.contentWindow.location.href == "string";
    } catch {
      return !1;
    }
  }
  function Ib() {
    for (var e = window, t = oi(); t instanceof e.HTMLIFrameElement; ) {
      if (s_(t))
        e = t.contentWindow;
      else
        return t;
      t = oi(e.document);
    }
    return t;
  }
  function hv(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true");
  }
  function c_() {
    var e = Ib();
    return {
      focusedElem: e,
      selectionRange: hv(e) ? d_(e) : null
    };
  }
  function f_(e) {
    var t = Ib(), n = e.focusedElem, r = e.selectionRange;
    if (t !== n && u_(n)) {
      r !== null && hv(n) && p_(n, r);
      for (var i = [], l = n; l = l.parentNode; )
        l.nodeType === Kn && i.push({
          element: l,
          left: l.scrollLeft,
          top: l.scrollTop
        });
      typeof n.focus == "function" && n.focus();
      for (var f = 0; f < i.length; f++) {
        var p = i[f];
        p.element.scrollLeft = p.left, p.element.scrollTop = p.top;
      }
    }
  }
  function d_(e) {
    var t;
    return "selectionStart" in e ? t = {
      start: e.selectionStart,
      end: e.selectionEnd
    } : t = i_(e), t || {
      start: 0,
      end: 0
    };
  }
  function p_(e, t) {
    var n = t.start, r = t.end;
    r === void 0 && (r = n), "selectionStart" in e ? (e.selectionStart = n, e.selectionEnd = Math.min(r, e.value.length)) : l_(e, t);
  }
  var v_ = yt && "documentMode" in document && document.documentMode <= 11;
  function h_() {
    wn("onSelect", ["focusout", "contextmenu", "dragend", "focusin", "keydown", "keyup", "mousedown", "mouseup", "selectionchange"]);
  }
  var tl = null, mv = null, Uu = null, yv = !1;
  function m_(e) {
    if ("selectionStart" in e && hv(e))
      return {
        start: e.selectionStart,
        end: e.selectionEnd
      };
    var t = e.ownerDocument && e.ownerDocument.defaultView || window, n = t.getSelection();
    return {
      anchorNode: n.anchorNode,
      anchorOffset: n.anchorOffset,
      focusNode: n.focusNode,
      focusOffset: n.focusOffset
    };
  }
  function y_(e) {
    return e.window === e ? e.document : e.nodeType === Oa ? e : e.ownerDocument;
  }
  function Bb(e, t, n) {
    var r = y_(n);
    if (!(yv || tl == null || tl !== oi(r))) {
      var i = m_(tl);
      if (!Uu || !Pu(Uu, i)) {
        Uu = i;
        var l = Hc(mv, "onSelect");
        if (l.length > 0) {
          var f = new sv("onSelect", "select", null, t, n);
          e.push({
            event: f,
            listeners: l
          }), f.target = tl;
        }
      }
    }
  }
  function g_(e, t, n, r, i, l, f) {
    var p = n ? ol(n) : window;
    switch (t) {
      case "focusin":
        (Lb(p) || p.contentEditable === "true") && (tl = p, mv = n, Uu = null);
        break;
      case "focusout":
        tl = null, mv = null, Uu = null;
        break;
      case "mousedown":
        yv = !0;
        break;
      case "contextmenu":
      case "mouseup":
      case "dragend":
        yv = !1, Bb(e, r, i);
        break;
      case "selectionchange":
        if (v_)
          break;
      case "keydown":
      case "keyup":
        Bb(e, r, i);
    }
  }
  function jc(e, t) {
    var n = {};
    return n[e.toLowerCase()] = t.toLowerCase(), n["Webkit" + e] = "webkit" + t, n["Moz" + e] = "moz" + t, n;
  }
  var nl = {
    animationend: jc("Animation", "AnimationEnd"),
    animationiteration: jc("Animation", "AnimationIteration"),
    animationstart: jc("Animation", "AnimationStart"),
    transitionend: jc("Transition", "TransitionEnd")
  }, gv = {}, Vb = {};
  yt && (Vb = document.createElement("div").style, "AnimationEvent" in window || (delete nl.animationend.animation, delete nl.animationiteration.animation, delete nl.animationstart.animation), "TransitionEvent" in window || delete nl.transitionend.transition);
  function Fc(e) {
    if (gv[e])
      return gv[e];
    if (!nl[e])
      return e;
    var t = nl[e];
    for (var n in t)
      if (t.hasOwnProperty(n) && n in Vb)
        return gv[e] = t[n];
    return e;
  }
  var Yb = Fc("animationend"), Wb = Fc("animationiteration"), Gb = Fc("animationstart"), Xb = Fc("transitionend"), Kb = /* @__PURE__ */ new Map(), qb = ["abort", "auxClick", "cancel", "canPlay", "canPlayThrough", "click", "close", "contextMenu", "copy", "cut", "drag", "dragEnd", "dragEnter", "dragExit", "dragLeave", "dragOver", "dragStart", "drop", "durationChange", "emptied", "encrypted", "ended", "error", "gotPointerCapture", "input", "invalid", "keyDown", "keyPress", "keyUp", "load", "loadedData", "loadedMetadata", "loadStart", "lostPointerCapture", "mouseDown", "mouseMove", "mouseOut", "mouseOver", "mouseUp", "paste", "pause", "play", "playing", "pointerCancel", "pointerDown", "pointerMove", "pointerOut", "pointerOver", "pointerUp", "progress", "rateChange", "reset", "resize", "seeked", "seeking", "stalled", "submit", "suspend", "timeUpdate", "touchCancel", "touchEnd", "touchStart", "volumeChange", "scroll", "toggle", "touchMove", "waiting", "wheel"];
  function pi(e, t) {
    Kb.set(e, t), wn(t, [e]);
  }
  function b_() {
    for (var e = 0; e < qb.length; e++) {
      var t = qb[e], n = t.toLowerCase(), r = t[0].toUpperCase() + t.slice(1);
      pi(n, "on" + r);
    }
    pi(Yb, "onAnimationEnd"), pi(Wb, "onAnimationIteration"), pi(Gb, "onAnimationStart"), pi("dblclick", "onDoubleClick"), pi("focusin", "onFocus"), pi("focusout", "onBlur"), pi(Xb, "onTransitionEnd");
  }
  function S_(e, t, n, r, i, l, f) {
    var p = Kb.get(t);
    if (p !== void 0) {
      var m = sv, C = t;
      switch (t) {
        case "keypress":
          if (Lc(r) === 0)
            return;
        case "keydown":
        case "keyup":
          m = CD;
          break;
        case "focusin":
          C = "focus", m = dv;
          break;
        case "focusout":
          C = "blur", m = dv;
          break;
        case "beforeblur":
        case "afterblur":
          m = dv;
          break;
        case "click":
          if (r.button === 2)
            return;
        case "auxclick":
        case "dblclick":
        case "mousedown":
        case "mousemove":
        case "mouseup":
        case "mouseout":
        case "mouseover":
        case "contextmenu":
          m = Eb;
          break;
        case "drag":
        case "dragend":
        case "dragenter":
        case "dragexit":
        case "dragleave":
        case "dragover":
        case "dragstart":
        case "drop":
          m = lD;
          break;
        case "touchcancel":
        case "touchend":
        case "touchmove":
        case "touchstart":
          m = wD;
          break;
        case Yb:
        case Wb:
        case Gb:
          m = cD;
          break;
        case Xb:
          m = TD;
          break;
        case "scroll":
          m = aD;
          break;
        case "wheel":
          m = _D;
          break;
        case "copy":
        case "cut":
        case "paste":
          m = dD;
          break;
        case "gotpointercapture":
        case "lostpointercapture":
        case "pointercancel":
        case "pointerdown":
        case "pointermove":
        case "pointerout":
        case "pointerover":
        case "pointerup":
          m = wb;
          break;
      }
      var w = (l & lu) !== 0;
      {
        var N = !w && // TODO: ideally, we'd eventually add all events from
        // nonDelegatedEvents list in DOMPluginEventSystem.
        // Then we can remove this special list.
        // This is a breaking change that can wait until React 18.
        t === "scroll", A = w_(n, p, r.type, w, N);
        if (A.length > 0) {
          var j = new m(p, C, null, r, i);
          e.push({
            event: j,
            listeners: A
          });
        }
      }
    }
  }
  b_(), t_(), ID(), h_(), AD();
  function C_(e, t, n, r, i, l, f) {
    S_(e, t, n, r, i, l);
    var p = (l & mT) === 0;
    p && (n_(e, t, n, r, i), e_(e, t, n, r, i), g_(e, t, n, r, i), zD(e, t, n, r, i));
  }
  var ju = ["abort", "canplay", "canplaythrough", "durationchange", "emptied", "encrypted", "ended", "error", "loadeddata", "loadedmetadata", "loadstart", "pause", "play", "playing", "progress", "ratechange", "resize", "seeked", "seeking", "stalled", "suspend", "timeupdate", "volumechange", "waiting"], bv = new Set(["cancel", "close", "invalid", "load", "scroll", "toggle"].concat(ju));
  function Qb(e, t, n) {
    var r = e.type || "unknown-event";
    e.currentTarget = n, _T(r, t, void 0, e), e.currentTarget = null;
  }
  function E_(e, t, n) {
    var r;
    if (n)
      for (var i = t.length - 1; i >= 0; i--) {
        var l = t[i], f = l.instance, p = l.currentTarget, m = l.listener;
        if (f !== r && e.isPropagationStopped())
          return;
        Qb(e, m, p), r = f;
      }
    else
      for (var C = 0; C < t.length; C++) {
        var w = t[C], N = w.instance, A = w.currentTarget, j = w.listener;
        if (N !== r && e.isPropagationStopped())
          return;
        Qb(e, j, A), r = N;
      }
  }
  function Zb(e, t) {
    for (var n = (t & lu) !== 0, r = 0; r < e.length; r++) {
      var i = e[r], l = i.event, f = i.listeners;
      E_(l, f, n);
    }
    MT();
  }
  function R_(e, t, n, r, i) {
    var l = vp(n), f = [];
    C_(f, e, r, n, l, t), Zb(f, t);
  }
  function wt(e, t) {
    bv.has(e) || c('Did not expect a listenToNonDelegatedEvent() call for "%s". This is a bug in React. Please file an issue.', e);
    var n = !1, r = JM(t), i = D_(e);
    r.has(i) || (Jb(t, e, pp, n), r.add(i));
  }
  function Sv(e, t, n) {
    bv.has(e) && !t && c('Did not expect a listenToNativeEvent() call for "%s" in the bubble phase. This is a bug in React. Please file an issue.', e);
    var r = 0;
    t && (r |= lu), Jb(n, e, r, t);
  }
  var zc = "_reactListening" + Math.random().toString(36).slice(2);
  function Fu(e) {
    if (!e[zc]) {
      e[zc] = !0, an.forEach(function(n) {
        n !== "selectionchange" && (bv.has(n) || Sv(n, !1, e), Sv(n, !0, e));
      });
      var t = e.nodeType === Oa ? e : e.ownerDocument;
      t !== null && (t[zc] || (t[zc] = !0, Sv("selectionchange", !1, t)));
    }
  }
  function Jb(e, t, n, r, i) {
    var l = X1(e, t, n), f = void 0;
    yp && (t === "touchstart" || t === "touchmove" || t === "wheel") && (f = !0), e = e, r ? f !== void 0 ? eD(e, t, l, f) : J1(e, t, l) : f !== void 0 ? tD(e, t, l, f) : Z1(e, t, l);
  }
  function eS(e, t) {
    return e === t || e.nodeType === $t && e.parentNode === t;
  }
  function Cv(e, t, n, r, i) {
    var l = r;
    if (!(t & Mg) && !(t & pp)) {
      var f = i;
      if (r !== null) {
        var p = r;
        e:
          for (; ; ) {
            if (p === null)
              return;
            var m = p.tag;
            if (m === E || m === x) {
              var C = p.stateNode.containerInfo;
              if (eS(C, f))
                break;
              if (m === x)
                for (var w = p.return; w !== null; ) {
                  var N = w.tag;
                  if (N === E || N === x) {
                    var A = w.stateNode.containerInfo;
                    if (eS(A, f))
                      return;
                  }
                  w = w.return;
                }
              for (; C !== null; ) {
                var j = oo(C);
                if (j === null)
                  return;
                var H = j.tag;
                if (H === T || H === M) {
                  p = l = j;
                  continue e;
                }
                C = C.parentNode;
              }
            }
            p = p.return;
          }
      }
    }
    Pg(function() {
      return R_(e, t, n, l);
    });
  }
  function zu(e, t, n) {
    return {
      instance: e,
      listener: t,
      currentTarget: n
    };
  }
  function w_(e, t, n, r, i, l) {
    for (var f = t !== null ? t + "Capture" : null, p = r ? f : t, m = [], C = e, w = null; C !== null; ) {
      var N = C, A = N.stateNode, j = N.tag;
      if (j === T && A !== null && (w = A, p !== null)) {
        var H = su(C, p);
        H != null && m.push(zu(C, H, w));
      }
      if (i)
        break;
      C = C.return;
    }
    return m;
  }
  function Hc(e, t) {
    for (var n = t + "Capture", r = [], i = e; i !== null; ) {
      var l = i, f = l.stateNode, p = l.tag;
      if (p === T && f !== null) {
        var m = f, C = su(i, n);
        C != null && r.unshift(zu(i, C, m));
        var w = su(i, t);
        w != null && r.push(zu(i, w, m));
      }
      i = i.return;
    }
    return r;
  }
  function rl(e) {
    if (e === null)
      return null;
    do
      e = e.return;
    while (e && e.tag !== T);
    return e || null;
  }
  function x_(e, t) {
    for (var n = e, r = t, i = 0, l = n; l; l = rl(l))
      i++;
    for (var f = 0, p = r; p; p = rl(p))
      f++;
    for (; i - f > 0; )
      n = rl(n), i--;
    for (; f - i > 0; )
      r = rl(r), f--;
    for (var m = i; m--; ) {
      if (n === r || r !== null && n === r.alternate)
        return n;
      n = rl(n), r = rl(r);
    }
    return null;
  }
  function tS(e, t, n, r, i) {
    for (var l = t._reactName, f = [], p = n; p !== null && p !== r; ) {
      var m = p, C = m.alternate, w = m.stateNode, N = m.tag;
      if (C !== null && C === r)
        break;
      if (N === T && w !== null) {
        var A = w;
        if (i) {
          var j = su(p, l);
          j != null && f.unshift(zu(p, j, A));
        } else if (!i) {
          var H = su(p, l);
          H != null && f.push(zu(p, H, A));
        }
      }
      p = p.return;
    }
    f.length !== 0 && e.push({
      event: t,
      listeners: f
    });
  }
  function T_(e, t, n, r, i) {
    var l = r && i ? x_(r, i) : null;
    r !== null && tS(e, t, r, l, !1), i !== null && n !== null && tS(e, n, i, l, !0);
  }
  function D_(e, t) {
    return e + "__bubble";
  }
  var qn = !1, Hu = "dangerouslySetInnerHTML", $c = "suppressContentEditableWarning", vi = "suppressHydrationWarning", nS = "autoFocus", ao = "children", io = "style", Ic = "__html", Ev, Bc, $u, rS, Vc, aS, iS;
  Ev = {
    // There are working polyfills for <dialog>. Let people use it.
    dialog: !0,
    // Electron ships a custom <webview> tag to display external web content in
    // an isolated frame and process.
    // This tag is not present in non Electron environments such as JSDom which
    // is often used for testing purposes.
    // @see https://electronjs.org/docs/api/webview-tag
    webview: !0
  }, Bc = function(e, t) {
    sT(e, t), cT(e, t), hT(e, t, {
      registrationNameDependencies: at,
      possibleRegistrationNames: zt
    });
  }, aS = yt && !document.documentMode, $u = function(e, t, n) {
    if (!qn) {
      var r = Yc(n), i = Yc(t);
      i !== r && (qn = !0, c("Prop `%s` did not match. Server: %s Client: %s", e, JSON.stringify(i), JSON.stringify(r)));
    }
  }, rS = function(e) {
    if (!qn) {
      qn = !0;
      var t = [];
      e.forEach(function(n) {
        t.push(n);
      }), c("Extra attributes from the server: %s", t);
    }
  }, Vc = function(e, t) {
    t === !1 ? c("Expected `%s` listener to be a function, instead got `false`.\n\nIf you used to conditionally omit it with %s={condition && value}, pass %s={condition ? value : undefined} instead.", e, e, e) : c("Expected `%s` listener to be a function, instead got a value of `%s` type.", e, typeof t);
  }, iS = function(e, t) {
    var n = e.namespaceURI === _a ? e.ownerDocument.createElement(e.tagName) : e.ownerDocument.createElementNS(e.namespaceURI, e.tagName);
    return n.innerHTML = t, n.innerHTML;
  };
  var __ = /\r\n?/g, M_ = /\u0000|\uFFFD/g;
  function Yc(e) {
    yr(e);
    var t = typeof e == "string" ? e : "" + e;
    return t.replace(__, `
`).replace(M_, "");
  }
  function Wc(e, t, n, r) {
    var i = Yc(t), l = Yc(e);
    if (l !== i && (r && (qn || (qn = !0, c('Text content did not match. Server: "%s" Client: "%s"', l, i))), n && de))
      throw new Error("Text content does not match server-rendered HTML.");
  }
  function oS(e) {
    return e.nodeType === Oa ? e : e.ownerDocument;
  }
  function O_() {
  }
  function Gc(e) {
    e.onclick = O_;
  }
  function A_(e, t, n, r, i) {
    for (var l in r)
      if (r.hasOwnProperty(l)) {
        var f = r[l];
        if (l === io)
          f && Object.freeze(f), Rg(t, f);
        else if (l === Hu) {
          var p = f ? f[Ic] : void 0;
          p != null && gg(t, p);
        } else if (l === ao)
          if (typeof f == "string") {
            var m = e !== "textarea" || f !== "";
            m && hc(t, f);
          } else
            typeof f == "number" && hc(t, "" + f);
        else
          l === $c || l === vi || l === nS || (at.hasOwnProperty(l) ? f != null && (typeof f != "function" && Vc(l, f), l === "onScroll" && wt("scroll", t)) : f != null && wa(t, l, f, i));
      }
  }
  function N_(e, t, n, r) {
    for (var i = 0; i < t.length; i += 2) {
      var l = t[i], f = t[i + 1];
      l === io ? Rg(e, f) : l === Hu ? gg(e, f) : l === ao ? hc(e, f) : wa(e, l, f, r);
    }
  }
  function L_(e, t, n, r) {
    var i, l = oS(n), f, p = r;
    if (p === _a && (p = lp(e)), p === _a) {
      if (i = Gi(e, t), !i && e !== e.toLowerCase() && c("<%s /> is using incorrect casing. Use PascalCase for React components, or lowercase for HTML elements.", e), e === "script") {
        var m = l.createElement("div");
        m.innerHTML = "<script><\/script>";
        var C = m.firstChild;
        f = m.removeChild(C);
      } else if (typeof t.is == "string")
        f = l.createElement(e, {
          is: t.is
        });
      else if (f = l.createElement(e), e === "select") {
        var w = f;
        t.multiple ? w.multiple = !0 : t.size && (w.size = t.size);
      }
    } else
      f = l.createElementNS(p, e);
    return p === _a && !i && Object.prototype.toString.call(f) === "[object HTMLUnknownElement]" && !Gt.call(Ev, e) && (Ev[e] = !0, c("The tag <%s> is unrecognized in this browser. If you meant to render a React component, start its name with an uppercase letter.", e)), f;
  }
  function k_(e, t) {
    return oS(t).createTextNode(e);
  }
  function P_(e, t, n, r) {
    var i = Gi(t, n);
    Bc(t, n);
    var l;
    switch (t) {
      case "dialog":
        wt("cancel", e), wt("close", e), l = n;
        break;
      case "iframe":
      case "object":
      case "embed":
        wt("load", e), l = n;
        break;
      case "video":
      case "audio":
        for (var f = 0; f < ju.length; f++)
          wt(ju[f], e);
        l = n;
        break;
      case "source":
        wt("error", e), l = n;
        break;
      case "img":
      case "image":
      case "link":
        wt("error", e), wt("load", e), l = n;
        break;
      case "details":
        wt("toggle", e), l = n;
        break;
      case "input":
        D(e, n), l = y(e, n), wt("invalid", e);
        break;
      case "option":
        ht(e, n), l = n;
        break;
      case "select":
        iu(e, n), l = au(e, n), wt("invalid", e);
        break;
      case "textarea":
        hg(e, n), l = ip(e, n), wt("invalid", e);
        break;
      default:
        l = n;
    }
    switch (dp(t, l), A_(t, e, r, l, i), t) {
      case "input":
        Ta(e), ee(e, n, !1);
        break;
      case "textarea":
        Ta(e), yg(e);
        break;
      case "option":
        Rt(e, n);
        break;
      case "select":
        ap(e, n);
        break;
      default:
        typeof l.onClick == "function" && Gc(e);
        break;
    }
  }
  function U_(e, t, n, r, i) {
    Bc(t, r);
    var l = null, f, p;
    switch (t) {
      case "input":
        f = y(e, n), p = y(e, r), l = [];
        break;
      case "select":
        f = au(e, n), p = au(e, r), l = [];
        break;
      case "textarea":
        f = ip(e, n), p = ip(e, r), l = [];
        break;
      default:
        f = n, p = r, typeof f.onClick != "function" && typeof p.onClick == "function" && Gc(e);
        break;
    }
    dp(t, p);
    var m, C, w = null;
    for (m in f)
      if (!(p.hasOwnProperty(m) || !f.hasOwnProperty(m) || f[m] == null))
        if (m === io) {
          var N = f[m];
          for (C in N)
            N.hasOwnProperty(C) && (w || (w = {}), w[C] = "");
        } else
          m === Hu || m === ao || m === $c || m === vi || m === nS || (at.hasOwnProperty(m) ? l || (l = []) : (l = l || []).push(m, null));
    for (m in p) {
      var A = p[m], j = f != null ? f[m] : void 0;
      if (!(!p.hasOwnProperty(m) || A === j || A == null && j == null))
        if (m === io)
          if (A && Object.freeze(A), j) {
            for (C in j)
              j.hasOwnProperty(C) && (!A || !A.hasOwnProperty(C)) && (w || (w = {}), w[C] = "");
            for (C in A)
              A.hasOwnProperty(C) && j[C] !== A[C] && (w || (w = {}), w[C] = A[C]);
          } else
            w || (l || (l = []), l.push(m, w)), w = A;
        else if (m === Hu) {
          var H = A ? A[Ic] : void 0, B = j ? j[Ic] : void 0;
          H != null && B !== H && (l = l || []).push(m, H);
        } else
          m === ao ? (typeof A == "string" || typeof A == "number") && (l = l || []).push(m, "" + A) : m === $c || m === vi || (at.hasOwnProperty(m) ? (A != null && (typeof A != "function" && Vc(m, A), m === "onScroll" && wt("scroll", e)), !l && j !== A && (l = [])) : (l = l || []).push(m, A));
    }
    return w && (tT(w, p[io]), (l = l || []).push(io, w)), l;
  }
  function j_(e, t, n, r, i) {
    n === "input" && i.type === "radio" && i.name != null && z(e, i);
    var l = Gi(n, r), f = Gi(n, i);
    switch (N_(e, t, l, f), n) {
      case "input":
        I(e, i);
        break;
      case "textarea":
        mg(e, i);
        break;
      case "select":
        Nx(e, i);
        break;
    }
  }
  function F_(e) {
    {
      var t = e.toLowerCase();
      return mc.hasOwnProperty(t) && mc[t] || null;
    }
  }
  function z_(e, t, n, r, i, l, f) {
    var p, m;
    switch (p = Gi(t, n), Bc(t, n), t) {
      case "dialog":
        wt("cancel", e), wt("close", e);
        break;
      case "iframe":
      case "object":
      case "embed":
        wt("load", e);
        break;
      case "video":
      case "audio":
        for (var C = 0; C < ju.length; C++)
          wt(ju[C], e);
        break;
      case "source":
        wt("error", e);
        break;
      case "img":
      case "image":
      case "link":
        wt("error", e), wt("load", e);
        break;
      case "details":
        wt("toggle", e);
        break;
      case "input":
        D(e, n), wt("invalid", e);
        break;
      case "option":
        ht(e, n);
        break;
      case "select":
        iu(e, n), wt("invalid", e);
        break;
      case "textarea":
        hg(e, n), wt("invalid", e);
        break;
    }
    dp(t, n);
    {
      m = /* @__PURE__ */ new Set();
      for (var w = e.attributes, N = 0; N < w.length; N++) {
        var A = w[N].name.toLowerCase();
        switch (A) {
          case "value":
            break;
          case "checked":
            break;
          case "selected":
            break;
          default:
            m.add(w[N].name);
        }
      }
    }
    var j = null;
    for (var H in n)
      if (n.hasOwnProperty(H)) {
        var B = n[H];
        if (H === ao)
          typeof B == "string" ? e.textContent !== B && (n[vi] !== !0 && Wc(e.textContent, B, l, f), j = [ao, B]) : typeof B == "number" && e.textContent !== "" + B && (n[vi] !== !0 && Wc(e.textContent, B, l, f), j = [ao, "" + B]);
        else if (at.hasOwnProperty(H))
          B != null && (typeof B != "function" && Vc(H, B), H === "onScroll" && wt("scroll", e));
        else if (f && // Convince Flow we've calculated it (it's DEV-only in this method.)
        typeof p == "boolean") {
          var ae = void 0, Ce = p && Ft ? null : nr(H);
          if (n[vi] !== !0) {
            if (!(H === $c || H === vi || // Controlled attributes are not validated
            // TODO: Only ignore them on controlled tags.
            H === "value" || H === "checked" || H === "selected")) {
              if (H === Hu) {
                var ye = e.innerHTML, Ge = B ? B[Ic] : void 0;
                if (Ge != null) {
                  var $e = iS(e, Ge);
                  $e !== ye && $u(H, ye, $e);
                }
              } else if (H === io) {
                if (m.delete(H), aS) {
                  var k = Jx(B);
                  ae = e.getAttribute("style"), k !== ae && $u(H, ae, k);
                }
              } else if (p && !Ft)
                m.delete(H.toLowerCase()), ae = Za(e, H, B), B !== ae && $u(H, ae, B);
              else if (!Ut(H, Ce, p) && !pt(H, B, Ce, p)) {
                var V = !1;
                if (Ce !== null)
                  m.delete(Ce.attributeName), ae = Ra(e, H, B, Ce);
                else {
                  var P = r;
                  if (P === _a && (P = lp(t)), P === _a)
                    m.delete(H.toLowerCase());
                  else {
                    var Q = F_(H);
                    Q !== null && Q !== H && (V = !0, m.delete(Q)), m.delete(H);
                  }
                  ae = Za(e, H, B);
                }
                var ue = Ft;
                !ue && B !== ae && !V && $u(H, ae, B);
              }
            }
          }
        }
      }
    switch (f && // $FlowFixMe - Should be inferred as not undefined.
    m.size > 0 && n[vi] !== !0 && rS(m), t) {
      case "input":
        Ta(e), ee(e, n, !0);
        break;
      case "textarea":
        Ta(e), yg(e);
        break;
      case "select":
      case "option":
        break;
      default:
        typeof n.onClick == "function" && Gc(e);
        break;
    }
    return j;
  }
  function H_(e, t, n) {
    var r = e.nodeValue !== t;
    return r;
  }
  function Rv(e, t) {
    {
      if (qn)
        return;
      qn = !0, c("Did not expect server HTML to contain a <%s> in <%s>.", t.nodeName.toLowerCase(), e.nodeName.toLowerCase());
    }
  }
  function wv(e, t) {
    {
      if (qn)
        return;
      qn = !0, c('Did not expect server HTML to contain the text node "%s" in <%s>.', t.nodeValue, e.nodeName.toLowerCase());
    }
  }
  function xv(e, t, n) {
    {
      if (qn)
        return;
      qn = !0, c("Expected server HTML to contain a matching <%s> in <%s>.", t, e.nodeName.toLowerCase());
    }
  }
  function Tv(e, t) {
    {
      if (t === "" || qn)
        return;
      qn = !0, c('Expected server HTML to contain a matching text node for "%s" in <%s>.', t, e.nodeName.toLowerCase());
    }
  }
  function $_(e, t, n) {
    switch (t) {
      case "input":
        _e(e, n);
        return;
      case "textarea":
        kx(e, n);
        return;
      case "select":
        Lx(e, n);
        return;
    }
  }
  var Iu = function() {
  }, Bu = function() {
  };
  {
    var I_ = ["address", "applet", "area", "article", "aside", "base", "basefont", "bgsound", "blockquote", "body", "br", "button", "caption", "center", "col", "colgroup", "dd", "details", "dir", "div", "dl", "dt", "embed", "fieldset", "figcaption", "figure", "footer", "form", "frame", "frameset", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "iframe", "img", "input", "isindex", "li", "link", "listing", "main", "marquee", "menu", "menuitem", "meta", "nav", "noembed", "noframes", "noscript", "object", "ol", "p", "param", "plaintext", "pre", "script", "section", "select", "source", "style", "summary", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "title", "tr", "track", "ul", "wbr", "xmp"], lS = [
      "applet",
      "caption",
      "html",
      "table",
      "td",
      "th",
      "marquee",
      "object",
      "template",
      // https://html.spec.whatwg.org/multipage/syntax.html#html-integration-point
      // TODO: Distinguish by namespace here -- for <title>, including it here
      // errs on the side of fewer warnings
      "foreignObject",
      "desc",
      "title"
    ], B_ = lS.concat(["button"]), V_ = ["dd", "dt", "li", "option", "optgroup", "p", "rp", "rt"], uS = {
      current: null,
      formTag: null,
      aTagInScope: null,
      buttonTagInScope: null,
      nobrTagInScope: null,
      pTagInButtonScope: null,
      listItemTagAutoclosing: null,
      dlItemTagAutoclosing: null
    };
    Bu = function(e, t) {
      var n = He({}, e || uS), r = {
        tag: t
      };
      return lS.indexOf(t) !== -1 && (n.aTagInScope = null, n.buttonTagInScope = null, n.nobrTagInScope = null), B_.indexOf(t) !== -1 && (n.pTagInButtonScope = null), I_.indexOf(t) !== -1 && t !== "address" && t !== "div" && t !== "p" && (n.listItemTagAutoclosing = null, n.dlItemTagAutoclosing = null), n.current = r, t === "form" && (n.formTag = r), t === "a" && (n.aTagInScope = r), t === "button" && (n.buttonTagInScope = r), t === "nobr" && (n.nobrTagInScope = r), t === "p" && (n.pTagInButtonScope = r), t === "li" && (n.listItemTagAutoclosing = r), (t === "dd" || t === "dt") && (n.dlItemTagAutoclosing = r), n;
    };
    var Y_ = function(e, t) {
      switch (t) {
        case "select":
          return e === "option" || e === "optgroup" || e === "#text";
        case "optgroup":
          return e === "option" || e === "#text";
        case "option":
          return e === "#text";
        case "tr":
          return e === "th" || e === "td" || e === "style" || e === "script" || e === "template";
        case "tbody":
        case "thead":
        case "tfoot":
          return e === "tr" || e === "style" || e === "script" || e === "template";
        case "colgroup":
          return e === "col" || e === "template";
        case "table":
          return e === "caption" || e === "colgroup" || e === "tbody" || e === "tfoot" || e === "thead" || e === "style" || e === "script" || e === "template";
        case "head":
          return e === "base" || e === "basefont" || e === "bgsound" || e === "link" || e === "meta" || e === "title" || e === "noscript" || e === "noframes" || e === "style" || e === "script" || e === "template";
        case "html":
          return e === "head" || e === "body" || e === "frameset";
        case "frameset":
          return e === "frame";
        case "#document":
          return e === "html";
      }
      switch (e) {
        case "h1":
        case "h2":
        case "h3":
        case "h4":
        case "h5":
        case "h6":
          return t !== "h1" && t !== "h2" && t !== "h3" && t !== "h4" && t !== "h5" && t !== "h6";
        case "rp":
        case "rt":
          return V_.indexOf(t) === -1;
        case "body":
        case "caption":
        case "col":
        case "colgroup":
        case "frameset":
        case "frame":
        case "head":
        case "html":
        case "tbody":
        case "td":
        case "tfoot":
        case "th":
        case "thead":
        case "tr":
          return t == null;
      }
      return !0;
    }, W_ = function(e, t) {
      switch (e) {
        case "address":
        case "article":
        case "aside":
        case "blockquote":
        case "center":
        case "details":
        case "dialog":
        case "dir":
        case "div":
        case "dl":
        case "fieldset":
        case "figcaption":
        case "figure":
        case "footer":
        case "header":
        case "hgroup":
        case "main":
        case "menu":
        case "nav":
        case "ol":
        case "p":
        case "section":
        case "summary":
        case "ul":
        case "pre":
        case "listing":
        case "table":
        case "hr":
        case "xmp":
        case "h1":
        case "h2":
        case "h3":
        case "h4":
        case "h5":
        case "h6":
          return t.pTagInButtonScope;
        case "form":
          return t.formTag || t.pTagInButtonScope;
        case "li":
          return t.listItemTagAutoclosing;
        case "dd":
        case "dt":
          return t.dlItemTagAutoclosing;
        case "button":
          return t.buttonTagInScope;
        case "a":
          return t.aTagInScope;
        case "nobr":
          return t.nobrTagInScope;
      }
      return null;
    }, sS = {};
    Iu = function(e, t, n) {
      n = n || uS;
      var r = n.current, i = r && r.tag;
      t != null && (e != null && c("validateDOMNesting: when childText is passed, childTag should be null"), e = "#text");
      var l = Y_(e, i) ? null : r, f = l ? null : W_(e, n), p = l || f;
      if (p) {
        var m = p.tag, C = !!l + "|" + e + "|" + m;
        if (!sS[C]) {
          sS[C] = !0;
          var w = e, N = "";
          if (e === "#text" ? /\S/.test(t) ? w = "Text nodes" : (w = "Whitespace text nodes", N = " Make sure you don't have any extra whitespace between tags on each line of your source code.") : w = "<" + e + ">", l) {
            var A = "";
            m === "table" && e === "tr" && (A += " Add a <tbody>, <thead> or <tfoot> to your code to match the DOM tree generated by the browser."), c("validateDOMNesting(...): %s cannot appear as a child of <%s>.%s%s", w, m, N, A);
          } else
            c("validateDOMNesting(...): %s cannot appear as a descendant of <%s>.", w, m);
        }
      }
    };
  }
  var Xc = "suppressHydrationWarning", Kc = "$", qc = "/$", Vu = "$?", Yu = "$!", G_ = "style", Dv = null, _v = null;
  function X_(e) {
    var t, n, r = e.nodeType;
    switch (r) {
      case Oa:
      case sp: {
        t = r === Oa ? "#document" : "#fragment";
        var i = e.documentElement;
        n = i ? i.namespaceURI : up(null, "");
        break;
      }
      default: {
        var l = r === $t ? e.parentNode : e, f = l.namespaceURI || null;
        t = l.tagName, n = up(f, t);
        break;
      }
    }
    {
      var p = t.toLowerCase(), m = Bu(null, p);
      return {
        namespace: n,
        ancestorInfo: m
      };
    }
  }
  function K_(e, t, n) {
    {
      var r = e, i = up(r.namespace, t), l = Bu(r.ancestorInfo, t);
      return {
        namespace: i,
        ancestorInfo: l
      };
    }
  }
  function b3(e) {
    return e;
  }
  function q_(e) {
    Dv = G1(), _v = c_();
    var t = null;
    return yb(!1), t;
  }
  function Q_(e) {
    f_(_v), yb(Dv), Dv = null, _v = null;
  }
  function Z_(e, t, n, r, i) {
    var l;
    {
      var f = r;
      if (Iu(e, null, f.ancestorInfo), typeof t.children == "string" || typeof t.children == "number") {
        var p = "" + t.children, m = Bu(f.ancestorInfo, e);
        Iu(null, p, m);
      }
      l = f.namespace;
    }
    var C = L_(e, t, n, l);
    return Xu(i, C), Uv(C, t), C;
  }
  function J_(e, t) {
    e.appendChild(t);
  }
  function eM(e, t, n, r, i) {
    switch (P_(e, t, n, r), t) {
      case "button":
      case "input":
      case "select":
      case "textarea":
        return !!n.autoFocus;
      case "img":
        return !0;
      default:
        return !1;
    }
  }
  function tM(e, t, n, r, i, l) {
    {
      var f = l;
      if (typeof r.children != typeof n.children && (typeof r.children == "string" || typeof r.children == "number")) {
        var p = "" + r.children, m = Bu(f.ancestorInfo, t);
        Iu(null, p, m);
      }
    }
    return U_(e, t, n, r);
  }
  function Mv(e, t) {
    return e === "textarea" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null;
  }
  function nM(e, t, n, r) {
    {
      var i = n;
      Iu(null, e, i.ancestorInfo);
    }
    var l = k_(e, t);
    return Xu(r, l), l;
  }
  function rM() {
    var e = window.event;
    return e === void 0 ? ja : gb(e.type);
  }
  var Ov = typeof setTimeout == "function" ? setTimeout : void 0, aM = typeof clearTimeout == "function" ? clearTimeout : void 0, Av = -1, cS = typeof Promise == "function" ? Promise : void 0, iM = typeof queueMicrotask == "function" ? queueMicrotask : typeof cS < "u" ? function(e) {
    return cS.resolve(null).then(e).catch(oM);
  } : Ov;
  function oM(e) {
    setTimeout(function() {
      throw e;
    });
  }
  function lM(e, t, n, r) {
    switch (t) {
      case "button":
      case "input":
      case "select":
      case "textarea":
        n.autoFocus && e.focus();
        return;
      case "img": {
        n.src && (e.src = n.src);
        return;
      }
    }
  }
  function uM(e, t, n, r, i, l) {
    j_(e, t, n, r, i), Uv(e, i);
  }
  function fS(e) {
    hc(e, "");
  }
  function sM(e, t, n) {
    e.nodeValue = n;
  }
  function cM(e, t) {
    e.appendChild(t);
  }
  function fM(e, t) {
    var n;
    e.nodeType === $t ? (n = e.parentNode, n.insertBefore(t, e)) : (n = e, n.appendChild(t));
    var r = e._reactRootContainer;
    r == null && n.onclick === null && Gc(n);
  }
  function dM(e, t, n) {
    e.insertBefore(t, n);
  }
  function pM(e, t, n) {
    e.nodeType === $t ? e.parentNode.insertBefore(t, n) : e.insertBefore(t, n);
  }
  function vM(e, t) {
    e.removeChild(t);
  }
  function hM(e, t) {
    e.nodeType === $t ? e.parentNode.removeChild(t) : e.removeChild(t);
  }
  function Nv(e, t) {
    var n = t, r = 0;
    do {
      var i = n.nextSibling;
      if (e.removeChild(n), i && i.nodeType === $t) {
        var l = i.data;
        if (l === qc)
          if (r === 0) {
            e.removeChild(i), Du(t);
            return;
          } else
            r--;
        else
          (l === Kc || l === Vu || l === Yu) && r++;
      }
      n = i;
    } while (n);
    Du(t);
  }
  function mM(e, t) {
    e.nodeType === $t ? Nv(e.parentNode, t) : e.nodeType === Kn && Nv(e, t), Du(e);
  }
  function yM(e) {
    e = e;
    var t = e.style;
    typeof t.setProperty == "function" ? t.setProperty("display", "none", "important") : t.display = "none";
  }
  function gM(e) {
    e.nodeValue = "";
  }
  function bM(e, t) {
    e = e;
    var n = t[G_], r = n != null && n.hasOwnProperty("display") ? n.display : null;
    e.style.display = cp("display", r);
  }
  function SM(e, t) {
    e.nodeValue = t;
  }
  function CM(e) {
    e.nodeType === Kn ? e.textContent = "" : e.nodeType === Oa && e.documentElement && e.removeChild(e.documentElement);
  }
  function EM(e, t, n) {
    return e.nodeType !== Kn || t.toLowerCase() !== e.nodeName.toLowerCase() ? null : e;
  }
  function RM(e, t) {
    return t === "" || e.nodeType !== Ma ? null : e;
  }
  function wM(e) {
    return e.nodeType !== $t ? null : e;
  }
  function dS(e) {
    return e.data === Vu;
  }
  function Lv(e) {
    return e.data === Yu;
  }
  function xM(e) {
    var t = e.nextSibling && e.nextSibling.dataset, n, r, i;
    return t && (n = t.dgst, r = t.msg, i = t.stck), {
      message: r,
      digest: n,
      stack: i
    };
  }
  function TM(e, t) {
    e._reactRetry = t;
  }
  function Qc(e) {
    for (; e != null; e = e.nextSibling) {
      var t = e.nodeType;
      if (t === Kn || t === Ma)
        break;
      if (t === $t) {
        var n = e.data;
        if (n === Kc || n === Yu || n === Vu)
          break;
        if (n === qc)
          return null;
      }
    }
    return e;
  }
  function Wu(e) {
    return Qc(e.nextSibling);
  }
  function DM(e) {
    return Qc(e.firstChild);
  }
  function _M(e) {
    return Qc(e.firstChild);
  }
  function MM(e) {
    return Qc(e.nextSibling);
  }
  function OM(e, t, n, r, i, l, f) {
    Xu(l, e), Uv(e, n);
    var p;
    {
      var m = i;
      p = m.namespace;
    }
    var C = (l.mode & Ye) !== Re;
    return z_(e, t, n, p, r, C, f);
  }
  function AM(e, t, n, r) {
    return Xu(n, e), n.mode & Ye, H_(e, t);
  }
  function NM(e, t) {
    Xu(t, e);
  }
  function LM(e) {
    for (var t = e.nextSibling, n = 0; t; ) {
      if (t.nodeType === $t) {
        var r = t.data;
        if (r === qc) {
          if (n === 0)
            return Wu(t);
          n--;
        } else
          (r === Kc || r === Yu || r === Vu) && n++;
      }
      t = t.nextSibling;
    }
    return null;
  }
  function pS(e) {
    for (var t = e.previousSibling, n = 0; t; ) {
      if (t.nodeType === $t) {
        var r = t.data;
        if (r === Kc || r === Yu || r === Vu) {
          if (n === 0)
            return t;
          n--;
        } else
          r === qc && n++;
      }
      t = t.previousSibling;
    }
    return null;
  }
  function kM(e) {
    Du(e);
  }
  function PM(e) {
    Du(e);
  }
  function UM(e) {
    return e !== "head" && e !== "body";
  }
  function jM(e, t, n, r) {
    var i = !0;
    Wc(t.nodeValue, n, r, i);
  }
  function FM(e, t, n, r, i, l) {
    if (t[Xc] !== !0) {
      var f = !0;
      Wc(r.nodeValue, i, l, f);
    }
  }
  function zM(e, t) {
    t.nodeType === Kn ? Rv(e, t) : t.nodeType === $t || wv(e, t);
  }
  function HM(e, t) {
    {
      var n = e.parentNode;
      n !== null && (t.nodeType === Kn ? Rv(n, t) : t.nodeType === $t || wv(n, t));
    }
  }
  function $M(e, t, n, r, i) {
    (i || t[Xc] !== !0) && (r.nodeType === Kn ? Rv(n, r) : r.nodeType === $t || wv(n, r));
  }
  function IM(e, t, n) {
    xv(e, t);
  }
  function BM(e, t) {
    Tv(e, t);
  }
  function VM(e, t, n) {
    {
      var r = e.parentNode;
      r !== null && xv(r, t);
    }
  }
  function YM(e, t) {
    {
      var n = e.parentNode;
      n !== null && Tv(n, t);
    }
  }
  function WM(e, t, n, r, i, l) {
    (l || t[Xc] !== !0) && xv(n, r);
  }
  function GM(e, t, n, r, i) {
    (i || t[Xc] !== !0) && Tv(n, r);
  }
  function XM(e) {
    c("An error occurred during hydration. The server HTML was replaced with client content in <%s>.", e.nodeName.toLowerCase());
  }
  function KM(e) {
    Fu(e);
  }
  var al = Math.random().toString(36).slice(2), il = "__reactFiber$" + al, kv = "__reactProps$" + al, Gu = "__reactContainer$" + al, Pv = "__reactEvents$" + al, qM = "__reactListeners$" + al, QM = "__reactHandles$" + al;
  function ZM(e) {
    delete e[il], delete e[kv], delete e[Pv], delete e[qM], delete e[QM];
  }
  function Xu(e, t) {
    t[il] = e;
  }
  function Zc(e, t) {
    t[Gu] = e;
  }
  function vS(e) {
    e[Gu] = null;
  }
  function Ku(e) {
    return !!e[Gu];
  }
  function oo(e) {
    var t = e[il];
    if (t)
      return t;
    for (var n = e.parentNode; n; ) {
      if (t = n[Gu] || n[il], t) {
        var r = t.alternate;
        if (t.child !== null || r !== null && r.child !== null)
          for (var i = pS(e); i !== null; ) {
            var l = i[il];
            if (l)
              return l;
            i = pS(i);
          }
        return t;
      }
      e = n, n = e.parentNode;
    }
    return null;
  }
  function hi(e) {
    var t = e[il] || e[Gu];
    return t && (t.tag === T || t.tag === M || t.tag === W || t.tag === E) ? t : null;
  }
  function ol(e) {
    if (e.tag === T || e.tag === M)
      return e.stateNode;
    throw new Error("getNodeFromInstance: Invalid argument.");
  }
  function Jc(e) {
    return e[kv] || null;
  }
  function Uv(e, t) {
    e[kv] = t;
  }
  function JM(e) {
    var t = e[Pv];
    return t === void 0 && (t = e[Pv] = /* @__PURE__ */ new Set()), t;
  }
  var hS = {}, mS = u.ReactDebugCurrentFrame;
  function ef(e) {
    if (e) {
      var t = e._owner, n = ri(e.type, e._source, t ? t.type : null);
      mS.setExtraStackFrame(n);
    } else
      mS.setExtraStackFrame(null);
  }
  function Fr(e, t, n, r, i) {
    {
      var l = Function.call.bind(Gt);
      for (var f in e)
        if (l(e, f)) {
          var p = void 0;
          try {
            if (typeof e[f] != "function") {
              var m = Error((r || "React class") + ": " + n + " type `" + f + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof e[f] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.");
              throw m.name = "Invariant Violation", m;
            }
            p = e[f](t, f, r, n, null, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
          } catch (C) {
            p = C;
          }
          p && !(p instanceof Error) && (ef(i), c("%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", r || "React class", n, f, typeof p), ef(null)), p instanceof Error && !(p.message in hS) && (hS[p.message] = !0, ef(i), c("Failed %s type: %s", n, p.message), ef(null));
        }
    }
  }
  var jv = [], tf;
  tf = [];
  var Fa = -1;
  function mi(e) {
    return {
      current: e
    };
  }
  function On(e, t) {
    if (Fa < 0) {
      c("Unexpected pop.");
      return;
    }
    t !== tf[Fa] && c("Unexpected Fiber popped."), e.current = jv[Fa], jv[Fa] = null, tf[Fa] = null, Fa--;
  }
  function An(e, t, n) {
    Fa++, jv[Fa] = e.current, tf[Fa] = n, e.current = t;
  }
  var Fv;
  Fv = {};
  var cr = {};
  Object.freeze(cr);
  var za = mi(cr), oa = mi(!1), zv = cr;
  function ll(e, t, n) {
    return n && la(t) ? zv : za.current;
  }
  function yS(e, t, n) {
    {
      var r = e.stateNode;
      r.__reactInternalMemoizedUnmaskedChildContext = t, r.__reactInternalMemoizedMaskedChildContext = n;
    }
  }
  function ul(e, t) {
    {
      var n = e.type, r = n.contextTypes;
      if (!r)
        return cr;
      var i = e.stateNode;
      if (i && i.__reactInternalMemoizedUnmaskedChildContext === t)
        return i.__reactInternalMemoizedMaskedChildContext;
      var l = {};
      for (var f in r)
        l[f] = t[f];
      {
        var p = Pe(e) || "Unknown";
        Fr(r, l, "context", p);
      }
      return i && yS(e, t, l), l;
    }
  }
  function nf() {
    return oa.current;
  }
  function la(e) {
    {
      var t = e.childContextTypes;
      return t != null;
    }
  }
  function rf(e) {
    On(oa, e), On(za, e);
  }
  function Hv(e) {
    On(oa, e), On(za, e);
  }
  function gS(e, t, n) {
    {
      if (za.current !== cr)
        throw new Error("Unexpected context found on stack. This error is likely caused by a bug in React. Please file an issue.");
      An(za, t, e), An(oa, n, e);
    }
  }
  function bS(e, t, n) {
    {
      var r = e.stateNode, i = t.childContextTypes;
      if (typeof r.getChildContext != "function") {
        {
          var l = Pe(e) || "Unknown";
          Fv[l] || (Fv[l] = !0, c("%s.childContextTypes is specified but there is no getChildContext() method on the instance. You can either define getChildContext() on %s or remove childContextTypes from it.", l, l));
        }
        return n;
      }
      var f = r.getChildContext();
      for (var p in f)
        if (!(p in i))
          throw new Error((Pe(e) || "Unknown") + '.getChildContext(): key "' + p + '" is not defined in childContextTypes.');
      {
        var m = Pe(e) || "Unknown";
        Fr(i, f, "child context", m);
      }
      return He({}, n, f);
    }
  }
  function af(e) {
    {
      var t = e.stateNode, n = t && t.__reactInternalMemoizedMergedChildContext || cr;
      return zv = za.current, An(za, n, e), An(oa, oa.current, e), !0;
    }
  }
  function SS(e, t, n) {
    {
      var r = e.stateNode;
      if (!r)
        throw new Error("Expected to have an instance by this point. This error is likely caused by a bug in React. Please file an issue.");
      if (n) {
        var i = bS(e, t, zv);
        r.__reactInternalMemoizedMergedChildContext = i, On(oa, e), On(za, e), An(za, i, e), An(oa, n, e);
      } else
        On(oa, e), An(oa, n, e);
    }
  }
  function eO(e) {
    {
      if (!UT(e) || e.tag !== S)
        throw new Error("Expected subtree parent to be a mounted class component. This error is likely caused by a bug in React. Please file an issue.");
      var t = e;
      do {
        switch (t.tag) {
          case E:
            return t.stateNode.context;
          case S: {
            var n = t.type;
            if (la(n))
              return t.stateNode.__reactInternalMemoizedMergedChildContext;
            break;
          }
        }
        t = t.return;
      } while (t !== null);
      throw new Error("Found unexpected detached subtree parent. This error is likely caused by a bug in React. Please file an issue.");
    }
  }
  var yi = 0, of = 1, Ha = null, $v = !1, Iv = !1;
  function CS(e) {
    Ha === null ? Ha = [e] : Ha.push(e);
  }
  function tO(e) {
    $v = !0, CS(e);
  }
  function ES() {
    $v && gi();
  }
  function gi() {
    if (!Iv && Ha !== null) {
      Iv = !0;
      var e = 0, t = jr();
      try {
        var n = !0, r = Ha;
        for (fn(lr); e < r.length; e++) {
          var i = r[e];
          do
            i = i(n);
          while (i !== null);
        }
        Ha = null, $v = !1;
      } catch (l) {
        throw Ha !== null && (Ha = Ha.slice(e + 1)), Wg(Cc, gi), l;
      } finally {
        fn(t), Iv = !1;
      }
    }
    return null;
  }
  var sl = [], cl = 0, lf = null, uf = 0, Er = [], Rr = 0, lo = null, $a = 1, Ia = "";
  function nO(e) {
    return so(), (e.flags & Fg) !== Te;
  }
  function rO(e) {
    return so(), uf;
  }
  function aO() {
    var e = Ia, t = $a, n = t & ~iO(t);
    return n.toString(32) + e;
  }
  function uo(e, t) {
    so(), sl[cl++] = uf, sl[cl++] = lf, lf = e, uf = t;
  }
  function RS(e, t, n) {
    so(), Er[Rr++] = $a, Er[Rr++] = Ia, Er[Rr++] = lo, lo = e;
    var r = $a, i = Ia, l = sf(r) - 1, f = r & ~(1 << l), p = n + 1, m = sf(t) + l;
    if (m > 30) {
      var C = l - l % 5, w = (1 << C) - 1, N = (f & w).toString(32), A = f >> C, j = l - C, H = sf(t) + j, B = p << j, ae = B | A, Ce = N + i;
      $a = 1 << H | ae, Ia = Ce;
    } else {
      var ye = p << l, Ge = ye | f, $e = i;
      $a = 1 << m | Ge, Ia = $e;
    }
  }
  function Bv(e) {
    so();
    var t = e.return;
    if (t !== null) {
      var n = 1, r = 0;
      uo(e, n), RS(e, n, r);
    }
  }
  function sf(e) {
    return 32 - Zg(e);
  }
  function iO(e) {
    return 1 << sf(e) - 1;
  }
  function Vv(e) {
    for (; e === lf; )
      lf = sl[--cl], sl[cl] = null, uf = sl[--cl], sl[cl] = null;
    for (; e === lo; )
      lo = Er[--Rr], Er[Rr] = null, Ia = Er[--Rr], Er[Rr] = null, $a = Er[--Rr], Er[Rr] = null;
  }
  function oO() {
    return so(), lo !== null ? {
      id: $a,
      overflow: Ia
    } : null;
  }
  function lO(e, t) {
    so(), Er[Rr++] = $a, Er[Rr++] = Ia, Er[Rr++] = lo, $a = t.id, Ia = t.overflow, lo = e;
  }
  function so() {
    hn() || c("Expected to be hydrating. This is a bug in React. Please file an issue.");
  }
  var vn = null, wr = null, zr = !1, co = !1, bi = null;
  function uO() {
    zr && c("We should not be hydrating here. This is a bug in React. Please file a bug.");
  }
  function wS() {
    co = !0;
  }
  function sO() {
    return co;
  }
  function cO(e) {
    var t = e.stateNode.containerInfo;
    return wr = _M(t), vn = e, zr = !0, bi = null, co = !1, !0;
  }
  function fO(e, t, n) {
    return wr = MM(t), vn = e, zr = !0, bi = null, co = !1, n !== null && lO(e, n), !0;
  }
  function xS(e, t) {
    switch (e.tag) {
      case E: {
        zM(e.stateNode.containerInfo, t);
        break;
      }
      case T: {
        var n = (e.mode & Ye) !== Re;
        $M(
          e.type,
          e.memoizedProps,
          e.stateNode,
          t,
          // TODO: Delete this argument when we remove the legacy root API.
          n
        );
        break;
      }
      case W: {
        var r = e.memoizedState;
        r.dehydrated !== null && HM(r.dehydrated, t);
        break;
      }
    }
  }
  function TS(e, t) {
    xS(e, t);
    var n = hL();
    n.stateNode = t, n.return = e;
    var r = e.deletions;
    r === null ? (e.deletions = [n], e.flags |= Xi) : r.push(n);
  }
  function Yv(e, t) {
    {
      if (co)
        return;
      switch (e.tag) {
        case E: {
          var n = e.stateNode.containerInfo;
          switch (t.tag) {
            case T:
              var r = t.type;
              t.pendingProps, IM(n, r);
              break;
            case M:
              var i = t.pendingProps;
              BM(n, i);
              break;
          }
          break;
        }
        case T: {
          var l = e.type, f = e.memoizedProps, p = e.stateNode;
          switch (t.tag) {
            case T: {
              var m = t.type, C = t.pendingProps, w = (e.mode & Ye) !== Re;
              WM(
                l,
                f,
                p,
                m,
                C,
                // TODO: Delete this argument when we remove the legacy root API.
                w
              );
              break;
            }
            case M: {
              var N = t.pendingProps, A = (e.mode & Ye) !== Re;
              GM(
                l,
                f,
                p,
                N,
                // TODO: Delete this argument when we remove the legacy root API.
                A
              );
              break;
            }
          }
          break;
        }
        case W: {
          var j = e.memoizedState, H = j.dehydrated;
          if (H !== null)
            switch (t.tag) {
              case T:
                var B = t.type;
                t.pendingProps, VM(H, B);
                break;
              case M:
                var ae = t.pendingProps;
                YM(H, ae);
                break;
            }
          break;
        }
        default:
          return;
      }
    }
  }
  function DS(e, t) {
    t.flags = t.flags & ~Na | It, Yv(e, t);
  }
  function _S(e, t) {
    switch (e.tag) {
      case T: {
        var n = e.type;
        e.pendingProps;
        var r = EM(t, n);
        return r !== null ? (e.stateNode = r, vn = e, wr = DM(r), !0) : !1;
      }
      case M: {
        var i = e.pendingProps, l = RM(t, i);
        return l !== null ? (e.stateNode = l, vn = e, wr = null, !0) : !1;
      }
      case W: {
        var f = wM(t);
        if (f !== null) {
          var p = {
            dehydrated: f,
            treeContext: oO(),
            retryLane: ir
          };
          e.memoizedState = p;
          var m = mL(f);
          return m.return = e, e.child = m, vn = e, wr = null, !0;
        }
        return !1;
      }
      default:
        return !1;
    }
  }
  function Wv(e) {
    return (e.mode & Ye) !== Re && (e.flags & nt) === Te;
  }
  function Gv(e) {
    throw new Error("Hydration failed because the initial UI does not match what was rendered on the server.");
  }
  function Xv(e) {
    if (zr) {
      var t = wr;
      if (!t) {
        Wv(e) && (Yv(vn, e), Gv()), DS(vn, e), zr = !1, vn = e;
        return;
      }
      var n = t;
      if (!_S(e, t)) {
        Wv(e) && (Yv(vn, e), Gv()), t = Wu(n);
        var r = vn;
        if (!t || !_S(e, t)) {
          DS(vn, e), zr = !1, vn = e;
          return;
        }
        TS(r, n);
      }
    }
  }
  function dO(e, t, n) {
    var r = e.stateNode, i = !co, l = OM(r, e.type, e.memoizedProps, t, n, e, i);
    return e.updateQueue = l, l !== null;
  }
  function pO(e) {
    var t = e.stateNode, n = e.memoizedProps, r = AM(t, n, e);
    if (r) {
      var i = vn;
      if (i !== null)
        switch (i.tag) {
          case E: {
            var l = i.stateNode.containerInfo, f = (i.mode & Ye) !== Re;
            jM(
              l,
              t,
              n,
              // TODO: Delete this argument when we remove the legacy root API.
              f
            );
            break;
          }
          case T: {
            var p = i.type, m = i.memoizedProps, C = i.stateNode, w = (i.mode & Ye) !== Re;
            FM(
              p,
              m,
              C,
              t,
              n,
              // TODO: Delete this argument when we remove the legacy root API.
              w
            );
            break;
          }
        }
    }
    return r;
  }
  function vO(e) {
    var t = e.memoizedState, n = t !== null ? t.dehydrated : null;
    if (!n)
      throw new Error("Expected to have a hydrated suspense instance. This error is likely caused by a bug in React. Please file an issue.");
    NM(n, e);
  }
  function hO(e) {
    var t = e.memoizedState, n = t !== null ? t.dehydrated : null;
    if (!n)
      throw new Error("Expected to have a hydrated suspense instance. This error is likely caused by a bug in React. Please file an issue.");
    return LM(n);
  }
  function MS(e) {
    for (var t = e.return; t !== null && t.tag !== T && t.tag !== E && t.tag !== W; )
      t = t.return;
    vn = t;
  }
  function cf(e) {
    if (e !== vn)
      return !1;
    if (!zr)
      return MS(e), zr = !0, !1;
    if (e.tag !== E && (e.tag !== T || UM(e.type) && !Mv(e.type, e.memoizedProps))) {
      var t = wr;
      if (t)
        if (Wv(e))
          OS(e), Gv();
        else
          for (; t; )
            TS(e, t), t = Wu(t);
    }
    return MS(e), e.tag === W ? wr = hO(e) : wr = vn ? Wu(e.stateNode) : null, !0;
  }
  function mO() {
    return zr && wr !== null;
  }
  function OS(e) {
    for (var t = wr; t; )
      xS(e, t), t = Wu(t);
  }
  function fl() {
    vn = null, wr = null, zr = !1, co = !1;
  }
  function AS() {
    bi !== null && (wE(bi), bi = null);
  }
  function hn() {
    return zr;
  }
  function Kv(e) {
    bi === null ? bi = [e] : bi.push(e);
  }
  var yO = u.ReactCurrentBatchConfig, gO = null;
  function bO() {
    return yO.transition;
  }
  var Hr = {
    recordUnsafeLifecycleWarnings: function(e, t) {
    },
    flushPendingUnsafeLifecycleWarnings: function() {
    },
    recordLegacyContextWarning: function(e, t) {
    },
    flushLegacyContextWarning: function() {
    },
    discardPendingWarnings: function() {
    }
  };
  {
    var SO = function(e) {
      for (var t = null, n = e; n !== null; )
        n.mode & Mt && (t = n), n = n.return;
      return t;
    }, fo = function(e) {
      var t = [];
      return e.forEach(function(n) {
        t.push(n);
      }), t.sort().join(", ");
    }, qu = [], Qu = [], Zu = [], Ju = [], es = [], ts = [], po = /* @__PURE__ */ new Set();
    Hr.recordUnsafeLifecycleWarnings = function(e, t) {
      po.has(e.type) || (typeof t.componentWillMount == "function" && // Don't warn about react-lifecycles-compat polyfilled components.
      t.componentWillMount.__suppressDeprecationWarning !== !0 && qu.push(e), e.mode & Mt && typeof t.UNSAFE_componentWillMount == "function" && Qu.push(e), typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps.__suppressDeprecationWarning !== !0 && Zu.push(e), e.mode & Mt && typeof t.UNSAFE_componentWillReceiveProps == "function" && Ju.push(e), typeof t.componentWillUpdate == "function" && t.componentWillUpdate.__suppressDeprecationWarning !== !0 && es.push(e), e.mode & Mt && typeof t.UNSAFE_componentWillUpdate == "function" && ts.push(e));
    }, Hr.flushPendingUnsafeLifecycleWarnings = function() {
      var e = /* @__PURE__ */ new Set();
      qu.length > 0 && (qu.forEach(function(A) {
        e.add(Pe(A) || "Component"), po.add(A.type);
      }), qu = []);
      var t = /* @__PURE__ */ new Set();
      Qu.length > 0 && (Qu.forEach(function(A) {
        t.add(Pe(A) || "Component"), po.add(A.type);
      }), Qu = []);
      var n = /* @__PURE__ */ new Set();
      Zu.length > 0 && (Zu.forEach(function(A) {
        n.add(Pe(A) || "Component"), po.add(A.type);
      }), Zu = []);
      var r = /* @__PURE__ */ new Set();
      Ju.length > 0 && (Ju.forEach(function(A) {
        r.add(Pe(A) || "Component"), po.add(A.type);
      }), Ju = []);
      var i = /* @__PURE__ */ new Set();
      es.length > 0 && (es.forEach(function(A) {
        i.add(Pe(A) || "Component"), po.add(A.type);
      }), es = []);
      var l = /* @__PURE__ */ new Set();
      if (ts.length > 0 && (ts.forEach(function(A) {
        l.add(Pe(A) || "Component"), po.add(A.type);
      }), ts = []), t.size > 0) {
        var f = fo(t);
        c(`Using UNSAFE_componentWillMount in strict mode is not recommended and may indicate bugs in your code. See https://reactjs.org/link/unsafe-component-lifecycles for details.

* Move code with side effects to componentDidMount, and set initial state in the constructor.

Please update the following components: %s`, f);
      }
      if (r.size > 0) {
        var p = fo(r);
        c(`Using UNSAFE_componentWillReceiveProps in strict mode is not recommended and may indicate bugs in your code. See https://reactjs.org/link/unsafe-component-lifecycles for details.

* Move data fetching code or side effects to componentDidUpdate.
* If you're updating state whenever props change, refactor your code to use memoization techniques or move it to static getDerivedStateFromProps. Learn more at: https://reactjs.org/link/derived-state

Please update the following components: %s`, p);
      }
      if (l.size > 0) {
        var m = fo(l);
        c(`Using UNSAFE_componentWillUpdate in strict mode is not recommended and may indicate bugs in your code. See https://reactjs.org/link/unsafe-component-lifecycles for details.

* Move data fetching code or side effects to componentDidUpdate.

Please update the following components: %s`, m);
      }
      if (e.size > 0) {
        var C = fo(e);
        v(`componentWillMount has been renamed, and is not recommended for use. See https://reactjs.org/link/unsafe-component-lifecycles for details.

* Move code with side effects to componentDidMount, and set initial state in the constructor.
* Rename componentWillMount to UNSAFE_componentWillMount to suppress this warning in non-strict mode. In React 18.x, only the UNSAFE_ name will work. To rename all deprecated lifecycles to their new names, you can run \`npx react-codemod rename-unsafe-lifecycles\` in your project source folder.

Please update the following components: %s`, C);
      }
      if (n.size > 0) {
        var w = fo(n);
        v(`componentWillReceiveProps has been renamed, and is not recommended for use. See https://reactjs.org/link/unsafe-component-lifecycles for details.

* Move data fetching code or side effects to componentDidUpdate.
* If you're updating state whenever props change, refactor your code to use memoization techniques or move it to static getDerivedStateFromProps. Learn more at: https://reactjs.org/link/derived-state
* Rename componentWillReceiveProps to UNSAFE_componentWillReceiveProps to suppress this warning in non-strict mode. In React 18.x, only the UNSAFE_ name will work. To rename all deprecated lifecycles to their new names, you can run \`npx react-codemod rename-unsafe-lifecycles\` in your project source folder.

Please update the following components: %s`, w);
      }
      if (i.size > 0) {
        var N = fo(i);
        v(`componentWillUpdate has been renamed, and is not recommended for use. See https://reactjs.org/link/unsafe-component-lifecycles for details.

* Move data fetching code or side effects to componentDidUpdate.
* Rename componentWillUpdate to UNSAFE_componentWillUpdate to suppress this warning in non-strict mode. In React 18.x, only the UNSAFE_ name will work. To rename all deprecated lifecycles to their new names, you can run \`npx react-codemod rename-unsafe-lifecycles\` in your project source folder.

Please update the following components: %s`, N);
      }
    };
    var ff = /* @__PURE__ */ new Map(), NS = /* @__PURE__ */ new Set();
    Hr.recordLegacyContextWarning = function(e, t) {
      var n = SO(e);
      if (n === null) {
        c("Expected to find a StrictMode component in a strict mode tree. This error is likely caused by a bug in React. Please file an issue.");
        return;
      }
      if (!NS.has(e.type)) {
        var r = ff.get(n);
        (e.type.contextTypes != null || e.type.childContextTypes != null || t !== null && typeof t.getChildContext == "function") && (r === void 0 && (r = [], ff.set(n, r)), r.push(e));
      }
    }, Hr.flushLegacyContextWarning = function() {
      ff.forEach(function(e, t) {
        if (e.length !== 0) {
          var n = e[0], r = /* @__PURE__ */ new Set();
          e.forEach(function(l) {
            r.add(Pe(l) || "Component"), NS.add(l.type);
          });
          var i = fo(r);
          try {
            Tt(n), c(`Legacy context API has been detected within a strict-mode tree.

The old API will be supported in all 16.x releases, but applications using it should migrate to the new version.

Please update the following components: %s

Learn more about this warning here: https://reactjs.org/link/legacy-context`, i);
          } finally {
            ln();
          }
        }
      });
    }, Hr.discardPendingWarnings = function() {
      qu = [], Qu = [], Zu = [], Ju = [], es = [], ts = [], ff = /* @__PURE__ */ new Map();
    };
  }
  var qv, Qv, Zv, Jv, eh, LS = function(e, t) {
  };
  qv = !1, Qv = !1, Zv = {}, Jv = {}, eh = {}, LS = function(e, t) {
    if (!(e === null || typeof e != "object") && !(!e._store || e._store.validated || e.key != null)) {
      if (typeof e._store != "object")
        throw new Error("React Component in warnForMissingKey should have a _store. This error is likely caused by a bug in React. Please file an issue.");
      e._store.validated = !0;
      var n = Pe(t) || "Component";
      Jv[n] || (Jv[n] = !0, c('Each child in a list should have a unique "key" prop. See https://reactjs.org/link/warning-keys for more information.'));
    }
  };
  function CO(e) {
    return e.prototype && e.prototype.isReactComponent;
  }
  function ns(e, t, n) {
    var r = n.ref;
    if (r !== null && typeof r != "function" && typeof r != "object") {
      if ((e.mode & Mt || Yt) && // We warn in ReactElement.js if owner and self are equal for string refs
      // because these cannot be automatically converted to an arrow function
      // using a codemod. Therefore, we don't have to warn about string refs again.
      !(n._owner && n._self && n._owner.stateNode !== n._self) && // Will already throw with "Function components cannot have string refs"
      !(n._owner && n._owner.tag !== S) && // Will already warn with "Function components cannot be given refs"
      !(typeof n.type == "function" && !CO(n.type)) && // Will already throw with "Element ref was specified as a string (someStringRef) but no owner was set"
      n._owner) {
        var i = Pe(e) || "Component";
        Zv[i] || (c('Component "%s" contains the string ref "%s". Support for string refs will be removed in a future major release. We recommend using useRef() or createRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref', i, r), Zv[i] = !0);
      }
      if (n._owner) {
        var l = n._owner, f;
        if (l) {
          var p = l;
          if (p.tag !== S)
            throw new Error("Function components cannot have string refs. We recommend using useRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref");
          f = p.stateNode;
        }
        if (!f)
          throw new Error("Missing owner for string ref " + r + ". This error is likely caused by a bug in React. Please file an issue.");
        var m = f;
        Wn(r, "ref");
        var C = "" + r;
        if (t !== null && t.ref !== null && typeof t.ref == "function" && t.ref._stringRef === C)
          return t.ref;
        var w = function(N) {
          var A = m.refs;
          N === null ? delete A[C] : A[C] = N;
        };
        return w._stringRef = C, w;
      } else {
        if (typeof r != "string")
          throw new Error("Expected ref to be a function, a string, an object returned by React.createRef(), or null.");
        if (!n._owner)
          throw new Error("Element ref was specified as a string (" + r + `) but no owner was set. This could happen for one of the following reasons:
1. You may be adding a ref to a function component
2. You may be adding a ref to a component that was not created inside a component's render method
3. You have multiple copies of React loaded
See https://reactjs.org/link/refs-must-have-owner for more information.`);
      }
    }
    return r;
  }
  function df(e, t) {
    var n = Object.prototype.toString.call(t);
    throw new Error("Objects are not valid as a React child (found: " + (n === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : n) + "). If you meant to render a collection of children, use an array instead.");
  }
  function pf(e) {
    {
      var t = Pe(e) || "Component";
      if (eh[t])
        return;
      eh[t] = !0, c("Functions are not valid as a React child. This may happen if you return a Component instead of <Component /> from render. Or maybe you meant to call this function rather than return it.");
    }
  }
  function kS(e) {
    var t = e._payload, n = e._init;
    return n(t);
  }
  function PS(e) {
    function t(k, V) {
      if (e) {
        var P = k.deletions;
        P === null ? (k.deletions = [V], k.flags |= Xi) : P.push(V);
      }
    }
    function n(k, V) {
      if (!e)
        return null;
      for (var P = V; P !== null; )
        t(k, P), P = P.sibling;
      return null;
    }
    function r(k, V) {
      for (var P = /* @__PURE__ */ new Map(), Q = V; Q !== null; )
        Q.key !== null ? P.set(Q.key, Q) : P.set(Q.index, Q), Q = Q.sibling;
      return P;
    }
    function i(k, V) {
      var P = Eo(k, V);
      return P.index = 0, P.sibling = null, P;
    }
    function l(k, V, P) {
      if (k.index = P, !e)
        return k.flags |= Fg, V;
      var Q = k.alternate;
      if (Q !== null) {
        var ue = Q.index;
        return ue < V ? (k.flags |= It, V) : ue;
      } else
        return k.flags |= It, V;
    }
    function f(k) {
      return e && k.alternate === null && (k.flags |= It), k;
    }
    function p(k, V, P, Q) {
      if (V === null || V.tag !== M) {
        var ue = Km(P, k.mode, Q);
        return ue.return = k, ue;
      } else {
        var ie = i(V, P);
        return ie.return = k, ie;
      }
    }
    function m(k, V, P, Q) {
      var ue = P.type;
      if (ue === ea)
        return w(k, V, P.props.children, Q, P.key);
      if (V !== null && (V.elementType === ue || // Keep this check inline so it only runs on the false path:
      HE(V, P) || // Lazy types should reconcile their resolved type.
      // We need to do this after the Hot Reloading check above,
      // because hot reloading has different semantics than prod because
      // it doesn't resuspend. So we can't let the call below suspend.
      typeof ue == "object" && ue !== null && ue.$$typeof === xe && kS(ue) === V.type)) {
        var ie = i(V, P.props);
        return ie.ref = ns(k, V, P), ie.return = k, ie._debugSource = P._source, ie._debugOwner = P._owner, ie;
      }
      var Me = Xm(P, k.mode, Q);
      return Me.ref = ns(k, V, P), Me.return = k, Me;
    }
    function C(k, V, P, Q) {
      if (V === null || V.tag !== x || V.stateNode.containerInfo !== P.containerInfo || V.stateNode.implementation !== P.implementation) {
        var ue = qm(P, k.mode, Q);
        return ue.return = k, ue;
      } else {
        var ie = i(V, P.children || []);
        return ie.return = k, ie;
      }
    }
    function w(k, V, P, Q, ue) {
      if (V === null || V.tag !== L) {
        var ie = Oi(P, k.mode, Q, ue);
        return ie.return = k, ie;
      } else {
        var Me = i(V, P);
        return Me.return = k, Me;
      }
    }
    function N(k, V, P) {
      if (typeof V == "string" && V !== "" || typeof V == "number") {
        var Q = Km("" + V, k.mode, P);
        return Q.return = k, Q;
      }
      if (typeof V == "object" && V !== null) {
        switch (V.$$typeof) {
          case Lr: {
            var ue = Xm(V, k.mode, P);
            return ue.ref = ns(k, null, V), ue.return = k, ue;
          }
          case kr: {
            var ie = qm(V, k.mode, P);
            return ie.return = k, ie;
          }
          case xe: {
            var Me = V._payload, ke = V._init;
            return N(k, ke(Me), P);
          }
        }
        if (tt(V) || rr(V)) {
          var ct = Oi(V, k.mode, P, null);
          return ct.return = k, ct;
        }
        df(k, V);
      }
      return typeof V == "function" && pf(k), null;
    }
    function A(k, V, P, Q) {
      var ue = V !== null ? V.key : null;
      if (typeof P == "string" && P !== "" || typeof P == "number")
        return ue !== null ? null : p(k, V, "" + P, Q);
      if (typeof P == "object" && P !== null) {
        switch (P.$$typeof) {
          case Lr:
            return P.key === ue ? m(k, V, P, Q) : null;
          case kr:
            return P.key === ue ? C(k, V, P, Q) : null;
          case xe: {
            var ie = P._payload, Me = P._init;
            return A(k, V, Me(ie), Q);
          }
        }
        if (tt(P) || rr(P))
          return ue !== null ? null : w(k, V, P, Q, null);
        df(k, P);
      }
      return typeof P == "function" && pf(k), null;
    }
    function j(k, V, P, Q, ue) {
      if (typeof Q == "string" && Q !== "" || typeof Q == "number") {
        var ie = k.get(P) || null;
        return p(V, ie, "" + Q, ue);
      }
      if (typeof Q == "object" && Q !== null) {
        switch (Q.$$typeof) {
          case Lr: {
            var Me = k.get(Q.key === null ? P : Q.key) || null;
            return m(V, Me, Q, ue);
          }
          case kr: {
            var ke = k.get(Q.key === null ? P : Q.key) || null;
            return C(V, ke, Q, ue);
          }
          case xe:
            var ct = Q._payload, Je = Q._init;
            return j(k, V, P, Je(ct), ue);
        }
        if (tt(Q) || rr(Q)) {
          var jt = k.get(P) || null;
          return w(V, jt, Q, ue, null);
        }
        df(V, Q);
      }
      return typeof Q == "function" && pf(V), null;
    }
    function H(k, V, P) {
      {
        if (typeof k != "object" || k === null)
          return V;
        switch (k.$$typeof) {
          case Lr:
          case kr:
            LS(k, P);
            var Q = k.key;
            if (typeof Q != "string")
              break;
            if (V === null) {
              V = /* @__PURE__ */ new Set(), V.add(Q);
              break;
            }
            if (!V.has(Q)) {
              V.add(Q);
              break;
            }
            c("Encountered two children with the same key, `%s`. Keys should be unique so that components maintain their identity across updates. Non-unique keys may cause children to be duplicated and/or omitted — the behavior is unsupported and could change in a future version.", Q);
            break;
          case xe:
            var ue = k._payload, ie = k._init;
            H(ie(ue), V, P);
            break;
        }
      }
      return V;
    }
    function B(k, V, P, Q) {
      for (var ue = null, ie = 0; ie < P.length; ie++) {
        var Me = P[ie];
        ue = H(Me, ue, k);
      }
      for (var ke = null, ct = null, Je = V, jt = 0, et = 0, Ot = null; Je !== null && et < P.length; et++) {
        Je.index > et ? (Ot = Je, Je = null) : Ot = Je.sibling;
        var Ln = A(k, Je, P[et], Q);
        if (Ln === null) {
          Je === null && (Je = Ot);
          break;
        }
        e && Je && Ln.alternate === null && t(k, Je), jt = l(Ln, jt, et), ct === null ? ke = Ln : ct.sibling = Ln, ct = Ln, Je = Ot;
      }
      if (et === P.length) {
        if (n(k, Je), hn()) {
          var En = et;
          uo(k, En);
        }
        return ke;
      }
      if (Je === null) {
        for (; et < P.length; et++) {
          var dr = N(k, P[et], Q);
          dr !== null && (jt = l(dr, jt, et), ct === null ? ke = dr : ct.sibling = dr, ct = dr);
        }
        if (hn()) {
          var Bn = et;
          uo(k, Bn);
        }
        return ke;
      }
      for (var Vn = r(k, Je); et < P.length; et++) {
        var kn = j(Vn, k, et, P[et], Q);
        kn !== null && (e && kn.alternate !== null && Vn.delete(kn.key === null ? et : kn.key), jt = l(kn, jt, et), ct === null ? ke = kn : ct.sibling = kn, ct = kn);
      }
      if (e && Vn.forEach(function(Ol) {
        return t(k, Ol);
      }), hn()) {
        var Ka = et;
        uo(k, Ka);
      }
      return ke;
    }
    function ae(k, V, P, Q) {
      var ue = rr(P);
      if (typeof ue != "function")
        throw new Error("An object is not an iterable. This error is likely caused by a bug in React. Please file an issue.");
      {
        typeof Symbol == "function" && // $FlowFixMe Flow doesn't know about toStringTag
        P[Symbol.toStringTag] === "Generator" && (Qv || c("Using Generators as children is unsupported and will likely yield unexpected results because enumerating a generator mutates it. You may convert it to an array with `Array.from()` or the `[...spread]` operator before rendering. Keep in mind you might need to polyfill these features for older browsers."), Qv = !0), P.entries === ue && (qv || c("Using Maps as children is not supported. Use an array of keyed ReactElements instead."), qv = !0);
        var ie = ue.call(P);
        if (ie)
          for (var Me = null, ke = ie.next(); !ke.done; ke = ie.next()) {
            var ct = ke.value;
            Me = H(ct, Me, k);
          }
      }
      var Je = ue.call(P);
      if (Je == null)
        throw new Error("An iterable object provided no iterator.");
      for (var jt = null, et = null, Ot = V, Ln = 0, En = 0, dr = null, Bn = Je.next(); Ot !== null && !Bn.done; En++, Bn = Je.next()) {
        Ot.index > En ? (dr = Ot, Ot = null) : dr = Ot.sibling;
        var Vn = A(k, Ot, Bn.value, Q);
        if (Vn === null) {
          Ot === null && (Ot = dr);
          break;
        }
        e && Ot && Vn.alternate === null && t(k, Ot), Ln = l(Vn, Ln, En), et === null ? jt = Vn : et.sibling = Vn, et = Vn, Ot = dr;
      }
      if (Bn.done) {
        if (n(k, Ot), hn()) {
          var kn = En;
          uo(k, kn);
        }
        return jt;
      }
      if (Ot === null) {
        for (; !Bn.done; En++, Bn = Je.next()) {
          var Ka = N(k, Bn.value, Q);
          Ka !== null && (Ln = l(Ka, Ln, En), et === null ? jt = Ka : et.sibling = Ka, et = Ka);
        }
        if (hn()) {
          var Ol = En;
          uo(k, Ol);
        }
        return jt;
      }
      for (var ks = r(k, Ot); !Bn.done; En++, Bn = Je.next()) {
        var ha = j(ks, k, En, Bn.value, Q);
        ha !== null && (e && ha.alternate !== null && ks.delete(ha.key === null ? En : ha.key), Ln = l(ha, Ln, En), et === null ? jt = ha : et.sibling = ha, et = ha);
      }
      if (e && ks.forEach(function(GL) {
        return t(k, GL);
      }), hn()) {
        var WL = En;
        uo(k, WL);
      }
      return jt;
    }
    function Ce(k, V, P, Q) {
      if (V !== null && V.tag === M) {
        n(k, V.sibling);
        var ue = i(V, P);
        return ue.return = k, ue;
      }
      n(k, V);
      var ie = Km(P, k.mode, Q);
      return ie.return = k, ie;
    }
    function ye(k, V, P, Q) {
      for (var ue = P.key, ie = V; ie !== null; ) {
        if (ie.key === ue) {
          var Me = P.type;
          if (Me === ea) {
            if (ie.tag === L) {
              n(k, ie.sibling);
              var ke = i(ie, P.props.children);
              return ke.return = k, ke._debugSource = P._source, ke._debugOwner = P._owner, ke;
            }
          } else if (ie.elementType === Me || // Keep this check inline so it only runs on the false path:
          HE(ie, P) || // Lazy types should reconcile their resolved type.
          // We need to do this after the Hot Reloading check above,
          // because hot reloading has different semantics than prod because
          // it doesn't resuspend. So we can't let the call below suspend.
          typeof Me == "object" && Me !== null && Me.$$typeof === xe && kS(Me) === ie.type) {
            n(k, ie.sibling);
            var ct = i(ie, P.props);
            return ct.ref = ns(k, ie, P), ct.return = k, ct._debugSource = P._source, ct._debugOwner = P._owner, ct;
          }
          n(k, ie);
          break;
        } else
          t(k, ie);
        ie = ie.sibling;
      }
      if (P.type === ea) {
        var Je = Oi(P.props.children, k.mode, Q, P.key);
        return Je.return = k, Je;
      } else {
        var jt = Xm(P, k.mode, Q);
        return jt.ref = ns(k, V, P), jt.return = k, jt;
      }
    }
    function Ge(k, V, P, Q) {
      for (var ue = P.key, ie = V; ie !== null; ) {
        if (ie.key === ue)
          if (ie.tag === x && ie.stateNode.containerInfo === P.containerInfo && ie.stateNode.implementation === P.implementation) {
            n(k, ie.sibling);
            var Me = i(ie, P.children || []);
            return Me.return = k, Me;
          } else {
            n(k, ie);
            break;
          }
        else
          t(k, ie);
        ie = ie.sibling;
      }
      var ke = qm(P, k.mode, Q);
      return ke.return = k, ke;
    }
    function $e(k, V, P, Q) {
      var ue = typeof P == "object" && P !== null && P.type === ea && P.key === null;
      if (ue && (P = P.props.children), typeof P == "object" && P !== null) {
        switch (P.$$typeof) {
          case Lr:
            return f(ye(k, V, P, Q));
          case kr:
            return f(Ge(k, V, P, Q));
          case xe:
            var ie = P._payload, Me = P._init;
            return $e(k, V, Me(ie), Q);
        }
        if (tt(P))
          return B(k, V, P, Q);
        if (rr(P))
          return ae(k, V, P, Q);
        df(k, P);
      }
      return typeof P == "string" && P !== "" || typeof P == "number" ? f(Ce(k, V, "" + P, Q)) : (typeof P == "function" && pf(k), n(k, V));
    }
    return $e;
  }
  var dl = PS(!0), US = PS(!1);
  function EO(e, t) {
    if (e !== null && t.child !== e.child)
      throw new Error("Resuming work not yet implemented.");
    if (t.child !== null) {
      var n = t.child, r = Eo(n, n.pendingProps);
      for (t.child = r, r.return = t; n.sibling !== null; )
        n = n.sibling, r = r.sibling = Eo(n, n.pendingProps), r.return = t;
      r.sibling = null;
    }
  }
  function RO(e, t) {
    for (var n = e.child; n !== null; )
      cL(n, t), n = n.sibling;
  }
  var th = mi(null), nh;
  nh = {};
  var vf = null, pl = null, rh = null, hf = !1;
  function mf() {
    vf = null, pl = null, rh = null, hf = !1;
  }
  function jS() {
    hf = !0;
  }
  function FS() {
    hf = !1;
  }
  function zS(e, t, n) {
    An(th, t._currentValue, e), t._currentValue = n, t._currentRenderer !== void 0 && t._currentRenderer !== null && t._currentRenderer !== nh && c("Detected multiple renderers concurrently rendering the same context provider. This is currently unsupported."), t._currentRenderer = nh;
  }
  function ah(e, t) {
    var n = th.current;
    On(th, t), e._currentValue = n;
  }
  function ih(e, t, n) {
    for (var r = e; r !== null; ) {
      var i = r.alternate;
      if (Qo(r.childLanes, t) ? i !== null && !Qo(i.childLanes, t) && (i.childLanes = Ue(i.childLanes, t)) : (r.childLanes = Ue(r.childLanes, t), i !== null && (i.childLanes = Ue(i.childLanes, t))), r === n)
        break;
      r = r.return;
    }
    r !== n && c("Expected to find the propagation root when scheduling context work. This error is likely caused by a bug in React. Please file an issue.");
  }
  function wO(e, t, n) {
    xO(e, t, n);
  }
  function xO(e, t, n) {
    var r = e.child;
    for (r !== null && (r.return = e); r !== null; ) {
      var i = void 0, l = r.dependencies;
      if (l !== null) {
        i = r.child;
        for (var f = l.firstContext; f !== null; ) {
          if (f.context === t) {
            if (r.tag === S) {
              var p = Su(n), m = Ba(bt, p);
              m.tag = gf;
              var C = r.updateQueue;
              if (C !== null) {
                var w = C.shared, N = w.pending;
                N === null ? m.next = m : (m.next = N.next, N.next = m), w.pending = m;
              }
            }
            r.lanes = Ue(r.lanes, n);
            var A = r.alternate;
            A !== null && (A.lanes = Ue(A.lanes, n)), ih(r.return, n, e), l.lanes = Ue(l.lanes, n);
            break;
          }
          f = f.next;
        }
      } else if (r.tag === F)
        i = r.type === e.type ? null : r.child;
      else if (r.tag === he) {
        var j = r.return;
        if (j === null)
          throw new Error("We just came from a parent so we must have had a parent. This is a bug in React.");
        j.lanes = Ue(j.lanes, n);
        var H = j.alternate;
        H !== null && (H.lanes = Ue(H.lanes, n)), ih(j, n, e), i = r.sibling;
      } else
        i = r.child;
      if (i !== null)
        i.return = r;
      else
        for (i = r; i !== null; ) {
          if (i === e) {
            i = null;
            break;
          }
          var B = i.sibling;
          if (B !== null) {
            B.return = i.return, i = B;
            break;
          }
          i = i.return;
        }
      r = i;
    }
  }
  function vl(e, t) {
    vf = e, pl = null, rh = null;
    var n = e.dependencies;
    if (n !== null) {
      var r = n.firstContext;
      r !== null && (or(n.lanes, t) && ys(), n.firstContext = null);
    }
  }
  function Bt(e) {
    hf && c("Context can only be read while React is rendering. In classes, you can read it in the render method or getDerivedStateFromProps. In function components, you can read it directly in the function body, but not inside Hooks like useReducer() or useMemo().");
    var t = e._currentValue;
    if (rh !== e) {
      var n = {
        context: e,
        memoizedValue: t,
        next: null
      };
      if (pl === null) {
        if (vf === null)
          throw new Error("Context can only be read while React is rendering. In classes, you can read it in the render method or getDerivedStateFromProps. In function components, you can read it directly in the function body, but not inside Hooks like useReducer() or useMemo().");
        pl = n, vf.dependencies = {
          lanes: K,
          firstContext: n
        };
      } else
        pl = pl.next = n;
    }
    return t;
  }
  var vo = null;
  function oh(e) {
    vo === null ? vo = [e] : vo.push(e);
  }
  function TO() {
    if (vo !== null) {
      for (var e = 0; e < vo.length; e++) {
        var t = vo[e], n = t.interleaved;
        if (n !== null) {
          t.interleaved = null;
          var r = n.next, i = t.pending;
          if (i !== null) {
            var l = i.next;
            i.next = r, n.next = l;
          }
          t.pending = n;
        }
      }
      vo = null;
    }
  }
  function HS(e, t, n, r) {
    var i = t.interleaved;
    return i === null ? (n.next = n, oh(t)) : (n.next = i.next, i.next = n), t.interleaved = n, yf(e, r);
  }
  function DO(e, t, n, r) {
    var i = t.interleaved;
    i === null ? (n.next = n, oh(t)) : (n.next = i.next, i.next = n), t.interleaved = n;
  }
  function _O(e, t, n, r) {
    var i = t.interleaved;
    return i === null ? (n.next = n, oh(t)) : (n.next = i.next, i.next = n), t.interleaved = n, yf(e, r);
  }
  function Qn(e, t) {
    return yf(e, t);
  }
  var MO = yf;
  function yf(e, t) {
    e.lanes = Ue(e.lanes, t);
    var n = e.alternate;
    n !== null && (n.lanes = Ue(n.lanes, t)), n === null && (e.flags & (It | Na)) !== Te && UE(e);
    for (var r = e, i = e.return; i !== null; )
      i.childLanes = Ue(i.childLanes, t), n = i.alternate, n !== null ? n.childLanes = Ue(n.childLanes, t) : (i.flags & (It | Na)) !== Te && UE(e), r = i, i = i.return;
    if (r.tag === E) {
      var l = r.stateNode;
      return l;
    } else
      return null;
  }
  var $S = 0, IS = 1, gf = 2, lh = 3, bf = !1, uh, Sf;
  uh = !1, Sf = null;
  function sh(e) {
    var t = {
      baseState: e.memoizedState,
      firstBaseUpdate: null,
      lastBaseUpdate: null,
      shared: {
        pending: null,
        interleaved: null,
        lanes: K
      },
      effects: null
    };
    e.updateQueue = t;
  }
  function BS(e, t) {
    var n = t.updateQueue, r = e.updateQueue;
    if (n === r) {
      var i = {
        baseState: r.baseState,
        firstBaseUpdate: r.firstBaseUpdate,
        lastBaseUpdate: r.lastBaseUpdate,
        shared: r.shared,
        effects: r.effects
      };
      t.updateQueue = i;
    }
  }
  function Ba(e, t) {
    var n = {
      eventTime: e,
      lane: t,
      tag: $S,
      payload: null,
      callback: null,
      next: null
    };
    return n;
  }
  function Si(e, t, n) {
    var r = e.updateQueue;
    if (r === null)
      return null;
    var i = r.shared;
    if (Sf === i && !uh && (c("An update (setState, replaceState, or forceUpdate) was scheduled from inside an update function. Update functions should be pure, with zero side-effects. Consider using componentDidUpdate or a callback."), uh = !0), DN()) {
      var l = i.pending;
      return l === null ? t.next = t : (t.next = l.next, l.next = t), i.pending = t, MO(e, n);
    } else
      return _O(e, i, t, n);
  }
  function Cf(e, t, n) {
    var r = t.updateQueue;
    if (r !== null) {
      var i = r.shared;
      if (nb(n)) {
        var l = i.lanes;
        l = ab(l, e.pendingLanes);
        var f = Ue(l, n);
        i.lanes = f, tv(e, f);
      }
    }
  }
  function ch(e, t) {
    var n = e.updateQueue, r = e.alternate;
    if (r !== null) {
      var i = r.updateQueue;
      if (n === i) {
        var l = null, f = null, p = n.firstBaseUpdate;
        if (p !== null) {
          var m = p;
          do {
            var C = {
              eventTime: m.eventTime,
              lane: m.lane,
              tag: m.tag,
              payload: m.payload,
              callback: m.callback,
              next: null
            };
            f === null ? l = f = C : (f.next = C, f = C), m = m.next;
          } while (m !== null);
          f === null ? l = f = t : (f.next = t, f = t);
        } else
          l = f = t;
        n = {
          baseState: i.baseState,
          firstBaseUpdate: l,
          lastBaseUpdate: f,
          shared: i.shared,
          effects: i.effects
        }, e.updateQueue = n;
        return;
      }
    }
    var w = n.lastBaseUpdate;
    w === null ? n.firstBaseUpdate = t : w.next = t, n.lastBaseUpdate = t;
  }
  function OO(e, t, n, r, i, l) {
    switch (n.tag) {
      case IS: {
        var f = n.payload;
        if (typeof f == "function") {
          jS();
          var p = f.call(l, r, i);
          {
            if (e.mode & Mt) {
              sn(!0);
              try {
                f.call(l, r, i);
              } finally {
                sn(!1);
              }
            }
            FS();
          }
          return p;
        }
        return f;
      }
      case lh:
        e.flags = e.flags & ~zn | nt;
      case $S: {
        var m = n.payload, C;
        if (typeof m == "function") {
          jS(), C = m.call(l, r, i);
          {
            if (e.mode & Mt) {
              sn(!0);
              try {
                m.call(l, r, i);
              } finally {
                sn(!1);
              }
            }
            FS();
          }
        } else
          C = m;
        return C == null ? r : He({}, r, C);
      }
      case gf:
        return bf = !0, r;
    }
    return r;
  }
  function Ef(e, t, n, r) {
    var i = e.updateQueue;
    bf = !1, Sf = i.shared;
    var l = i.firstBaseUpdate, f = i.lastBaseUpdate, p = i.shared.pending;
    if (p !== null) {
      i.shared.pending = null;
      var m = p, C = m.next;
      m.next = null, f === null ? l = C : f.next = C, f = m;
      var w = e.alternate;
      if (w !== null) {
        var N = w.updateQueue, A = N.lastBaseUpdate;
        A !== f && (A === null ? N.firstBaseUpdate = C : A.next = C, N.lastBaseUpdate = m);
      }
    }
    if (l !== null) {
      var j = i.baseState, H = K, B = null, ae = null, Ce = null, ye = l;
      do {
        var Ge = ye.lane, $e = ye.eventTime;
        if (Qo(r, Ge)) {
          if (Ce !== null) {
            var V = {
              eventTime: $e,
              // This update is going to be committed so we never want uncommit
              // it. Using NoLane works because 0 is a subset of all bitmasks, so
              // this will never be skipped by the check above.
              lane: cn,
              tag: ye.tag,
              payload: ye.payload,
              callback: ye.callback,
              next: null
            };
            Ce = Ce.next = V;
          }
          j = OO(e, i, ye, j, t, n);
          var P = ye.callback;
          if (P !== null && // If the update was already committed, we should not queue its
          // callback again.
          ye.lane !== cn) {
            e.flags |= Ep;
            var Q = i.effects;
            Q === null ? i.effects = [ye] : Q.push(ye);
          }
        } else {
          var k = {
            eventTime: $e,
            lane: Ge,
            tag: ye.tag,
            payload: ye.payload,
            callback: ye.callback,
            next: null
          };
          Ce === null ? (ae = Ce = k, B = j) : Ce = Ce.next = k, H = Ue(H, Ge);
        }
        if (ye = ye.next, ye === null) {
          if (p = i.shared.pending, p === null)
            break;
          var ue = p, ie = ue.next;
          ue.next = null, ye = ie, i.lastBaseUpdate = ue, i.shared.pending = null;
        }
      } while (!0);
      Ce === null && (B = j), i.baseState = B, i.firstBaseUpdate = ae, i.lastBaseUpdate = Ce;
      var Me = i.shared.interleaved;
      if (Me !== null) {
        var ke = Me;
        do
          H = Ue(H, ke.lane), ke = ke.next;
        while (ke !== Me);
      } else
        l === null && (i.shared.lanes = K);
      Ms(H), e.lanes = H, e.memoizedState = j;
    }
    Sf = null;
  }
  function AO(e, t) {
    if (typeof e != "function")
      throw new Error("Invalid argument passed as callback. Expected a function. Instead " + ("received: " + e));
    e.call(t);
  }
  function VS() {
    bf = !1;
  }
  function Rf() {
    return bf;
  }
  function YS(e, t, n) {
    var r = t.effects;
    if (t.effects = null, r !== null)
      for (var i = 0; i < r.length; i++) {
        var l = r[i], f = l.callback;
        f !== null && (l.callback = null, AO(f, n));
      }
  }
  var rs = {}, Ci = mi(rs), as = mi(rs), wf = mi(rs);
  function xf(e) {
    if (e === rs)
      throw new Error("Expected host context to exist. This error is likely caused by a bug in React. Please file an issue.");
    return e;
  }
  function WS() {
    var e = xf(wf.current);
    return e;
  }
  function fh(e, t) {
    An(wf, t, e), An(as, e, e), An(Ci, rs, e);
    var n = X_(t);
    On(Ci, e), An(Ci, n, e);
  }
  function hl(e) {
    On(Ci, e), On(as, e), On(wf, e);
  }
  function dh() {
    var e = xf(Ci.current);
    return e;
  }
  function GS(e) {
    xf(wf.current);
    var t = xf(Ci.current), n = K_(t, e.type);
    t !== n && (An(as, e, e), An(Ci, n, e));
  }
  function ph(e) {
    as.current === e && (On(Ci, e), On(as, e));
  }
  var NO = 0, XS = 1, KS = 1, is = 2, $r = mi(NO);
  function vh(e, t) {
    return (e & t) !== 0;
  }
  function ml(e) {
    return e & XS;
  }
  function hh(e, t) {
    return e & XS | t;
  }
  function LO(e, t) {
    return e | t;
  }
  function Ei(e, t) {
    An($r, t, e);
  }
  function yl(e) {
    On($r, e);
  }
  function kO(e, t) {
    var n = e.memoizedState;
    return n !== null ? n.dehydrated !== null : (e.memoizedProps, !0);
  }
  function Tf(e) {
    for (var t = e; t !== null; ) {
      if (t.tag === W) {
        var n = t.memoizedState;
        if (n !== null) {
          var r = n.dehydrated;
          if (r === null || dS(r) || Lv(r))
            return t;
        }
      } else if (t.tag === Ee && // revealOrder undefined can't be trusted because it don't
      // keep track of whether it suspended or not.
      t.memoizedProps.revealOrder !== void 0) {
        var i = (t.flags & nt) !== Te;
        if (i)
          return t;
      } else if (t.child !== null) {
        t.child.return = t, t = t.child;
        continue;
      }
      if (t === e)
        return null;
      for (; t.sibling === null; ) {
        if (t.return === null || t.return === e)
          return null;
        t = t.return;
      }
      t.sibling.return = t.return, t = t.sibling;
    }
    return null;
  }
  var Zn = (
    /*   */
    0
  ), qt = (
    /* */
    1
  ), ua = (
    /*  */
    2
  ), Qt = (
    /*    */
    4
  ), mn = (
    /*   */
    8
  ), mh = [];
  function yh() {
    for (var e = 0; e < mh.length; e++) {
      var t = mh[e];
      t._workInProgressVersionPrimary = null;
    }
    mh.length = 0;
  }
  function PO(e, t) {
    var n = t._getVersion, r = n(t._source);
    e.mutableSourceEagerHydrationData == null ? e.mutableSourceEagerHydrationData = [t, r] : e.mutableSourceEagerHydrationData.push(t, r);
  }
  var le = u.ReactCurrentDispatcher, os = u.ReactCurrentBatchConfig, gh, gl;
  gh = /* @__PURE__ */ new Set();
  var ho = K, st = null, Zt = null, Jt = null, Df = !1, ls = !1, us = 0, UO = 0, jO = 25, G = null, xr = null, Ri = -1, bh = !1;
  function rt() {
    {
      var e = G;
      xr === null ? xr = [e] : xr.push(e);
    }
  }
  function te() {
    {
      var e = G;
      xr !== null && (Ri++, xr[Ri] !== e && FO(e));
    }
  }
  function bl(e) {
    e != null && !tt(e) && c("%s received a final argument that is not an array (instead, received `%s`). When specified, the final argument must be an array.", G, typeof e);
  }
  function FO(e) {
    {
      var t = Pe(st);
      if (!gh.has(t) && (gh.add(t), xr !== null)) {
        for (var n = "", r = 30, i = 0; i <= Ri; i++) {
          for (var l = xr[i], f = i === Ri ? e : l, p = i + 1 + ". " + l; p.length < r; )
            p += " ";
          p += f + `
`, n += p;
        }
        c(`React has detected a change in the order of Hooks called by %s. This will lead to bugs and errors if not fixed. For more information, read the Rules of Hooks: https://reactjs.org/link/rules-of-hooks

   Previous render            Next render
   ------------------------------------------------------
%s   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
`, t, n);
      }
    }
  }
  function Nn() {
    throw new Error(`Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:
1. You might have mismatching versions of React and the renderer (such as React DOM)
2. You might be breaking the Rules of Hooks
3. You might have more than one copy of React in the same app
See https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.`);
  }
  function Sh(e, t) {
    if (bh)
      return !1;
    if (t === null)
      return c("%s received a final argument during this render, but not during the previous render. Even though the final argument is optional, its type cannot change between renders.", G), !1;
    e.length !== t.length && c(`The final argument passed to %s changed size between renders. The order and size of this array must remain constant.

Previous: %s
Incoming: %s`, G, "[" + t.join(", ") + "]", "[" + e.join(", ") + "]");
    for (var n = 0; n < t.length && n < e.length; n++)
      if (!sr(e[n], t[n]))
        return !1;
    return !0;
  }
  function Sl(e, t, n, r, i, l) {
    ho = l, st = t, xr = e !== null ? e._debugHookTypes : null, Ri = -1, bh = e !== null && e.type !== t.type, t.memoizedState = null, t.updateQueue = null, t.lanes = K, e !== null && e.memoizedState !== null ? le.current = yC : xr !== null ? le.current = mC : le.current = hC;
    var f = n(r, i);
    if (ls) {
      var p = 0;
      do {
        if (ls = !1, us = 0, p >= jO)
          throw new Error("Too many re-renders. React limits the number of renders to prevent an infinite loop.");
        p += 1, bh = !1, Zt = null, Jt = null, t.updateQueue = null, Ri = -1, le.current = gC, f = n(r, i);
      } while (ls);
    }
    le.current = Hf, t._debugHookTypes = xr;
    var m = Zt !== null && Zt.next !== null;
    if (ho = K, st = null, Zt = null, Jt = null, G = null, xr = null, Ri = -1, e !== null && (e.flags & ka) !== (t.flags & ka) && // Disable this warning in legacy mode, because legacy Suspense is weird
    // and creates false positives. To make this work in legacy mode, we'd
    // need to mark fibers that commit in an incomplete state, somehow. For
    // now I'll disable the warning that most of the bugs that would trigger
    // it are either exclusive to concurrent mode or exist in both.
    (e.mode & Ye) !== Re && c("Internal React error: Expected static flag was missing. Please notify the React team."), Df = !1, m)
      throw new Error("Rendered fewer hooks than expected. This may be caused by an accidental early return statement.");
    return f;
  }
  function Cl() {
    var e = us !== 0;
    return us = 0, e;
  }
  function qS(e, t, n) {
    t.updateQueue = e.updateQueue, (t.mode & aa) !== Re ? t.flags &= ~(Sc | La | Pr | qe) : t.flags &= ~(Pr | qe), e.lanes = Dc(e.lanes, n);
  }
  function QS() {
    if (le.current = Hf, Df) {
      for (var e = st.memoizedState; e !== null; ) {
        var t = e.queue;
        t !== null && (t.pending = null), e = e.next;
      }
      Df = !1;
    }
    ho = K, st = null, Zt = null, Jt = null, xr = null, Ri = -1, G = null, cC = !1, ls = !1, us = 0;
  }
  function sa() {
    var e = {
      memoizedState: null,
      baseState: null,
      baseQueue: null,
      queue: null,
      next: null
    };
    return Jt === null ? st.memoizedState = Jt = e : Jt = Jt.next = e, Jt;
  }
  function Tr() {
    var e;
    if (Zt === null) {
      var t = st.alternate;
      t !== null ? e = t.memoizedState : e = null;
    } else
      e = Zt.next;
    var n;
    if (Jt === null ? n = st.memoizedState : n = Jt.next, n !== null)
      Jt = n, n = Jt.next, Zt = e;
    else {
      if (e === null)
        throw new Error("Rendered more hooks than during the previous render.");
      Zt = e;
      var r = {
        memoizedState: Zt.memoizedState,
        baseState: Zt.baseState,
        baseQueue: Zt.baseQueue,
        queue: Zt.queue,
        next: null
      };
      Jt === null ? st.memoizedState = Jt = r : Jt = Jt.next = r;
    }
    return Jt;
  }
  function ZS() {
    return {
      lastEffect: null,
      stores: null
    };
  }
  function Ch(e, t) {
    return typeof t == "function" ? t(e) : t;
  }
  function Eh(e, t, n) {
    var r = sa(), i;
    n !== void 0 ? i = n(t) : i = t, r.memoizedState = r.baseState = i;
    var l = {
      pending: null,
      interleaved: null,
      lanes: K,
      dispatch: null,
      lastRenderedReducer: e,
      lastRenderedState: i
    };
    r.queue = l;
    var f = l.dispatch = IO.bind(null, st, l);
    return [r.memoizedState, f];
  }
  function Rh(e, t, n) {
    var r = Tr(), i = r.queue;
    if (i === null)
      throw new Error("Should have a queue. This is likely a bug in React. Please file an issue.");
    i.lastRenderedReducer = e;
    var l = Zt, f = l.baseQueue, p = i.pending;
    if (p !== null) {
      if (f !== null) {
        var m = f.next, C = p.next;
        f.next = C, p.next = m;
      }
      l.baseQueue !== f && c("Internal error: Expected work-in-progress queue to be a clone. This is a bug in React."), l.baseQueue = f = p, i.pending = null;
    }
    if (f !== null) {
      var w = f.next, N = l.baseState, A = null, j = null, H = null, B = w;
      do {
        var ae = B.lane;
        if (Qo(ho, ae)) {
          if (H !== null) {
            var ye = {
              // This update is going to be committed so we never want uncommit
              // it. Using NoLane works because 0 is a subset of all bitmasks, so
              // this will never be skipped by the check above.
              lane: cn,
              action: B.action,
              hasEagerState: B.hasEagerState,
              eagerState: B.eagerState,
              next: null
            };
            H = H.next = ye;
          }
          if (B.hasEagerState)
            N = B.eagerState;
          else {
            var Ge = B.action;
            N = e(N, Ge);
          }
        } else {
          var Ce = {
            lane: ae,
            action: B.action,
            hasEagerState: B.hasEagerState,
            eagerState: B.eagerState,
            next: null
          };
          H === null ? (j = H = Ce, A = N) : H = H.next = Ce, st.lanes = Ue(st.lanes, ae), Ms(ae);
        }
        B = B.next;
      } while (B !== null && B !== w);
      H === null ? A = N : H.next = j, sr(N, r.memoizedState) || ys(), r.memoizedState = N, r.baseState = A, r.baseQueue = H, i.lastRenderedState = N;
    }
    var $e = i.interleaved;
    if ($e !== null) {
      var k = $e;
      do {
        var V = k.lane;
        st.lanes = Ue(st.lanes, V), Ms(V), k = k.next;
      } while (k !== $e);
    } else
      f === null && (i.lanes = K);
    var P = i.dispatch;
    return [r.memoizedState, P];
  }
  function wh(e, t, n) {
    var r = Tr(), i = r.queue;
    if (i === null)
      throw new Error("Should have a queue. This is likely a bug in React. Please file an issue.");
    i.lastRenderedReducer = e;
    var l = i.dispatch, f = i.pending, p = r.memoizedState;
    if (f !== null) {
      i.pending = null;
      var m = f.next, C = m;
      do {
        var w = C.action;
        p = e(p, w), C = C.next;
      } while (C !== m);
      sr(p, r.memoizedState) || ys(), r.memoizedState = p, r.baseQueue === null && (r.baseState = p), i.lastRenderedState = p;
    }
    return [p, l];
  }
  function S3(e, t, n) {
  }
  function C3(e, t, n) {
  }
  function xh(e, t, n) {
    var r = st, i = sa(), l, f = hn();
    if (f) {
      if (n === void 0)
        throw new Error("Missing getServerSnapshot, which is required for server-rendered content. Will revert to client rendering.");
      l = n(), gl || l !== n() && (c("The result of getServerSnapshot should be cached to avoid an infinite loop"), gl = !0);
    } else {
      if (l = t(), !gl) {
        var p = t();
        sr(l, p) || (c("The result of getSnapshot should be cached to avoid an infinite loop"), gl = !0);
      }
      var m = id();
      if (m === null)
        throw new Error("Expected a work-in-progress root. This is a bug in React. Please file an issue.");
      Tc(m, ho) || JS(r, t, l);
    }
    i.memoizedState = l;
    var C = {
      value: l,
      getSnapshot: t
    };
    return i.queue = C, Nf(tC.bind(null, r, C, e), [e]), r.flags |= Pr, ss(qt | mn, eC.bind(null, r, C, l, t), void 0, null), l;
  }
  function _f(e, t, n) {
    var r = st, i = Tr(), l = t();
    if (!gl) {
      var f = t();
      sr(l, f) || (c("The result of getSnapshot should be cached to avoid an infinite loop"), gl = !0);
    }
    var p = i.memoizedState, m = !sr(p, l);
    m && (i.memoizedState = l, ys());
    var C = i.queue;
    if (fs(tC.bind(null, r, C, e), [e]), C.getSnapshot !== t || m || // Check if the susbcribe function changed. We can save some memory by
    // checking whether we scheduled a subscription effect above.
    Jt !== null && Jt.memoizedState.tag & qt) {
      r.flags |= Pr, ss(qt | mn, eC.bind(null, r, C, l, t), void 0, null);
      var w = id();
      if (w === null)
        throw new Error("Expected a work-in-progress root. This is a bug in React. Please file an issue.");
      Tc(w, ho) || JS(r, t, l);
    }
    return l;
  }
  function JS(e, t, n) {
    e.flags |= bc;
    var r = {
      getSnapshot: t,
      value: n
    }, i = st.updateQueue;
    if (i === null)
      i = ZS(), st.updateQueue = i, i.stores = [r];
    else {
      var l = i.stores;
      l === null ? i.stores = [r] : l.push(r);
    }
  }
  function eC(e, t, n, r) {
    t.value = n, t.getSnapshot = r, nC(t) && rC(e);
  }
  function tC(e, t, n) {
    var r = function() {
      nC(t) && rC(e);
    };
    return n(r);
  }
  function nC(e) {
    var t = e.getSnapshot, n = e.value;
    try {
      var r = t();
      return !sr(n, r);
    } catch {
      return !0;
    }
  }
  function rC(e) {
    var t = Qn(e, Ne);
    t !== null && rn(t, e, Ne, bt);
  }
  function Mf(e) {
    var t = sa();
    typeof e == "function" && (e = e()), t.memoizedState = t.baseState = e;
    var n = {
      pending: null,
      interleaved: null,
      lanes: K,
      dispatch: null,
      lastRenderedReducer: Ch,
      lastRenderedState: e
    };
    t.queue = n;
    var r = n.dispatch = BO.bind(null, st, n);
    return [t.memoizedState, r];
  }
  function Th(e) {
    return Rh(Ch);
  }
  function Dh(e) {
    return wh(Ch);
  }
  function ss(e, t, n, r) {
    var i = {
      tag: e,
      create: t,
      destroy: n,
      deps: r,
      // Circular
      next: null
    }, l = st.updateQueue;
    if (l === null)
      l = ZS(), st.updateQueue = l, l.lastEffect = i.next = i;
    else {
      var f = l.lastEffect;
      if (f === null)
        l.lastEffect = i.next = i;
      else {
        var p = f.next;
        f.next = i, i.next = p, l.lastEffect = i;
      }
    }
    return i;
  }
  function _h(e) {
    var t = sa();
    {
      var n = {
        current: e
      };
      return t.memoizedState = n, n;
    }
  }
  function Of(e) {
    var t = Tr();
    return t.memoizedState;
  }
  function cs(e, t, n, r) {
    var i = sa(), l = r === void 0 ? null : r;
    st.flags |= e, i.memoizedState = ss(qt | t, n, void 0, l);
  }
  function Af(e, t, n, r) {
    var i = Tr(), l = r === void 0 ? null : r, f = void 0;
    if (Zt !== null) {
      var p = Zt.memoizedState;
      if (f = p.destroy, l !== null) {
        var m = p.deps;
        if (Sh(l, m)) {
          i.memoizedState = ss(t, n, f, l);
          return;
        }
      }
    }
    st.flags |= e, i.memoizedState = ss(qt | t, n, f, l);
  }
  function Nf(e, t) {
    return (st.mode & aa) !== Re ? cs(Sc | Pr | xp, mn, e, t) : cs(Pr | xp, mn, e, t);
  }
  function fs(e, t) {
    return Af(Pr, mn, e, t);
  }
  function Mh(e, t) {
    return cs(qe, ua, e, t);
  }
  function Lf(e, t) {
    return Af(qe, ua, e, t);
  }
  function Oh(e, t) {
    var n = qe;
    return n |= Qi, (st.mode & aa) !== Re && (n |= La), cs(n, Qt, e, t);
  }
  function kf(e, t) {
    return Af(qe, Qt, e, t);
  }
  function aC(e, t) {
    if (typeof t == "function") {
      var n = t, r = e();
      return n(r), function() {
        n(null);
      };
    } else if (t != null) {
      var i = t;
      i.hasOwnProperty("current") || c("Expected useImperativeHandle() first argument to either be a ref callback or React.createRef() object. Instead received: %s.", "an object with keys {" + Object.keys(i).join(", ") + "}");
      var l = e();
      return i.current = l, function() {
        i.current = null;
      };
    }
  }
  function Ah(e, t, n) {
    typeof t != "function" && c("Expected useImperativeHandle() second argument to be a function that creates a handle. Instead received: %s.", t !== null ? typeof t : "null");
    var r = n != null ? n.concat([e]) : null, i = qe;
    return i |= Qi, (st.mode & aa) !== Re && (i |= La), cs(i, Qt, aC.bind(null, t, e), r);
  }
  function Pf(e, t, n) {
    typeof t != "function" && c("Expected useImperativeHandle() second argument to be a function that creates a handle. Instead received: %s.", t !== null ? typeof t : "null");
    var r = n != null ? n.concat([e]) : null;
    return Af(qe, Qt, aC.bind(null, t, e), r);
  }
  function zO(e, t) {
  }
  var Uf = zO;
  function Nh(e, t) {
    var n = sa(), r = t === void 0 ? null : t;
    return n.memoizedState = [e, r], e;
  }
  function jf(e, t) {
    var n = Tr(), r = t === void 0 ? null : t, i = n.memoizedState;
    if (i !== null && r !== null) {
      var l = i[1];
      if (Sh(r, l))
        return i[0];
    }
    return n.memoizedState = [e, r], e;
  }
  function Lh(e, t) {
    var n = sa(), r = t === void 0 ? null : t, i = e();
    return n.memoizedState = [i, r], i;
  }
  function Ff(e, t) {
    var n = Tr(), r = t === void 0 ? null : t, i = n.memoizedState;
    if (i !== null && r !== null) {
      var l = i[1];
      if (Sh(r, l))
        return i[0];
    }
    var f = e();
    return n.memoizedState = [f, r], f;
  }
  function kh(e) {
    var t = sa();
    return t.memoizedState = e, e;
  }
  function iC(e) {
    var t = Tr(), n = Zt, r = n.memoizedState;
    return lC(t, r, e);
  }
  function oC(e) {
    var t = Tr();
    if (Zt === null)
      return t.memoizedState = e, e;
    var n = Zt.memoizedState;
    return lC(t, n, e);
  }
  function lC(e, t, n) {
    var r = !w1(ho);
    if (r) {
      if (!sr(n, t)) {
        var i = rb();
        st.lanes = Ue(st.lanes, i), Ms(i), e.baseState = !0;
      }
      return t;
    } else
      return e.baseState && (e.baseState = !1, ys()), e.memoizedState = n, n;
  }
  function HO(e, t, n) {
    var r = jr();
    fn(L1(r, Ua)), e(!0);
    var i = os.transition;
    os.transition = {};
    var l = os.transition;
    os.transition._updatedFibers = /* @__PURE__ */ new Set();
    try {
      e(!1), t();
    } finally {
      if (fn(r), os.transition = i, i === null && l._updatedFibers) {
        var f = l._updatedFibers.size;
        f > 10 && v("Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table."), l._updatedFibers.clear();
      }
    }
  }
  function Ph() {
    var e = Mf(!1), t = e[0], n = e[1], r = HO.bind(null, n), i = sa();
    return i.memoizedState = r, [t, r];
  }
  function uC() {
    var e = Th(), t = e[0], n = Tr(), r = n.memoizedState;
    return [t, r];
  }
  function sC() {
    var e = Dh(), t = e[0], n = Tr(), r = n.memoizedState;
    return [t, r];
  }
  var cC = !1;
  function $O() {
    return cC;
  }
  function Uh() {
    var e = sa(), t = id(), n = t.identifierPrefix, r;
    if (hn()) {
      var i = aO();
      r = ":" + n + "R" + i;
      var l = us++;
      l > 0 && (r += "H" + l.toString(32)), r += ":";
    } else {
      var f = UO++;
      r = ":" + n + "r" + f.toString(32) + ":";
    }
    return e.memoizedState = r, r;
  }
  function zf() {
    var e = Tr(), t = e.memoizedState;
    return t;
  }
  function IO(e, t, n) {
    typeof arguments[3] == "function" && c("State updates from the useState() and useReducer() Hooks don't support the second callback argument. To execute a side effect after rendering, declare it in the component body with useEffect().");
    var r = _i(e), i = {
      lane: r,
      action: n,
      hasEagerState: !1,
      eagerState: null,
      next: null
    };
    if (fC(e))
      dC(t, i);
    else {
      var l = HS(e, t, i, r);
      if (l !== null) {
        var f = In();
        rn(l, e, r, f), pC(l, t, r);
      }
    }
    vC(e, r);
  }
  function BO(e, t, n) {
    typeof arguments[3] == "function" && c("State updates from the useState() and useReducer() Hooks don't support the second callback argument. To execute a side effect after rendering, declare it in the component body with useEffect().");
    var r = _i(e), i = {
      lane: r,
      action: n,
      hasEagerState: !1,
      eagerState: null,
      next: null
    };
    if (fC(e))
      dC(t, i);
    else {
      var l = e.alternate;
      if (e.lanes === K && (l === null || l.lanes === K)) {
        var f = t.lastRenderedReducer;
        if (f !== null) {
          var p;
          p = le.current, le.current = Ir;
          try {
            var m = t.lastRenderedState, C = f(m, n);
            if (i.hasEagerState = !0, i.eagerState = C, sr(C, m)) {
              DO(e, t, i, r);
              return;
            }
          } catch {
          } finally {
            le.current = p;
          }
        }
      }
      var w = HS(e, t, i, r);
      if (w !== null) {
        var N = In();
        rn(w, e, r, N), pC(w, t, r);
      }
    }
    vC(e, r);
  }
  function fC(e) {
    var t = e.alternate;
    return e === st || t !== null && t === st;
  }
  function dC(e, t) {
    ls = Df = !0;
    var n = e.pending;
    n === null ? t.next = t : (t.next = n.next, n.next = t), e.pending = t;
  }
  function pC(e, t, n) {
    if (nb(n)) {
      var r = t.lanes;
      r = ab(r, e.pendingLanes);
      var i = Ue(r, n);
      t.lanes = i, tv(e, i);
    }
  }
  function vC(e, t, n) {
    Op(e, t);
  }
  var Hf = {
    readContext: Bt,
    useCallback: Nn,
    useContext: Nn,
    useEffect: Nn,
    useImperativeHandle: Nn,
    useInsertionEffect: Nn,
    useLayoutEffect: Nn,
    useMemo: Nn,
    useReducer: Nn,
    useRef: Nn,
    useState: Nn,
    useDebugValue: Nn,
    useDeferredValue: Nn,
    useTransition: Nn,
    useMutableSource: Nn,
    useSyncExternalStore: Nn,
    useId: Nn,
    unstable_isNewReconciler: Se
  }, hC = null, mC = null, yC = null, gC = null, ca = null, Ir = null, $f = null;
  {
    var jh = function() {
      c("Context can only be read while React is rendering. In classes, you can read it in the render method or getDerivedStateFromProps. In function components, you can read it directly in the function body, but not inside Hooks like useReducer() or useMemo().");
    }, Le = function() {
      c("Do not call Hooks inside useEffect(...), useMemo(...), or other built-in Hooks. You can only call Hooks at the top level of your React function. For more information, see https://reactjs.org/link/rules-of-hooks");
    };
    hC = {
      readContext: function(e) {
        return Bt(e);
      },
      useCallback: function(e, t) {
        return G = "useCallback", rt(), bl(t), Nh(e, t);
      },
      useContext: function(e) {
        return G = "useContext", rt(), Bt(e);
      },
      useEffect: function(e, t) {
        return G = "useEffect", rt(), bl(t), Nf(e, t);
      },
      useImperativeHandle: function(e, t, n) {
        return G = "useImperativeHandle", rt(), bl(n), Ah(e, t, n);
      },
      useInsertionEffect: function(e, t) {
        return G = "useInsertionEffect", rt(), bl(t), Mh(e, t);
      },
      useLayoutEffect: function(e, t) {
        return G = "useLayoutEffect", rt(), bl(t), Oh(e, t);
      },
      useMemo: function(e, t) {
        G = "useMemo", rt(), bl(t);
        var n = le.current;
        le.current = ca;
        try {
          return Lh(e, t);
        } finally {
          le.current = n;
        }
      },
      useReducer: function(e, t, n) {
        G = "useReducer", rt();
        var r = le.current;
        le.current = ca;
        try {
          return Eh(e, t, n);
        } finally {
          le.current = r;
        }
      },
      useRef: function(e) {
        return G = "useRef", rt(), _h(e);
      },
      useState: function(e) {
        G = "useState", rt();
        var t = le.current;
        le.current = ca;
        try {
          return Mf(e);
        } finally {
          le.current = t;
        }
      },
      useDebugValue: function(e, t) {
        return G = "useDebugValue", rt(), void 0;
      },
      useDeferredValue: function(e) {
        return G = "useDeferredValue", rt(), kh(e);
      },
      useTransition: function() {
        return G = "useTransition", rt(), Ph();
      },
      useMutableSource: function(e, t, n) {
        return G = "useMutableSource", rt(), void 0;
      },
      useSyncExternalStore: function(e, t, n) {
        return G = "useSyncExternalStore", rt(), xh(e, t, n);
      },
      useId: function() {
        return G = "useId", rt(), Uh();
      },
      unstable_isNewReconciler: Se
    }, mC = {
      readContext: function(e) {
        return Bt(e);
      },
      useCallback: function(e, t) {
        return G = "useCallback", te(), Nh(e, t);
      },
      useContext: function(e) {
        return G = "useContext", te(), Bt(e);
      },
      useEffect: function(e, t) {
        return G = "useEffect", te(), Nf(e, t);
      },
      useImperativeHandle: function(e, t, n) {
        return G = "useImperativeHandle", te(), Ah(e, t, n);
      },
      useInsertionEffect: function(e, t) {
        return G = "useInsertionEffect", te(), Mh(e, t);
      },
      useLayoutEffect: function(e, t) {
        return G = "useLayoutEffect", te(), Oh(e, t);
      },
      useMemo: function(e, t) {
        G = "useMemo", te();
        var n = le.current;
        le.current = ca;
        try {
          return Lh(e, t);
        } finally {
          le.current = n;
        }
      },
      useReducer: function(e, t, n) {
        G = "useReducer", te();
        var r = le.current;
        le.current = ca;
        try {
          return Eh(e, t, n);
        } finally {
          le.current = r;
        }
      },
      useRef: function(e) {
        return G = "useRef", te(), _h(e);
      },
      useState: function(e) {
        G = "useState", te();
        var t = le.current;
        le.current = ca;
        try {
          return Mf(e);
        } finally {
          le.current = t;
        }
      },
      useDebugValue: function(e, t) {
        return G = "useDebugValue", te(), void 0;
      },
      useDeferredValue: function(e) {
        return G = "useDeferredValue", te(), kh(e);
      },
      useTransition: function() {
        return G = "useTransition", te(), Ph();
      },
      useMutableSource: function(e, t, n) {
        return G = "useMutableSource", te(), void 0;
      },
      useSyncExternalStore: function(e, t, n) {
        return G = "useSyncExternalStore", te(), xh(e, t, n);
      },
      useId: function() {
        return G = "useId", te(), Uh();
      },
      unstable_isNewReconciler: Se
    }, yC = {
      readContext: function(e) {
        return Bt(e);
      },
      useCallback: function(e, t) {
        return G = "useCallback", te(), jf(e, t);
      },
      useContext: function(e) {
        return G = "useContext", te(), Bt(e);
      },
      useEffect: function(e, t) {
        return G = "useEffect", te(), fs(e, t);
      },
      useImperativeHandle: function(e, t, n) {
        return G = "useImperativeHandle", te(), Pf(e, t, n);
      },
      useInsertionEffect: function(e, t) {
        return G = "useInsertionEffect", te(), Lf(e, t);
      },
      useLayoutEffect: function(e, t) {
        return G = "useLayoutEffect", te(), kf(e, t);
      },
      useMemo: function(e, t) {
        G = "useMemo", te();
        var n = le.current;
        le.current = Ir;
        try {
          return Ff(e, t);
        } finally {
          le.current = n;
        }
      },
      useReducer: function(e, t, n) {
        G = "useReducer", te();
        var r = le.current;
        le.current = Ir;
        try {
          return Rh(e, t, n);
        } finally {
          le.current = r;
        }
      },
      useRef: function(e) {
        return G = "useRef", te(), Of();
      },
      useState: function(e) {
        G = "useState", te();
        var t = le.current;
        le.current = Ir;
        try {
          return Th(e);
        } finally {
          le.current = t;
        }
      },
      useDebugValue: function(e, t) {
        return G = "useDebugValue", te(), Uf();
      },
      useDeferredValue: function(e) {
        return G = "useDeferredValue", te(), iC(e);
      },
      useTransition: function() {
        return G = "useTransition", te(), uC();
      },
      useMutableSource: function(e, t, n) {
        return G = "useMutableSource", te(), void 0;
      },
      useSyncExternalStore: function(e, t, n) {
        return G = "useSyncExternalStore", te(), _f(e, t);
      },
      useId: function() {
        return G = "useId", te(), zf();
      },
      unstable_isNewReconciler: Se
    }, gC = {
      readContext: function(e) {
        return Bt(e);
      },
      useCallback: function(e, t) {
        return G = "useCallback", te(), jf(e, t);
      },
      useContext: function(e) {
        return G = "useContext", te(), Bt(e);
      },
      useEffect: function(e, t) {
        return G = "useEffect", te(), fs(e, t);
      },
      useImperativeHandle: function(e, t, n) {
        return G = "useImperativeHandle", te(), Pf(e, t, n);
      },
      useInsertionEffect: function(e, t) {
        return G = "useInsertionEffect", te(), Lf(e, t);
      },
      useLayoutEffect: function(e, t) {
        return G = "useLayoutEffect", te(), kf(e, t);
      },
      useMemo: function(e, t) {
        G = "useMemo", te();
        var n = le.current;
        le.current = $f;
        try {
          return Ff(e, t);
        } finally {
          le.current = n;
        }
      },
      useReducer: function(e, t, n) {
        G = "useReducer", te();
        var r = le.current;
        le.current = $f;
        try {
          return wh(e, t, n);
        } finally {
          le.current = r;
        }
      },
      useRef: function(e) {
        return G = "useRef", te(), Of();
      },
      useState: function(e) {
        G = "useState", te();
        var t = le.current;
        le.current = $f;
        try {
          return Dh(e);
        } finally {
          le.current = t;
        }
      },
      useDebugValue: function(e, t) {
        return G = "useDebugValue", te(), Uf();
      },
      useDeferredValue: function(e) {
        return G = "useDeferredValue", te(), oC(e);
      },
      useTransition: function() {
        return G = "useTransition", te(), sC();
      },
      useMutableSource: function(e, t, n) {
        return G = "useMutableSource", te(), void 0;
      },
      useSyncExternalStore: function(e, t, n) {
        return G = "useSyncExternalStore", te(), _f(e, t);
      },
      useId: function() {
        return G = "useId", te(), zf();
      },
      unstable_isNewReconciler: Se
    }, ca = {
      readContext: function(e) {
        return jh(), Bt(e);
      },
      useCallback: function(e, t) {
        return G = "useCallback", Le(), rt(), Nh(e, t);
      },
      useContext: function(e) {
        return G = "useContext", Le(), rt(), Bt(e);
      },
      useEffect: function(e, t) {
        return G = "useEffect", Le(), rt(), Nf(e, t);
      },
      useImperativeHandle: function(e, t, n) {
        return G = "useImperativeHandle", Le(), rt(), Ah(e, t, n);
      },
      useInsertionEffect: function(e, t) {
        return G = "useInsertionEffect", Le(), rt(), Mh(e, t);
      },
      useLayoutEffect: function(e, t) {
        return G = "useLayoutEffect", Le(), rt(), Oh(e, t);
      },
      useMemo: function(e, t) {
        G = "useMemo", Le(), rt();
        var n = le.current;
        le.current = ca;
        try {
          return Lh(e, t);
        } finally {
          le.current = n;
        }
      },
      useReducer: function(e, t, n) {
        G = "useReducer", Le(), rt();
        var r = le.current;
        le.current = ca;
        try {
          return Eh(e, t, n);
        } finally {
          le.current = r;
        }
      },
      useRef: function(e) {
        return G = "useRef", Le(), rt(), _h(e);
      },
      useState: function(e) {
        G = "useState", Le(), rt();
        var t = le.current;
        le.current = ca;
        try {
          return Mf(e);
        } finally {
          le.current = t;
        }
      },
      useDebugValue: function(e, t) {
        return G = "useDebugValue", Le(), rt(), void 0;
      },
      useDeferredValue: function(e) {
        return G = "useDeferredValue", Le(), rt(), kh(e);
      },
      useTransition: function() {
        return G = "useTransition", Le(), rt(), Ph();
      },
      useMutableSource: function(e, t, n) {
        return G = "useMutableSource", Le(), rt(), void 0;
      },
      useSyncExternalStore: function(e, t, n) {
        return G = "useSyncExternalStore", Le(), rt(), xh(e, t, n);
      },
      useId: function() {
        return G = "useId", Le(), rt(), Uh();
      },
      unstable_isNewReconciler: Se
    }, Ir = {
      readContext: function(e) {
        return jh(), Bt(e);
      },
      useCallback: function(e, t) {
        return G = "useCallback", Le(), te(), jf(e, t);
      },
      useContext: function(e) {
        return G = "useContext", Le(), te(), Bt(e);
      },
      useEffect: function(e, t) {
        return G = "useEffect", Le(), te(), fs(e, t);
      },
      useImperativeHandle: function(e, t, n) {
        return G = "useImperativeHandle", Le(), te(), Pf(e, t, n);
      },
      useInsertionEffect: function(e, t) {
        return G = "useInsertionEffect", Le(), te(), Lf(e, t);
      },
      useLayoutEffect: function(e, t) {
        return G = "useLayoutEffect", Le(), te(), kf(e, t);
      },
      useMemo: function(e, t) {
        G = "useMemo", Le(), te();
        var n = le.current;
        le.current = Ir;
        try {
          return Ff(e, t);
        } finally {
          le.current = n;
        }
      },
      useReducer: function(e, t, n) {
        G = "useReducer", Le(), te();
        var r = le.current;
        le.current = Ir;
        try {
          return Rh(e, t, n);
        } finally {
          le.current = r;
        }
      },
      useRef: function(e) {
        return G = "useRef", Le(), te(), Of();
      },
      useState: function(e) {
        G = "useState", Le(), te();
        var t = le.current;
        le.current = Ir;
        try {
          return Th(e);
        } finally {
          le.current = t;
        }
      },
      useDebugValue: function(e, t) {
        return G = "useDebugValue", Le(), te(), Uf();
      },
      useDeferredValue: function(e) {
        return G = "useDeferredValue", Le(), te(), iC(e);
      },
      useTransition: function() {
        return G = "useTransition", Le(), te(), uC();
      },
      useMutableSource: function(e, t, n) {
        return G = "useMutableSource", Le(), te(), void 0;
      },
      useSyncExternalStore: function(e, t, n) {
        return G = "useSyncExternalStore", Le(), te(), _f(e, t);
      },
      useId: function() {
        return G = "useId", Le(), te(), zf();
      },
      unstable_isNewReconciler: Se
    }, $f = {
      readContext: function(e) {
        return jh(), Bt(e);
      },
      useCallback: function(e, t) {
        return G = "useCallback", Le(), te(), jf(e, t);
      },
      useContext: function(e) {
        return G = "useContext", Le(), te(), Bt(e);
      },
      useEffect: function(e, t) {
        return G = "useEffect", Le(), te(), fs(e, t);
      },
      useImperativeHandle: function(e, t, n) {
        return G = "useImperativeHandle", Le(), te(), Pf(e, t, n);
      },
      useInsertionEffect: function(e, t) {
        return G = "useInsertionEffect", Le(), te(), Lf(e, t);
      },
      useLayoutEffect: function(e, t) {
        return G = "useLayoutEffect", Le(), te(), kf(e, t);
      },
      useMemo: function(e, t) {
        G = "useMemo", Le(), te();
        var n = le.current;
        le.current = Ir;
        try {
          return Ff(e, t);
        } finally {
          le.current = n;
        }
      },
      useReducer: function(e, t, n) {
        G = "useReducer", Le(), te();
        var r = le.current;
        le.current = Ir;
        try {
          return wh(e, t, n);
        } finally {
          le.current = r;
        }
      },
      useRef: function(e) {
        return G = "useRef", Le(), te(), Of();
      },
      useState: function(e) {
        G = "useState", Le(), te();
        var t = le.current;
        le.current = Ir;
        try {
          return Dh(e);
        } finally {
          le.current = t;
        }
      },
      useDebugValue: function(e, t) {
        return G = "useDebugValue", Le(), te(), Uf();
      },
      useDeferredValue: function(e) {
        return G = "useDeferredValue", Le(), te(), oC(e);
      },
      useTransition: function() {
        return G = "useTransition", Le(), te(), sC();
      },
      useMutableSource: function(e, t, n) {
        return G = "useMutableSource", Le(), te(), void 0;
      },
      useSyncExternalStore: function(e, t, n) {
        return G = "useSyncExternalStore", Le(), te(), _f(e, t);
      },
      useId: function() {
        return G = "useId", Le(), te(), zf();
      },
      unstable_isNewReconciler: Se
    };
  }
  var wi = o.unstable_now, bC = 0, If = -1, ds = -1, Bf = -1, Fh = !1, Vf = !1;
  function SC() {
    return Fh;
  }
  function VO() {
    Vf = !0;
  }
  function YO() {
    Fh = !1, Vf = !1;
  }
  function WO() {
    Fh = Vf, Vf = !1;
  }
  function CC() {
    return bC;
  }
  function EC() {
    bC = wi();
  }
  function zh(e) {
    ds = wi(), e.actualStartTime < 0 && (e.actualStartTime = wi());
  }
  function RC(e) {
    ds = -1;
  }
  function Yf(e, t) {
    if (ds >= 0) {
      var n = wi() - ds;
      e.actualDuration += n, t && (e.selfBaseDuration = n), ds = -1;
    }
  }
  function fa(e) {
    if (If >= 0) {
      var t = wi() - If;
      If = -1;
      for (var n = e.return; n !== null; ) {
        switch (n.tag) {
          case E:
            var r = n.stateNode;
            r.effectDuration += t;
            return;
          case X:
            var i = n.stateNode;
            i.effectDuration += t;
            return;
        }
        n = n.return;
      }
    }
  }
  function Hh(e) {
    if (Bf >= 0) {
      var t = wi() - Bf;
      Bf = -1;
      for (var n = e.return; n !== null; ) {
        switch (n.tag) {
          case E:
            var r = n.stateNode;
            r !== null && (r.passiveEffectDuration += t);
            return;
          case X:
            var i = n.stateNode;
            i !== null && (i.passiveEffectDuration += t);
            return;
        }
        n = n.return;
      }
    }
  }
  function da() {
    If = wi();
  }
  function $h() {
    Bf = wi();
  }
  function Ih(e) {
    for (var t = e.child; t; )
      e.actualDuration += t.actualDuration, t = t.sibling;
  }
  function Br(e, t) {
    if (e && e.defaultProps) {
      var n = He({}, t), r = e.defaultProps;
      for (var i in r)
        n[i] === void 0 && (n[i] = r[i]);
      return n;
    }
    return t;
  }
  var Bh = {}, Vh, Yh, Wh, Gh, Xh, wC, Wf, Kh, qh, Qh, ps;
  {
    Vh = /* @__PURE__ */ new Set(), Yh = /* @__PURE__ */ new Set(), Wh = /* @__PURE__ */ new Set(), Gh = /* @__PURE__ */ new Set(), Kh = /* @__PURE__ */ new Set(), Xh = /* @__PURE__ */ new Set(), qh = /* @__PURE__ */ new Set(), Qh = /* @__PURE__ */ new Set(), ps = /* @__PURE__ */ new Set();
    var xC = /* @__PURE__ */ new Set();
    Wf = function(e, t) {
      if (!(e === null || typeof e == "function")) {
        var n = t + "_" + e;
        xC.has(n) || (xC.add(n), c("%s(...): Expected the last optional `callback` argument to be a function. Instead received: %s.", t, e));
      }
    }, wC = function(e, t) {
      if (t === void 0) {
        var n = Ze(e) || "Component";
        Xh.has(n) || (Xh.add(n), c("%s.getDerivedStateFromProps(): A valid state object (or null) must be returned. You have returned undefined.", n));
      }
    }, Object.defineProperty(Bh, "_processChildContext", {
      enumerable: !1,
      value: function() {
        throw new Error("_processChildContext is not available in React 16+. This likely means you have multiple copies of React and are attempting to nest a React 15 tree inside a React 16 tree using unstable_renderSubtreeIntoContainer, which isn't supported. Try to make sure you have only one copy of React (and ideally, switch to ReactDOM.createPortal).");
      }
    }), Object.freeze(Bh);
  }
  function Zh(e, t, n, r) {
    var i = e.memoizedState, l = n(r, i);
    {
      if (e.mode & Mt) {
        sn(!0);
        try {
          l = n(r, i);
        } finally {
          sn(!1);
        }
      }
      wC(t, l);
    }
    var f = l == null ? i : He({}, i, l);
    if (e.memoizedState = f, e.lanes === K) {
      var p = e.updateQueue;
      p.baseState = f;
    }
  }
  var Jh = {
    isMounted: jT,
    enqueueSetState: function(e, t, n) {
      var r = Bo(e), i = In(), l = _i(r), f = Ba(i, l);
      f.payload = t, n != null && (Wf(n, "setState"), f.callback = n);
      var p = Si(r, f, l);
      p !== null && (rn(p, r, l, i), Cf(p, r, l)), Op(r, l);
    },
    enqueueReplaceState: function(e, t, n) {
      var r = Bo(e), i = In(), l = _i(r), f = Ba(i, l);
      f.tag = IS, f.payload = t, n != null && (Wf(n, "replaceState"), f.callback = n);
      var p = Si(r, f, l);
      p !== null && (rn(p, r, l, i), Cf(p, r, l)), Op(r, l);
    },
    enqueueForceUpdate: function(e, t) {
      var n = Bo(e), r = In(), i = _i(n), l = Ba(r, i);
      l.tag = gf, t != null && (Wf(t, "forceUpdate"), l.callback = t);
      var f = Si(n, l, i);
      f !== null && (rn(f, n, i, r), Cf(f, n, i)), v1(n, i);
    }
  };
  function TC(e, t, n, r, i, l, f) {
    var p = e.stateNode;
    if (typeof p.shouldComponentUpdate == "function") {
      var m = p.shouldComponentUpdate(r, l, f);
      {
        if (e.mode & Mt) {
          sn(!0);
          try {
            m = p.shouldComponentUpdate(r, l, f);
          } finally {
            sn(!1);
          }
        }
        m === void 0 && c("%s.shouldComponentUpdate(): Returned undefined instead of a boolean value. Make sure to return true or false.", Ze(t) || "Component");
      }
      return m;
    }
    return t.prototype && t.prototype.isPureReactComponent ? !Pu(n, r) || !Pu(i, l) : !0;
  }
  function GO(e, t, n) {
    var r = e.stateNode;
    {
      var i = Ze(t) || "Component", l = r.render;
      l || (t.prototype && typeof t.prototype.render == "function" ? c("%s(...): No `render` method found on the returned component instance: did you accidentally return an object from the constructor?", i) : c("%s(...): No `render` method found on the returned component instance: you may have forgotten to define `render`.", i)), r.getInitialState && !r.getInitialState.isReactClassApproved && !r.state && c("getInitialState was defined on %s, a plain JavaScript class. This is only supported for classes created using React.createClass. Did you mean to define a state property instead?", i), r.getDefaultProps && !r.getDefaultProps.isReactClassApproved && c("getDefaultProps was defined on %s, a plain JavaScript class. This is only supported for classes created using React.createClass. Use a static property to define defaultProps instead.", i), r.propTypes && c("propTypes was defined as an instance property on %s. Use a static property to define propTypes instead.", i), r.contextType && c("contextType was defined as an instance property on %s. Use a static property to define contextType instead.", i), t.childContextTypes && !ps.has(t) && // Strict Mode has its own warning for legacy context, so we can skip
      // this one.
      (e.mode & Mt) === Re && (ps.add(t), c(`%s uses the legacy childContextTypes API which is no longer supported and will be removed in the next major release. Use React.createContext() instead

.Learn more about this warning here: https://reactjs.org/link/legacy-context`, i)), t.contextTypes && !ps.has(t) && // Strict Mode has its own warning for legacy context, so we can skip
      // this one.
      (e.mode & Mt) === Re && (ps.add(t), c(`%s uses the legacy contextTypes API which is no longer supported and will be removed in the next major release. Use React.createContext() with static contextType instead.

Learn more about this warning here: https://reactjs.org/link/legacy-context`, i)), r.contextTypes && c("contextTypes was defined as an instance property on %s. Use a static property to define contextTypes instead.", i), t.contextType && t.contextTypes && !qh.has(t) && (qh.add(t), c("%s declares both contextTypes and contextType static properties. The legacy contextTypes property will be ignored.", i)), typeof r.componentShouldUpdate == "function" && c("%s has a method called componentShouldUpdate(). Did you mean shouldComponentUpdate()? The name is phrased as a question because the function is expected to return a value.", i), t.prototype && t.prototype.isPureReactComponent && typeof r.shouldComponentUpdate < "u" && c("%s has a method called shouldComponentUpdate(). shouldComponentUpdate should not be used when extending React.PureComponent. Please extend React.Component if shouldComponentUpdate is used.", Ze(t) || "A pure component"), typeof r.componentDidUnmount == "function" && c("%s has a method called componentDidUnmount(). But there is no such lifecycle method. Did you mean componentWillUnmount()?", i), typeof r.componentDidReceiveProps == "function" && c("%s has a method called componentDidReceiveProps(). But there is no such lifecycle method. If you meant to update the state in response to changing props, use componentWillReceiveProps(). If you meant to fetch data or run side-effects or mutations after React has updated the UI, use componentDidUpdate().", i), typeof r.componentWillRecieveProps == "function" && c("%s has a method called componentWillRecieveProps(). Did you mean componentWillReceiveProps()?", i), typeof r.UNSAFE_componentWillRecieveProps == "function" && c("%s has a method called UNSAFE_componentWillRecieveProps(). Did you mean UNSAFE_componentWillReceiveProps()?", i);
      var f = r.props !== n;
      r.props !== void 0 && f && c("%s(...): When calling super() in `%s`, make sure to pass up the same props that your component's constructor was passed.", i, i), r.defaultProps && c("Setting defaultProps as an instance property on %s is not supported and will be ignored. Instead, define defaultProps as a static property on %s.", i, i), typeof r.getSnapshotBeforeUpdate == "function" && typeof r.componentDidUpdate != "function" && !Wh.has(t) && (Wh.add(t), c("%s: getSnapshotBeforeUpdate() should be used with componentDidUpdate(). This component defines getSnapshotBeforeUpdate() only.", Ze(t))), typeof r.getDerivedStateFromProps == "function" && c("%s: getDerivedStateFromProps() is defined as an instance method and will be ignored. Instead, declare it as a static method.", i), typeof r.getDerivedStateFromError == "function" && c("%s: getDerivedStateFromError() is defined as an instance method and will be ignored. Instead, declare it as a static method.", i), typeof t.getSnapshotBeforeUpdate == "function" && c("%s: getSnapshotBeforeUpdate() is defined as a static method and will be ignored. Instead, declare it as an instance method.", i);
      var p = r.state;
      p && (typeof p != "object" || tt(p)) && c("%s.state: must be set to an object or null", i), typeof r.getChildContext == "function" && typeof t.childContextTypes != "object" && c("%s.getChildContext(): childContextTypes must be defined in order to use getChildContext().", i);
    }
  }
  function DC(e, t) {
    t.updater = Jh, e.stateNode = t, NT(t, e), t._reactInternalInstance = Bh;
  }
  function _C(e, t, n) {
    var r = !1, i = cr, l = cr, f = t.contextType;
    if ("contextType" in t) {
      var p = (
        // Allow null for conditional declaration
        f === null || f !== void 0 && f.$$typeof === q && f._context === void 0
      );
      if (!p && !Qh.has(t)) {
        Qh.add(t);
        var m = "";
        f === void 0 ? m = " However, it is set to undefined. This can be caused by a typo or by mixing up named and default imports. This can also happen due to a circular dependency, so try moving the createContext() call to a separate file." : typeof f != "object" ? m = " However, it is set to a " + typeof f + "." : f.$$typeof === _ ? m = " Did you accidentally pass the Context.Provider instead?" : f._context !== void 0 ? m = " Did you accidentally pass the Context.Consumer instead?" : m = " However, it is set to an object with keys {" + Object.keys(f).join(", ") + "}.", c("%s defines an invalid contextType. contextType should point to the Context object returned by React.createContext().%s", Ze(t) || "Component", m);
      }
    }
    if (typeof f == "object" && f !== null)
      l = Bt(f);
    else {
      i = ll(e, t, !0);
      var C = t.contextTypes;
      r = C != null, l = r ? ul(e, i) : cr;
    }
    var w = new t(n, l);
    if (e.mode & Mt) {
      sn(!0);
      try {
        w = new t(n, l);
      } finally {
        sn(!1);
      }
    }
    var N = e.memoizedState = w.state !== null && w.state !== void 0 ? w.state : null;
    DC(e, w);
    {
      if (typeof t.getDerivedStateFromProps == "function" && N === null) {
        var A = Ze(t) || "Component";
        Yh.has(A) || (Yh.add(A), c("`%s` uses `getDerivedStateFromProps` but its initial state is %s. This is not recommended. Instead, define the initial state by assigning an object to `this.state` in the constructor of `%s`. This ensures that `getDerivedStateFromProps` arguments have a consistent shape.", A, w.state === null ? "null" : "undefined", A));
      }
      if (typeof t.getDerivedStateFromProps == "function" || typeof w.getSnapshotBeforeUpdate == "function") {
        var j = null, H = null, B = null;
        if (typeof w.componentWillMount == "function" && w.componentWillMount.__suppressDeprecationWarning !== !0 ? j = "componentWillMount" : typeof w.UNSAFE_componentWillMount == "function" && (j = "UNSAFE_componentWillMount"), typeof w.componentWillReceiveProps == "function" && w.componentWillReceiveProps.__suppressDeprecationWarning !== !0 ? H = "componentWillReceiveProps" : typeof w.UNSAFE_componentWillReceiveProps == "function" && (H = "UNSAFE_componentWillReceiveProps"), typeof w.componentWillUpdate == "function" && w.componentWillUpdate.__suppressDeprecationWarning !== !0 ? B = "componentWillUpdate" : typeof w.UNSAFE_componentWillUpdate == "function" && (B = "UNSAFE_componentWillUpdate"), j !== null || H !== null || B !== null) {
          var ae = Ze(t) || "Component", Ce = typeof t.getDerivedStateFromProps == "function" ? "getDerivedStateFromProps()" : "getSnapshotBeforeUpdate()";
          Gh.has(ae) || (Gh.add(ae), c(`Unsafe legacy lifecycles will not be called for components using new component APIs.

%s uses %s but also contains the following legacy lifecycles:%s%s%s

The above lifecycles should be removed. Learn more about this warning here:
https://reactjs.org/link/unsafe-component-lifecycles`, ae, Ce, j !== null ? `
  ` + j : "", H !== null ? `
  ` + H : "", B !== null ? `
  ` + B : ""));
        }
      }
    }
    return r && yS(e, i, l), w;
  }
  function XO(e, t) {
    var n = t.state;
    typeof t.componentWillMount == "function" && t.componentWillMount(), typeof t.UNSAFE_componentWillMount == "function" && t.UNSAFE_componentWillMount(), n !== t.state && (c("%s.componentWillMount(): Assigning directly to this.state is deprecated (except inside a component's constructor). Use setState instead.", Pe(e) || "Component"), Jh.enqueueReplaceState(t, t.state, null));
  }
  function MC(e, t, n, r) {
    var i = t.state;
    if (typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(n, r), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(n, r), t.state !== i) {
      {
        var l = Pe(e) || "Component";
        Vh.has(l) || (Vh.add(l), c("%s.componentWillReceiveProps(): Assigning directly to this.state is deprecated (except inside a component's constructor). Use setState instead.", l));
      }
      Jh.enqueueReplaceState(t, t.state, null);
    }
  }
  function em(e, t, n, r) {
    GO(e, t, n);
    var i = e.stateNode;
    i.props = n, i.state = e.memoizedState, i.refs = {}, sh(e);
    var l = t.contextType;
    if (typeof l == "object" && l !== null)
      i.context = Bt(l);
    else {
      var f = ll(e, t, !0);
      i.context = ul(e, f);
    }
    {
      if (i.state === n) {
        var p = Ze(t) || "Component";
        Kh.has(p) || (Kh.add(p), c("%s: It is not recommended to assign props directly to state because updates to props won't be reflected in state. In most cases, it is better to use props directly.", p));
      }
      e.mode & Mt && Hr.recordLegacyContextWarning(e, i), Hr.recordUnsafeLifecycleWarnings(e, i);
    }
    i.state = e.memoizedState;
    var m = t.getDerivedStateFromProps;
    if (typeof m == "function" && (Zh(e, t, m, n), i.state = e.memoizedState), typeof t.getDerivedStateFromProps != "function" && typeof i.getSnapshotBeforeUpdate != "function" && (typeof i.UNSAFE_componentWillMount == "function" || typeof i.componentWillMount == "function") && (XO(e, i), Ef(e, n, i, r), i.state = e.memoizedState), typeof i.componentDidMount == "function") {
      var C = qe;
      C |= Qi, (e.mode & aa) !== Re && (C |= La), e.flags |= C;
    }
  }
  function KO(e, t, n, r) {
    var i = e.stateNode, l = e.memoizedProps;
    i.props = l;
    var f = i.context, p = t.contextType, m = cr;
    if (typeof p == "object" && p !== null)
      m = Bt(p);
    else {
      var C = ll(e, t, !0);
      m = ul(e, C);
    }
    var w = t.getDerivedStateFromProps, N = typeof w == "function" || typeof i.getSnapshotBeforeUpdate == "function";
    !N && (typeof i.UNSAFE_componentWillReceiveProps == "function" || typeof i.componentWillReceiveProps == "function") && (l !== n || f !== m) && MC(e, i, n, m), VS();
    var A = e.memoizedState, j = i.state = A;
    if (Ef(e, n, i, r), j = e.memoizedState, l === n && A === j && !nf() && !Rf()) {
      if (typeof i.componentDidMount == "function") {
        var H = qe;
        H |= Qi, (e.mode & aa) !== Re && (H |= La), e.flags |= H;
      }
      return !1;
    }
    typeof w == "function" && (Zh(e, t, w, n), j = e.memoizedState);
    var B = Rf() || TC(e, t, l, n, A, j, m);
    if (B) {
      if (!N && (typeof i.UNSAFE_componentWillMount == "function" || typeof i.componentWillMount == "function") && (typeof i.componentWillMount == "function" && i.componentWillMount(), typeof i.UNSAFE_componentWillMount == "function" && i.UNSAFE_componentWillMount()), typeof i.componentDidMount == "function") {
        var ae = qe;
        ae |= Qi, (e.mode & aa) !== Re && (ae |= La), e.flags |= ae;
      }
    } else {
      if (typeof i.componentDidMount == "function") {
        var Ce = qe;
        Ce |= Qi, (e.mode & aa) !== Re && (Ce |= La), e.flags |= Ce;
      }
      e.memoizedProps = n, e.memoizedState = j;
    }
    return i.props = n, i.state = j, i.context = m, B;
  }
  function qO(e, t, n, r, i) {
    var l = t.stateNode;
    BS(e, t);
    var f = t.memoizedProps, p = t.type === t.elementType ? f : Br(t.type, f);
    l.props = p;
    var m = t.pendingProps, C = l.context, w = n.contextType, N = cr;
    if (typeof w == "object" && w !== null)
      N = Bt(w);
    else {
      var A = ll(t, n, !0);
      N = ul(t, A);
    }
    var j = n.getDerivedStateFromProps, H = typeof j == "function" || typeof l.getSnapshotBeforeUpdate == "function";
    !H && (typeof l.UNSAFE_componentWillReceiveProps == "function" || typeof l.componentWillReceiveProps == "function") && (f !== m || C !== N) && MC(t, l, r, N), VS();
    var B = t.memoizedState, ae = l.state = B;
    if (Ef(t, r, l, i), ae = t.memoizedState, f === m && B === ae && !nf() && !Rf() && !se)
      return typeof l.componentDidUpdate == "function" && (f !== e.memoizedProps || B !== e.memoizedState) && (t.flags |= qe), typeof l.getSnapshotBeforeUpdate == "function" && (f !== e.memoizedProps || B !== e.memoizedState) && (t.flags |= Ki), !1;
    typeof j == "function" && (Zh(t, n, j, r), ae = t.memoizedState);
    var Ce = Rf() || TC(t, n, p, r, B, ae, N) || // TODO: In some cases, we'll end up checking if context has changed twice,
    // both before and after `shouldComponentUpdate` has been called. Not ideal,
    // but I'm loath to refactor this function. This only happens for memoized
    // components so it's not that common.
    se;
    return Ce ? (!H && (typeof l.UNSAFE_componentWillUpdate == "function" || typeof l.componentWillUpdate == "function") && (typeof l.componentWillUpdate == "function" && l.componentWillUpdate(r, ae, N), typeof l.UNSAFE_componentWillUpdate == "function" && l.UNSAFE_componentWillUpdate(r, ae, N)), typeof l.componentDidUpdate == "function" && (t.flags |= qe), typeof l.getSnapshotBeforeUpdate == "function" && (t.flags |= Ki)) : (typeof l.componentDidUpdate == "function" && (f !== e.memoizedProps || B !== e.memoizedState) && (t.flags |= qe), typeof l.getSnapshotBeforeUpdate == "function" && (f !== e.memoizedProps || B !== e.memoizedState) && (t.flags |= Ki), t.memoizedProps = r, t.memoizedState = ae), l.props = r, l.state = ae, l.context = N, Ce;
  }
  function mo(e, t) {
    return {
      value: e,
      source: t,
      stack: eu(t),
      digest: null
    };
  }
  function tm(e, t, n) {
    return {
      value: e,
      source: null,
      stack: n ?? null,
      digest: t ?? null
    };
  }
  function QO(e, t) {
    return !0;
  }
  function nm(e, t) {
    try {
      var n = QO(e, t);
      if (n === !1)
        return;
      var r = t.value, i = t.source, l = t.stack, f = l !== null ? l : "";
      if (r != null && r._suppressLogging) {
        if (e.tag === S)
          return;
        console.error(r);
      }
      var p = i ? Pe(i) : null, m = p ? "The above error occurred in the <" + p + "> component:" : "The above error occurred in one of your React components:", C;
      if (e.tag === E)
        C = `Consider adding an error boundary to your tree to customize error handling behavior.
Visit https://reactjs.org/link/error-boundaries to learn more about error boundaries.`;
      else {
        var w = Pe(e) || "Anonymous";
        C = "React will try to recreate this component tree from scratch " + ("using the error boundary you provided, " + w + ".");
      }
      var N = m + `
` + f + `

` + ("" + C);
      console.error(N);
    } catch (A) {
      setTimeout(function() {
        throw A;
      });
    }
  }
  var ZO = typeof WeakMap == "function" ? WeakMap : Map;
  function OC(e, t, n) {
    var r = Ba(bt, n);
    r.tag = lh, r.payload = {
      element: null
    };
    var i = t.value;
    return r.callback = function() {
      VN(i), nm(e, t);
    }, r;
  }
  function rm(e, t, n) {
    var r = Ba(bt, n);
    r.tag = lh;
    var i = e.type.getDerivedStateFromError;
    if (typeof i == "function") {
      var l = t.value;
      r.payload = function() {
        return i(l);
      }, r.callback = function() {
        $E(e), nm(e, t);
      };
    }
    var f = e.stateNode;
    return f !== null && typeof f.componentDidCatch == "function" && (r.callback = function() {
      $E(e), nm(e, t), typeof i != "function" && IN(this);
      var m = t.value, C = t.stack;
      this.componentDidCatch(m, {
        componentStack: C !== null ? C : ""
      }), typeof i != "function" && (or(e.lanes, Ne) || c("%s: Error boundaries should implement getDerivedStateFromError(). In that method, return a state update to display an error message or fallback UI.", Pe(e) || "Unknown"));
    }), r;
  }
  function AC(e, t, n) {
    var r = e.pingCache, i;
    if (r === null ? (r = e.pingCache = new ZO(), i = /* @__PURE__ */ new Set(), r.set(t, i)) : (i = r.get(t), i === void 0 && (i = /* @__PURE__ */ new Set(), r.set(t, i))), !i.has(n)) {
      i.add(n);
      var l = YN.bind(null, e, t, n);
      Ur && Os(e, n), t.then(l, l);
    }
  }
  function JO(e, t, n, r) {
    var i = e.updateQueue;
    if (i === null) {
      var l = /* @__PURE__ */ new Set();
      l.add(n), e.updateQueue = l;
    } else
      i.add(n);
  }
  function eA(e, t) {
    var n = e.tag;
    if ((e.mode & Ye) === Re && (n === b || n === Y || n === Z)) {
      var r = e.alternate;
      r ? (e.updateQueue = r.updateQueue, e.memoizedState = r.memoizedState, e.lanes = r.lanes) : (e.updateQueue = null, e.memoizedState = null);
    }
  }
  function NC(e) {
    var t = e;
    do {
      if (t.tag === W && kO(t))
        return t;
      t = t.return;
    } while (t !== null);
    return null;
  }
  function LC(e, t, n, r, i) {
    if ((e.mode & Ye) === Re) {
      if (e === t)
        e.flags |= zn;
      else {
        if (e.flags |= nt, n.flags |= Rp, n.flags &= ~(LT | du), n.tag === S) {
          var l = n.alternate;
          if (l === null)
            n.tag = me;
          else {
            var f = Ba(bt, Ne);
            f.tag = gf, Si(n, f, Ne);
          }
        }
        n.lanes = Ue(n.lanes, Ne);
      }
      return e;
    }
    return e.flags |= zn, e.lanes = i, e;
  }
  function tA(e, t, n, r, i) {
    if (n.flags |= du, Ur && Os(e, i), r !== null && typeof r == "object" && typeof r.then == "function") {
      var l = r;
      eA(n), hn() && n.mode & Ye && wS();
      var f = NC(t);
      if (f !== null) {
        f.flags &= ~Aa, LC(f, t, n, e, i), f.mode & Ye && AC(e, l, i), JO(f, e, l);
        return;
      } else {
        if (!R1(i)) {
          AC(e, l, i), Um();
          return;
        }
        var p = new Error("A component suspended while responding to synchronous input. This will cause the UI to be replaced with a loading indicator. To fix, updates that suspend should be wrapped with startTransition.");
        r = p;
      }
    } else if (hn() && n.mode & Ye) {
      wS();
      var m = NC(t);
      if (m !== null) {
        (m.flags & zn) === Te && (m.flags |= Aa), LC(m, t, n, e, i), Kv(mo(r, n));
        return;
      }
    }
    r = mo(r, n), kN(r);
    var C = t;
    do {
      switch (C.tag) {
        case E: {
          var w = r;
          C.flags |= zn;
          var N = Su(i);
          C.lanes = Ue(C.lanes, N);
          var A = OC(C, w, N);
          ch(C, A);
          return;
        }
        case S:
          var j = r, H = C.type, B = C.stateNode;
          if ((C.flags & nt) === Te && (typeof H.getDerivedStateFromError == "function" || B !== null && typeof B.componentDidCatch == "function" && !NE(B))) {
            C.flags |= zn;
            var ae = Su(i);
            C.lanes = Ue(C.lanes, ae);
            var Ce = rm(C, j, ae);
            ch(C, Ce);
            return;
          }
          break;
      }
      C = C.return;
    } while (C !== null);
  }
  function nA() {
    return null;
  }
  var vs = u.ReactCurrentOwner, Vr = !1, am, hs, im, om, lm, yo, um, Gf, ms;
  am = {}, hs = {}, im = {}, om = {}, lm = {}, yo = !1, um = {}, Gf = {}, ms = {};
  function Hn(e, t, n, r) {
    e === null ? t.child = US(t, null, n, r) : t.child = dl(t, e.child, n, r);
  }
  function rA(e, t, n, r) {
    t.child = dl(t, e.child, null, r), t.child = dl(t, null, n, r);
  }
  function kC(e, t, n, r, i) {
    if (t.type !== t.elementType) {
      var l = n.propTypes;
      l && Fr(
        l,
        r,
        // Resolved props
        "prop",
        Ze(n)
      );
    }
    var f = n.render, p = t.ref, m, C;
    vl(t, i), vu(t);
    {
      if (vs.current = t, ar(!0), m = Sl(e, t, f, r, p, i), C = Cl(), t.mode & Mt) {
        sn(!0);
        try {
          m = Sl(e, t, f, r, p, i), C = Cl();
        } finally {
          sn(!1);
        }
      }
      ar(!1);
    }
    return Go(), e !== null && !Vr ? (qS(e, t, i), Va(e, t, i)) : (hn() && C && Bv(t), t.flags |= Vo, Hn(e, t, m, i), t.child);
  }
  function PC(e, t, n, r, i) {
    if (e === null) {
      var l = n.type;
      if (uL(l) && n.compare === null && // SimpleMemoComponent codepath doesn't resolve outer props either.
      n.defaultProps === void 0) {
        var f = l;
        return f = Ml(l), t.tag = Z, t.type = f, fm(t, l), UC(e, t, f, r, i);
      }
      {
        var p = l.propTypes;
        if (p && Fr(
          p,
          r,
          // Resolved props
          "prop",
          Ze(l)
        ), n.defaultProps !== void 0) {
          var m = Ze(l) || "Unknown";
          ms[m] || (c("%s: Support for defaultProps will be removed from memo components in a future major release. Use JavaScript default parameters instead.", m), ms[m] = !0);
        }
      }
      var C = Gm(n.type, null, r, t, t.mode, i);
      return C.ref = t.ref, C.return = t, t.child = C, C;
    }
    {
      var w = n.type, N = w.propTypes;
      N && Fr(
        N,
        r,
        // Resolved props
        "prop",
        Ze(w)
      );
    }
    var A = e.child, j = ym(e, i);
    if (!j) {
      var H = A.memoizedProps, B = n.compare;
      if (B = B !== null ? B : Pu, B(H, r) && e.ref === t.ref)
        return Va(e, t, i);
    }
    t.flags |= Vo;
    var ae = Eo(A, r);
    return ae.ref = t.ref, ae.return = t, t.child = ae, ae;
  }
  function UC(e, t, n, r, i) {
    if (t.type !== t.elementType) {
      var l = t.elementType;
      if (l.$$typeof === xe) {
        var f = l, p = f._payload, m = f._init;
        try {
          l = m(p);
        } catch {
          l = null;
        }
        var C = l && l.propTypes;
        C && Fr(
          C,
          r,
          // Resolved (SimpleMemoComponent has no defaultProps)
          "prop",
          Ze(l)
        );
      }
    }
    if (e !== null) {
      var w = e.memoizedProps;
      if (Pu(w, r) && e.ref === t.ref && // Prevent bailout if the implementation changed due to hot reload.
      t.type === e.type)
        if (Vr = !1, t.pendingProps = r = w, ym(e, i))
          (e.flags & Rp) !== Te && (Vr = !0);
        else
          return t.lanes = e.lanes, Va(e, t, i);
    }
    return sm(e, t, n, r, i);
  }
  function jC(e, t, n) {
    var r = t.pendingProps, i = r.children, l = e !== null ? e.memoizedState : null;
    if (r.mode === "hidden" || Ke)
      if ((t.mode & Ye) === Re) {
        var f = {
          baseLanes: K,
          cachePool: null,
          transitions: null
        };
        t.memoizedState = f, od(t, n);
      } else if (or(n, ir)) {
        var N = {
          baseLanes: K,
          cachePool: null,
          transitions: null
        };
        t.memoizedState = N;
        var A = l !== null ? l.baseLanes : n;
        od(t, A);
      } else {
        var p = null, m;
        if (l !== null) {
          var C = l.baseLanes;
          m = Ue(C, n);
        } else
          m = n;
        t.lanes = t.childLanes = ir;
        var w = {
          baseLanes: m,
          cachePool: p,
          transitions: null
        };
        return t.memoizedState = w, t.updateQueue = null, od(t, m), null;
      }
    else {
      var j;
      l !== null ? (j = Ue(l.baseLanes, n), t.memoizedState = null) : j = n, od(t, j);
    }
    return Hn(e, t, i, n), t.child;
  }
  function aA(e, t, n) {
    var r = t.pendingProps;
    return Hn(e, t, r, n), t.child;
  }
  function iA(e, t, n) {
    var r = t.pendingProps.children;
    return Hn(e, t, r, n), t.child;
  }
  function oA(e, t, n) {
    {
      t.flags |= qe;
      {
        var r = t.stateNode;
        r.effectDuration = 0, r.passiveEffectDuration = 0;
      }
    }
    var i = t.pendingProps, l = i.children;
    return Hn(e, t, l, n), t.child;
  }
  function FC(e, t) {
    var n = t.ref;
    (e === null && n !== null || e !== null && e.ref !== n) && (t.flags |= ui, t.flags |= wp);
  }
  function sm(e, t, n, r, i) {
    if (t.type !== t.elementType) {
      var l = n.propTypes;
      l && Fr(
        l,
        r,
        // Resolved props
        "prop",
        Ze(n)
      );
    }
    var f;
    {
      var p = ll(t, n, !0);
      f = ul(t, p);
    }
    var m, C;
    vl(t, i), vu(t);
    {
      if (vs.current = t, ar(!0), m = Sl(e, t, n, r, f, i), C = Cl(), t.mode & Mt) {
        sn(!0);
        try {
          m = Sl(e, t, n, r, f, i), C = Cl();
        } finally {
          sn(!1);
        }
      }
      ar(!1);
    }
    return Go(), e !== null && !Vr ? (qS(e, t, i), Va(e, t, i)) : (hn() && C && Bv(t), t.flags |= Vo, Hn(e, t, m, i), t.child);
  }
  function zC(e, t, n, r, i) {
    {
      switch (RL(t)) {
        case !1: {
          var l = t.stateNode, f = t.type, p = new f(t.memoizedProps, l.context), m = p.state;
          l.updater.enqueueSetState(l, m, null);
          break;
        }
        case !0: {
          t.flags |= nt, t.flags |= zn;
          var C = new Error("Simulated error coming from DevTools"), w = Su(i);
          t.lanes = Ue(t.lanes, w);
          var N = rm(t, mo(C, t), w);
          ch(t, N);
          break;
        }
      }
      if (t.type !== t.elementType) {
        var A = n.propTypes;
        A && Fr(
          A,
          r,
          // Resolved props
          "prop",
          Ze(n)
        );
      }
    }
    var j;
    la(n) ? (j = !0, af(t)) : j = !1, vl(t, i);
    var H = t.stateNode, B;
    H === null ? (Kf(e, t), _C(t, n, r), em(t, n, r, i), B = !0) : e === null ? B = KO(t, n, r, i) : B = qO(e, t, n, r, i);
    var ae = cm(e, t, n, B, j, i);
    {
      var Ce = t.stateNode;
      B && Ce.props !== r && (yo || c("It looks like %s is reassigning its own `this.props` while rendering. This is not supported and can lead to confusing bugs.", Pe(t) || "a component"), yo = !0);
    }
    return ae;
  }
  function cm(e, t, n, r, i, l) {
    FC(e, t);
    var f = (t.flags & nt) !== Te;
    if (!r && !f)
      return i && SS(t, n, !1), Va(e, t, l);
    var p = t.stateNode;
    vs.current = t;
    var m;
    if (f && typeof n.getDerivedStateFromError != "function")
      m = null, RC();
    else {
      vu(t);
      {
        if (ar(!0), m = p.render(), t.mode & Mt) {
          sn(!0);
          try {
            p.render();
          } finally {
            sn(!1);
          }
        }
        ar(!1);
      }
      Go();
    }
    return t.flags |= Vo, e !== null && f ? rA(e, t, m, l) : Hn(e, t, m, l), t.memoizedState = p.state, i && SS(t, n, !0), t.child;
  }
  function HC(e) {
    var t = e.stateNode;
    t.pendingContext ? gS(e, t.pendingContext, t.pendingContext !== t.context) : t.context && gS(e, t.context, !1), fh(e, t.containerInfo);
  }
  function lA(e, t, n) {
    if (HC(t), e === null)
      throw new Error("Should have a current fiber. This is a bug in React.");
    var r = t.pendingProps, i = t.memoizedState, l = i.element;
    BS(e, t), Ef(t, r, null, n);
    var f = t.memoizedState;
    t.stateNode;
    var p = f.element;
    if (i.isDehydrated) {
      var m = {
        element: p,
        isDehydrated: !1,
        cache: f.cache,
        pendingSuspenseBoundaries: f.pendingSuspenseBoundaries,
        transitions: f.transitions
      }, C = t.updateQueue;
      if (C.baseState = m, t.memoizedState = m, t.flags & Aa) {
        var w = mo(new Error("There was an error while hydrating. Because the error happened outside of a Suspense boundary, the entire root will switch to client rendering."), t);
        return $C(e, t, p, n, w);
      } else if (p !== l) {
        var N = mo(new Error("This root received an early update, before anything was able hydrate. Switched the entire root to client rendering."), t);
        return $C(e, t, p, n, N);
      } else {
        cO(t);
        var A = US(t, null, p, n);
        t.child = A;
        for (var j = A; j; )
          j.flags = j.flags & ~It | Na, j = j.sibling;
      }
    } else {
      if (fl(), p === l)
        return Va(e, t, n);
      Hn(e, t, p, n);
    }
    return t.child;
  }
  function $C(e, t, n, r, i) {
    return fl(), Kv(i), t.flags |= Aa, Hn(e, t, n, r), t.child;
  }
  function uA(e, t, n) {
    GS(t), e === null && Xv(t);
    var r = t.type, i = t.pendingProps, l = e !== null ? e.memoizedProps : null, f = i.children, p = Mv(r, i);
    return p ? f = null : l !== null && Mv(r, l) && (t.flags |= fu), FC(e, t), Hn(e, t, f, n), t.child;
  }
  function sA(e, t) {
    return e === null && Xv(t), null;
  }
  function cA(e, t, n, r) {
    Kf(e, t);
    var i = t.pendingProps, l = n, f = l._payload, p = l._init, m = p(f);
    t.type = m;
    var C = t.tag = sL(m), w = Br(m, i), N;
    switch (C) {
      case b:
        return fm(t, m), t.type = m = Ml(m), N = sm(null, t, m, w, r), N;
      case S:
        return t.type = m = $m(m), N = zC(null, t, m, w, r), N;
      case Y:
        return t.type = m = Im(m), N = kC(null, t, m, w, r), N;
      case ne: {
        if (t.type !== t.elementType) {
          var A = m.propTypes;
          A && Fr(
            A,
            w,
            // Resolved for outer only
            "prop",
            Ze(m)
          );
        }
        return N = PC(
          null,
          t,
          m,
          Br(m.type, w),
          // The inner type can have defaults too
          r
        ), N;
      }
    }
    var j = "";
    throw m !== null && typeof m == "object" && m.$$typeof === xe && (j = " Did you wrap a component in React.lazy() more than once?"), new Error("Element type is invalid. Received a promise that resolves to: " + m + ". " + ("Lazy element type must resolve to a class or function." + j));
  }
  function fA(e, t, n, r, i) {
    Kf(e, t), t.tag = S;
    var l;
    return la(n) ? (l = !0, af(t)) : l = !1, vl(t, i), _C(t, n, r), em(t, n, r, i), cm(null, t, n, !0, l, i);
  }
  function dA(e, t, n, r) {
    Kf(e, t);
    var i = t.pendingProps, l;
    {
      var f = ll(t, n, !1);
      l = ul(t, f);
    }
    vl(t, r);
    var p, m;
    vu(t);
    {
      if (n.prototype && typeof n.prototype.render == "function") {
        var C = Ze(n) || "Unknown";
        am[C] || (c("The <%s /> component appears to have a render method, but doesn't extend React.Component. This is likely to cause errors. Change %s to extend React.Component instead.", C, C), am[C] = !0);
      }
      t.mode & Mt && Hr.recordLegacyContextWarning(t, null), ar(!0), vs.current = t, p = Sl(null, t, n, i, l, r), m = Cl(), ar(!1);
    }
    if (Go(), t.flags |= Vo, typeof p == "object" && p !== null && typeof p.render == "function" && p.$$typeof === void 0) {
      var w = Ze(n) || "Unknown";
      hs[w] || (c("The <%s /> component appears to be a function component that returns a class instance. Change %s to a class that extends React.Component instead. If you can't use a class try assigning the prototype on the function as a workaround. `%s.prototype = React.Component.prototype`. Don't use an arrow function since it cannot be called with `new` by React.", w, w, w), hs[w] = !0);
    }
    if (
      // Run these checks in production only if the flag is off.
      // Eventually we'll delete this branch altogether.
      typeof p == "object" && p !== null && typeof p.render == "function" && p.$$typeof === void 0
    ) {
      {
        var N = Ze(n) || "Unknown";
        hs[N] || (c("The <%s /> component appears to be a function component that returns a class instance. Change %s to a class that extends React.Component instead. If you can't use a class try assigning the prototype on the function as a workaround. `%s.prototype = React.Component.prototype`. Don't use an arrow function since it cannot be called with `new` by React.", N, N, N), hs[N] = !0);
      }
      t.tag = S, t.memoizedState = null, t.updateQueue = null;
      var A = !1;
      return la(n) ? (A = !0, af(t)) : A = !1, t.memoizedState = p.state !== null && p.state !== void 0 ? p.state : null, sh(t), DC(t, p), em(t, n, i, r), cm(null, t, n, !0, A, r);
    } else {
      if (t.tag = b, t.mode & Mt) {
        sn(!0);
        try {
          p = Sl(null, t, n, i, l, r), m = Cl();
        } finally {
          sn(!1);
        }
      }
      return hn() && m && Bv(t), Hn(null, t, p, r), fm(t, n), t.child;
    }
  }
  function fm(e, t) {
    {
      if (t && t.childContextTypes && c("%s(...): childContextTypes cannot be defined on a function component.", t.displayName || t.name || "Component"), e.ref !== null) {
        var n = "", r = ai();
        r && (n += `

Check the render method of \`` + r + "`.");
        var i = r || "", l = e._debugSource;
        l && (i = l.fileName + ":" + l.lineNumber), lm[i] || (lm[i] = !0, c("Function components cannot be given refs. Attempts to access this ref will fail. Did you mean to use React.forwardRef()?%s", n));
      }
      if (t.defaultProps !== void 0) {
        var f = Ze(t) || "Unknown";
        ms[f] || (c("%s: Support for defaultProps will be removed from function components in a future major release. Use JavaScript default parameters instead.", f), ms[f] = !0);
      }
      if (typeof t.getDerivedStateFromProps == "function") {
        var p = Ze(t) || "Unknown";
        om[p] || (c("%s: Function components do not support getDerivedStateFromProps.", p), om[p] = !0);
      }
      if (typeof t.contextType == "object" && t.contextType !== null) {
        var m = Ze(t) || "Unknown";
        im[m] || (c("%s: Function components do not support contextType.", m), im[m] = !0);
      }
    }
  }
  var dm = {
    dehydrated: null,
    treeContext: null,
    retryLane: cn
  };
  function pm(e) {
    return {
      baseLanes: e,
      cachePool: nA(),
      transitions: null
    };
  }
  function pA(e, t) {
    var n = null;
    return {
      baseLanes: Ue(e.baseLanes, t),
      cachePool: n,
      transitions: e.transitions
    };
  }
  function vA(e, t, n, r) {
    if (t !== null) {
      var i = t.memoizedState;
      if (i === null)
        return !1;
    }
    return vh(e, is);
  }
  function hA(e, t) {
    return Dc(e.childLanes, t);
  }
  function IC(e, t, n) {
    var r = t.pendingProps;
    wL(t) && (t.flags |= nt);
    var i = $r.current, l = !1, f = (t.flags & nt) !== Te;
    if (f || vA(i, e) ? (l = !0, t.flags &= ~nt) : (e === null || e.memoizedState !== null) && (i = LO(i, KS)), i = ml(i), Ei(t, i), e === null) {
      Xv(t);
      var p = t.memoizedState;
      if (p !== null) {
        var m = p.dehydrated;
        if (m !== null)
          return SA(t, m);
      }
      var C = r.children, w = r.fallback;
      if (l) {
        var N = mA(t, C, w, n), A = t.child;
        return A.memoizedState = pm(n), t.memoizedState = dm, N;
      } else
        return vm(t, C);
    } else {
      var j = e.memoizedState;
      if (j !== null) {
        var H = j.dehydrated;
        if (H !== null)
          return CA(e, t, f, r, H, j, n);
      }
      if (l) {
        var B = r.fallback, ae = r.children, Ce = gA(e, t, ae, B, n), ye = t.child, Ge = e.child.memoizedState;
        return ye.memoizedState = Ge === null ? pm(n) : pA(Ge, n), ye.childLanes = hA(e, n), t.memoizedState = dm, Ce;
      } else {
        var $e = r.children, k = yA(e, t, $e, n);
        return t.memoizedState = null, k;
      }
    }
  }
  function vm(e, t, n) {
    var r = e.mode, i = {
      mode: "visible",
      children: t
    }, l = hm(i, r);
    return l.return = e, e.child = l, l;
  }
  function mA(e, t, n, r) {
    var i = e.mode, l = e.child, f = {
      mode: "hidden",
      children: t
    }, p, m;
    return (i & Ye) === Re && l !== null ? (p = l, p.childLanes = K, p.pendingProps = f, e.mode & ut && (p.actualDuration = 0, p.actualStartTime = -1, p.selfBaseDuration = 0, p.treeBaseDuration = 0), m = Oi(n, i, r, null)) : (p = hm(f, i), m = Oi(n, i, r, null)), p.return = e, m.return = e, p.sibling = m, e.child = p, m;
  }
  function hm(e, t, n) {
    return BE(e, t, K, null);
  }
  function BC(e, t) {
    return Eo(e, t);
  }
  function yA(e, t, n, r) {
    var i = e.child, l = i.sibling, f = BC(i, {
      mode: "visible",
      children: n
    });
    if ((t.mode & Ye) === Re && (f.lanes = r), f.return = t, f.sibling = null, l !== null) {
      var p = t.deletions;
      p === null ? (t.deletions = [l], t.flags |= Xi) : p.push(l);
    }
    return t.child = f, f;
  }
  function gA(e, t, n, r, i) {
    var l = t.mode, f = e.child, p = f.sibling, m = {
      mode: "hidden",
      children: n
    }, C;
    if (
      // In legacy mode, we commit the primary tree as if it successfully
      // completed, even though it's in an inconsistent state.
      (l & Ye) === Re && // Make sure we're on the second pass, i.e. the primary child fragment was
      // already cloned. In legacy mode, the only case where this isn't true is
      // when DevTools forces us to display a fallback; we skip the first render
      // pass entirely and go straight to rendering the fallback. (In Concurrent
      // Mode, SuspenseList can also trigger this scenario, but this is a legacy-
      // only codepath.)
      t.child !== f
    ) {
      var w = t.child;
      C = w, C.childLanes = K, C.pendingProps = m, t.mode & ut && (C.actualDuration = 0, C.actualStartTime = -1, C.selfBaseDuration = f.selfBaseDuration, C.treeBaseDuration = f.treeBaseDuration), t.deletions = null;
    } else
      C = BC(f, m), C.subtreeFlags = f.subtreeFlags & ka;
    var N;
    return p !== null ? N = Eo(p, r) : (N = Oi(r, l, i, null), N.flags |= It), N.return = t, C.return = t, C.sibling = N, t.child = C, N;
  }
  function Xf(e, t, n, r) {
    r !== null && Kv(r), dl(t, e.child, null, n);
    var i = t.pendingProps, l = i.children, f = vm(t, l);
    return f.flags |= It, t.memoizedState = null, f;
  }
  function bA(e, t, n, r, i) {
    var l = t.mode, f = {
      mode: "visible",
      children: n
    }, p = hm(f, l), m = Oi(r, l, i, null);
    return m.flags |= It, p.return = t, m.return = t, p.sibling = m, t.child = p, (t.mode & Ye) !== Re && dl(t, e.child, null, i), m;
  }
  function SA(e, t, n) {
    return (e.mode & Ye) === Re ? (c("Cannot hydrate Suspense in legacy mode. Switch from ReactDOM.hydrate(element, container) to ReactDOMClient.hydrateRoot(container, <App />).render(element) or remove the Suspense components from the server rendered components."), e.lanes = Ne) : Lv(t) ? e.lanes = eo : e.lanes = ir, null;
  }
  function CA(e, t, n, r, i, l, f) {
    if (n)
      if (t.flags & Aa) {
        t.flags &= ~Aa;
        var k = tm(new Error("There was an error while hydrating this Suspense boundary. Switched to client rendering."));
        return Xf(e, t, f, k);
      } else {
        if (t.memoizedState !== null)
          return t.child = e.child, t.flags |= nt, null;
        var V = r.children, P = r.fallback, Q = bA(e, t, V, P, f), ue = t.child;
        return ue.memoizedState = pm(f), t.memoizedState = dm, Q;
      }
    else {
      if (uO(), (t.mode & Ye) === Re)
        return Xf(
          e,
          t,
          f,
          // TODO: When we delete legacy mode, we should make this error argument
          // required — every concurrent mode path that causes hydration to
          // de-opt to client rendering should have an error message.
          null
        );
      if (Lv(i)) {
        var p, m, C;
        {
          var w = xM(i);
          p = w.digest, m = w.message, C = w.stack;
        }
        var N;
        m ? N = new Error(m) : N = new Error("The server could not finish this Suspense boundary, likely due to an error during server rendering. Switched to client rendering.");
        var A = tm(N, p, C);
        return Xf(e, t, f, A);
      }
      var j = or(f, e.childLanes);
      if (Vr || j) {
        var H = id();
        if (H !== null) {
          var B = A1(H, f);
          if (B !== cn && B !== l.retryLane) {
            l.retryLane = B;
            var ae = bt;
            Qn(e, B), rn(H, e, B, ae);
          }
        }
        Um();
        var Ce = tm(new Error("This Suspense boundary received an update before it finished hydrating. This caused the boundary to switch to client rendering. The usual way to fix this is to wrap the original update in startTransition."));
        return Xf(e, t, f, Ce);
      } else if (dS(i)) {
        t.flags |= nt, t.child = e.child;
        var ye = WN.bind(null, e);
        return TM(i, ye), null;
      } else {
        fO(t, i, l.treeContext);
        var Ge = r.children, $e = vm(t, Ge);
        return $e.flags |= Na, $e;
      }
    }
  }
  function VC(e, t, n) {
    e.lanes = Ue(e.lanes, t);
    var r = e.alternate;
    r !== null && (r.lanes = Ue(r.lanes, t)), ih(e.return, t, n);
  }
  function EA(e, t, n) {
    for (var r = t; r !== null; ) {
      if (r.tag === W) {
        var i = r.memoizedState;
        i !== null && VC(r, n, e);
      } else if (r.tag === Ee)
        VC(r, n, e);
      else if (r.child !== null) {
        r.child.return = r, r = r.child;
        continue;
      }
      if (r === e)
        return;
      for (; r.sibling === null; ) {
        if (r.return === null || r.return === e)
          return;
        r = r.return;
      }
      r.sibling.return = r.return, r = r.sibling;
    }
  }
  function RA(e) {
    for (var t = e, n = null; t !== null; ) {
      var r = t.alternate;
      r !== null && Tf(r) === null && (n = t), t = t.sibling;
    }
    return n;
  }
  function wA(e) {
    if (e !== void 0 && e !== "forwards" && e !== "backwards" && e !== "together" && !um[e])
      if (um[e] = !0, typeof e == "string")
        switch (e.toLowerCase()) {
          case "together":
          case "forwards":
          case "backwards": {
            c('"%s" is not a valid value for revealOrder on <SuspenseList />. Use lowercase "%s" instead.', e, e.toLowerCase());
            break;
          }
          case "forward":
          case "backward": {
            c('"%s" is not a valid value for revealOrder on <SuspenseList />. React uses the -s suffix in the spelling. Use "%ss" instead.', e, e.toLowerCase());
            break;
          }
          default:
            c('"%s" is not a supported revealOrder on <SuspenseList />. Did you mean "together", "forwards" or "backwards"?', e);
            break;
        }
      else
        c('%s is not a supported value for revealOrder on <SuspenseList />. Did you mean "together", "forwards" or "backwards"?', e);
  }
  function xA(e, t) {
    e !== void 0 && !Gf[e] && (e !== "collapsed" && e !== "hidden" ? (Gf[e] = !0, c('"%s" is not a supported value for tail on <SuspenseList />. Did you mean "collapsed" or "hidden"?', e)) : t !== "forwards" && t !== "backwards" && (Gf[e] = !0, c('<SuspenseList tail="%s" /> is only valid if revealOrder is "forwards" or "backwards". Did you mean to specify revealOrder="forwards"?', e)));
  }
  function YC(e, t) {
    {
      var n = tt(e), r = !n && typeof rr(e) == "function";
      if (n || r) {
        var i = n ? "array" : "iterable";
        return c("A nested %s was passed to row #%s in <SuspenseList />. Wrap it in an additional SuspenseList to configure its revealOrder: <SuspenseList revealOrder=...> ... <SuspenseList revealOrder=...>{%s}</SuspenseList> ... </SuspenseList>", i, t, i), !1;
      }
    }
    return !0;
  }
  function TA(e, t) {
    if ((t === "forwards" || t === "backwards") && e !== void 0 && e !== null && e !== !1)
      if (tt(e)) {
        for (var n = 0; n < e.length; n++)
          if (!YC(e[n], n))
            return;
      } else {
        var r = rr(e);
        if (typeof r == "function") {
          var i = r.call(e);
          if (i)
            for (var l = i.next(), f = 0; !l.done; l = i.next()) {
              if (!YC(l.value, f))
                return;
              f++;
            }
        } else
          c('A single row was passed to a <SuspenseList revealOrder="%s" />. This is not useful since it needs multiple rows. Did you mean to pass multiple children or an array?', t);
      }
  }
  function mm(e, t, n, r, i) {
    var l = e.memoizedState;
    l === null ? e.memoizedState = {
      isBackwards: t,
      rendering: null,
      renderingStartTime: 0,
      last: r,
      tail: n,
      tailMode: i
    } : (l.isBackwards = t, l.rendering = null, l.renderingStartTime = 0, l.last = r, l.tail = n, l.tailMode = i);
  }
  function WC(e, t, n) {
    var r = t.pendingProps, i = r.revealOrder, l = r.tail, f = r.children;
    wA(i), xA(l, i), TA(f, i), Hn(e, t, f, n);
    var p = $r.current, m = vh(p, is);
    if (m)
      p = hh(p, is), t.flags |= nt;
    else {
      var C = e !== null && (e.flags & nt) !== Te;
      C && EA(t, t.child, n), p = ml(p);
    }
    if (Ei(t, p), (t.mode & Ye) === Re)
      t.memoizedState = null;
    else
      switch (i) {
        case "forwards": {
          var w = RA(t.child), N;
          w === null ? (N = t.child, t.child = null) : (N = w.sibling, w.sibling = null), mm(
            t,
            !1,
            // isBackwards
            N,
            w,
            l
          );
          break;
        }
        case "backwards": {
          var A = null, j = t.child;
          for (t.child = null; j !== null; ) {
            var H = j.alternate;
            if (H !== null && Tf(H) === null) {
              t.child = j;
              break;
            }
            var B = j.sibling;
            j.sibling = A, A = j, j = B;
          }
          mm(
            t,
            !0,
            // isBackwards
            A,
            null,
            // last
            l
          );
          break;
        }
        case "together": {
          mm(
            t,
            !1,
            // isBackwards
            null,
            // tail
            null,
            // last
            void 0
          );
          break;
        }
        default:
          t.memoizedState = null;
      }
    return t.child;
  }
  function DA(e, t, n) {
    fh(t, t.stateNode.containerInfo);
    var r = t.pendingProps;
    return e === null ? t.child = dl(t, null, r, n) : Hn(e, t, r, n), t.child;
  }
  var GC = !1;
  function _A(e, t, n) {
    var r = t.type, i = r._context, l = t.pendingProps, f = t.memoizedProps, p = l.value;
    {
      "value" in l || GC || (GC = !0, c("The `value` prop is required for the `<Context.Provider>`. Did you misspell it or forget to pass it?"));
      var m = t.type.propTypes;
      m && Fr(m, l, "prop", "Context.Provider");
    }
    if (zS(t, i, p), f !== null) {
      var C = f.value;
      if (sr(C, p)) {
        if (f.children === l.children && !nf())
          return Va(e, t, n);
      } else
        wO(t, i, n);
    }
    var w = l.children;
    return Hn(e, t, w, n), t.child;
  }
  var XC = !1;
  function MA(e, t, n) {
    var r = t.type;
    r._context === void 0 ? r !== r.Consumer && (XC || (XC = !0, c("Rendering <Context> directly is not supported and will be removed in a future major release. Did you mean to render <Context.Consumer> instead?"))) : r = r._context;
    var i = t.pendingProps, l = i.children;
    typeof l != "function" && c("A context consumer was rendered with multiple children, or a child that isn't a function. A context consumer expects a single child that is a function. If you did pass a function, make sure there is no trailing or leading whitespace around it."), vl(t, n);
    var f = Bt(r);
    vu(t);
    var p;
    return vs.current = t, ar(!0), p = l(f), ar(!1), Go(), t.flags |= Vo, Hn(e, t, p, n), t.child;
  }
  function ys() {
    Vr = !0;
  }
  function Kf(e, t) {
    (t.mode & Ye) === Re && e !== null && (e.alternate = null, t.alternate = null, t.flags |= It);
  }
  function Va(e, t, n) {
    return e !== null && (t.dependencies = e.dependencies), RC(), Ms(t.lanes), or(n, t.childLanes) ? (EO(e, t), t.child) : null;
  }
  function OA(e, t, n) {
    {
      var r = t.return;
      if (r === null)
        throw new Error("Cannot swap the root fiber.");
      if (e.alternate = null, t.alternate = null, n.index = t.index, n.sibling = t.sibling, n.return = t.return, n.ref = t.ref, t === r.child)
        r.child = n;
      else {
        var i = r.child;
        if (i === null)
          throw new Error("Expected parent to have a child.");
        for (; i.sibling !== t; )
          if (i = i.sibling, i === null)
            throw new Error("Expected to find the previous sibling.");
        i.sibling = n;
      }
      var l = r.deletions;
      return l === null ? (r.deletions = [e], r.flags |= Xi) : l.push(e), n.flags |= It, n;
    }
  }
  function ym(e, t) {
    var n = e.lanes;
    return !!or(n, t);
  }
  function AA(e, t, n) {
    switch (t.tag) {
      case E:
        HC(t), t.stateNode, fl();
        break;
      case T:
        GS(t);
        break;
      case S: {
        var r = t.type;
        la(r) && af(t);
        break;
      }
      case x:
        fh(t, t.stateNode.containerInfo);
        break;
      case F: {
        var i = t.memoizedProps.value, l = t.type._context;
        zS(t, l, i);
        break;
      }
      case X:
        {
          var f = or(n, t.childLanes);
          f && (t.flags |= qe);
          {
            var p = t.stateNode;
            p.effectDuration = 0, p.passiveEffectDuration = 0;
          }
        }
        break;
      case W: {
        var m = t.memoizedState;
        if (m !== null) {
          if (m.dehydrated !== null)
            return Ei(t, ml($r.current)), t.flags |= nt, null;
          var C = t.child, w = C.childLanes;
          if (or(n, w))
            return IC(e, t, n);
          Ei(t, ml($r.current));
          var N = Va(e, t, n);
          return N !== null ? N.sibling : null;
        } else
          Ei(t, ml($r.current));
        break;
      }
      case Ee: {
        var A = (e.flags & nt) !== Te, j = or(n, t.childLanes);
        if (A) {
          if (j)
            return WC(e, t, n);
          t.flags |= nt;
        }
        var H = t.memoizedState;
        if (H !== null && (H.rendering = null, H.tail = null, H.lastEffect = null), Ei(t, $r.current), j)
          break;
        return null;
      }
      case fe:
      case ge:
        return t.lanes = K, jC(e, t, n);
    }
    return Va(e, t, n);
  }
  function KC(e, t, n) {
    if (t._debugNeedsRemount && e !== null)
      return OA(e, t, Gm(t.type, t.key, t.pendingProps, t._debugOwner || null, t.mode, t.lanes));
    if (e !== null) {
      var r = e.memoizedProps, i = t.pendingProps;
      if (r !== i || nf() || // Force a re-render if the implementation changed due to hot reload:
      t.type !== e.type)
        Vr = !0;
      else {
        var l = ym(e, n);
        if (!l && // If this is the second pass of an error or suspense boundary, there
        // may not be work scheduled on `current`, so we check for this flag.
        (t.flags & nt) === Te)
          return Vr = !1, AA(e, t, n);
        (e.flags & Rp) !== Te ? Vr = !0 : Vr = !1;
      }
    } else if (Vr = !1, hn() && nO(t)) {
      var f = t.index, p = rO();
      RS(t, p, f);
    }
    switch (t.lanes = K, t.tag) {
      case R:
        return dA(e, t, t.type, n);
      case ve: {
        var m = t.elementType;
        return cA(e, t, m, n);
      }
      case b: {
        var C = t.type, w = t.pendingProps, N = t.elementType === C ? w : Br(C, w);
        return sm(e, t, C, N, n);
      }
      case S: {
        var A = t.type, j = t.pendingProps, H = t.elementType === A ? j : Br(A, j);
        return zC(e, t, A, H, n);
      }
      case E:
        return lA(e, t, n);
      case T:
        return uA(e, t, n);
      case M:
        return sA(e, t);
      case W:
        return IC(e, t, n);
      case x:
        return DA(e, t, n);
      case Y: {
        var B = t.type, ae = t.pendingProps, Ce = t.elementType === B ? ae : Br(B, ae);
        return kC(e, t, B, Ce, n);
      }
      case L:
        return aA(e, t, n);
      case $:
        return iA(e, t, n);
      case X:
        return oA(e, t, n);
      case F:
        return _A(e, t, n);
      case U:
        return MA(e, t, n);
      case ne: {
        var ye = t.type, Ge = t.pendingProps, $e = Br(ye, Ge);
        if (t.type !== t.elementType) {
          var k = ye.propTypes;
          k && Fr(
            k,
            $e,
            // Resolved for outer only
            "prop",
            Ze(ye)
          );
        }
        return $e = Br(ye.type, $e), PC(e, t, ye, $e, n);
      }
      case Z:
        return UC(e, t, t.type, t.pendingProps, n);
      case me: {
        var V = t.type, P = t.pendingProps, Q = t.elementType === V ? P : Br(V, P);
        return fA(e, t, V, Q, n);
      }
      case Ee:
        return WC(e, t, n);
      case Xe:
        break;
      case fe:
        return jC(e, t, n);
    }
    throw new Error("Unknown unit of work tag (" + t.tag + "). This error is likely caused by a bug in React. Please file an issue.");
  }
  function El(e) {
    e.flags |= qe;
  }
  function qC(e) {
    e.flags |= ui, e.flags |= wp;
  }
  var QC, gm, ZC, JC;
  QC = function(e, t, n, r) {
    for (var i = t.child; i !== null; ) {
      if (i.tag === T || i.tag === M)
        J_(e, i.stateNode);
      else if (i.tag !== x) {
        if (i.child !== null) {
          i.child.return = i, i = i.child;
          continue;
        }
      }
      if (i === t)
        return;
      for (; i.sibling === null; ) {
        if (i.return === null || i.return === t)
          return;
        i = i.return;
      }
      i.sibling.return = i.return, i = i.sibling;
    }
  }, gm = function(e, t) {
  }, ZC = function(e, t, n, r, i) {
    var l = e.memoizedProps;
    if (l !== r) {
      var f = t.stateNode, p = dh(), m = tM(f, n, l, r, i, p);
      t.updateQueue = m, m && El(t);
    }
  }, JC = function(e, t, n, r) {
    n !== r && El(t);
  };
  function gs(e, t) {
    if (!hn())
      switch (e.tailMode) {
        case "hidden": {
          for (var n = e.tail, r = null; n !== null; )
            n.alternate !== null && (r = n), n = n.sibling;
          r === null ? e.tail = null : r.sibling = null;
          break;
        }
        case "collapsed": {
          for (var i = e.tail, l = null; i !== null; )
            i.alternate !== null && (l = i), i = i.sibling;
          l === null ? !t && e.tail !== null ? e.tail.sibling = null : e.tail = null : l.sibling = null;
          break;
        }
      }
  }
  function yn(e) {
    var t = e.alternate !== null && e.alternate.child === e.child, n = K, r = Te;
    if (t) {
      if ((e.mode & ut) !== Re) {
        for (var m = e.selfBaseDuration, C = e.child; C !== null; )
          n = Ue(n, Ue(C.lanes, C.childLanes)), r |= C.subtreeFlags & ka, r |= C.flags & ka, m += C.treeBaseDuration, C = C.sibling;
        e.treeBaseDuration = m;
      } else
        for (var w = e.child; w !== null; )
          n = Ue(n, Ue(w.lanes, w.childLanes)), r |= w.subtreeFlags & ka, r |= w.flags & ka, w.return = e, w = w.sibling;
      e.subtreeFlags |= r;
    } else {
      if ((e.mode & ut) !== Re) {
        for (var i = e.actualDuration, l = e.selfBaseDuration, f = e.child; f !== null; )
          n = Ue(n, Ue(f.lanes, f.childLanes)), r |= f.subtreeFlags, r |= f.flags, i += f.actualDuration, l += f.treeBaseDuration, f = f.sibling;
        e.actualDuration = i, e.treeBaseDuration = l;
      } else
        for (var p = e.child; p !== null; )
          n = Ue(n, Ue(p.lanes, p.childLanes)), r |= p.subtreeFlags, r |= p.flags, p.return = e, p = p.sibling;
      e.subtreeFlags |= r;
    }
    return e.childLanes = n, t;
  }
  function NA(e, t, n) {
    if (mO() && (t.mode & Ye) !== Re && (t.flags & nt) === Te)
      return OS(t), fl(), t.flags |= Aa | du | zn, !1;
    var r = cf(t);
    if (n !== null && n.dehydrated !== null)
      if (e === null) {
        if (!r)
          throw new Error("A dehydrated suspense component was completed without a hydrated node. This is probably a bug in React.");
        if (vO(t), yn(t), (t.mode & ut) !== Re) {
          var i = n !== null;
          if (i) {
            var l = t.child;
            l !== null && (t.treeBaseDuration -= l.treeBaseDuration);
          }
        }
        return !1;
      } else {
        if (fl(), (t.flags & nt) === Te && (t.memoizedState = null), t.flags |= qe, yn(t), (t.mode & ut) !== Re) {
          var f = n !== null;
          if (f) {
            var p = t.child;
            p !== null && (t.treeBaseDuration -= p.treeBaseDuration);
          }
        }
        return !1;
      }
    else
      return AS(), !0;
  }
  function eE(e, t, n) {
    var r = t.pendingProps;
    switch (Vv(t), t.tag) {
      case R:
      case ve:
      case Z:
      case b:
      case Y:
      case L:
      case $:
      case X:
      case U:
      case ne:
        return yn(t), null;
      case S: {
        var i = t.type;
        return la(i) && rf(t), yn(t), null;
      }
      case E: {
        var l = t.stateNode;
        if (hl(t), Hv(t), yh(), l.pendingContext && (l.context = l.pendingContext, l.pendingContext = null), e === null || e.child === null) {
          var f = cf(t);
          if (f)
            El(t);
          else if (e !== null) {
            var p = e.memoizedState;
            // Check if this is a client root
            (!p.isDehydrated || // Check if we reverted to client rendering (e.g. due to an error)
            (t.flags & Aa) !== Te) && (t.flags |= Ki, AS());
          }
        }
        return gm(e, t), yn(t), null;
      }
      case T: {
        ph(t);
        var m = WS(), C = t.type;
        if (e !== null && t.stateNode != null)
          ZC(e, t, C, r, m), e.ref !== t.ref && qC(t);
        else {
          if (!r) {
            if (t.stateNode === null)
              throw new Error("We must have new props for new mounts. This error is likely caused by a bug in React. Please file an issue.");
            return yn(t), null;
          }
          var w = dh(), N = cf(t);
          if (N)
            dO(t, m, w) && El(t);
          else {
            var A = Z_(C, r, m, w, t);
            QC(A, t, !1, !1), t.stateNode = A, eM(A, C, r, m) && El(t);
          }
          t.ref !== null && qC(t);
        }
        return yn(t), null;
      }
      case M: {
        var j = r;
        if (e && t.stateNode != null) {
          var H = e.memoizedProps;
          JC(e, t, H, j);
        } else {
          if (typeof j != "string" && t.stateNode === null)
            throw new Error("We must have new props for new mounts. This error is likely caused by a bug in React. Please file an issue.");
          var B = WS(), ae = dh(), Ce = cf(t);
          Ce ? pO(t) && El(t) : t.stateNode = nM(j, B, ae, t);
        }
        return yn(t), null;
      }
      case W: {
        yl(t);
        var ye = t.memoizedState;
        if (e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
          var Ge = NA(e, t, ye);
          if (!Ge)
            return t.flags & zn ? t : null;
        }
        if ((t.flags & nt) !== Te)
          return t.lanes = n, (t.mode & ut) !== Re && Ih(t), t;
        var $e = ye !== null, k = e !== null && e.memoizedState !== null;
        if ($e !== k && $e) {
          var V = t.child;
          if (V.flags |= qi, (t.mode & Ye) !== Re) {
            var P = e === null && (t.memoizedProps.unstable_avoidThisFallback !== !0 || !dt);
            P || vh($r.current, KS) ? LN() : Um();
          }
        }
        var Q = t.updateQueue;
        if (Q !== null && (t.flags |= qe), yn(t), (t.mode & ut) !== Re && $e) {
          var ue = t.child;
          ue !== null && (t.treeBaseDuration -= ue.treeBaseDuration);
        }
        return null;
      }
      case x:
        return hl(t), gm(e, t), e === null && KM(t.stateNode.containerInfo), yn(t), null;
      case F:
        var ie = t.type._context;
        return ah(ie, t), yn(t), null;
      case me: {
        var Me = t.type;
        return la(Me) && rf(t), yn(t), null;
      }
      case Ee: {
        yl(t);
        var ke = t.memoizedState;
        if (ke === null)
          return yn(t), null;
        var ct = (t.flags & nt) !== Te, Je = ke.rendering;
        if (Je === null)
          if (ct)
            gs(ke, !1);
          else {
            var jt = PN() && (e === null || (e.flags & nt) === Te);
            if (!jt)
              for (var et = t.child; et !== null; ) {
                var Ot = Tf(et);
                if (Ot !== null) {
                  ct = !0, t.flags |= nt, gs(ke, !1);
                  var Ln = Ot.updateQueue;
                  return Ln !== null && (t.updateQueue = Ln, t.flags |= qe), t.subtreeFlags = Te, RO(t, n), Ei(t, hh($r.current, is)), t.child;
                }
                et = et.sibling;
              }
            ke.tail !== null && un() > CE() && (t.flags |= nt, ct = !0, gs(ke, !1), t.lanes = Jg);
          }
        else {
          if (!ct) {
            var En = Tf(Je);
            if (En !== null) {
              t.flags |= nt, ct = !0;
              var dr = En.updateQueue;
              if (dr !== null && (t.updateQueue = dr, t.flags |= qe), gs(ke, !0), ke.tail === null && ke.tailMode === "hidden" && !Je.alternate && !hn())
                return yn(t), null;
            } else
              // The time it took to render last row is greater than the remaining
              // time we have to render. So rendering one more row would likely
              // exceed it.
              un() * 2 - ke.renderingStartTime > CE() && n !== ir && (t.flags |= nt, ct = !0, gs(ke, !1), t.lanes = Jg);
          }
          if (ke.isBackwards)
            Je.sibling = t.child, t.child = Je;
          else {
            var Bn = ke.last;
            Bn !== null ? Bn.sibling = Je : t.child = Je, ke.last = Je;
          }
        }
        if (ke.tail !== null) {
          var Vn = ke.tail;
          ke.rendering = Vn, ke.tail = Vn.sibling, ke.renderingStartTime = un(), Vn.sibling = null;
          var kn = $r.current;
          return ct ? kn = hh(kn, is) : kn = ml(kn), Ei(t, kn), Vn;
        }
        return yn(t), null;
      }
      case Xe:
        break;
      case fe:
      case ge: {
        Pm(t);
        var Ka = t.memoizedState, Ol = Ka !== null;
        if (e !== null) {
          var ks = e.memoizedState, ha = ks !== null;
          ha !== Ol && // LegacyHidden doesn't do any hiding — it only pre-renders.
          !Ke && (t.flags |= qi);
        }
        return !Ol || (t.mode & Ye) === Re ? yn(t) : or(va, ir) && (yn(t), t.subtreeFlags & (It | qe) && (t.flags |= qi)), null;
      }
      case Ie:
        return null;
      case De:
        return null;
    }
    throw new Error("Unknown unit of work tag (" + t.tag + "). This error is likely caused by a bug in React. Please file an issue.");
  }
  function LA(e, t, n) {
    switch (Vv(t), t.tag) {
      case S: {
        var r = t.type;
        la(r) && rf(t);
        var i = t.flags;
        return i & zn ? (t.flags = i & ~zn | nt, (t.mode & ut) !== Re && Ih(t), t) : null;
      }
      case E: {
        t.stateNode, hl(t), Hv(t), yh();
        var l = t.flags;
        return (l & zn) !== Te && (l & nt) === Te ? (t.flags = l & ~zn | nt, t) : null;
      }
      case T:
        return ph(t), null;
      case W: {
        yl(t);
        var f = t.memoizedState;
        if (f !== null && f.dehydrated !== null) {
          if (t.alternate === null)
            throw new Error("Threw in newly mounted dehydrated component. This is likely a bug in React. Please file an issue.");
          fl();
        }
        var p = t.flags;
        return p & zn ? (t.flags = p & ~zn | nt, (t.mode & ut) !== Re && Ih(t), t) : null;
      }
      case Ee:
        return yl(t), null;
      case x:
        return hl(t), null;
      case F:
        var m = t.type._context;
        return ah(m, t), null;
      case fe:
      case ge:
        return Pm(t), null;
      case Ie:
        return null;
      default:
        return null;
    }
  }
  function tE(e, t, n) {
    switch (Vv(t), t.tag) {
      case S: {
        var r = t.type.childContextTypes;
        r != null && rf(t);
        break;
      }
      case E: {
        t.stateNode, hl(t), Hv(t), yh();
        break;
      }
      case T: {
        ph(t);
        break;
      }
      case x:
        hl(t);
        break;
      case W:
        yl(t);
        break;
      case Ee:
        yl(t);
        break;
      case F:
        var i = t.type._context;
        ah(i, t);
        break;
      case fe:
      case ge:
        Pm(t);
        break;
    }
  }
  var nE = null;
  nE = /* @__PURE__ */ new Set();
  var qf = !1, gn = !1, kA = typeof WeakSet == "function" ? WeakSet : Set, ce = null, Rl = null, wl = null;
  function PA(e) {
    Sp(null, function() {
      throw e;
    }), Cp();
  }
  var UA = function(e, t) {
    if (t.props = e.memoizedProps, t.state = e.memoizedState, e.mode & ut)
      try {
        da(), t.componentWillUnmount();
      } finally {
        fa(e);
      }
    else
      t.componentWillUnmount();
  };
  function rE(e, t) {
    try {
      xi(Qt, e);
    } catch (n) {
      mt(e, t, n);
    }
  }
  function bm(e, t, n) {
    try {
      UA(e, n);
    } catch (r) {
      mt(e, t, r);
    }
  }
  function jA(e, t, n) {
    try {
      n.componentDidMount();
    } catch (r) {
      mt(e, t, r);
    }
  }
  function aE(e, t) {
    try {
      oE(e);
    } catch (n) {
      mt(e, t, n);
    }
  }
  function xl(e, t) {
    var n = e.ref;
    if (n !== null)
      if (typeof n == "function") {
        var r;
        try {
          if (Wt && Nt && e.mode & ut)
            try {
              da(), r = n(null);
            } finally {
              fa(e);
            }
          else
            r = n(null);
        } catch (i) {
          mt(e, t, i);
        }
        typeof r == "function" && c("Unexpected return value from a callback ref in %s. A callback ref should not return a function.", Pe(e));
      } else
        n.current = null;
  }
  function Qf(e, t, n) {
    try {
      n();
    } catch (r) {
      mt(e, t, r);
    }
  }
  var iE = !1;
  function FA(e, t) {
    q_(e.containerInfo), ce = t, zA();
    var n = iE;
    return iE = !1, n;
  }
  function zA() {
    for (; ce !== null; ) {
      var e = ce, t = e.child;
      (e.subtreeFlags & Tp) !== Te && t !== null ? (t.return = e, ce = t) : HA();
    }
  }
  function HA() {
    for (; ce !== null; ) {
      var e = ce;
      Tt(e);
      try {
        $A(e);
      } catch (n) {
        mt(e, e.return, n);
      }
      ln();
      var t = e.sibling;
      if (t !== null) {
        t.return = e.return, ce = t;
        return;
      }
      ce = e.return;
    }
  }
  function $A(e) {
    var t = e.alternate, n = e.flags;
    if ((n & Ki) !== Te) {
      switch (Tt(e), e.tag) {
        case b:
        case Y:
        case Z:
          break;
        case S: {
          if (t !== null) {
            var r = t.memoizedProps, i = t.memoizedState, l = e.stateNode;
            e.type === e.elementType && !yo && (l.props !== e.memoizedProps && c("Expected %s props to match memoized props before getSnapshotBeforeUpdate. This might either be because of a bug in React, or because a component reassigns its own `this.props`. Please file an issue.", Pe(e) || "instance"), l.state !== e.memoizedState && c("Expected %s state to match memoized state before getSnapshotBeforeUpdate. This might either be because of a bug in React, or because a component reassigns its own `this.state`. Please file an issue.", Pe(e) || "instance"));
            var f = l.getSnapshotBeforeUpdate(e.elementType === e.type ? r : Br(e.type, r), i);
            {
              var p = nE;
              f === void 0 && !p.has(e.type) && (p.add(e.type), c("%s.getSnapshotBeforeUpdate(): A snapshot value (or null) must be returned. You have returned undefined.", Pe(e)));
            }
            l.__reactInternalSnapshotBeforeUpdate = f;
          }
          break;
        }
        case E: {
          {
            var m = e.stateNode;
            CM(m.containerInfo);
          }
          break;
        }
        case T:
        case M:
        case x:
        case me:
          break;
        default:
          throw new Error("This unit of work tag should not have side-effects. This error is likely caused by a bug in React. Please file an issue.");
      }
      ln();
    }
  }
  function Yr(e, t, n) {
    var r = t.updateQueue, i = r !== null ? r.lastEffect : null;
    if (i !== null) {
      var l = i.next, f = l;
      do {
        if ((f.tag & e) === e) {
          var p = f.destroy;
          f.destroy = void 0, p !== void 0 && ((e & mn) !== Zn ? n1(t) : (e & Qt) !== Zn && Xg(t), (e & ua) !== Zn && As(!0), Qf(t, n, p), (e & ua) !== Zn && As(!1), (e & mn) !== Zn ? r1() : (e & Qt) !== Zn && Kg());
        }
        f = f.next;
      } while (f !== l);
    }
  }
  function xi(e, t) {
    var n = t.updateQueue, r = n !== null ? n.lastEffect : null;
    if (r !== null) {
      var i = r.next, l = i;
      do {
        if ((l.tag & e) === e) {
          (e & mn) !== Zn ? e1(t) : (e & Qt) !== Zn && a1(t);
          var f = l.create;
          (e & ua) !== Zn && As(!0), l.destroy = f(), (e & ua) !== Zn && As(!1), (e & mn) !== Zn ? t1() : (e & Qt) !== Zn && i1();
          {
            var p = l.destroy;
            if (p !== void 0 && typeof p != "function") {
              var m = void 0;
              (l.tag & Qt) !== Te ? m = "useLayoutEffect" : (l.tag & ua) !== Te ? m = "useInsertionEffect" : m = "useEffect";
              var C = void 0;
              p === null ? C = " You returned null. If your effect does not require clean up, return undefined (or nothing)." : typeof p.then == "function" ? C = `

It looks like you wrote ` + m + `(async () => ...) or returned a Promise. Instead, write the async function inside your effect and call it immediately:

` + m + `(() => {
  async function fetchData() {
    // You can await here
    const response = await MyAPI.getData(someId);
    // ...
  }
  fetchData();
}, [someId]); // Or [] if effect doesn't need props or state

Learn more about data fetching with Hooks: https://reactjs.org/link/hooks-data-fetching` : C = " You returned: " + p, c("%s must not return anything besides a function, which is used for clean-up.%s", m, C);
            }
          }
        }
        l = l.next;
      } while (l !== i);
    }
  }
  function IA(e, t) {
    if ((t.flags & qe) !== Te)
      switch (t.tag) {
        case X: {
          var n = t.stateNode.passiveEffectDuration, r = t.memoizedProps, i = r.id, l = r.onPostCommit, f = CC(), p = t.alternate === null ? "mount" : "update";
          SC() && (p = "nested-update"), typeof l == "function" && l(i, p, n, f);
          var m = t.return;
          e:
            for (; m !== null; ) {
              switch (m.tag) {
                case E:
                  var C = m.stateNode;
                  C.passiveEffectDuration += n;
                  break e;
                case X:
                  var w = m.stateNode;
                  w.passiveEffectDuration += n;
                  break e;
              }
              m = m.return;
            }
          break;
        }
      }
  }
  function BA(e, t, n, r) {
    if ((n.flags & pu) !== Te)
      switch (n.tag) {
        case b:
        case Y:
        case Z: {
          if (!gn)
            if (n.mode & ut)
              try {
                da(), xi(Qt | qt, n);
              } finally {
                fa(n);
              }
            else
              xi(Qt | qt, n);
          break;
        }
        case S: {
          var i = n.stateNode;
          if (n.flags & qe && !gn)
            if (t === null)
              if (n.type === n.elementType && !yo && (i.props !== n.memoizedProps && c("Expected %s props to match memoized props before componentDidMount. This might either be because of a bug in React, or because a component reassigns its own `this.props`. Please file an issue.", Pe(n) || "instance"), i.state !== n.memoizedState && c("Expected %s state to match memoized state before componentDidMount. This might either be because of a bug in React, or because a component reassigns its own `this.state`. Please file an issue.", Pe(n) || "instance")), n.mode & ut)
                try {
                  da(), i.componentDidMount();
                } finally {
                  fa(n);
                }
              else
                i.componentDidMount();
            else {
              var l = n.elementType === n.type ? t.memoizedProps : Br(n.type, t.memoizedProps), f = t.memoizedState;
              if (n.type === n.elementType && !yo && (i.props !== n.memoizedProps && c("Expected %s props to match memoized props before componentDidUpdate. This might either be because of a bug in React, or because a component reassigns its own `this.props`. Please file an issue.", Pe(n) || "instance"), i.state !== n.memoizedState && c("Expected %s state to match memoized state before componentDidUpdate. This might either be because of a bug in React, or because a component reassigns its own `this.state`. Please file an issue.", Pe(n) || "instance")), n.mode & ut)
                try {
                  da(), i.componentDidUpdate(l, f, i.__reactInternalSnapshotBeforeUpdate);
                } finally {
                  fa(n);
                }
              else
                i.componentDidUpdate(l, f, i.__reactInternalSnapshotBeforeUpdate);
            }
          var p = n.updateQueue;
          p !== null && (n.type === n.elementType && !yo && (i.props !== n.memoizedProps && c("Expected %s props to match memoized props before processing the update queue. This might either be because of a bug in React, or because a component reassigns its own `this.props`. Please file an issue.", Pe(n) || "instance"), i.state !== n.memoizedState && c("Expected %s state to match memoized state before processing the update queue. This might either be because of a bug in React, or because a component reassigns its own `this.state`. Please file an issue.", Pe(n) || "instance")), YS(n, p, i));
          break;
        }
        case E: {
          var m = n.updateQueue;
          if (m !== null) {
            var C = null;
            if (n.child !== null)
              switch (n.child.tag) {
                case T:
                  C = n.child.stateNode;
                  break;
                case S:
                  C = n.child.stateNode;
                  break;
              }
            YS(n, m, C);
          }
          break;
        }
        case T: {
          var w = n.stateNode;
          if (t === null && n.flags & qe) {
            var N = n.type, A = n.memoizedProps;
            lM(w, N, A);
          }
          break;
        }
        case M:
          break;
        case x:
          break;
        case X: {
          {
            var j = n.memoizedProps, H = j.onCommit, B = j.onRender, ae = n.stateNode.effectDuration, Ce = CC(), ye = t === null ? "mount" : "update";
            SC() && (ye = "nested-update"), typeof B == "function" && B(n.memoizedProps.id, ye, n.actualDuration, n.treeBaseDuration, n.actualStartTime, Ce);
            {
              typeof H == "function" && H(n.memoizedProps.id, ye, ae, Ce), HN(n);
              var Ge = n.return;
              e:
                for (; Ge !== null; ) {
                  switch (Ge.tag) {
                    case E:
                      var $e = Ge.stateNode;
                      $e.effectDuration += ae;
                      break e;
                    case X:
                      var k = Ge.stateNode;
                      k.effectDuration += ae;
                      break e;
                  }
                  Ge = Ge.return;
                }
            }
          }
          break;
        }
        case W: {
          QA(e, n);
          break;
        }
        case Ee:
        case me:
        case Xe:
        case fe:
        case ge:
        case De:
          break;
        default:
          throw new Error("This unit of work tag should not have side-effects. This error is likely caused by a bug in React. Please file an issue.");
      }
    gn || n.flags & ui && oE(n);
  }
  function VA(e) {
    switch (e.tag) {
      case b:
      case Y:
      case Z: {
        if (e.mode & ut)
          try {
            da(), rE(e, e.return);
          } finally {
            fa(e);
          }
        else
          rE(e, e.return);
        break;
      }
      case S: {
        var t = e.stateNode;
        typeof t.componentDidMount == "function" && jA(e, e.return, t), aE(e, e.return);
        break;
      }
      case T: {
        aE(e, e.return);
        break;
      }
    }
  }
  function YA(e, t) {
    for (var n = null, r = e; ; ) {
      if (r.tag === T) {
        if (n === null) {
          n = r;
          try {
            var i = r.stateNode;
            t ? yM(i) : bM(r.stateNode, r.memoizedProps);
          } catch (f) {
            mt(e, e.return, f);
          }
        }
      } else if (r.tag === M) {
        if (n === null)
          try {
            var l = r.stateNode;
            t ? gM(l) : SM(l, r.memoizedProps);
          } catch (f) {
            mt(e, e.return, f);
          }
      } else if (!((r.tag === fe || r.tag === ge) && r.memoizedState !== null && r !== e)) {
        if (r.child !== null) {
          r.child.return = r, r = r.child;
          continue;
        }
      }
      if (r === e)
        return;
      for (; r.sibling === null; ) {
        if (r.return === null || r.return === e)
          return;
        n === r && (n = null), r = r.return;
      }
      n === r && (n = null), r.sibling.return = r.return, r = r.sibling;
    }
  }
  function oE(e) {
    var t = e.ref;
    if (t !== null) {
      var n = e.stateNode, r;
      switch (e.tag) {
        case T:
          r = n;
          break;
        default:
          r = n;
      }
      if (typeof t == "function") {
        var i;
        if (e.mode & ut)
          try {
            da(), i = t(r);
          } finally {
            fa(e);
          }
        else
          i = t(r);
        typeof i == "function" && c("Unexpected return value from a callback ref in %s. A callback ref should not return a function.", Pe(e));
      } else
        t.hasOwnProperty("current") || c("Unexpected ref object provided for %s. Use either a ref-setter function or React.createRef().", Pe(e)), t.current = r;
    }
  }
  function WA(e) {
    var t = e.alternate;
    t !== null && (t.return = null), e.return = null;
  }
  function lE(e) {
    var t = e.alternate;
    t !== null && (e.alternate = null, lE(t));
    {
      if (e.child = null, e.deletions = null, e.sibling = null, e.tag === T) {
        var n = e.stateNode;
        n !== null && ZM(n);
      }
      e.stateNode = null, e._debugOwner = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null;
    }
  }
  function GA(e) {
    for (var t = e.return; t !== null; ) {
      if (uE(t))
        return t;
      t = t.return;
    }
    throw new Error("Expected to find a host parent. This error is likely caused by a bug in React. Please file an issue.");
  }
  function uE(e) {
    return e.tag === T || e.tag === E || e.tag === x;
  }
  function sE(e) {
    var t = e;
    e:
      for (; ; ) {
        for (; t.sibling === null; ) {
          if (t.return === null || uE(t.return))
            return null;
          t = t.return;
        }
        for (t.sibling.return = t.return, t = t.sibling; t.tag !== T && t.tag !== M && t.tag !== he; ) {
          if (t.flags & It || t.child === null || t.tag === x)
            continue e;
          t.child.return = t, t = t.child;
        }
        if (!(t.flags & It))
          return t.stateNode;
      }
  }
  function XA(e) {
    var t = GA(e);
    switch (t.tag) {
      case T: {
        var n = t.stateNode;
        t.flags & fu && (fS(n), t.flags &= ~fu);
        var r = sE(e);
        Cm(e, r, n);
        break;
      }
      case E:
      case x: {
        var i = t.stateNode.containerInfo, l = sE(e);
        Sm(e, l, i);
        break;
      }
      default:
        throw new Error("Invalid host parent fiber. This error is likely caused by a bug in React. Please file an issue.");
    }
  }
  function Sm(e, t, n) {
    var r = e.tag, i = r === T || r === M;
    if (i) {
      var l = e.stateNode;
      t ? pM(n, l, t) : fM(n, l);
    } else if (r !== x) {
      var f = e.child;
      if (f !== null) {
        Sm(f, t, n);
        for (var p = f.sibling; p !== null; )
          Sm(p, t, n), p = p.sibling;
      }
    }
  }
  function Cm(e, t, n) {
    var r = e.tag, i = r === T || r === M;
    if (i) {
      var l = e.stateNode;
      t ? dM(n, l, t) : cM(n, l);
    } else if (r !== x) {
      var f = e.child;
      if (f !== null) {
        Cm(f, t, n);
        for (var p = f.sibling; p !== null; )
          Cm(p, t, n), p = p.sibling;
      }
    }
  }
  var bn = null, Wr = !1;
  function KA(e, t, n) {
    {
      var r = t;
      e:
        for (; r !== null; ) {
          switch (r.tag) {
            case T: {
              bn = r.stateNode, Wr = !1;
              break e;
            }
            case E: {
              bn = r.stateNode.containerInfo, Wr = !0;
              break e;
            }
            case x: {
              bn = r.stateNode.containerInfo, Wr = !0;
              break e;
            }
          }
          r = r.return;
        }
      if (bn === null)
        throw new Error("Expected to find a host parent. This error is likely caused by a bug in React. Please file an issue.");
      cE(e, t, n), bn = null, Wr = !1;
    }
    WA(n);
  }
  function Ti(e, t, n) {
    for (var r = n.child; r !== null; )
      cE(e, t, r), r = r.sibling;
  }
  function cE(e, t, n) {
    switch (qT(n), n.tag) {
      case T:
        gn || xl(n, t);
      case M: {
        {
          var r = bn, i = Wr;
          bn = null, Ti(e, t, n), bn = r, Wr = i, bn !== null && (Wr ? hM(bn, n.stateNode) : vM(bn, n.stateNode));
        }
        return;
      }
      case he: {
        bn !== null && (Wr ? mM(bn, n.stateNode) : Nv(bn, n.stateNode));
        return;
      }
      case x: {
        {
          var l = bn, f = Wr;
          bn = n.stateNode.containerInfo, Wr = !0, Ti(e, t, n), bn = l, Wr = f;
        }
        return;
      }
      case b:
      case Y:
      case ne:
      case Z: {
        if (!gn) {
          var p = n.updateQueue;
          if (p !== null) {
            var m = p.lastEffect;
            if (m !== null) {
              var C = m.next, w = C;
              do {
                var N = w, A = N.destroy, j = N.tag;
                A !== void 0 && ((j & ua) !== Zn ? Qf(n, t, A) : (j & Qt) !== Zn && (Xg(n), n.mode & ut ? (da(), Qf(n, t, A), fa(n)) : Qf(n, t, A), Kg())), w = w.next;
              } while (w !== C);
            }
          }
        }
        Ti(e, t, n);
        return;
      }
      case S: {
        if (!gn) {
          xl(n, t);
          var H = n.stateNode;
          typeof H.componentWillUnmount == "function" && bm(n, t, H);
        }
        Ti(e, t, n);
        return;
      }
      case Xe: {
        Ti(e, t, n);
        return;
      }
      case fe: {
        if (
          // TODO: Remove this dead flag
          n.mode & Ye
        ) {
          var B = gn;
          gn = B || n.memoizedState !== null, Ti(e, t, n), gn = B;
        } else
          Ti(e, t, n);
        break;
      }
      default: {
        Ti(e, t, n);
        return;
      }
    }
  }
  function qA(e) {
    e.memoizedState;
  }
  function QA(e, t) {
    var n = t.memoizedState;
    if (n === null) {
      var r = t.alternate;
      if (r !== null) {
        var i = r.memoizedState;
        if (i !== null) {
          var l = i.dehydrated;
          l !== null && PM(l);
        }
      }
    }
  }
  function fE(e) {
    var t = e.updateQueue;
    if (t !== null) {
      e.updateQueue = null;
      var n = e.stateNode;
      n === null && (n = e.stateNode = new kA()), t.forEach(function(r) {
        var i = GN.bind(null, e, r);
        if (!n.has(r)) {
          if (n.add(r), Ur)
            if (Rl !== null && wl !== null)
              Os(wl, Rl);
            else
              throw Error("Expected finished root and lanes to be set. This is a bug in React.");
          r.then(i, i);
        }
      });
    }
  }
  function ZA(e, t, n) {
    Rl = n, wl = e, Tt(t), dE(t, e), Tt(t), Rl = null, wl = null;
  }
  function Gr(e, t, n) {
    var r = t.deletions;
    if (r !== null)
      for (var i = 0; i < r.length; i++) {
        var l = r[i];
        try {
          KA(e, t, l);
        } catch (m) {
          mt(l, t, m);
        }
      }
    var f = oc();
    if (t.subtreeFlags & Dp)
      for (var p = t.child; p !== null; )
        Tt(p), dE(p, e), p = p.sibling;
    Tt(f);
  }
  function dE(e, t, n) {
    var r = e.alternate, i = e.flags;
    switch (e.tag) {
      case b:
      case Y:
      case ne:
      case Z: {
        if (Gr(t, e), pa(e), i & qe) {
          try {
            Yr(ua | qt, e, e.return), xi(ua | qt, e);
          } catch (Me) {
            mt(e, e.return, Me);
          }
          if (e.mode & ut) {
            try {
              da(), Yr(Qt | qt, e, e.return);
            } catch (Me) {
              mt(e, e.return, Me);
            }
            fa(e);
          } else
            try {
              Yr(Qt | qt, e, e.return);
            } catch (Me) {
              mt(e, e.return, Me);
            }
        }
        return;
      }
      case S: {
        Gr(t, e), pa(e), i & ui && r !== null && xl(r, r.return);
        return;
      }
      case T: {
        Gr(t, e), pa(e), i & ui && r !== null && xl(r, r.return);
        {
          if (e.flags & fu) {
            var l = e.stateNode;
            try {
              fS(l);
            } catch (Me) {
              mt(e, e.return, Me);
            }
          }
          if (i & qe) {
            var f = e.stateNode;
            if (f != null) {
              var p = e.memoizedProps, m = r !== null ? r.memoizedProps : p, C = e.type, w = e.updateQueue;
              if (e.updateQueue = null, w !== null)
                try {
                  uM(f, w, C, m, p, e);
                } catch (Me) {
                  mt(e, e.return, Me);
                }
            }
          }
        }
        return;
      }
      case M: {
        if (Gr(t, e), pa(e), i & qe) {
          if (e.stateNode === null)
            throw new Error("This should have a text node initialized. This error is likely caused by a bug in React. Please file an issue.");
          var N = e.stateNode, A = e.memoizedProps, j = r !== null ? r.memoizedProps : A;
          try {
            sM(N, j, A);
          } catch (Me) {
            mt(e, e.return, Me);
          }
        }
        return;
      }
      case E: {
        if (Gr(t, e), pa(e), i & qe && r !== null) {
          var H = r.memoizedState;
          if (H.isDehydrated)
            try {
              kM(t.containerInfo);
            } catch (Me) {
              mt(e, e.return, Me);
            }
        }
        return;
      }
      case x: {
        Gr(t, e), pa(e);
        return;
      }
      case W: {
        Gr(t, e), pa(e);
        var B = e.child;
        if (B.flags & qi) {
          var ae = B.stateNode, Ce = B.memoizedState, ye = Ce !== null;
          if (ae.isHidden = ye, ye) {
            var Ge = B.alternate !== null && B.alternate.memoizedState !== null;
            Ge || NN();
          }
        }
        if (i & qe) {
          try {
            qA(e);
          } catch (Me) {
            mt(e, e.return, Me);
          }
          fE(e);
        }
        return;
      }
      case fe: {
        var $e = r !== null && r.memoizedState !== null;
        if (
          // TODO: Remove this dead flag
          e.mode & Ye
        ) {
          var k = gn;
          gn = k || $e, Gr(t, e), gn = k;
        } else
          Gr(t, e);
        if (pa(e), i & qi) {
          var V = e.stateNode, P = e.memoizedState, Q = P !== null, ue = e;
          if (V.isHidden = Q, Q && !$e && (ue.mode & Ye) !== Re) {
            ce = ue;
            for (var ie = ue.child; ie !== null; )
              ce = ie, eN(ie), ie = ie.sibling;
          }
          YA(ue, Q);
        }
        return;
      }
      case Ee: {
        Gr(t, e), pa(e), i & qe && fE(e);
        return;
      }
      case Xe:
        return;
      default: {
        Gr(t, e), pa(e);
        return;
      }
    }
  }
  function pa(e) {
    var t = e.flags;
    if (t & It) {
      try {
        XA(e);
      } catch (n) {
        mt(e, e.return, n);
      }
      e.flags &= ~It;
    }
    t & Na && (e.flags &= ~Na);
  }
  function JA(e, t, n) {
    Rl = n, wl = t, ce = e, pE(e, t, n), Rl = null, wl = null;
  }
  function pE(e, t, n) {
    for (var r = (e.mode & Ye) !== Re; ce !== null; ) {
      var i = ce, l = i.child;
      if (i.tag === fe && r) {
        var f = i.memoizedState !== null, p = f || qf;
        if (p) {
          Em(e, t, n);
          continue;
        } else {
          var m = i.alternate, C = m !== null && m.memoizedState !== null, w = C || gn, N = qf, A = gn;
          qf = p, gn = w, gn && !A && (ce = i, tN(i));
          for (var j = l; j !== null; )
            ce = j, pE(
              j,
              // New root; bubble back up to here and stop.
              t,
              n
            ), j = j.sibling;
          ce = i, qf = N, gn = A, Em(e, t, n);
          continue;
        }
      }
      (i.subtreeFlags & pu) !== Te && l !== null ? (l.return = i, ce = l) : Em(e, t, n);
    }
  }
  function Em(e, t, n) {
    for (; ce !== null; ) {
      var r = ce;
      if ((r.flags & pu) !== Te) {
        var i = r.alternate;
        Tt(r);
        try {
          BA(t, i, r, n);
        } catch (f) {
          mt(r, r.return, f);
        }
        ln();
      }
      if (r === e) {
        ce = null;
        return;
      }
      var l = r.sibling;
      if (l !== null) {
        l.return = r.return, ce = l;
        return;
      }
      ce = r.return;
    }
  }
  function eN(e) {
    for (; ce !== null; ) {
      var t = ce, n = t.child;
      switch (t.tag) {
        case b:
        case Y:
        case ne:
        case Z: {
          if (t.mode & ut)
            try {
              da(), Yr(Qt, t, t.return);
            } finally {
              fa(t);
            }
          else
            Yr(Qt, t, t.return);
          break;
        }
        case S: {
          xl(t, t.return);
          var r = t.stateNode;
          typeof r.componentWillUnmount == "function" && bm(t, t.return, r);
          break;
        }
        case T: {
          xl(t, t.return);
          break;
        }
        case fe: {
          var i = t.memoizedState !== null;
          if (i) {
            vE(e);
            continue;
          }
          break;
        }
      }
      n !== null ? (n.return = t, ce = n) : vE(e);
    }
  }
  function vE(e) {
    for (; ce !== null; ) {
      var t = ce;
      if (t === e) {
        ce = null;
        return;
      }
      var n = t.sibling;
      if (n !== null) {
        n.return = t.return, ce = n;
        return;
      }
      ce = t.return;
    }
  }
  function tN(e) {
    for (; ce !== null; ) {
      var t = ce, n = t.child;
      if (t.tag === fe) {
        var r = t.memoizedState !== null;
        if (r) {
          hE(e);
          continue;
        }
      }
      n !== null ? (n.return = t, ce = n) : hE(e);
    }
  }
  function hE(e) {
    for (; ce !== null; ) {
      var t = ce;
      Tt(t);
      try {
        VA(t);
      } catch (r) {
        mt(t, t.return, r);
      }
      if (ln(), t === e) {
        ce = null;
        return;
      }
      var n = t.sibling;
      if (n !== null) {
        n.return = t.return, ce = n;
        return;
      }
      ce = t.return;
    }
  }
  function nN(e, t, n, r) {
    ce = t, rN(t, e, n, r);
  }
  function rN(e, t, n, r) {
    for (; ce !== null; ) {
      var i = ce, l = i.child;
      (i.subtreeFlags & Yo) !== Te && l !== null ? (l.return = i, ce = l) : aN(e, t, n, r);
    }
  }
  function aN(e, t, n, r) {
    for (; ce !== null; ) {
      var i = ce;
      if ((i.flags & Pr) !== Te) {
        Tt(i);
        try {
          iN(t, i, n, r);
        } catch (f) {
          mt(i, i.return, f);
        }
        ln();
      }
      if (i === e) {
        ce = null;
        return;
      }
      var l = i.sibling;
      if (l !== null) {
        l.return = i.return, ce = l;
        return;
      }
      ce = i.return;
    }
  }
  function iN(e, t, n, r) {
    switch (t.tag) {
      case b:
      case Y:
      case Z: {
        if (t.mode & ut) {
          $h();
          try {
            xi(mn | qt, t);
          } finally {
            Hh(t);
          }
        } else
          xi(mn | qt, t);
        break;
      }
    }
  }
  function oN(e) {
    ce = e, lN();
  }
  function lN() {
    for (; ce !== null; ) {
      var e = ce, t = e.child;
      if ((ce.flags & Xi) !== Te) {
        var n = e.deletions;
        if (n !== null) {
          for (var r = 0; r < n.length; r++) {
            var i = n[r];
            ce = i, cN(i, e);
          }
          {
            var l = e.alternate;
            if (l !== null) {
              var f = l.child;
              if (f !== null) {
                l.child = null;
                do {
                  var p = f.sibling;
                  f.sibling = null, f = p;
                } while (f !== null);
              }
            }
          }
          ce = e;
        }
      }
      (e.subtreeFlags & Yo) !== Te && t !== null ? (t.return = e, ce = t) : uN();
    }
  }
  function uN() {
    for (; ce !== null; ) {
      var e = ce;
      (e.flags & Pr) !== Te && (Tt(e), sN(e), ln());
      var t = e.sibling;
      if (t !== null) {
        t.return = e.return, ce = t;
        return;
      }
      ce = e.return;
    }
  }
  function sN(e) {
    switch (e.tag) {
      case b:
      case Y:
      case Z: {
        e.mode & ut ? ($h(), Yr(mn | qt, e, e.return), Hh(e)) : Yr(mn | qt, e, e.return);
        break;
      }
    }
  }
  function cN(e, t) {
    for (; ce !== null; ) {
      var n = ce;
      Tt(n), dN(n, t), ln();
      var r = n.child;
      r !== null ? (r.return = n, ce = r) : fN(e);
    }
  }
  function fN(e) {
    for (; ce !== null; ) {
      var t = ce, n = t.sibling, r = t.return;
      if (lE(t), t === e) {
        ce = null;
        return;
      }
      if (n !== null) {
        n.return = r, ce = n;
        return;
      }
      ce = r;
    }
  }
  function dN(e, t) {
    switch (e.tag) {
      case b:
      case Y:
      case Z: {
        e.mode & ut ? ($h(), Yr(mn, e, t), Hh(e)) : Yr(mn, e, t);
        break;
      }
    }
  }
  function pN(e) {
    switch (e.tag) {
      case b:
      case Y:
      case Z: {
        try {
          xi(Qt | qt, e);
        } catch (n) {
          mt(e, e.return, n);
        }
        break;
      }
      case S: {
        var t = e.stateNode;
        try {
          t.componentDidMount();
        } catch (n) {
          mt(e, e.return, n);
        }
        break;
      }
    }
  }
  function vN(e) {
    switch (e.tag) {
      case b:
      case Y:
      case Z: {
        try {
          xi(mn | qt, e);
        } catch (t) {
          mt(e, e.return, t);
        }
        break;
      }
    }
  }
  function hN(e) {
    switch (e.tag) {
      case b:
      case Y:
      case Z: {
        try {
          Yr(Qt | qt, e, e.return);
        } catch (n) {
          mt(e, e.return, n);
        }
        break;
      }
      case S: {
        var t = e.stateNode;
        typeof t.componentWillUnmount == "function" && bm(e, e.return, t);
        break;
      }
    }
  }
  function mN(e) {
    switch (e.tag) {
      case b:
      case Y:
      case Z:
        try {
          Yr(mn | qt, e, e.return);
        } catch (t) {
          mt(e, e.return, t);
        }
    }
  }
  if (typeof Symbol == "function" && Symbol.for) {
    var bs = Symbol.for;
    bs("selector.component"), bs("selector.has_pseudo_class"), bs("selector.role"), bs("selector.test_id"), bs("selector.text");
  }
  var yN = [];
  function gN() {
    yN.forEach(function(e) {
      return e();
    });
  }
  var bN = u.ReactCurrentActQueue;
  function SN(e) {
    {
      var t = (
        // $FlowExpectedError – Flow doesn't know about IS_REACT_ACT_ENVIRONMENT global
        typeof IS_REACT_ACT_ENVIRONMENT < "u" ? IS_REACT_ACT_ENVIRONMENT : void 0
      ), n = typeof jest < "u";
      return n && t !== !1;
    }
  }
  function mE() {
    {
      var e = (
        // $FlowExpectedError – Flow doesn't know about IS_REACT_ACT_ENVIRONMENT global
        typeof IS_REACT_ACT_ENVIRONMENT < "u" ? IS_REACT_ACT_ENVIRONMENT : void 0
      );
      return !e && bN.current !== null && c("The current testing environment is not configured to support act(...)"), e;
    }
  }
  var CN = Math.ceil, Rm = u.ReactCurrentDispatcher, wm = u.ReactCurrentOwner, Sn = u.ReactCurrentBatchConfig, Xr = u.ReactCurrentActQueue, en = (
    /*             */
    0
  ), yE = (
    /*               */
    1
  ), Cn = (
    /*                */
    2
  ), Dr = (
    /*                */
    4
  ), Ya = 0, Ss = 1, go = 2, Zf = 3, Cs = 4, gE = 5, xm = 6, We = en, $n = null, Dt = null, tn = K, va = K, Tm = mi(K), nn = Ya, Es = null, Jf = K, Rs = K, ed = K, ws = null, Jn = null, Dm = 0, bE = 500, SE = 1 / 0, EN = 500, Wa = null;
  function xs() {
    SE = un() + EN;
  }
  function CE() {
    return SE;
  }
  var td = !1, _m = null, Tl = null, bo = !1, Di = null, Ts = K, Mm = [], Om = null, RN = 50, Ds = 0, Am = null, Nm = !1, nd = !1, wN = 50, Dl = 0, rd = null, _s = bt, ad = K, EE = !1;
  function id() {
    return $n;
  }
  function In() {
    return (We & (Cn | Dr)) !== en ? un() : (_s !== bt || (_s = un()), _s);
  }
  function _i(e) {
    var t = e.mode;
    if ((t & Ye) === Re)
      return Ne;
    if ((We & Cn) !== en && tn !== K)
      return Su(tn);
    var n = bO() !== gO;
    if (n) {
      if (Sn.transition !== null) {
        var r = Sn.transition;
        r._updatedFibers || (r._updatedFibers = /* @__PURE__ */ new Set()), r._updatedFibers.add(e);
      }
      return ad === cn && (ad = rb()), ad;
    }
    var i = jr();
    if (i !== cn)
      return i;
    var l = rM();
    return l;
  }
  function xN(e) {
    var t = e.mode;
    return (t & Ye) === Re ? Ne : D1();
  }
  function rn(e, t, n, r) {
    KN(), EE && c("useInsertionEffect must not schedule updates."), Nm && (nd = !0), Cu(e, n, r), (We & Cn) !== K && e === $n ? ZN(t) : (Ur && ob(e, t, n), JN(t), e === $n && ((We & Cn) === en && (Rs = Ue(Rs, n)), nn === Cs && Mi(e, tn)), er(e, r), n === Ne && We === en && (t.mode & Ye) === Re && // Treat `act` as if it's inside `batchedUpdates`, even in legacy mode.
    !Xr.isBatchingLegacy && (xs(), ES()));
  }
  function TN(e, t, n) {
    var r = e.current;
    r.lanes = t, Cu(e, t, n), er(e, n);
  }
  function DN(e) {
    return (
      // TODO: Remove outdated deferRenderPhaseUpdateToNextBatch experiment. We
      // decided not to enable it.
      (We & Cn) !== en
    );
  }
  function er(e, t) {
    var n = e.callbackNode;
    C1(e, t);
    var r = xc(e, e === $n ? tn : K);
    if (r === K) {
      n !== null && FE(n), e.callbackNode = null, e.callbackPriority = cn;
      return;
    }
    var i = no(r), l = e.callbackPriority;
    if (l === i && // Special case related to `act`. If the currently scheduled task is a
    // Scheduler task, rather than an `act` task, cancel it and re-scheduled
    // on the `act` queue.
    !(Xr.current !== null && n !== zm)) {
      n == null && l !== Ne && c("Expected scheduled callback to exist. This error is likely caused by a bug in React. Please file an issue.");
      return;
    }
    n != null && FE(n);
    var f;
    if (i === Ne)
      e.tag === yi ? (Xr.isBatchingLegacy !== null && (Xr.didScheduleLegacyUpdate = !0), tO(xE.bind(null, e))) : CS(xE.bind(null, e)), Xr.current !== null ? Xr.current.push(gi) : iM(function() {
        (We & (Cn | Dr)) === en && gi();
      }), f = null;
    else {
      var p;
      switch (sb(r)) {
        case lr:
          p = Cc;
          break;
        case Ua:
          p = _p;
          break;
        case ja:
          p = Ji;
          break;
        case _c:
          p = Mp;
          break;
        default:
          p = Ji;
          break;
      }
      f = Hm(p, RE.bind(null, e));
    }
    e.callbackPriority = i, e.callbackNode = f;
  }
  function RE(e, t) {
    if (YO(), _s = bt, ad = K, (We & (Cn | Dr)) !== en)
      throw new Error("Should not already be working.");
    var n = e.callbackNode, r = Xa();
    if (r && e.callbackNode !== n)
      return null;
    var i = xc(e, e === $n ? tn : K);
    if (i === K)
      return null;
    var l = !Tc(e, i) && !T1(e, i) && !t, f = l ? jN(e, i) : ld(e, i);
    if (f !== Ya) {
      if (f === go) {
        var p = Qp(e);
        p !== K && (i = p, f = Lm(e, p));
      }
      if (f === Ss) {
        var m = Es;
        throw So(e, K), Mi(e, i), er(e, un()), m;
      }
      if (f === xm)
        Mi(e, i);
      else {
        var C = !Tc(e, i), w = e.current.alternate;
        if (C && !MN(w)) {
          if (f = ld(e, i), f === go) {
            var N = Qp(e);
            N !== K && (i = N, f = Lm(e, N));
          }
          if (f === Ss) {
            var A = Es;
            throw So(e, K), Mi(e, i), er(e, un()), A;
          }
        }
        e.finishedWork = w, e.finishedLanes = i, _N(e, f, i);
      }
    }
    return er(e, un()), e.callbackNode === n ? RE.bind(null, e) : null;
  }
  function Lm(e, t) {
    var n = ws;
    if (Mc(e)) {
      var r = So(e, t);
      r.flags |= Aa, XM(e.containerInfo);
    }
    var i = ld(e, t);
    if (i !== go) {
      var l = Jn;
      Jn = n, l !== null && wE(l);
    }
    return i;
  }
  function wE(e) {
    Jn === null ? Jn = e : Jn.push.apply(Jn, e);
  }
  function _N(e, t, n) {
    switch (t) {
      case Ya:
      case Ss:
        throw new Error("Root did not complete. This is a bug in React.");
      case go: {
        Co(e, Jn, Wa);
        break;
      }
      case Zf: {
        if (Mi(e, n), tb(n) && // do not delay if we're inside an act() scope
        !zE()) {
          var r = Dm + bE - un();
          if (r > 10) {
            var i = xc(e, K);
            if (i !== K)
              break;
            var l = e.suspendedLanes;
            if (!Qo(l, n)) {
              In(), ib(e, l);
              break;
            }
            e.timeoutHandle = Ov(Co.bind(null, e, Jn, Wa), r);
            break;
          }
        }
        Co(e, Jn, Wa);
        break;
      }
      case Cs: {
        if (Mi(e, n), x1(n))
          break;
        if (!zE()) {
          var f = b1(e, n), p = f, m = un() - p, C = XN(m) - m;
          if (C > 10) {
            e.timeoutHandle = Ov(Co.bind(null, e, Jn, Wa), C);
            break;
          }
        }
        Co(e, Jn, Wa);
        break;
      }
      case gE: {
        Co(e, Jn, Wa);
        break;
      }
      default:
        throw new Error("Unknown root exit status.");
    }
  }
  function MN(e) {
    for (var t = e; ; ) {
      if (t.flags & bc) {
        var n = t.updateQueue;
        if (n !== null) {
          var r = n.stores;
          if (r !== null)
            for (var i = 0; i < r.length; i++) {
              var l = r[i], f = l.getSnapshot, p = l.value;
              try {
                if (!sr(f(), p))
                  return !1;
              } catch {
                return !1;
              }
            }
        }
      }
      var m = t.child;
      if (t.subtreeFlags & bc && m !== null) {
        m.return = t, t = m;
        continue;
      }
      if (t === e)
        return !0;
      for (; t.sibling === null; ) {
        if (t.return === null || t.return === e)
          return !0;
        t = t.return;
      }
      t.sibling.return = t.return, t = t.sibling;
    }
    return !0;
  }
  function Mi(e, t) {
    t = Dc(t, ed), t = Dc(t, Rs), M1(e, t);
  }
  function xE(e) {
    if (WO(), (We & (Cn | Dr)) !== en)
      throw new Error("Should not already be working.");
    Xa();
    var t = xc(e, K);
    if (!or(t, Ne))
      return er(e, un()), null;
    var n = ld(e, t);
    if (e.tag !== yi && n === go) {
      var r = Qp(e);
      r !== K && (t = r, n = Lm(e, r));
    }
    if (n === Ss) {
      var i = Es;
      throw So(e, K), Mi(e, t), er(e, un()), i;
    }
    if (n === xm)
      throw new Error("Root did not complete. This is a bug in React.");
    var l = e.current.alternate;
    return e.finishedWork = l, e.finishedLanes = t, Co(e, Jn, Wa), er(e, un()), null;
  }
  function ON(e, t) {
    t !== K && (tv(e, Ue(t, Ne)), er(e, un()), (We & (Cn | Dr)) === en && (xs(), gi()));
  }
  function km(e, t) {
    var n = We;
    We |= yE;
    try {
      return e(t);
    } finally {
      We = n, We === en && // Treat `act` as if it's inside `batchedUpdates`, even in legacy mode.
      !Xr.isBatchingLegacy && (xs(), ES());
    }
  }
  function AN(e, t, n, r, i) {
    var l = jr(), f = Sn.transition;
    try {
      return Sn.transition = null, fn(lr), e(t, n, r, i);
    } finally {
      fn(l), Sn.transition = f, We === en && xs();
    }
  }
  function Ga(e) {
    Di !== null && Di.tag === yi && (We & (Cn | Dr)) === en && Xa();
    var t = We;
    We |= yE;
    var n = Sn.transition, r = jr();
    try {
      return Sn.transition = null, fn(lr), e ? e() : void 0;
    } finally {
      fn(r), Sn.transition = n, We = t, (We & (Cn | Dr)) === en && gi();
    }
  }
  function TE() {
    return (We & (Cn | Dr)) !== en;
  }
  function od(e, t) {
    An(Tm, va, e), va = Ue(va, t);
  }
  function Pm(e) {
    va = Tm.current, On(Tm, e);
  }
  function So(e, t) {
    e.finishedWork = null, e.finishedLanes = K;
    var n = e.timeoutHandle;
    if (n !== Av && (e.timeoutHandle = Av, aM(n)), Dt !== null)
      for (var r = Dt.return; r !== null; ) {
        var i = r.alternate;
        tE(i, r), r = r.return;
      }
    $n = e;
    var l = Eo(e.current, null);
    return Dt = l, tn = va = t, nn = Ya, Es = null, Jf = K, Rs = K, ed = K, ws = null, Jn = null, TO(), Hr.discardPendingWarnings(), l;
  }
  function DE(e, t) {
    do {
      var n = Dt;
      try {
        if (mf(), QS(), ln(), wm.current = null, n === null || n.return === null) {
          nn = Ss, Es = t, Dt = null;
          return;
        }
        if (Wt && n.mode & ut && Yf(n, !0), Pn)
          if (Go(), t !== null && typeof t == "object" && typeof t.then == "function") {
            var r = t;
            l1(n, r, tn);
          } else
            o1(n, t, tn);
        tA(e, n.return, n, t, tn), AE(n);
      } catch (i) {
        t = i, Dt === n && n !== null ? (n = n.return, Dt = n) : n = Dt;
        continue;
      }
      return;
    } while (!0);
  }
  function _E() {
    var e = Rm.current;
    return Rm.current = Hf, e === null ? Hf : e;
  }
  function ME(e) {
    Rm.current = e;
  }
  function NN() {
    Dm = un();
  }
  function Ms(e) {
    Jf = Ue(e, Jf);
  }
  function LN() {
    nn === Ya && (nn = Zf);
  }
  function Um() {
    (nn === Ya || nn === Zf || nn === go) && (nn = Cs), $n !== null && (Zp(Jf) || Zp(Rs)) && Mi($n, tn);
  }
  function kN(e) {
    nn !== Cs && (nn = go), ws === null ? ws = [e] : ws.push(e);
  }
  function PN() {
    return nn === Ya;
  }
  function ld(e, t) {
    var n = We;
    We |= Cn;
    var r = _E();
    if ($n !== e || tn !== t) {
      if (Ur) {
        var i = e.memoizedUpdaters;
        i.size > 0 && (Os(e, tn), i.clear()), lb(e, t);
      }
      Wa = ub(), So(e, t);
    }
    qg(t);
    do
      try {
        UN();
        break;
      } catch (l) {
        DE(e, l);
      }
    while (!0);
    if (mf(), We = n, ME(r), Dt !== null)
      throw new Error("Cannot commit an incomplete root. This error is likely caused by a bug in React. Please file an issue.");
    return Qg(), $n = null, tn = K, nn;
  }
  function UN() {
    for (; Dt !== null; )
      OE(Dt);
  }
  function jN(e, t) {
    var n = We;
    We |= Cn;
    var r = _E();
    if ($n !== e || tn !== t) {
      if (Ur) {
        var i = e.memoizedUpdaters;
        i.size > 0 && (Os(e, tn), i.clear()), lb(e, t);
      }
      Wa = ub(), xs(), So(e, t);
    }
    qg(t);
    do
      try {
        FN();
        break;
      } catch (l) {
        DE(e, l);
      }
    while (!0);
    return mf(), ME(r), We = n, Dt !== null ? (d1(), Ya) : (Qg(), $n = null, tn = K, nn);
  }
  function FN() {
    for (; Dt !== null && !HT(); )
      OE(Dt);
  }
  function OE(e) {
    var t = e.alternate;
    Tt(e);
    var n;
    (e.mode & ut) !== Re ? (zh(e), n = jm(t, e, va), Yf(e, !0)) : n = jm(t, e, va), ln(), e.memoizedProps = e.pendingProps, n === null ? AE(e) : Dt = n, wm.current = null;
  }
  function AE(e) {
    var t = e;
    do {
      var n = t.alternate, r = t.return;
      if ((t.flags & du) === Te) {
        Tt(t);
        var i = void 0;
        if ((t.mode & ut) === Re ? i = eE(n, t, va) : (zh(t), i = eE(n, t, va), Yf(t, !1)), ln(), i !== null) {
          Dt = i;
          return;
        }
      } else {
        var l = LA(n, t);
        if (l !== null) {
          l.flags &= kT, Dt = l;
          return;
        }
        if ((t.mode & ut) !== Re) {
          Yf(t, !1);
          for (var f = t.actualDuration, p = t.child; p !== null; )
            f += p.actualDuration, p = p.sibling;
          t.actualDuration = f;
        }
        if (r !== null)
          r.flags |= du, r.subtreeFlags = Te, r.deletions = null;
        else {
          nn = xm, Dt = null;
          return;
        }
      }
      var m = t.sibling;
      if (m !== null) {
        Dt = m;
        return;
      }
      t = r, Dt = t;
    } while (t !== null);
    nn === Ya && (nn = gE);
  }
  function Co(e, t, n) {
    var r = jr(), i = Sn.transition;
    try {
      Sn.transition = null, fn(lr), zN(e, t, n, r);
    } finally {
      Sn.transition = i, fn(r);
    }
    return null;
  }
  function zN(e, t, n, r) {
    do
      Xa();
    while (Di !== null);
    if (qN(), (We & (Cn | Dr)) !== en)
      throw new Error("Should not already be working.");
    var i = e.finishedWork, l = e.finishedLanes;
    if (JT(l), i === null)
      return Gg(), null;
    if (l === K && c("root.finishedLanes should not be empty during a commit. This is a bug in React."), e.finishedWork = null, e.finishedLanes = K, i === e.current)
      throw new Error("Cannot commit the same tree as before. This error is likely caused by a bug in React. Please file an issue.");
    e.callbackNode = null, e.callbackPriority = cn;
    var f = Ue(i.lanes, i.childLanes);
    O1(e, f), e === $n && ($n = null, Dt = null, tn = K), ((i.subtreeFlags & Yo) !== Te || (i.flags & Yo) !== Te) && (bo || (bo = !0, Om = n, Hm(Ji, function() {
      return Xa(), null;
    })));
    var p = (i.subtreeFlags & (Tp | Dp | pu | Yo)) !== Te, m = (i.flags & (Tp | Dp | pu | Yo)) !== Te;
    if (p || m) {
      var C = Sn.transition;
      Sn.transition = null;
      var w = jr();
      fn(lr);
      var N = We;
      We |= Dr, wm.current = null, FA(e, i), EC(), ZA(e, i, l), Q_(e.containerInfo), e.current = i, u1(l), JA(i, e, l), s1(), $T(), We = N, fn(w), Sn.transition = C;
    } else
      e.current = i, EC();
    var A = bo;
    if (bo ? (bo = !1, Di = e, Ts = l) : (Dl = 0, rd = null), f = e.pendingLanes, f === K && (Tl = null), A || PE(e.current, !1), XT(i.stateNode, r), Ur && e.memoizedUpdaters.clear(), gN(), er(e, un()), t !== null)
      for (var j = e.onRecoverableError, H = 0; H < t.length; H++) {
        var B = t[H], ae = B.stack, Ce = B.digest;
        j(B.value, {
          componentStack: ae,
          digest: Ce
        });
      }
    if (td) {
      td = !1;
      var ye = _m;
      throw _m = null, ye;
    }
    return or(Ts, Ne) && e.tag !== yi && Xa(), f = e.pendingLanes, or(f, Ne) ? (VO(), e === Am ? Ds++ : (Ds = 0, Am = e)) : Ds = 0, gi(), Gg(), null;
  }
  function Xa() {
    if (Di !== null) {
      var e = sb(Ts), t = k1(ja, e), n = Sn.transition, r = jr();
      try {
        return Sn.transition = null, fn(t), $N();
      } finally {
        fn(r), Sn.transition = n;
      }
    }
    return !1;
  }
  function HN(e) {
    Mm.push(e), bo || (bo = !0, Hm(Ji, function() {
      return Xa(), null;
    }));
  }
  function $N() {
    if (Di === null)
      return !1;
    var e = Om;
    Om = null;
    var t = Di, n = Ts;
    if (Di = null, Ts = K, (We & (Cn | Dr)) !== en)
      throw new Error("Cannot flush passive effects while already rendering.");
    Nm = !0, nd = !1, c1(n);
    var r = We;
    We |= Dr, oN(t.current), nN(t, t.current, n, e);
    {
      var i = Mm;
      Mm = [];
      for (var l = 0; l < i.length; l++) {
        var f = i[l];
        IA(t, f);
      }
    }
    f1(), PE(t.current, !0), We = r, gi(), nd ? t === rd ? Dl++ : (Dl = 0, rd = t) : Dl = 0, Nm = !1, nd = !1, KT(t);
    {
      var p = t.current.stateNode;
      p.effectDuration = 0, p.passiveEffectDuration = 0;
    }
    return !0;
  }
  function NE(e) {
    return Tl !== null && Tl.has(e);
  }
  function IN(e) {
    Tl === null ? Tl = /* @__PURE__ */ new Set([e]) : Tl.add(e);
  }
  function BN(e) {
    td || (td = !0, _m = e);
  }
  var VN = BN;
  function LE(e, t, n) {
    var r = mo(n, t), i = OC(e, r, Ne), l = Si(e, i, Ne), f = In();
    l !== null && (Cu(l, Ne, f), er(l, f));
  }
  function mt(e, t, n) {
    if (PA(n), As(!1), e.tag === E) {
      LE(e, e, n);
      return;
    }
    var r = null;
    for (r = t; r !== null; ) {
      if (r.tag === E) {
        LE(r, e, n);
        return;
      } else if (r.tag === S) {
        var i = r.type, l = r.stateNode;
        if (typeof i.getDerivedStateFromError == "function" || typeof l.componentDidCatch == "function" && !NE(l)) {
          var f = mo(n, e), p = rm(r, f, Ne), m = Si(r, p, Ne), C = In();
          m !== null && (Cu(m, Ne, C), er(m, C));
          return;
        }
      }
      r = r.return;
    }
    c(`Internal React error: Attempted to capture a commit phase error inside a detached tree. This indicates a bug in React. Likely causes include deleting the same fiber more than once, committing an already-finished tree, or an inconsistent return pointer.

Error message:

%s`, n);
  }
  function YN(e, t, n) {
    var r = e.pingCache;
    r !== null && r.delete(t);
    var i = In();
    ib(e, n), eL(e), $n === e && Qo(tn, n) && (nn === Cs || nn === Zf && tb(tn) && un() - Dm < bE ? So(e, K) : ed = Ue(ed, n)), er(e, i);
  }
  function kE(e, t) {
    t === cn && (t = xN(e));
    var n = In(), r = Qn(e, t);
    r !== null && (Cu(r, t, n), er(r, n));
  }
  function WN(e) {
    var t = e.memoizedState, n = cn;
    t !== null && (n = t.retryLane), kE(e, n);
  }
  function GN(e, t) {
    var n = cn, r;
    switch (e.tag) {
      case W:
        r = e.stateNode;
        var i = e.memoizedState;
        i !== null && (n = i.retryLane);
        break;
      case Ee:
        r = e.stateNode;
        break;
      default:
        throw new Error("Pinged unknown suspense boundary type. This is probably a bug in React.");
    }
    r !== null && r.delete(t), kE(e, n);
  }
  function XN(e) {
    return e < 120 ? 120 : e < 480 ? 480 : e < 1080 ? 1080 : e < 1920 ? 1920 : e < 3e3 ? 3e3 : e < 4320 ? 4320 : CN(e / 1960) * 1960;
  }
  function KN() {
    if (Ds > RN)
      throw Ds = 0, Am = null, new Error("Maximum update depth exceeded. This can happen when a component repeatedly calls setState inside componentWillUpdate or componentDidUpdate. React limits the number of nested updates to prevent infinite loops.");
    Dl > wN && (Dl = 0, rd = null, c("Maximum update depth exceeded. This can happen when a component calls setState inside useEffect, but useEffect either doesn't have a dependency array, or one of the dependencies changes on every render."));
  }
  function qN() {
    Hr.flushLegacyContextWarning(), Hr.flushPendingUnsafeLifecycleWarnings();
  }
  function PE(e, t) {
    Tt(e), ud(e, La, hN), t && ud(e, Sc, mN), ud(e, La, pN), t && ud(e, Sc, vN), ln();
  }
  function ud(e, t, n) {
    for (var r = e, i = null; r !== null; ) {
      var l = r.subtreeFlags & t;
      r !== i && r.child !== null && l !== Te ? r = r.child : ((r.flags & t) !== Te && n(r), r.sibling !== null ? r = r.sibling : r = i = r.return);
    }
  }
  var sd = null;
  function UE(e) {
    {
      if ((We & Cn) !== en || !(e.mode & Ye))
        return;
      var t = e.tag;
      if (t !== R && t !== E && t !== S && t !== b && t !== Y && t !== ne && t !== Z)
        return;
      var n = Pe(e) || "ReactComponent";
      if (sd !== null) {
        if (sd.has(n))
          return;
        sd.add(n);
      } else
        sd = /* @__PURE__ */ new Set([n]);
      var r = _n;
      try {
        Tt(e), c("Can't perform a React state update on a component that hasn't mounted yet. This indicates that you have a side-effect in your render function that asynchronously later calls tries to update the component. Move this work to useEffect instead.");
      } finally {
        r ? Tt(e) : ln();
      }
    }
  }
  var jm;
  {
    var QN = null;
    jm = function(e, t, n) {
      var r = VE(QN, t);
      try {
        return KC(e, t, n);
      } catch (l) {
        if (sO() || l !== null && typeof l == "object" && typeof l.then == "function")
          throw l;
        if (mf(), QS(), tE(e, t), VE(t, r), t.mode & ut && zh(t), Sp(null, KC, null, e, t, n), OT()) {
          var i = Cp();
          typeof i == "object" && i !== null && i._suppressLogging && typeof l == "object" && l !== null && !l._suppressLogging && (l._suppressLogging = !0);
        }
        throw l;
      }
    };
  }
  var jE = !1, Fm;
  Fm = /* @__PURE__ */ new Set();
  function ZN(e) {
    if (Yi && !$O())
      switch (e.tag) {
        case b:
        case Y:
        case Z: {
          var t = Dt && Pe(Dt) || "Unknown", n = t;
          if (!Fm.has(n)) {
            Fm.add(n);
            var r = Pe(e) || "Unknown";
            c("Cannot update a component (`%s`) while rendering a different component (`%s`). To locate the bad setState() call inside `%s`, follow the stack trace as described in https://reactjs.org/link/setstate-in-render", r, t, t);
          }
          break;
        }
        case S: {
          jE || (c("Cannot update during an existing state transition (such as within `render`). Render methods should be a pure function of props and state."), jE = !0);
          break;
        }
      }
  }
  function Os(e, t) {
    if (Ur) {
      var n = e.memoizedUpdaters;
      n.forEach(function(r) {
        ob(e, r, t);
      });
    }
  }
  var zm = {};
  function Hm(e, t) {
    {
      var n = Xr.current;
      return n !== null ? (n.push(t), zm) : Wg(e, t);
    }
  }
  function FE(e) {
    if (e !== zm)
      return zT(e);
  }
  function zE() {
    return Xr.current !== null;
  }
  function JN(e) {
    {
      if (e.mode & Ye) {
        if (!mE())
          return;
      } else if (!SN() || We !== en || e.tag !== b && e.tag !== Y && e.tag !== Z)
        return;
      if (Xr.current === null) {
        var t = _n;
        try {
          Tt(e), c(`An update to %s inside a test was not wrapped in act(...).

When testing, code that causes React state updates should be wrapped into act(...):

act(() => {
  /* fire events that update state */
});
/* assert on the output */

This ensures that you're testing the behavior the user would see in the browser. Learn more at https://reactjs.org/link/wrap-tests-with-act`, Pe(e));
        } finally {
          t ? Tt(e) : ln();
        }
      }
    }
  }
  function eL(e) {
    e.tag !== yi && mE() && Xr.current === null && c(`A suspended resource finished loading inside a test, but the event was not wrapped in act(...).

When testing, code that resolves suspended data should be wrapped into act(...):

act(() => {
  /* finish loading suspended data */
});
/* assert on the output */

This ensures that you're testing the behavior the user would see in the browser. Learn more at https://reactjs.org/link/wrap-tests-with-act`);
  }
  function As(e) {
    EE = e;
  }
  var _r = null, _l = null, tL = function(e) {
    _r = e;
  };
  function Ml(e) {
    {
      if (_r === null)
        return e;
      var t = _r(e);
      return t === void 0 ? e : t.current;
    }
  }
  function $m(e) {
    return Ml(e);
  }
  function Im(e) {
    {
      if (_r === null)
        return e;
      var t = _r(e);
      if (t === void 0) {
        if (e != null && typeof e.render == "function") {
          var n = Ml(e.render);
          if (e.render !== n) {
            var r = {
              $$typeof: J,
              render: n
            };
            return e.displayName !== void 0 && (r.displayName = e.displayName), r;
          }
        }
        return e;
      }
      return t.current;
    }
  }
  function HE(e, t) {
    {
      if (_r === null)
        return !1;
      var n = e.elementType, r = t.type, i = !1, l = typeof r == "object" && r !== null ? r.$$typeof : null;
      switch (e.tag) {
        case S: {
          typeof r == "function" && (i = !0);
          break;
        }
        case b: {
          (typeof r == "function" || l === xe) && (i = !0);
          break;
        }
        case Y: {
          (l === J || l === xe) && (i = !0);
          break;
        }
        case ne:
        case Z: {
          (l === Qe || l === xe) && (i = !0);
          break;
        }
        default:
          return !1;
      }
      if (i) {
        var f = _r(n);
        if (f !== void 0 && f === _r(r))
          return !0;
      }
      return !1;
    }
  }
  function $E(e) {
    {
      if (_r === null || typeof WeakSet != "function")
        return;
      _l === null && (_l = /* @__PURE__ */ new WeakSet()), _l.add(e);
    }
  }
  var nL = function(e, t) {
    {
      if (_r === null)
        return;
      var n = t.staleFamilies, r = t.updatedFamilies;
      Xa(), Ga(function() {
        Bm(e.current, r, n);
      });
    }
  }, rL = function(e, t) {
    {
      if (e.context !== cr)
        return;
      Xa(), Ga(function() {
        Ns(t, e, null, null);
      });
    }
  };
  function Bm(e, t, n) {
    {
      var r = e.alternate, i = e.child, l = e.sibling, f = e.tag, p = e.type, m = null;
      switch (f) {
        case b:
        case Z:
        case S:
          m = p;
          break;
        case Y:
          m = p.render;
          break;
      }
      if (_r === null)
        throw new Error("Expected resolveFamily to be set during hot reload.");
      var C = !1, w = !1;
      if (m !== null) {
        var N = _r(m);
        N !== void 0 && (n.has(N) ? w = !0 : t.has(N) && (f === S ? w = !0 : C = !0));
      }
      if (_l !== null && (_l.has(e) || r !== null && _l.has(r)) && (w = !0), w && (e._debugNeedsRemount = !0), w || C) {
        var A = Qn(e, Ne);
        A !== null && rn(A, e, Ne, bt);
      }
      i !== null && !w && Bm(i, t, n), l !== null && Bm(l, t, n);
    }
  }
  var aL = function(e, t) {
    {
      var n = /* @__PURE__ */ new Set(), r = new Set(t.map(function(i) {
        return i.current;
      }));
      return Vm(e.current, r, n), n;
    }
  };
  function Vm(e, t, n) {
    {
      var r = e.child, i = e.sibling, l = e.tag, f = e.type, p = null;
      switch (l) {
        case b:
        case Z:
        case S:
          p = f;
          break;
        case Y:
          p = f.render;
          break;
      }
      var m = !1;
      p !== null && t.has(p) && (m = !0), m ? iL(e, n) : r !== null && Vm(r, t, n), i !== null && Vm(i, t, n);
    }
  }
  function iL(e, t) {
    {
      var n = oL(e, t);
      if (n)
        return;
      for (var r = e; ; ) {
        switch (r.tag) {
          case T:
            t.add(r.stateNode);
            return;
          case x:
            t.add(r.stateNode.containerInfo);
            return;
          case E:
            t.add(r.stateNode.containerInfo);
            return;
        }
        if (r.return === null)
          throw new Error("Expected to reach root first.");
        r = r.return;
      }
    }
  }
  function oL(e, t) {
    for (var n = e, r = !1; ; ) {
      if (n.tag === T)
        r = !0, t.add(n.stateNode);
      else if (n.child !== null) {
        n.child.return = n, n = n.child;
        continue;
      }
      if (n === e)
        return r;
      for (; n.sibling === null; ) {
        if (n.return === null || n.return === e)
          return r;
        n = n.return;
      }
      n.sibling.return = n.return, n = n.sibling;
    }
    return !1;
  }
  var Ym;
  {
    Ym = !1;
    try {
      var IE = Object.preventExtensions({});
    } catch {
      Ym = !0;
    }
  }
  function lL(e, t, n, r) {
    this.tag = e, this.key = n, this.elementType = null, this.type = null, this.stateNode = null, this.return = null, this.child = null, this.sibling = null, this.index = 0, this.ref = null, this.pendingProps = t, this.memoizedProps = null, this.updateQueue = null, this.memoizedState = null, this.dependencies = null, this.mode = r, this.flags = Te, this.subtreeFlags = Te, this.deletions = null, this.lanes = K, this.childLanes = K, this.alternate = null, this.actualDuration = Number.NaN, this.actualStartTime = Number.NaN, this.selfBaseDuration = Number.NaN, this.treeBaseDuration = Number.NaN, this.actualDuration = 0, this.actualStartTime = -1, this.selfBaseDuration = 0, this.treeBaseDuration = 0, this._debugSource = null, this._debugOwner = null, this._debugNeedsRemount = !1, this._debugHookTypes = null, !Ym && typeof Object.preventExtensions == "function" && Object.preventExtensions(this);
  }
  var fr = function(e, t, n, r) {
    return new lL(e, t, n, r);
  };
  function Wm(e) {
    var t = e.prototype;
    return !!(t && t.isReactComponent);
  }
  function uL(e) {
    return typeof e == "function" && !Wm(e) && e.defaultProps === void 0;
  }
  function sL(e) {
    if (typeof e == "function")
      return Wm(e) ? S : b;
    if (e != null) {
      var t = e.$$typeof;
      if (t === J)
        return Y;
      if (t === Qe)
        return ne;
    }
    return R;
  }
  function Eo(e, t) {
    var n = e.alternate;
    n === null ? (n = fr(e.tag, t, e.key, e.mode), n.elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n._debugSource = e._debugSource, n._debugOwner = e._debugOwner, n._debugHookTypes = e._debugHookTypes, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = Te, n.subtreeFlags = Te, n.deletions = null, n.actualDuration = 0, n.actualStartTime = -1), n.flags = e.flags & ka, n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue;
    var r = e.dependencies;
    switch (n.dependencies = r === null ? null : {
      lanes: r.lanes,
      firstContext: r.firstContext
    }, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n.selfBaseDuration = e.selfBaseDuration, n.treeBaseDuration = e.treeBaseDuration, n._debugNeedsRemount = e._debugNeedsRemount, n.tag) {
      case R:
      case b:
      case Z:
        n.type = Ml(e.type);
        break;
      case S:
        n.type = $m(e.type);
        break;
      case Y:
        n.type = Im(e.type);
        break;
    }
    return n;
  }
  function cL(e, t) {
    e.flags &= ka | It;
    var n = e.alternate;
    if (n === null)
      e.childLanes = K, e.lanes = t, e.child = null, e.subtreeFlags = Te, e.memoizedProps = null, e.memoizedState = null, e.updateQueue = null, e.dependencies = null, e.stateNode = null, e.selfBaseDuration = 0, e.treeBaseDuration = 0;
    else {
      e.childLanes = n.childLanes, e.lanes = n.lanes, e.child = n.child, e.subtreeFlags = Te, e.deletions = null, e.memoizedProps = n.memoizedProps, e.memoizedState = n.memoizedState, e.updateQueue = n.updateQueue, e.type = n.type;
      var r = n.dependencies;
      e.dependencies = r === null ? null : {
        lanes: r.lanes,
        firstContext: r.firstContext
      }, e.selfBaseDuration = n.selfBaseDuration, e.treeBaseDuration = n.treeBaseDuration;
    }
    return e;
  }
  function fL(e, t, n) {
    var r;
    return e === of ? (r = Ye, t === !0 && (r |= Mt, r |= aa)) : r = Re, Ur && (r |= ut), fr(E, null, null, r);
  }
  function Gm(e, t, n, r, i, l) {
    var f = R, p = e;
    if (typeof e == "function")
      Wm(e) ? (f = S, p = $m(p)) : p = Ml(p);
    else if (typeof e == "string")
      f = T;
    else
      e:
        switch (e) {
          case ea:
            return Oi(n.children, i, l, t);
          case Bi:
            f = $, i |= Mt, (i & Ye) !== Re && (i |= aa);
            break;
          case Ja:
            return dL(n, i, l, t);
          case we:
            return pL(n, i, l, t);
          case Be:
            return vL(n, i, l, t);
          case gt:
            return BE(n, i, l, t);
          case xt:
          case ze:
          case Dn:
          case ta:
          case Kt:
          default: {
            if (typeof e == "object" && e !== null)
              switch (e.$$typeof) {
                case _:
                  f = F;
                  break e;
                case q:
                  f = U;
                  break e;
                case J:
                  f = Y, p = Im(p);
                  break e;
                case Qe:
                  f = ne;
                  break e;
                case xe:
                  f = ve, p = null;
                  break e;
              }
            var m = "";
            {
              (e === void 0 || typeof e == "object" && e !== null && Object.keys(e).length === 0) && (m += " You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports.");
              var C = r ? Pe(r) : null;
              C && (m += `

Check the render method of \`` + C + "`.");
            }
            throw new Error("Element type is invalid: expected a string (for built-in components) or a class/function (for composite components) " + ("but got: " + (e == null ? e : typeof e) + "." + m));
          }
        }
    var w = fr(f, n, t, i);
    return w.elementType = e, w.type = p, w.lanes = l, w._debugOwner = r, w;
  }
  function Xm(e, t, n) {
    var r = null;
    r = e._owner;
    var i = e.type, l = e.key, f = e.props, p = Gm(i, l, f, r, t, n);
    return p._debugSource = e._source, p._debugOwner = e._owner, p;
  }
  function Oi(e, t, n, r) {
    var i = fr(L, e, r, t);
    return i.lanes = n, i;
  }
  function dL(e, t, n, r) {
    typeof e.id != "string" && c('Profiler must specify an "id" of type `string` as a prop. Received the type `%s` instead.', typeof e.id);
    var i = fr(X, e, r, t | ut);
    return i.elementType = Ja, i.lanes = n, i.stateNode = {
      effectDuration: 0,
      passiveEffectDuration: 0
    }, i;
  }
  function pL(e, t, n, r) {
    var i = fr(W, e, r, t);
    return i.elementType = we, i.lanes = n, i;
  }
  function vL(e, t, n, r) {
    var i = fr(Ee, e, r, t);
    return i.elementType = Be, i.lanes = n, i;
  }
  function BE(e, t, n, r) {
    var i = fr(fe, e, r, t);
    i.elementType = gt, i.lanes = n;
    var l = {
      isHidden: !1
    };
    return i.stateNode = l, i;
  }
  function Km(e, t, n) {
    var r = fr(M, e, null, t);
    return r.lanes = n, r;
  }
  function hL() {
    var e = fr(T, null, null, Re);
    return e.elementType = "DELETED", e;
  }
  function mL(e) {
    var t = fr(he, null, null, Re);
    return t.stateNode = e, t;
  }
  function qm(e, t, n) {
    var r = e.children !== null ? e.children : [], i = fr(x, r, e.key, t);
    return i.lanes = n, i.stateNode = {
      containerInfo: e.containerInfo,
      pendingChildren: null,
      // Used by persistent updates
      implementation: e.implementation
    }, i;
  }
  function VE(e, t) {
    return e === null && (e = fr(R, null, null, Re)), e.tag = t.tag, e.key = t.key, e.elementType = t.elementType, e.type = t.type, e.stateNode = t.stateNode, e.return = t.return, e.child = t.child, e.sibling = t.sibling, e.index = t.index, e.ref = t.ref, e.pendingProps = t.pendingProps, e.memoizedProps = t.memoizedProps, e.updateQueue = t.updateQueue, e.memoizedState = t.memoizedState, e.dependencies = t.dependencies, e.mode = t.mode, e.flags = t.flags, e.subtreeFlags = t.subtreeFlags, e.deletions = t.deletions, e.lanes = t.lanes, e.childLanes = t.childLanes, e.alternate = t.alternate, e.actualDuration = t.actualDuration, e.actualStartTime = t.actualStartTime, e.selfBaseDuration = t.selfBaseDuration, e.treeBaseDuration = t.treeBaseDuration, e._debugSource = t._debugSource, e._debugOwner = t._debugOwner, e._debugNeedsRemount = t._debugNeedsRemount, e._debugHookTypes = t._debugHookTypes, e;
  }
  function yL(e, t, n, r, i) {
    this.tag = t, this.containerInfo = e, this.pendingChildren = null, this.current = null, this.pingCache = null, this.finishedWork = null, this.timeoutHandle = Av, this.context = null, this.pendingContext = null, this.callbackNode = null, this.callbackPriority = cn, this.eventTimes = ev(K), this.expirationTimes = ev(bt), this.pendingLanes = K, this.suspendedLanes = K, this.pingedLanes = K, this.expiredLanes = K, this.mutableReadLanes = K, this.finishedLanes = K, this.entangledLanes = K, this.entanglements = ev(K), this.identifierPrefix = r, this.onRecoverableError = i, this.mutableSourceEagerHydrationData = null, this.effectDuration = 0, this.passiveEffectDuration = 0;
    {
      this.memoizedUpdaters = /* @__PURE__ */ new Set();
      for (var l = this.pendingUpdatersLaneMap = [], f = 0; f < Ap; f++)
        l.push(/* @__PURE__ */ new Set());
    }
    switch (t) {
      case of:
        this._debugRootType = n ? "hydrateRoot()" : "createRoot()";
        break;
      case yi:
        this._debugRootType = n ? "hydrate()" : "render()";
        break;
    }
  }
  function YE(e, t, n, r, i, l, f, p, m, C) {
    var w = new yL(e, t, n, p, m), N = fL(t, l);
    w.current = N, N.stateNode = w;
    {
      var A = {
        element: r,
        isDehydrated: n,
        cache: null,
        // not enabled yet
        transitions: null,
        pendingSuspenseBoundaries: null
      };
      N.memoizedState = A;
    }
    return sh(N), w;
  }
  var Qm = "18.3.1";
  function gL(e, t, n) {
    var r = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : null;
    return pn(r), {
      // This tag allow us to uniquely identify this as a React Portal
      $$typeof: kr,
      key: r == null ? null : "" + r,
      children: e,
      containerInfo: t,
      implementation: n
    };
  }
  var Zm, Jm;
  Zm = !1, Jm = {};
  function WE(e) {
    if (!e)
      return cr;
    var t = Bo(e), n = eO(t);
    if (t.tag === S) {
      var r = t.type;
      if (la(r))
        return bS(t, r, n);
    }
    return n;
  }
  function bL(e, t) {
    {
      var n = Bo(e);
      if (n === void 0) {
        if (typeof e.render == "function")
          throw new Error("Unable to find node on an unmounted component.");
        var r = Object.keys(e).join(",");
        throw new Error("Argument appears to not be a ReactComponent. Keys: " + r);
      }
      var i = Bg(n);
      if (i === null)
        return null;
      if (i.mode & Mt) {
        var l = Pe(n) || "Component";
        if (!Jm[l]) {
          Jm[l] = !0;
          var f = _n;
          try {
            Tt(i), n.mode & Mt ? c("%s is deprecated in StrictMode. %s was passed an instance of %s which is inside StrictMode. Instead, add a ref directly to the element you want to reference. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-find-node", t, t, l) : c("%s is deprecated in StrictMode. %s was passed an instance of %s which renders StrictMode children. Instead, add a ref directly to the element you want to reference. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-find-node", t, t, l);
          } finally {
            f ? Tt(f) : ln();
          }
        }
      }
      return i.stateNode;
    }
  }
  function GE(e, t, n, r, i, l, f, p) {
    var m = !1, C = null;
    return YE(e, t, m, C, n, r, i, l, f);
  }
  function XE(e, t, n, r, i, l, f, p, m, C) {
    var w = !0, N = YE(n, r, w, e, i, l, f, p, m);
    N.context = WE(null);
    var A = N.current, j = In(), H = _i(A), B = Ba(j, H);
    return B.callback = t ?? null, Si(A, B, H), TN(N, H, j), N;
  }
  function Ns(e, t, n, r) {
    GT(t, e);
    var i = t.current, l = In(), f = _i(i);
    p1(f);
    var p = WE(n);
    t.context === null ? t.context = p : t.pendingContext = p, Yi && _n !== null && !Zm && (Zm = !0, c(`Render methods should be a pure function of props and state; triggering nested component updates from render is not allowed. If necessary, trigger nested updates in componentDidUpdate.

Check the render method of %s.`, Pe(_n) || "Unknown"));
    var m = Ba(l, f);
    m.payload = {
      element: e
    }, r = r === void 0 ? null : r, r !== null && (typeof r != "function" && c("render(...): Expected the last optional `callback` argument to be a function. Instead received: %s.", r), m.callback = r);
    var C = Si(i, m, f);
    return C !== null && (rn(C, i, f, l), Cf(C, i, f)), f;
  }
  function cd(e) {
    var t = e.current;
    if (!t.child)
      return null;
    switch (t.child.tag) {
      case T:
        return t.child.stateNode;
      default:
        return t.child.stateNode;
    }
  }
  function SL(e) {
    switch (e.tag) {
      case E: {
        var t = e.stateNode;
        if (Mc(t)) {
          var n = E1(t);
          ON(t, n);
        }
        break;
      }
      case W: {
        Ga(function() {
          var i = Qn(e, Ne);
          if (i !== null) {
            var l = In();
            rn(i, e, Ne, l);
          }
        });
        var r = Ne;
        ey(e, r);
        break;
      }
    }
  }
  function KE(e, t) {
    var n = e.memoizedState;
    n !== null && n.dehydrated !== null && (n.retryLane = _1(n.retryLane, t));
  }
  function ey(e, t) {
    KE(e, t);
    var n = e.alternate;
    n && KE(n, t);
  }
  function CL(e) {
    if (e.tag === W) {
      var t = yu, n = Qn(e, t);
      if (n !== null) {
        var r = In();
        rn(n, e, t, r);
      }
      ey(e, t);
    }
  }
  function EL(e) {
    if (e.tag === W) {
      var t = _i(e), n = Qn(e, t);
      if (n !== null) {
        var r = In();
        rn(n, e, t, r);
      }
      ey(e, t);
    }
  }
  function qE(e) {
    var t = FT(e);
    return t === null ? null : t.stateNode;
  }
  var QE = function(e) {
    return null;
  };
  function RL(e) {
    return QE(e);
  }
  var ZE = function(e) {
    return !1;
  };
  function wL(e) {
    return ZE(e);
  }
  var JE = null, eR = null, tR = null, nR = null, rR = null, aR = null, iR = null, oR = null, lR = null;
  {
    var uR = function(e, t, n) {
      var r = t[n], i = tt(e) ? e.slice() : He({}, e);
      return n + 1 === t.length ? (tt(i) ? i.splice(r, 1) : delete i[r], i) : (i[r] = uR(e[r], t, n + 1), i);
    }, sR = function(e, t) {
      return uR(e, t, 0);
    }, cR = function(e, t, n, r) {
      var i = t[r], l = tt(e) ? e.slice() : He({}, e);
      if (r + 1 === t.length) {
        var f = n[r];
        l[f] = l[i], tt(l) ? l.splice(i, 1) : delete l[i];
      } else
        l[i] = cR(
          // $FlowFixMe number or string is fine here
          e[i],
          t,
          n,
          r + 1
        );
      return l;
    }, fR = function(e, t, n) {
      if (t.length !== n.length) {
        v("copyWithRename() expects paths of the same length");
        return;
      } else
        for (var r = 0; r < n.length - 1; r++)
          if (t[r] !== n[r]) {
            v("copyWithRename() expects paths to be the same except for the deepest key");
            return;
          }
      return cR(e, t, n, 0);
    }, dR = function(e, t, n, r) {
      if (n >= t.length)
        return r;
      var i = t[n], l = tt(e) ? e.slice() : He({}, e);
      return l[i] = dR(e[i], t, n + 1, r), l;
    }, pR = function(e, t, n) {
      return dR(e, t, 0, n);
    }, ty = function(e, t) {
      for (var n = e.memoizedState; n !== null && t > 0; )
        n = n.next, t--;
      return n;
    };
    JE = function(e, t, n, r) {
      var i = ty(e, t);
      if (i !== null) {
        var l = pR(i.memoizedState, n, r);
        i.memoizedState = l, i.baseState = l, e.memoizedProps = He({}, e.memoizedProps);
        var f = Qn(e, Ne);
        f !== null && rn(f, e, Ne, bt);
      }
    }, eR = function(e, t, n) {
      var r = ty(e, t);
      if (r !== null) {
        var i = sR(r.memoizedState, n);
        r.memoizedState = i, r.baseState = i, e.memoizedProps = He({}, e.memoizedProps);
        var l = Qn(e, Ne);
        l !== null && rn(l, e, Ne, bt);
      }
    }, tR = function(e, t, n, r) {
      var i = ty(e, t);
      if (i !== null) {
        var l = fR(i.memoizedState, n, r);
        i.memoizedState = l, i.baseState = l, e.memoizedProps = He({}, e.memoizedProps);
        var f = Qn(e, Ne);
        f !== null && rn(f, e, Ne, bt);
      }
    }, nR = function(e, t, n) {
      e.pendingProps = pR(e.memoizedProps, t, n), e.alternate && (e.alternate.pendingProps = e.pendingProps);
      var r = Qn(e, Ne);
      r !== null && rn(r, e, Ne, bt);
    }, rR = function(e, t) {
      e.pendingProps = sR(e.memoizedProps, t), e.alternate && (e.alternate.pendingProps = e.pendingProps);
      var n = Qn(e, Ne);
      n !== null && rn(n, e, Ne, bt);
    }, aR = function(e, t, n) {
      e.pendingProps = fR(e.memoizedProps, t, n), e.alternate && (e.alternate.pendingProps = e.pendingProps);
      var r = Qn(e, Ne);
      r !== null && rn(r, e, Ne, bt);
    }, iR = function(e) {
      var t = Qn(e, Ne);
      t !== null && rn(t, e, Ne, bt);
    }, oR = function(e) {
      QE = e;
    }, lR = function(e) {
      ZE = e;
    };
  }
  function xL(e) {
    var t = Bg(e);
    return t === null ? null : t.stateNode;
  }
  function TL(e) {
    return null;
  }
  function DL() {
    return _n;
  }
  function _L(e) {
    var t = e.findFiberByHostInstance, n = u.ReactCurrentDispatcher;
    return WT({
      bundleType: e.bundleType,
      version: e.version,
      rendererPackageName: e.rendererPackageName,
      rendererConfig: e.rendererConfig,
      overrideHookState: JE,
      overrideHookStateDeletePath: eR,
      overrideHookStateRenamePath: tR,
      overrideProps: nR,
      overridePropsDeletePath: rR,
      overridePropsRenamePath: aR,
      setErrorHandler: oR,
      setSuspenseHandler: lR,
      scheduleUpdate: iR,
      currentDispatcherRef: n,
      findHostInstanceByFiber: xL,
      findFiberByHostInstance: t || TL,
      // React Refresh
      findHostInstancesForRefresh: aL,
      scheduleRefresh: nL,
      scheduleRoot: rL,
      setRefreshHandler: tL,
      // Enables DevTools to append owner stacks to error messages in DEV mode.
      getCurrentFiber: DL,
      // Enables DevTools to detect reconciler version rather than renderer version
      // which may not match for third party renderers.
      reconcilerVersion: Qm
    });
  }
  var vR = typeof reportError == "function" ? (
    // In modern browsers, reportError will dispatch an error event,
    // emulating an uncaught JavaScript error.
    reportError
  ) : function(e) {
    console.error(e);
  };
  function ny(e) {
    this._internalRoot = e;
  }
  fd.prototype.render = ny.prototype.render = function(e) {
    var t = this._internalRoot;
    if (t === null)
      throw new Error("Cannot update an unmounted root.");
    {
      typeof arguments[1] == "function" ? c("render(...): does not support the second callback argument. To execute a side effect after rendering, declare it in a component body with useEffect().") : dd(arguments[1]) ? c("You passed a container to the second argument of root.render(...). You don't need to pass it again since you already passed it to create the root.") : typeof arguments[1] < "u" && c("You passed a second argument to root.render(...) but it only accepts one argument.");
      var n = t.containerInfo;
      if (n.nodeType !== $t) {
        var r = qE(t.current);
        r && r.parentNode !== n && c("render(...): It looks like the React-rendered content of the root container was removed without using React. This is not supported and will cause errors. Instead, call root.unmount() to empty a root's container.");
      }
    }
    Ns(e, t, null, null);
  }, fd.prototype.unmount = ny.prototype.unmount = function() {
    typeof arguments[0] == "function" && c("unmount(...): does not support a callback argument. To execute a side effect after rendering, declare it in a component body with useEffect().");
    var e = this._internalRoot;
    if (e !== null) {
      this._internalRoot = null;
      var t = e.containerInfo;
      TE() && c("Attempted to synchronously unmount a root while React was already rendering. React cannot finish unmounting the root until the current render has completed, which may lead to a race condition."), Ga(function() {
        Ns(null, e, null, null);
      }), vS(t);
    }
  };
  function ML(e, t) {
    if (!dd(e))
      throw new Error("createRoot(...): Target container is not a DOM element.");
    hR(e);
    var n = !1, r = !1, i = "", l = vR;
    t != null && (t.hydrate ? v("hydrate through createRoot is deprecated. Use ReactDOMClient.hydrateRoot(container, <App />) instead.") : typeof t == "object" && t !== null && t.$$typeof === Lr && c(`You passed a JSX element to createRoot. You probably meant to call root.render instead. Example usage:

  let root = createRoot(domContainer);
  root.render(<App />);`), t.unstable_strictMode === !0 && (n = !0), t.identifierPrefix !== void 0 && (i = t.identifierPrefix), t.onRecoverableError !== void 0 && (l = t.onRecoverableError), t.transitionCallbacks !== void 0 && t.transitionCallbacks);
    var f = GE(e, of, null, n, r, i, l);
    Zc(f.current, e);
    var p = e.nodeType === $t ? e.parentNode : e;
    return Fu(p), new ny(f);
  }
  function fd(e) {
    this._internalRoot = e;
  }
  function OL(e) {
    e && Y1(e);
  }
  fd.prototype.unstable_scheduleHydration = OL;
  function AL(e, t, n) {
    if (!dd(e))
      throw new Error("hydrateRoot(...): Target container is not a DOM element.");
    hR(e), t === void 0 && c("Must provide initial children as second argument to hydrateRoot. Example usage: hydrateRoot(domContainer, <App />)");
    var r = n ?? null, i = n != null && n.hydratedSources || null, l = !1, f = !1, p = "", m = vR;
    n != null && (n.unstable_strictMode === !0 && (l = !0), n.identifierPrefix !== void 0 && (p = n.identifierPrefix), n.onRecoverableError !== void 0 && (m = n.onRecoverableError));
    var C = XE(t, null, e, of, r, l, f, p, m);
    if (Zc(C.current, e), Fu(e), i)
      for (var w = 0; w < i.length; w++) {
        var N = i[w];
        PO(C, N);
      }
    return new fd(C);
  }
  function dd(e) {
    return !!(e && (e.nodeType === Kn || e.nodeType === Oa || e.nodeType === sp || !ft));
  }
  function Ls(e) {
    return !!(e && (e.nodeType === Kn || e.nodeType === Oa || e.nodeType === sp || e.nodeType === $t && e.nodeValue === " react-mount-point-unstable "));
  }
  function hR(e) {
    e.nodeType === Kn && e.tagName && e.tagName.toUpperCase() === "BODY" && c("createRoot(): Creating roots directly with document.body is discouraged, since its children are often manipulated by third-party scripts and browser extensions. This may lead to subtle reconciliation issues. Try using a container element created for your app."), Ku(e) && (e._reactRootContainer ? c("You are calling ReactDOMClient.createRoot() on a container that was previously passed to ReactDOM.render(). This is not supported.") : c("You are calling ReactDOMClient.createRoot() on a container that has already been passed to createRoot() before. Instead, call root.render() on the existing root instead if you want to update it."));
  }
  var NL = u.ReactCurrentOwner, mR;
  mR = function(e) {
    if (e._reactRootContainer && e.nodeType !== $t) {
      var t = qE(e._reactRootContainer.current);
      t && t.parentNode !== e && c("render(...): It looks like the React-rendered content of this container was removed without using React. This is not supported and will cause errors. Instead, call ReactDOM.unmountComponentAtNode to empty a container.");
    }
    var n = !!e._reactRootContainer, r = ry(e), i = !!(r && hi(r));
    i && !n && c("render(...): Replacing React-rendered children with a new root component. If you intended to update the children of this node, you should instead have the existing children update their state and render the new components instead of calling ReactDOM.render."), e.nodeType === Kn && e.tagName && e.tagName.toUpperCase() === "BODY" && c("render(): Rendering components directly into document.body is discouraged, since its children are often manipulated by third-party scripts and browser extensions. This may lead to subtle reconciliation issues. Try rendering into a container element created for your app.");
  };
  function ry(e) {
    return e ? e.nodeType === Oa ? e.documentElement : e.firstChild : null;
  }
  function yR() {
  }
  function LL(e, t, n, r, i) {
    if (i) {
      if (typeof r == "function") {
        var l = r;
        r = function() {
          var A = cd(f);
          l.call(A);
        };
      }
      var f = XE(
        t,
        r,
        e,
        yi,
        null,
        // hydrationCallbacks
        !1,
        // isStrictMode
        !1,
        // concurrentUpdatesByDefaultOverride,
        "",
        // identifierPrefix
        yR
      );
      e._reactRootContainer = f, Zc(f.current, e);
      var p = e.nodeType === $t ? e.parentNode : e;
      return Fu(p), Ga(), f;
    } else {
      for (var m; m = e.lastChild; )
        e.removeChild(m);
      if (typeof r == "function") {
        var C = r;
        r = function() {
          var A = cd(w);
          C.call(A);
        };
      }
      var w = GE(
        e,
        yi,
        null,
        // hydrationCallbacks
        !1,
        // isStrictMode
        !1,
        // concurrentUpdatesByDefaultOverride,
        "",
        // identifierPrefix
        yR
      );
      e._reactRootContainer = w, Zc(w.current, e);
      var N = e.nodeType === $t ? e.parentNode : e;
      return Fu(N), Ga(function() {
        Ns(t, w, n, r);
      }), w;
    }
  }
  function kL(e, t) {
    e !== null && typeof e != "function" && c("%s(...): Expected the last optional `callback` argument to be a function. Instead received: %s.", t, e);
  }
  function pd(e, t, n, r, i) {
    mR(n), kL(i === void 0 ? null : i, "render");
    var l = n._reactRootContainer, f;
    if (!l)
      f = LL(n, t, e, i, r);
    else {
      if (f = l, typeof i == "function") {
        var p = i;
        i = function() {
          var m = cd(f);
          p.call(m);
        };
      }
      Ns(t, f, e, i);
    }
    return cd(f);
  }
  var gR = !1;
  function PL(e) {
    {
      gR || (gR = !0, c("findDOMNode is deprecated and will be removed in the next major release. Instead, add a ref directly to the element you want to reference. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-find-node"));
      var t = NL.current;
      if (t !== null && t.stateNode !== null) {
        var n = t.stateNode._warnedAboutRefsInRender;
        n || c("%s is accessing findDOMNode inside its render(). render() should be a pure function of props and state. It should never access something that requires stale data from the previous render, such as refs. Move this logic to componentDidMount and componentDidUpdate instead.", Ze(t.type) || "A component"), t.stateNode._warnedAboutRefsInRender = !0;
      }
    }
    return e == null ? null : e.nodeType === Kn ? e : bL(e, "findDOMNode");
  }
  function UL(e, t, n) {
    if (c("ReactDOM.hydrate is no longer supported in React 18. Use hydrateRoot instead. Until you switch to the new API, your app will behave as if it's running React 17. Learn more: https://reactjs.org/link/switch-to-createroot"), !Ls(t))
      throw new Error("Target container is not a DOM element.");
    {
      var r = Ku(t) && t._reactRootContainer === void 0;
      r && c("You are calling ReactDOM.hydrate() on a container that was previously passed to ReactDOMClient.createRoot(). This is not supported. Did you mean to call hydrateRoot(container, element)?");
    }
    return pd(null, e, t, !0, n);
  }
  function jL(e, t, n) {
    if (c("ReactDOM.render is no longer supported in React 18. Use createRoot instead. Until you switch to the new API, your app will behave as if it's running React 17. Learn more: https://reactjs.org/link/switch-to-createroot"), !Ls(t))
      throw new Error("Target container is not a DOM element.");
    {
      var r = Ku(t) && t._reactRootContainer === void 0;
      r && c("You are calling ReactDOM.render() on a container that was previously passed to ReactDOMClient.createRoot(). This is not supported. Did you mean to call root.render(element)?");
    }
    return pd(null, e, t, !1, n);
  }
  function FL(e, t, n, r) {
    if (c("ReactDOM.unstable_renderSubtreeIntoContainer() is no longer supported in React 18. Consider using a portal instead. Until you switch to the createRoot API, your app will behave as if it's running React 17. Learn more: https://reactjs.org/link/switch-to-createroot"), !Ls(n))
      throw new Error("Target container is not a DOM element.");
    if (e == null || !AT(e))
      throw new Error("parentComponent must be a valid React Component");
    return pd(e, t, n, !1, r);
  }
  var bR = !1;
  function zL(e) {
    if (bR || (bR = !0, c("unmountComponentAtNode is deprecated and will be removed in the next major release. Switch to the createRoot API. Learn more: https://reactjs.org/link/switch-to-createroot")), !Ls(e))
      throw new Error("unmountComponentAtNode(...): Target container is not a DOM element.");
    {
      var t = Ku(e) && e._reactRootContainer === void 0;
      t && c("You are calling ReactDOM.unmountComponentAtNode() on a container that was previously passed to ReactDOMClient.createRoot(). This is not supported. Did you mean to call root.unmount()?");
    }
    if (e._reactRootContainer) {
      {
        var n = ry(e), r = n && !hi(n);
        r && c("unmountComponentAtNode(): The node you're attempting to unmount was rendered by another copy of React.");
      }
      return Ga(function() {
        pd(null, null, e, !1, function() {
          e._reactRootContainer = null, vS(e);
        });
      }), !0;
    } else {
      {
        var i = ry(e), l = !!(i && hi(i)), f = e.nodeType === Kn && Ls(e.parentNode) && !!e.parentNode._reactRootContainer;
        l && c("unmountComponentAtNode(): The node you're attempting to unmount was rendered by React and is not a top-level container. %s", f ? "You may have accidentally passed in a React root node instead of its container." : "Instead, have the parent component update its state and rerender in order to remove this component.");
      }
      return !1;
    }
  }
  P1(SL), j1(CL), F1(EL), z1(jr), H1(N1), (typeof Map != "function" || // $FlowIssue Flow incorrectly thinks Map has no prototype
  Map.prototype == null || typeof Map.prototype.forEach != "function" || typeof Set != "function" || // $FlowIssue Flow incorrectly thinks Set has no prototype
  Set.prototype == null || typeof Set.prototype.clear != "function" || typeof Set.prototype.forEach != "function") && c("React depends on Map and Set built-in types. Make sure that you load a polyfill in older browsers. https://reactjs.org/link/react-polyfills"), ST($_), RT(km, AN, Ga);
  function HL(e, t) {
    var n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null;
    if (!dd(t))
      throw new Error("Target container is not a DOM element.");
    return gL(e, t, null, n);
  }
  function $L(e, t, n, r) {
    return FL(e, t, n, r);
  }
  var ay = {
    usingClientEntryPoint: !1,
    // Keep in sync with ReactTestUtils.js.
    // This is an array for better minification.
    Events: [hi, ol, Jc, Ag, Ng, km]
  };
  function IL(e, t) {
    return ay.usingClientEntryPoint || c('You are importing createRoot from "react-dom" which is not supported. You should instead import it from "react-dom/client".'), ML(e, t);
  }
  function BL(e, t, n) {
    return ay.usingClientEntryPoint || c('You are importing hydrateRoot from "react-dom" which is not supported. You should instead import it from "react-dom/client".'), AL(e, t, n);
  }
  function VL(e) {
    return TE() && c("flushSync was called from inside a lifecycle method. React cannot flush when React is already rendering. Consider moving this call to a scheduler task or micro task."), Ga(e);
  }
  var YL = _L({
    findFiberByHostInstance: oo,
    bundleType: 1,
    version: Qm,
    rendererPackageName: "react-dom"
  });
  if (!YL && yt && window.top === window.self && (navigator.userAgent.indexOf("Chrome") > -1 && navigator.userAgent.indexOf("Edge") === -1 || navigator.userAgent.indexOf("Firefox") > -1)) {
    var SR = window.location.protocol;
    /^(https?|file):$/.test(SR) && console.info("%cDownload the React DevTools for a better development experience: https://reactjs.org/link/react-devtools" + (SR === "file:" ? `
You might need to use a local HTTP server (instead of file://): https://reactjs.org/link/react-devtools-faq` : ""), "font-weight:bold");
  }
  pr.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = ay, pr.createPortal = HL, pr.createRoot = IL, pr.findDOMNode = PL, pr.flushSync = VL, pr.hydrate = UL, pr.hydrateRoot = BL, pr.render = jL, pr.unmountComponentAtNode = zL, pr.unstable_batchedUpdates = km, pr.unstable_renderSubtreeIntoContainer = $L, pr.version = Qm, typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(new Error());
})();
JR.exports = pr;
var Ks = JR.exports;
const ZL = /* @__PURE__ */ Ay(Ks);
var Ny, CR = Ks;
{
  var ER = CR.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
  Ny = function(a, o) {
    ER.usingClientEntryPoint = !0;
    try {
      return CR.createRoot(a, o);
    } finally {
      ER.usingClientEntryPoint = !1;
    }
  };
}
let gy = null;
const JL = (a) => {
  gy = a;
}, RR = () => {
  if (!gy)
    throw new Error("CaidoAPI is not set yet!");
  return gy;
};
function ek(a, o) {
  typeof a == "function" ? a(o) : a != null && (a.current = o);
}
function qs(...a) {
  return (o) => a.forEach((u) => ek(u, o));
}
function At(...a) {
  return h.useCallback(qs(...a), a);
}
var ya = h.forwardRef((a, o) => {
  const { children: u, ...s } = a, d = h.Children.toArray(u), v = d.find(tk);
  if (v) {
    const c = v.props.children, g = d.map((b) => b === v ? h.Children.count(c) > 1 ? h.Children.only(null) : h.isValidElement(c) ? c.props.children : null : b);
    return /* @__PURE__ */ O.jsx(by, { ...s, ref: o, children: h.isValidElement(c) ? h.cloneElement(c, void 0, g) : null });
  }
  return /* @__PURE__ */ O.jsx(by, { ...s, ref: o, children: u });
});
ya.displayName = "Slot";
var by = h.forwardRef((a, o) => {
  const { children: u, ...s } = a;
  if (h.isValidElement(u)) {
    const d = rk(u);
    return h.cloneElement(u, {
      ...nk(s, u.props),
      // @ts-ignore
      ref: o ? qs(o, d) : d
    });
  }
  return h.Children.count(u) > 1 ? h.Children.only(null) : null;
});
by.displayName = "SlotClone";
var Ly = ({ children: a }) => /* @__PURE__ */ O.jsx(O.Fragment, { children: a });
function tk(a) {
  return h.isValidElement(a) && a.type === Ly;
}
function nk(a, o) {
  const u = { ...o };
  for (const s in o) {
    const d = a[s], v = o[s];
    /^on[A-Z]/.test(s) ? d && v ? u[s] = (...g) => {
      v(...g), d(...g);
    } : d && (u[s] = d) : s === "style" ? u[s] = { ...d, ...v } : s === "className" && (u[s] = [d, v].filter(Boolean).join(" "));
  }
  return { ...a, ...u };
}
function rk(a) {
  var s, d;
  let o = (s = Object.getOwnPropertyDescriptor(a.props, "ref")) == null ? void 0 : s.get, u = o && "isReactWarning" in o && o.isReactWarning;
  return u ? a.ref : (o = (d = Object.getOwnPropertyDescriptor(a, "ref")) == null ? void 0 : d.get, u = o && "isReactWarning" in o && o.isReactWarning, u ? a.props.ref : a.props.ref || a.ref);
}
var ak = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "span",
  "svg",
  "ul"
], St = ak.reduce((a, o) => {
  const u = h.forwardRef((s, d) => {
    const { asChild: v, ...c } = s, g = v ? ya : o;
    return typeof window < "u" && (window[Symbol.for("radix-ui")] = !0), /* @__PURE__ */ O.jsx(g, { ...c, ref: d });
  });
  return u.displayName = `Primitive.${o}`, { ...a, [o]: u };
}, {});
function n0(a, o) {
  a && Ks.flushSync(() => a.dispatchEvent(o));
}
var ik = "VisuallyHidden", ky = h.forwardRef(
  (a, o) => /* @__PURE__ */ O.jsx(
    St.span,
    {
      ...a,
      ref: o,
      style: {
        // See: https://github.com/twbs/bootstrap/blob/master/scss/mixins/_screen-reader.scss
        position: "absolute",
        border: 0,
        width: 1,
        height: 1,
        padding: 0,
        margin: -1,
        overflow: "hidden",
        clip: "rect(0, 0, 0, 0)",
        whiteSpace: "nowrap",
        wordWrap: "normal",
        ...a.style
      }
    }
  )
);
ky.displayName = ik;
var ok = ky, r0 = { exports: {} };
/*!
	Copyright (c) 2018 Jed Watson.
	Licensed under the MIT License (MIT), see
	http://jedwatson.github.io/classnames
*/
(function(a) {
  (function() {
    var o = {}.hasOwnProperty;
    function u() {
      for (var s = [], d = 0; d < arguments.length; d++) {
        var v = arguments[d];
        if (v) {
          var c = typeof v;
          if (c === "string" || c === "number")
            s.push(v);
          else if (Array.isArray(v)) {
            if (v.length) {
              var g = u.apply(null, v);
              g && s.push(g);
            }
          } else if (c === "object") {
            if (v.toString !== Object.prototype.toString && !v.toString.toString().includes("[native code]")) {
              s.push(v.toString());
              continue;
            }
            for (var b in v)
              o.call(v, b) && v[b] && s.push(b);
          }
        }
      }
      return s.join(" ");
    }
    a.exports ? (u.default = u, a.exports = u) : window.classNames = u;
  })();
})(r0);
var lk = r0.exports;
const je = /* @__PURE__ */ Ay(lk);
function zi(a, o = []) {
  let u = [];
  function s(v, c) {
    const g = h.createContext(c), b = u.length;
    u = [...u, c];
    function S(E) {
      const { scope: x, children: T, ...M } = E, L = (x == null ? void 0 : x[a][b]) || g, $ = h.useMemo(() => M, Object.values(M));
      return /* @__PURE__ */ O.jsx(L.Provider, { value: $, children: T });
    }
    function R(E, x) {
      const T = (x == null ? void 0 : x[a][b]) || g, M = h.useContext(T);
      if (M)
        return M;
      if (c !== void 0)
        return c;
      throw new Error(`\`${E}\` must be used within \`${v}\``);
    }
    return S.displayName = v + "Provider", [S, R];
  }
  const d = () => {
    const v = u.map((c) => h.createContext(c));
    return function(g) {
      const b = (g == null ? void 0 : g[a]) || v;
      return h.useMemo(
        () => ({ [`__scope${a}`]: { ...g, [a]: b } }),
        [g, b]
      );
    };
  };
  return d.scopeName = a, [s, uk(d, ...o)];
}
function uk(...a) {
  const o = a[0];
  if (a.length === 1)
    return o;
  const u = () => {
    const s = a.map((d) => ({
      useScope: d(),
      scopeName: d.scopeName
    }));
    return function(v) {
      const c = s.reduce((g, { useScope: b, scopeName: S }) => {
        const E = b(v)[`__scope${S}`];
        return { ...g, ...E };
      }, {});
      return h.useMemo(() => ({ [`__scope${o.scopeName}`]: c }), [c]);
    };
  };
  return u.scopeName = o.scopeName, u;
}
function Oe(a, o, { checkForDefaultPrevented: u = !0 } = {}) {
  return function(d) {
    if (a == null || a(d), u === !1 || !d.defaultPrevented)
      return o == null ? void 0 : o(d);
  };
}
var ki = globalThis != null && globalThis.document ? h.useLayoutEffect : () => {
}, sk = qL.useId || (() => {
}), ck = 0;
function Td(a) {
  const [o, u] = h.useState(sk());
  return ki(() => {
    a || u((s) => s ?? String(ck++));
  }, [a]), a || (o ? `radix-${o}` : "");
}
function dn(a) {
  const o = h.useRef(a);
  return h.useEffect(() => {
    o.current = a;
  }), h.useMemo(() => (...u) => {
    var s;
    return (s = o.current) == null ? void 0 : s.call(o, ...u);
  }, []);
}
function Py({
  prop: a,
  defaultProp: o,
  onChange: u = () => {
  }
}) {
  const [s, d] = fk({ defaultProp: o, onChange: u }), v = a !== void 0, c = v ? a : s, g = dn(u), b = h.useCallback(
    (S) => {
      if (v) {
        const E = typeof S == "function" ? S(a) : S;
        E !== a && g(E);
      } else
        d(S);
    },
    [v, a, d, g]
  );
  return [c, b];
}
function fk({
  defaultProp: a,
  onChange: o
}) {
  const u = h.useState(a), [s] = u, d = h.useRef(s), v = dn(o);
  return h.useEffect(() => {
    d.current !== s && (v(s), d.current = s);
  }, [s, d, v]), u;
}
function dk(a, o = globalThis == null ? void 0 : globalThis.document) {
  const u = dn(a);
  h.useEffect(() => {
    const s = (d) => {
      d.key === "Escape" && u(d);
    };
    return o.addEventListener("keydown", s, { capture: !0 }), () => o.removeEventListener("keydown", s, { capture: !0 });
  }, [u, o]);
}
var pk = "DismissableLayer", Sy = "dismissableLayer.update", vk = "dismissableLayer.pointerDownOutside", hk = "dismissableLayer.focusOutside", wR, a0 = h.createContext({
  layers: /* @__PURE__ */ new Set(),
  layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
  branches: /* @__PURE__ */ new Set()
}), Uy = h.forwardRef(
  (a, o) => {
    const {
      disableOutsidePointerEvents: u = !1,
      onEscapeKeyDown: s,
      onPointerDownOutside: d,
      onFocusOutside: v,
      onInteractOutside: c,
      onDismiss: g,
      ...b
    } = a, S = h.useContext(a0), [R, E] = h.useState(null), x = (R == null ? void 0 : R.ownerDocument) ?? (globalThis == null ? void 0 : globalThis.document), [, T] = h.useState({}), M = At(o, (Z) => E(Z)), L = Array.from(S.layers), [$] = [...S.layersWithOutsidePointerEventsDisabled].slice(-1), U = L.indexOf($), F = R ? L.indexOf(R) : -1, Y = S.layersWithOutsidePointerEventsDisabled.size > 0, X = F >= U, W = gk((Z) => {
      const ve = Z.target, me = [...S.branches].some((he) => he.contains(ve));
      !X || me || (d == null || d(Z), c == null || c(Z), Z.defaultPrevented || g == null || g());
    }, x), ne = bk((Z) => {
      const ve = Z.target;
      [...S.branches].some((he) => he.contains(ve)) || (v == null || v(Z), c == null || c(Z), Z.defaultPrevented || g == null || g());
    }, x);
    return dk((Z) => {
      F === S.layers.size - 1 && (s == null || s(Z), !Z.defaultPrevented && g && (Z.preventDefault(), g()));
    }, x), h.useEffect(() => {
      if (R)
        return u && (S.layersWithOutsidePointerEventsDisabled.size === 0 && (wR = x.body.style.pointerEvents, x.body.style.pointerEvents = "none"), S.layersWithOutsidePointerEventsDisabled.add(R)), S.layers.add(R), xR(), () => {
          u && S.layersWithOutsidePointerEventsDisabled.size === 1 && (x.body.style.pointerEvents = wR);
        };
    }, [R, x, u, S]), h.useEffect(() => () => {
      R && (S.layers.delete(R), S.layersWithOutsidePointerEventsDisabled.delete(R), xR());
    }, [R, S]), h.useEffect(() => {
      const Z = () => T({});
      return document.addEventListener(Sy, Z), () => document.removeEventListener(Sy, Z);
    }, []), /* @__PURE__ */ O.jsx(
      St.div,
      {
        ...b,
        ref: M,
        style: {
          pointerEvents: Y ? X ? "auto" : "none" : void 0,
          ...a.style
        },
        onFocusCapture: Oe(a.onFocusCapture, ne.onFocusCapture),
        onBlurCapture: Oe(a.onBlurCapture, ne.onBlurCapture),
        onPointerDownCapture: Oe(
          a.onPointerDownCapture,
          W.onPointerDownCapture
        )
      }
    );
  }
);
Uy.displayName = pk;
var mk = "DismissableLayerBranch", yk = h.forwardRef((a, o) => {
  const u = h.useContext(a0), s = h.useRef(null), d = At(o, s);
  return h.useEffect(() => {
    const v = s.current;
    if (v)
      return u.branches.add(v), () => {
        u.branches.delete(v);
      };
  }, [u.branches]), /* @__PURE__ */ O.jsx(St.div, { ...a, ref: d });
});
yk.displayName = mk;
function gk(a, o = globalThis == null ? void 0 : globalThis.document) {
  const u = dn(a), s = h.useRef(!1), d = h.useRef(() => {
  });
  return h.useEffect(() => {
    const v = (g) => {
      if (g.target && !s.current) {
        let b = function() {
          i0(
            vk,
            u,
            S,
            { discrete: !0 }
          );
        };
        const S = { originalEvent: g };
        g.pointerType === "touch" ? (o.removeEventListener("click", d.current), d.current = b, o.addEventListener("click", d.current, { once: !0 })) : b();
      } else
        o.removeEventListener("click", d.current);
      s.current = !1;
    }, c = window.setTimeout(() => {
      o.addEventListener("pointerdown", v);
    }, 0);
    return () => {
      window.clearTimeout(c), o.removeEventListener("pointerdown", v), o.removeEventListener("click", d.current);
    };
  }, [o, u]), {
    // ensures we check React component tree (not just DOM tree)
    onPointerDownCapture: () => s.current = !0
  };
}
function bk(a, o = globalThis == null ? void 0 : globalThis.document) {
  const u = dn(a), s = h.useRef(!1);
  return h.useEffect(() => {
    const d = (v) => {
      v.target && !s.current && i0(hk, u, { originalEvent: v }, {
        discrete: !1
      });
    };
    return o.addEventListener("focusin", d), () => o.removeEventListener("focusin", d);
  }, [o, u]), {
    onFocusCapture: () => s.current = !0,
    onBlurCapture: () => s.current = !1
  };
}
function xR() {
  const a = new CustomEvent(Sy);
  document.dispatchEvent(a);
}
function i0(a, o, u, { discrete: s }) {
  const d = u.originalEvent.target, v = new CustomEvent(a, { bubbles: !1, cancelable: !0, detail: u });
  o && d.addEventListener(a, o, { once: !0 }), s ? n0(d, v) : d.dispatchEvent(v);
}
var iy = "focusScope.autoFocusOnMount", oy = "focusScope.autoFocusOnUnmount", TR = { bubbles: !1, cancelable: !0 }, Sk = "FocusScope", o0 = h.forwardRef((a, o) => {
  const {
    loop: u = !1,
    trapped: s = !1,
    onMountAutoFocus: d,
    onUnmountAutoFocus: v,
    ...c
  } = a, [g, b] = h.useState(null), S = dn(d), R = dn(v), E = h.useRef(null), x = At(o, (L) => b(L)), T = h.useRef({
    paused: !1,
    pause() {
      this.paused = !0;
    },
    resume() {
      this.paused = !1;
    }
  }).current;
  h.useEffect(() => {
    if (s) {
      let L = function(Y) {
        if (T.paused || !g)
          return;
        const X = Y.target;
        g.contains(X) ? E.current = X : Ai(E.current, { select: !0 });
      }, $ = function(Y) {
        if (T.paused || !g)
          return;
        const X = Y.relatedTarget;
        X !== null && (g.contains(X) || Ai(E.current, { select: !0 }));
      }, U = function(Y) {
        if (document.activeElement === document.body)
          for (const W of Y)
            W.removedNodes.length > 0 && Ai(g);
      };
      document.addEventListener("focusin", L), document.addEventListener("focusout", $);
      const F = new MutationObserver(U);
      return g && F.observe(g, { childList: !0, subtree: !0 }), () => {
        document.removeEventListener("focusin", L), document.removeEventListener("focusout", $), F.disconnect();
      };
    }
  }, [s, g, T.paused]), h.useEffect(() => {
    if (g) {
      _R.add(T);
      const L = document.activeElement;
      if (!g.contains(L)) {
        const U = new CustomEvent(iy, TR);
        g.addEventListener(iy, S), g.dispatchEvent(U), U.defaultPrevented || (Ck(Tk(l0(g)), { select: !0 }), document.activeElement === L && Ai(g));
      }
      return () => {
        g.removeEventListener(iy, S), setTimeout(() => {
          const U = new CustomEvent(oy, TR);
          g.addEventListener(oy, R), g.dispatchEvent(U), U.defaultPrevented || Ai(L ?? document.body, { select: !0 }), g.removeEventListener(oy, R), _R.remove(T);
        }, 0);
      };
    }
  }, [g, S, R, T]);
  const M = h.useCallback(
    (L) => {
      if (!u && !s || T.paused)
        return;
      const $ = L.key === "Tab" && !L.altKey && !L.ctrlKey && !L.metaKey, U = document.activeElement;
      if ($ && U) {
        const F = L.currentTarget, [Y, X] = Ek(F);
        Y && X ? !L.shiftKey && U === X ? (L.preventDefault(), u && Ai(Y, { select: !0 })) : L.shiftKey && U === Y && (L.preventDefault(), u && Ai(X, { select: !0 })) : U === F && L.preventDefault();
      }
    },
    [u, s, T.paused]
  );
  return /* @__PURE__ */ O.jsx(St.div, { tabIndex: -1, ...c, ref: x, onKeyDown: M });
});
o0.displayName = Sk;
function Ck(a, { select: o = !1 } = {}) {
  const u = document.activeElement;
  for (const s of a)
    if (Ai(s, { select: o }), document.activeElement !== u)
      return;
}
function Ek(a) {
  const o = l0(a), u = DR(o, a), s = DR(o.reverse(), a);
  return [u, s];
}
function l0(a) {
  const o = [], u = document.createTreeWalker(a, NodeFilter.SHOW_ELEMENT, {
    acceptNode: (s) => {
      const d = s.tagName === "INPUT" && s.type === "hidden";
      return s.disabled || s.hidden || d ? NodeFilter.FILTER_SKIP : s.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }
  });
  for (; u.nextNode(); )
    o.push(u.currentNode);
  return o;
}
function DR(a, o) {
  for (const u of a)
    if (!Rk(u, { upTo: o }))
      return u;
}
function Rk(a, { upTo: o }) {
  if (getComputedStyle(a).visibility === "hidden")
    return !0;
  for (; a; ) {
    if (o !== void 0 && a === o)
      return !1;
    if (getComputedStyle(a).display === "none")
      return !0;
    a = a.parentElement;
  }
  return !1;
}
function wk(a) {
  return a instanceof HTMLInputElement && "select" in a;
}
function Ai(a, { select: o = !1 } = {}) {
  if (a && a.focus) {
    const u = document.activeElement;
    a.focus({ preventScroll: !0 }), a !== u && wk(a) && o && a.select();
  }
}
var _R = xk();
function xk() {
  let a = [];
  return {
    add(o) {
      const u = a[0];
      o !== u && (u == null || u.pause()), a = MR(a, o), a.unshift(o);
    },
    remove(o) {
      var u;
      a = MR(a, o), (u = a[0]) == null || u.resume();
    }
  };
}
function MR(a, o) {
  const u = [...a], s = u.indexOf(o);
  return s !== -1 && u.splice(s, 1), u;
}
function Tk(a) {
  return a.filter((o) => o.tagName !== "A");
}
var Dk = "Portal", u0 = h.forwardRef((a, o) => {
  var g;
  const { container: u, ...s } = a, [d, v] = h.useState(!1);
  ki(() => v(!0), []);
  const c = u || d && ((g = globalThis == null ? void 0 : globalThis.document) == null ? void 0 : g.body);
  return c ? ZL.createPortal(/* @__PURE__ */ O.jsx(St.div, { ...s, ref: o }), c) : null;
});
u0.displayName = Dk;
function _k(a, o) {
  return h.useReducer((u, s) => o[u][s] ?? u, a);
}
var Qr = (a) => {
  const { present: o, children: u } = a, s = Mk(o), d = typeof u == "function" ? u({ present: s.isPresent }) : h.Children.only(u), v = At(s.ref, Ok(d));
  return typeof u == "function" || s.isPresent ? h.cloneElement(d, { ref: v }) : null;
};
Qr.displayName = "Presence";
function Mk(a) {
  const [o, u] = h.useState(), s = h.useRef({}), d = h.useRef(a), v = h.useRef("none"), c = a ? "mounted" : "unmounted", [g, b] = _k(c, {
    mounted: {
      UNMOUNT: "unmounted",
      ANIMATION_OUT: "unmountSuspended"
    },
    unmountSuspended: {
      MOUNT: "mounted",
      ANIMATION_END: "unmounted"
    },
    unmounted: {
      MOUNT: "mounted"
    }
  });
  return h.useEffect(() => {
    const S = vd(s.current);
    v.current = g === "mounted" ? S : "none";
  }, [g]), ki(() => {
    const S = s.current, R = d.current;
    if (R !== a) {
      const x = v.current, T = vd(S);
      a ? b("MOUNT") : T === "none" || (S == null ? void 0 : S.display) === "none" ? b("UNMOUNT") : b(R && x !== T ? "ANIMATION_OUT" : "UNMOUNT"), d.current = a;
    }
  }, [a, b]), ki(() => {
    if (o) {
      const S = (E) => {
        const T = vd(s.current).includes(E.animationName);
        E.target === o && T && Ks.flushSync(() => b("ANIMATION_END"));
      }, R = (E) => {
        E.target === o && (v.current = vd(s.current));
      };
      return o.addEventListener("animationstart", R), o.addEventListener("animationcancel", S), o.addEventListener("animationend", S), () => {
        o.removeEventListener("animationstart", R), o.removeEventListener("animationcancel", S), o.removeEventListener("animationend", S);
      };
    } else
      b("ANIMATION_END");
  }, [o, b]), {
    isPresent: ["mounted", "unmountSuspended"].includes(g),
    ref: h.useCallback((S) => {
      S && (s.current = getComputedStyle(S)), u(S);
    }, [])
  };
}
function vd(a) {
  return (a == null ? void 0 : a.animationName) || "none";
}
function Ok(a) {
  var s, d;
  let o = (s = Object.getOwnPropertyDescriptor(a.props, "ref")) == null ? void 0 : s.get, u = o && "isReactWarning" in o && o.isReactWarning;
  return u ? a.ref : (o = (d = Object.getOwnPropertyDescriptor(a, "ref")) == null ? void 0 : d.get, u = o && "isReactWarning" in o && o.isReactWarning, u ? a.props.ref : a.props.ref || a.ref);
}
var ly = 0;
function Ak() {
  h.useEffect(() => {
    const a = document.querySelectorAll("[data-radix-focus-guard]");
    return document.body.insertAdjacentElement("afterbegin", a[0] ?? OR()), document.body.insertAdjacentElement("beforeend", a[1] ?? OR()), ly++, () => {
      ly === 1 && document.querySelectorAll("[data-radix-focus-guard]").forEach((o) => o.remove()), ly--;
    };
  }, []);
}
function OR() {
  const a = document.createElement("span");
  return a.setAttribute("data-radix-focus-guard", ""), a.tabIndex = 0, a.style.cssText = "outline: none; opacity: 0; position: fixed; pointer-events: none", a;
}
var ma = function() {
  return ma = Object.assign || function(o) {
    for (var u, s = 1, d = arguments.length; s < d; s++) {
      u = arguments[s];
      for (var v in u)
        Object.prototype.hasOwnProperty.call(u, v) && (o[v] = u[v]);
    }
    return o;
  }, ma.apply(this, arguments);
};
function s0(a, o) {
  var u = {};
  for (var s in a)
    Object.prototype.hasOwnProperty.call(a, s) && o.indexOf(s) < 0 && (u[s] = a[s]);
  if (a != null && typeof Object.getOwnPropertySymbols == "function")
    for (var d = 0, s = Object.getOwnPropertySymbols(a); d < s.length; d++)
      o.indexOf(s[d]) < 0 && Object.prototype.propertyIsEnumerable.call(a, s[d]) && (u[s[d]] = a[s[d]]);
  return u;
}
function Nk(a, o, u) {
  if (u || arguments.length === 2)
    for (var s = 0, d = o.length, v; s < d; s++)
      (v || !(s in o)) && (v || (v = Array.prototype.slice.call(o, 0, s)), v[s] = o[s]);
  return a.concat(v || Array.prototype.slice.call(o));
}
var Cd = "right-scroll-bar-position", Ed = "width-before-scroll-bar", Lk = "with-scroll-bars-hidden", kk = "--removed-body-scroll-bar-size";
function uy(a, o) {
  return typeof a == "function" ? a(o) : a && (a.current = o), a;
}
function Pk(a, o) {
  var u = h.useState(function() {
    return {
      // value
      value: a,
      // last callback
      callback: o,
      // "memoized" public interface
      facade: {
        get current() {
          return u.value;
        },
        set current(s) {
          var d = u.value;
          d !== s && (u.value = s, u.callback(s, d));
        }
      }
    };
  })[0];
  return u.callback = o, u.facade;
}
var Uk = typeof window < "u" ? h.useLayoutEffect : h.useEffect, AR = /* @__PURE__ */ new WeakMap();
function jk(a, o) {
  var u = Pk(null, function(s) {
    return a.forEach(function(d) {
      return uy(d, s);
    });
  });
  return Uk(function() {
    var s = AR.get(u);
    if (s) {
      var d = new Set(s), v = new Set(a), c = u.current;
      d.forEach(function(g) {
        v.has(g) || uy(g, null);
      }), v.forEach(function(g) {
        d.has(g) || uy(g, c);
      });
    }
    AR.set(u, a);
  }, [a]), u;
}
function Fk(a) {
  return a;
}
function zk(a, o) {
  o === void 0 && (o = Fk);
  var u = [], s = !1, d = {
    read: function() {
      if (s)
        throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
      return u.length ? u[u.length - 1] : a;
    },
    useMedium: function(v) {
      var c = o(v, s);
      return u.push(c), function() {
        u = u.filter(function(g) {
          return g !== c;
        });
      };
    },
    assignSyncMedium: function(v) {
      for (s = !0; u.length; ) {
        var c = u;
        u = [], c.forEach(v);
      }
      u = {
        push: function(g) {
          return v(g);
        },
        filter: function() {
          return u;
        }
      };
    },
    assignMedium: function(v) {
      s = !0;
      var c = [];
      if (u.length) {
        var g = u;
        u = [], g.forEach(v), c = u;
      }
      var b = function() {
        var R = c;
        c = [], R.forEach(v);
      }, S = function() {
        return Promise.resolve().then(b);
      };
      S(), u = {
        push: function(R) {
          c.push(R), S();
        },
        filter: function(R) {
          return c = c.filter(R), u;
        }
      };
    }
  };
  return d;
}
function Hk(a) {
  a === void 0 && (a = {});
  var o = zk(null);
  return o.options = ma({ async: !0, ssr: !1 }, a), o;
}
var c0 = function(a) {
  var o = a.sideCar, u = s0(a, ["sideCar"]);
  if (!o)
    throw new Error("Sidecar: please provide `sideCar` property to import the right car");
  var s = o.read();
  if (!s)
    throw new Error("Sidecar medium not found");
  return h.createElement(s, ma({}, u));
};
c0.isSideCarExport = !0;
function $k(a, o) {
  return a.useMedium(o), c0;
}
var f0 = Hk(), sy = function() {
}, Fd = h.forwardRef(function(a, o) {
  var u = h.useRef(null), s = h.useState({
    onScrollCapture: sy,
    onWheelCapture: sy,
    onTouchMoveCapture: sy
  }), d = s[0], v = s[1], c = a.forwardProps, g = a.children, b = a.className, S = a.removeScrollBar, R = a.enabled, E = a.shards, x = a.sideCar, T = a.noIsolation, M = a.inert, L = a.allowPinchZoom, $ = a.as, U = $ === void 0 ? "div" : $, F = a.gapMode, Y = s0(a, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noIsolation", "inert", "allowPinchZoom", "as", "gapMode"]), X = x, W = jk([u, o]), ne = ma(ma({}, Y), d);
  return h.createElement(
    h.Fragment,
    null,
    R && h.createElement(X, { sideCar: f0, removeScrollBar: S, shards: E, noIsolation: T, inert: M, setCallbacks: v, allowPinchZoom: !!L, lockRef: u, gapMode: F }),
    c ? h.cloneElement(h.Children.only(g), ma(ma({}, ne), { ref: W })) : h.createElement(U, ma({}, ne, { className: b, ref: W }), g)
  );
});
Fd.defaultProps = {
  enabled: !0,
  removeScrollBar: !0,
  inert: !1
};
Fd.classNames = {
  fullWidth: Ed,
  zeroRight: Cd
};
var Ik = function() {
  if (typeof __webpack_nonce__ < "u")
    return __webpack_nonce__;
};
function Bk() {
  if (!document)
    return null;
  var a = document.createElement("style");
  a.type = "text/css";
  var o = Ik();
  return o && a.setAttribute("nonce", o), a;
}
function Vk(a, o) {
  a.styleSheet ? a.styleSheet.cssText = o : a.appendChild(document.createTextNode(o));
}
function Yk(a) {
  var o = document.head || document.getElementsByTagName("head")[0];
  o.appendChild(a);
}
var Wk = function() {
  var a = 0, o = null;
  return {
    add: function(u) {
      a == 0 && (o = Bk()) && (Vk(o, u), Yk(o)), a++;
    },
    remove: function() {
      a--, !a && o && (o.parentNode && o.parentNode.removeChild(o), o = null);
    }
  };
}, Gk = function() {
  var a = Wk();
  return function(o, u) {
    h.useEffect(function() {
      return a.add(o), function() {
        a.remove();
      };
    }, [o && u]);
  };
}, d0 = function() {
  var a = Gk(), o = function(u) {
    var s = u.styles, d = u.dynamic;
    return a(s, d), null;
  };
  return o;
}, Xk = {
  left: 0,
  top: 0,
  right: 0,
  gap: 0
}, cy = function(a) {
  return parseInt(a || "", 10) || 0;
}, Kk = function(a) {
  var o = window.getComputedStyle(document.body), u = o[a === "padding" ? "paddingLeft" : "marginLeft"], s = o[a === "padding" ? "paddingTop" : "marginTop"], d = o[a === "padding" ? "paddingRight" : "marginRight"];
  return [cy(u), cy(s), cy(d)];
}, qk = function(a) {
  if (a === void 0 && (a = "margin"), typeof window > "u")
    return Xk;
  var o = Kk(a), u = document.documentElement.clientWidth, s = window.innerWidth;
  return {
    left: o[0],
    top: o[1],
    right: o[2],
    gap: Math.max(0, s - u + o[2] - o[0])
  };
}, Qk = d0(), Zk = function(a, o, u, s) {
  var d = a.left, v = a.top, c = a.right, g = a.gap;
  return u === void 0 && (u = "margin"), `
  .`.concat(Lk, ` {
   overflow: hidden `).concat(s, `;
   padding-right: `).concat(g, "px ").concat(s, `;
  }
  body {
    overflow: hidden `).concat(s, `;
    overscroll-behavior: contain;
    `).concat([
    o && "position: relative ".concat(s, ";"),
    u === "margin" && `
    padding-left: `.concat(d, `px;
    padding-top: `).concat(v, `px;
    padding-right: `).concat(c, `px;
    margin-left:0;
    margin-top:0;
    margin-right: `).concat(g, "px ").concat(s, `;
    `),
    u === "padding" && "padding-right: ".concat(g, "px ").concat(s, ";")
  ].filter(Boolean).join(""), `
  }
  
  .`).concat(Cd, ` {
    right: `).concat(g, "px ").concat(s, `;
  }
  
  .`).concat(Ed, ` {
    margin-right: `).concat(g, "px ").concat(s, `;
  }
  
  .`).concat(Cd, " .").concat(Cd, ` {
    right: 0 `).concat(s, `;
  }
  
  .`).concat(Ed, " .").concat(Ed, ` {
    margin-right: 0 `).concat(s, `;
  }
  
  body {
    `).concat(kk, ": ").concat(g, `px;
  }
`);
}, Jk = function(a) {
  var o = a.noRelative, u = a.noImportant, s = a.gapMode, d = s === void 0 ? "margin" : s, v = h.useMemo(function() {
    return qk(d);
  }, [d]);
  return h.createElement(Qk, { styles: Zk(v, !o, d, u ? "" : "!important") });
}, Cy = !1;
if (typeof window < "u")
  try {
    var hd = Object.defineProperty({}, "passive", {
      get: function() {
        return Cy = !0, !0;
      }
    });
    window.addEventListener("test", hd, hd), window.removeEventListener("test", hd, hd);
  } catch {
    Cy = !1;
  }
var Al = Cy ? { passive: !1 } : !1, eP = function(a) {
  return a.tagName === "TEXTAREA";
}, p0 = function(a, o) {
  var u = window.getComputedStyle(a);
  return (
    // not-not-scrollable
    u[o] !== "hidden" && // contains scroll inside self
    !(u.overflowY === u.overflowX && !eP(a) && u[o] === "visible")
  );
}, tP = function(a) {
  return p0(a, "overflowY");
}, nP = function(a) {
  return p0(a, "overflowX");
}, NR = function(a, o) {
  var u = o.ownerDocument, s = o;
  do {
    typeof ShadowRoot < "u" && s instanceof ShadowRoot && (s = s.host);
    var d = v0(a, s);
    if (d) {
      var v = h0(a, s), c = v[1], g = v[2];
      if (c > g)
        return !0;
    }
    s = s.parentNode;
  } while (s && s !== u.body);
  return !1;
}, rP = function(a) {
  var o = a.scrollTop, u = a.scrollHeight, s = a.clientHeight;
  return [
    o,
    u,
    s
  ];
}, aP = function(a) {
  var o = a.scrollLeft, u = a.scrollWidth, s = a.clientWidth;
  return [
    o,
    u,
    s
  ];
}, v0 = function(a, o) {
  return a === "v" ? tP(o) : nP(o);
}, h0 = function(a, o) {
  return a === "v" ? rP(o) : aP(o);
}, iP = function(a, o) {
  return a === "h" && o === "rtl" ? -1 : 1;
}, oP = function(a, o, u, s, d) {
  var v = iP(a, window.getComputedStyle(o).direction), c = v * s, g = u.target, b = o.contains(g), S = !1, R = c > 0, E = 0, x = 0;
  do {
    var T = h0(a, g), M = T[0], L = T[1], $ = T[2], U = L - $ - v * M;
    (M || U) && v0(a, g) && (E += U, x += M), g instanceof ShadowRoot ? g = g.host : g = g.parentNode;
  } while (
    // portaled content
    !b && g !== document.body || // self content
    b && (o.contains(g) || o === g)
  );
  return (R && (Math.abs(E) < 1 || !d) || !R && (Math.abs(x) < 1 || !d)) && (S = !0), S;
}, md = function(a) {
  return "changedTouches" in a ? [a.changedTouches[0].clientX, a.changedTouches[0].clientY] : [0, 0];
}, LR = function(a) {
  return [a.deltaX, a.deltaY];
}, kR = function(a) {
  return a && "current" in a ? a.current : a;
}, lP = function(a, o) {
  return a[0] === o[0] && a[1] === o[1];
}, uP = function(a) {
  return `
  .block-interactivity-`.concat(a, ` {pointer-events: none;}
  .allow-interactivity-`).concat(a, ` {pointer-events: all;}
`);
}, sP = 0, Nl = [];
function cP(a) {
  var o = h.useRef([]), u = h.useRef([0, 0]), s = h.useRef(), d = h.useState(sP++)[0], v = h.useState(d0)[0], c = h.useRef(a);
  h.useEffect(function() {
    c.current = a;
  }, [a]), h.useEffect(function() {
    if (a.inert) {
      document.body.classList.add("block-interactivity-".concat(d));
      var L = Nk([a.lockRef.current], (a.shards || []).map(kR), !0).filter(Boolean);
      return L.forEach(function($) {
        return $.classList.add("allow-interactivity-".concat(d));
      }), function() {
        document.body.classList.remove("block-interactivity-".concat(d)), L.forEach(function($) {
          return $.classList.remove("allow-interactivity-".concat(d));
        });
      };
    }
  }, [a.inert, a.lockRef.current, a.shards]);
  var g = h.useCallback(function(L, $) {
    if ("touches" in L && L.touches.length === 2)
      return !c.current.allowPinchZoom;
    var U = md(L), F = u.current, Y = "deltaX" in L ? L.deltaX : F[0] - U[0], X = "deltaY" in L ? L.deltaY : F[1] - U[1], W, ne = L.target, Z = Math.abs(Y) > Math.abs(X) ? "h" : "v";
    if ("touches" in L && Z === "h" && ne.type === "range")
      return !1;
    var ve = NR(Z, ne);
    if (!ve)
      return !0;
    if (ve ? W = Z : (W = Z === "v" ? "h" : "v", ve = NR(Z, ne)), !ve)
      return !1;
    if (!s.current && "changedTouches" in L && (Y || X) && (s.current = W), !W)
      return !0;
    var me = s.current || W;
    return oP(me, $, L, me === "h" ? Y : X, !0);
  }, []), b = h.useCallback(function(L) {
    var $ = L;
    if (!(!Nl.length || Nl[Nl.length - 1] !== v)) {
      var U = "deltaY" in $ ? LR($) : md($), F = o.current.filter(function(W) {
        return W.name === $.type && (W.target === $.target || $.target === W.shadowParent) && lP(W.delta, U);
      })[0];
      if (F && F.should) {
        $.cancelable && $.preventDefault();
        return;
      }
      if (!F) {
        var Y = (c.current.shards || []).map(kR).filter(Boolean).filter(function(W) {
          return W.contains($.target);
        }), X = Y.length > 0 ? g($, Y[0]) : !c.current.noIsolation;
        X && $.cancelable && $.preventDefault();
      }
    }
  }, []), S = h.useCallback(function(L, $, U, F) {
    var Y = { name: L, delta: $, target: U, should: F, shadowParent: fP(U) };
    o.current.push(Y), setTimeout(function() {
      o.current = o.current.filter(function(X) {
        return X !== Y;
      });
    }, 1);
  }, []), R = h.useCallback(function(L) {
    u.current = md(L), s.current = void 0;
  }, []), E = h.useCallback(function(L) {
    S(L.type, LR(L), L.target, g(L, a.lockRef.current));
  }, []), x = h.useCallback(function(L) {
    S(L.type, md(L), L.target, g(L, a.lockRef.current));
  }, []);
  h.useEffect(function() {
    return Nl.push(v), a.setCallbacks({
      onScrollCapture: E,
      onWheelCapture: E,
      onTouchMoveCapture: x
    }), document.addEventListener("wheel", b, Al), document.addEventListener("touchmove", b, Al), document.addEventListener("touchstart", R, Al), function() {
      Nl = Nl.filter(function(L) {
        return L !== v;
      }), document.removeEventListener("wheel", b, Al), document.removeEventListener("touchmove", b, Al), document.removeEventListener("touchstart", R, Al);
    };
  }, []);
  var T = a.removeScrollBar, M = a.inert;
  return h.createElement(
    h.Fragment,
    null,
    M ? h.createElement(v, { styles: uP(d) }) : null,
    T ? h.createElement(Jk, { gapMode: a.gapMode }) : null
  );
}
function fP(a) {
  for (var o = null; a !== null; )
    a instanceof ShadowRoot && (o = a.host, a = a.host), a = a.parentNode;
  return o;
}
const dP = $k(f0, cP);
var m0 = h.forwardRef(function(a, o) {
  return h.createElement(Fd, ma({}, a, { ref: o, sideCar: dP }));
});
m0.classNames = Fd.classNames;
var pP = function(a) {
  if (typeof document > "u")
    return null;
  var o = Array.isArray(a) ? a[0] : a;
  return o.ownerDocument.body;
}, Ll = /* @__PURE__ */ new WeakMap(), yd = /* @__PURE__ */ new WeakMap(), gd = {}, fy = 0, y0 = function(a) {
  return a && (a.host || y0(a.parentNode));
}, vP = function(a, o) {
  return o.map(function(u) {
    if (a.contains(u))
      return u;
    var s = y0(u);
    return s && a.contains(s) ? s : (console.error("aria-hidden", u, "in not contained inside", a, ". Doing nothing"), null);
  }).filter(function(u) {
    return !!u;
  });
}, hP = function(a, o, u, s) {
  var d = vP(o, Array.isArray(a) ? a : [a]);
  gd[u] || (gd[u] = /* @__PURE__ */ new WeakMap());
  var v = gd[u], c = [], g = /* @__PURE__ */ new Set(), b = new Set(d), S = function(E) {
    !E || g.has(E) || (g.add(E), S(E.parentNode));
  };
  d.forEach(S);
  var R = function(E) {
    !E || b.has(E) || Array.prototype.forEach.call(E.children, function(x) {
      if (g.has(x))
        R(x);
      else
        try {
          var T = x.getAttribute(s), M = T !== null && T !== "false", L = (Ll.get(x) || 0) + 1, $ = (v.get(x) || 0) + 1;
          Ll.set(x, L), v.set(x, $), c.push(x), L === 1 && M && yd.set(x, !0), $ === 1 && x.setAttribute(u, "true"), M || x.setAttribute(s, "true");
        } catch (U) {
          console.error("aria-hidden: cannot operate on ", x, U);
        }
    });
  };
  return R(o), g.clear(), fy++, function() {
    c.forEach(function(E) {
      var x = Ll.get(E) - 1, T = v.get(E) - 1;
      Ll.set(E, x), v.set(E, T), x || (yd.has(E) || E.removeAttribute(s), yd.delete(E)), T || E.removeAttribute(u);
    }), fy--, fy || (Ll = /* @__PURE__ */ new WeakMap(), Ll = /* @__PURE__ */ new WeakMap(), yd = /* @__PURE__ */ new WeakMap(), gd = {});
  };
}, mP = function(a, o, u) {
  u === void 0 && (u = "data-aria-hidden");
  var s = Array.from(Array.isArray(a) ? a : [a]), d = pP(a);
  return d ? (s.push.apply(s, Array.from(d.querySelectorAll("[aria-live]"))), hP(s, d, u, "aria-hidden")) : function() {
    return null;
  };
};
const Do = { asChild: { type: "boolean" } }, g0 = { width: { type: "string", className: "rt-r-w", customProperties: ["--width"], responsive: !0 }, minWidth: { type: "string", className: "rt-r-min-w", customProperties: ["--min-width"], responsive: !0 }, maxWidth: { type: "string", className: "rt-r-max-w", customProperties: ["--max-width"], responsive: !0 } }, yP = { height: { type: "string", className: "rt-r-h", customProperties: ["--height"], responsive: !0 }, minHeight: { type: "string", className: "rt-r-min-h", customProperties: ["--min-height"], responsive: !0 }, maxHeight: { type: "string", className: "rt-r-max-h", customProperties: ["--max-height"], responsive: !0 } }, jy = ["gray", "gold", "bronze", "brown", "yellow", "amber", "orange", "tomato", "red", "ruby", "crimson", "pink", "plum", "purple", "violet", "iris", "indigo", "blue", "cyan", "teal", "jade", "green", "grass", "lime", "mint", "sky"], gP = ["auto", "gray", "mauve", "slate", "sage", "olive", "sand"], _o = { color: { type: "enum", values: jy, default: void 0 } }, bP = { color: { type: "enum", values: jy, default: "" } }, Fy = { highContrast: { type: "boolean", className: "rt-high-contrast", default: void 0 } }, zy = ["initial", "xs", "sm", "md", "lg", "xl"];
function b0(a, o) {
  return Object.prototype.hasOwnProperty.call(a, o);
}
function Hs(a) {
  return typeof a == "object" && Object.keys(a).some((o) => zy.includes(o));
}
function Ni({ className: a, customProperties: o, ...u }) {
  const s = Bs({ allowArbitraryValues: !0, className: a, ...u }), d = SP({ customProperties: o, ...u });
  return [s, d];
}
function Bs({ allowArbitraryValues: a, value: o, className: u, propValues: s, parseValue: d = (v) => v }) {
  const v = [];
  if (o) {
    if (typeof o == "string" && s.includes(o))
      return PR(u, o, d);
    if (Hs(o)) {
      const c = o;
      for (const g in c) {
        if (!b0(c, g) || !zy.includes(g))
          continue;
        const b = c[g];
        if (b !== void 0) {
          if (s.includes(b)) {
            const S = PR(u, b, d), R = g === "initial" ? S : `${g}:${S}`;
            v.push(R);
          } else if (a) {
            const S = g === "initial" ? u : `${g}:${u}`;
            v.push(S);
          }
        }
      }
      return v.join(" ");
    }
    if (a)
      return u;
  }
}
function PR(a, o, u) {
  const s = a ? "-" : "", d = u(o), v = d == null ? void 0 : d.startsWith("-"), c = v ? "-" : "", g = v ? d == null ? void 0 : d.substring(1) : d;
  return `${c}${a}${s}${g}`;
}
function SP({ customProperties: a, value: o, propValues: u, parseValue: s = (d) => d }) {
  let d = {};
  if (!(!o || typeof o == "string" && u.includes(o))) {
    if (typeof o == "string" && (d = Object.fromEntries(a.map((v) => [v, o]))), Hs(o)) {
      const v = o;
      for (const c in v) {
        if (!b0(v, c) || !zy.includes(c))
          continue;
        const g = v[c];
        if (!u.includes(g))
          for (const b of a)
            d = { [c === "initial" ? b : `${b}-${c}`]: g, ...d };
      }
    }
    for (const v in d) {
      const c = d[v];
      c !== void 0 && (d[v] = s(c));
    }
    return d;
  }
}
function Dd(...a) {
  let o = {};
  for (const u of a)
    u && (o = { ...o, ...u });
  return Object.keys(o).length ? o : void 0;
}
function CP(...a) {
  return Object.assign({}, ...a);
}
function Rn(a, ...o) {
  let u, s;
  const d = { ...a }, v = CP(...o);
  for (const c in v) {
    let g = d[c];
    const b = v[c];
    if (b.default !== void 0 && g === void 0 && (g = b.default), b.type === "enum" && ![b.default, ...b.values].includes(g) && !Hs(g) && (g = b.default), d[c] = g, "className" in b && b.className) {
      delete d[c];
      const S = "responsive" in b;
      if (!g || Hs(g) && !S)
        continue;
      if (Hs(g) && (b.default !== void 0 && g.initial === void 0 && (g.initial = b.default), b.type === "enum" && ([b.default, ...b.values].includes(g.initial) || (g.initial = b.default))), b.type === "enum") {
        const R = Bs({ allowArbitraryValues: !1, value: g, className: b.className, propValues: b.values, parseValue: b.parseValue });
        u = je(u, R);
        continue;
      }
      if (b.type === "string" || b.type === "enum | string") {
        const R = b.type === "string" ? [] : b.values, [E, x] = Ni({ className: b.className, customProperties: b.customProperties, propValues: R, parseValue: b.parseValue, value: g });
        s = Dd(s, x), u = je(u, E);
        continue;
      }
      if (b.type === "boolean" && g) {
        u = je(u, b.className);
        continue;
      }
    }
  }
  return d.className = je(u, a.className), d.style = Dd(s, a.style), d;
}
const Ro = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "-1", "-2", "-3", "-4", "-5", "-6", "-7", "-8", "-9"], Zr = { m: { type: "enum | string", values: Ro, responsive: !0, className: "rt-r-m", customProperties: ["--m"] }, mx: { type: "enum | string", values: Ro, responsive: !0, className: "rt-r-mx", customProperties: ["--ml", "--mr"] }, my: { type: "enum | string", values: Ro, responsive: !0, className: "rt-r-my", customProperties: ["--mt", "--mb"] }, mt: { type: "enum | string", values: Ro, responsive: !0, className: "rt-r-mt", customProperties: ["--mt"] }, mr: { type: "enum | string", values: Ro, responsive: !0, className: "rt-r-mr", customProperties: ["--mr"] }, mb: { type: "enum | string", values: Ro, responsive: !0, className: "rt-r-mb", customProperties: ["--mb"] }, ml: { type: "enum | string", values: Ro, responsive: !0, className: "rt-r-ml", customProperties: ["--ml"] } }, EP = ["top", "right", "bottom", "left"], Pi = Math.min, hr = Math.max, _d = Math.round, bd = Math.floor, Ui = (a) => ({
  x: a,
  y: a
}), RP = {
  left: "right",
  right: "left",
  bottom: "top",
  top: "bottom"
}, wP = {
  start: "end",
  end: "start"
};
function Ey(a, o, u) {
  return hr(a, Pi(o, u));
}
function qa(a, o) {
  return typeof a == "function" ? a(o) : a;
}
function Qa(a) {
  return a.split("-")[0];
}
function Hl(a) {
  return a.split("-")[1];
}
function Hy(a) {
  return a === "x" ? "y" : "x";
}
function $y(a) {
  return a === "y" ? "height" : "width";
}
function ji(a) {
  return ["top", "bottom"].includes(Qa(a)) ? "y" : "x";
}
function Iy(a) {
  return Hy(ji(a));
}
function xP(a, o, u) {
  u === void 0 && (u = !1);
  const s = Hl(a), d = Iy(a), v = $y(d);
  let c = d === "x" ? s === (u ? "end" : "start") ? "right" : "left" : s === "start" ? "bottom" : "top";
  return o.reference[v] > o.floating[v] && (c = Md(c)), [c, Md(c)];
}
function TP(a) {
  const o = Md(a);
  return [Ry(a), o, Ry(o)];
}
function Ry(a) {
  return a.replace(/start|end/g, (o) => wP[o]);
}
function DP(a, o, u) {
  const s = ["left", "right"], d = ["right", "left"], v = ["top", "bottom"], c = ["bottom", "top"];
  switch (a) {
    case "top":
    case "bottom":
      return u ? o ? d : s : o ? s : d;
    case "left":
    case "right":
      return o ? v : c;
    default:
      return [];
  }
}
function _P(a, o, u, s) {
  const d = Hl(a);
  let v = DP(Qa(a), u === "start", s);
  return d && (v = v.map((c) => c + "-" + d), o && (v = v.concat(v.map(Ry)))), v;
}
function Md(a) {
  return a.replace(/left|right|bottom|top/g, (o) => RP[o]);
}
function MP(a) {
  return {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0,
    ...a
  };
}
function S0(a) {
  return typeof a != "number" ? MP(a) : {
    top: a,
    right: a,
    bottom: a,
    left: a
  };
}
function Od(a) {
  const {
    x: o,
    y: u,
    width: s,
    height: d
  } = a;
  return {
    width: s,
    height: d,
    top: u,
    left: o,
    right: o + s,
    bottom: u + d,
    x: o,
    y: u
  };
}
function UR(a, o, u) {
  let {
    reference: s,
    floating: d
  } = a;
  const v = ji(o), c = Iy(o), g = $y(c), b = Qa(o), S = v === "y", R = s.x + s.width / 2 - d.width / 2, E = s.y + s.height / 2 - d.height / 2, x = s[g] / 2 - d[g] / 2;
  let T;
  switch (b) {
    case "top":
      T = {
        x: R,
        y: s.y - d.height
      };
      break;
    case "bottom":
      T = {
        x: R,
        y: s.y + s.height
      };
      break;
    case "right":
      T = {
        x: s.x + s.width,
        y: E
      };
      break;
    case "left":
      T = {
        x: s.x - d.width,
        y: E
      };
      break;
    default:
      T = {
        x: s.x,
        y: s.y
      };
  }
  switch (Hl(o)) {
    case "start":
      T[c] -= x * (u && S ? -1 : 1);
      break;
    case "end":
      T[c] += x * (u && S ? -1 : 1);
      break;
  }
  return T;
}
const OP = async (a, o, u) => {
  const {
    placement: s = "bottom",
    strategy: d = "absolute",
    middleware: v = [],
    platform: c
  } = u, g = v.filter(Boolean), b = await (c.isRTL == null ? void 0 : c.isRTL(o));
  let S = await c.getElementRects({
    reference: a,
    floating: o,
    strategy: d
  }), {
    x: R,
    y: E
  } = UR(S, s, b), x = s, T = {}, M = 0;
  for (let L = 0; L < g.length; L++) {
    const {
      name: $,
      fn: U
    } = g[L], {
      x: F,
      y: Y,
      data: X,
      reset: W
    } = await U({
      x: R,
      y: E,
      initialPlacement: s,
      placement: x,
      strategy: d,
      middlewareData: T,
      rects: S,
      platform: c,
      elements: {
        reference: a,
        floating: o
      }
    });
    R = F ?? R, E = Y ?? E, T = {
      ...T,
      [$]: {
        ...T[$],
        ...X
      }
    }, W && M <= 50 && (M++, typeof W == "object" && (W.placement && (x = W.placement), W.rects && (S = W.rects === !0 ? await c.getElementRects({
      reference: a,
      floating: o,
      strategy: d
    }) : W.rects), {
      x: R,
      y: E
    } = UR(S, x, b)), L = -1);
  }
  return {
    x: R,
    y: E,
    placement: x,
    strategy: d,
    middlewareData: T
  };
};
async function Vs(a, o) {
  var u;
  o === void 0 && (o = {});
  const {
    x: s,
    y: d,
    platform: v,
    rects: c,
    elements: g,
    strategy: b
  } = a, {
    boundary: S = "clippingAncestors",
    rootBoundary: R = "viewport",
    elementContext: E = "floating",
    altBoundary: x = !1,
    padding: T = 0
  } = qa(o, a), M = S0(T), $ = g[x ? E === "floating" ? "reference" : "floating" : E], U = Od(await v.getClippingRect({
    element: (u = await (v.isElement == null ? void 0 : v.isElement($))) == null || u ? $ : $.contextElement || await (v.getDocumentElement == null ? void 0 : v.getDocumentElement(g.floating)),
    boundary: S,
    rootBoundary: R,
    strategy: b
  })), F = E === "floating" ? {
    x: s,
    y: d,
    width: c.floating.width,
    height: c.floating.height
  } : c.reference, Y = await (v.getOffsetParent == null ? void 0 : v.getOffsetParent(g.floating)), X = await (v.isElement == null ? void 0 : v.isElement(Y)) ? await (v.getScale == null ? void 0 : v.getScale(Y)) || {
    x: 1,
    y: 1
  } : {
    x: 1,
    y: 1
  }, W = Od(v.convertOffsetParentRelativeRectToViewportRelativeRect ? await v.convertOffsetParentRelativeRectToViewportRelativeRect({
    elements: g,
    rect: F,
    offsetParent: Y,
    strategy: b
  }) : F);
  return {
    top: (U.top - W.top + M.top) / X.y,
    bottom: (W.bottom - U.bottom + M.bottom) / X.y,
    left: (U.left - W.left + M.left) / X.x,
    right: (W.right - U.right + M.right) / X.x
  };
}
const AP = (a) => ({
  name: "arrow",
  options: a,
  async fn(o) {
    const {
      x: u,
      y: s,
      placement: d,
      rects: v,
      platform: c,
      elements: g,
      middlewareData: b
    } = o, {
      element: S,
      padding: R = 0
    } = qa(a, o) || {};
    if (S == null)
      return {};
    const E = S0(R), x = {
      x: u,
      y: s
    }, T = Iy(d), M = $y(T), L = await c.getDimensions(S), $ = T === "y", U = $ ? "top" : "left", F = $ ? "bottom" : "right", Y = $ ? "clientHeight" : "clientWidth", X = v.reference[M] + v.reference[T] - x[T] - v.floating[M], W = x[T] - v.reference[T], ne = await (c.getOffsetParent == null ? void 0 : c.getOffsetParent(S));
    let Z = ne ? ne[Y] : 0;
    (!Z || !await (c.isElement == null ? void 0 : c.isElement(ne))) && (Z = g.floating[Y] || v.floating[M]);
    const ve = X / 2 - W / 2, me = Z / 2 - L[M] / 2 - 1, he = Pi(E[U], me), Ee = Pi(E[F], me), Xe = he, fe = Z - L[M] - Ee, ge = Z / 2 - L[M] / 2 + ve, Ie = Ey(Xe, ge, fe), De = !b.arrow && Hl(d) != null && ge !== Ie && v.reference[M] / 2 - (ge < Xe ? he : Ee) - L[M] / 2 < 0, de = De ? ge < Xe ? ge - Xe : ge - fe : 0;
    return {
      [T]: x[T] + de,
      data: {
        [T]: Ie,
        centerOffset: ge - Ie - de,
        ...De && {
          alignmentOffset: de
        }
      },
      reset: De
    };
  }
}), NP = function(a) {
  return a === void 0 && (a = {}), {
    name: "flip",
    options: a,
    async fn(o) {
      var u, s;
      const {
        placement: d,
        middlewareData: v,
        rects: c,
        initialPlacement: g,
        platform: b,
        elements: S
      } = o, {
        mainAxis: R = !0,
        crossAxis: E = !0,
        fallbackPlacements: x,
        fallbackStrategy: T = "bestFit",
        fallbackAxisSideDirection: M = "none",
        flipAlignment: L = !0,
        ...$
      } = qa(a, o);
      if ((u = v.arrow) != null && u.alignmentOffset)
        return {};
      const U = Qa(d), F = ji(g), Y = Qa(g) === g, X = await (b.isRTL == null ? void 0 : b.isRTL(S.floating)), W = x || (Y || !L ? [Md(g)] : TP(g)), ne = M !== "none";
      !x && ne && W.push(..._P(g, L, M, X));
      const Z = [g, ...W], ve = await Vs(o, $), me = [];
      let he = ((s = v.flip) == null ? void 0 : s.overflows) || [];
      if (R && me.push(ve[U]), E) {
        const ge = xP(d, c, X);
        me.push(ve[ge[0]], ve[ge[1]]);
      }
      if (he = [...he, {
        placement: d,
        overflows: me
      }], !me.every((ge) => ge <= 0)) {
        var Ee, Xe;
        const ge = (((Ee = v.flip) == null ? void 0 : Ee.index) || 0) + 1, Ie = Z[ge];
        if (Ie)
          return {
            data: {
              index: ge,
              overflows: he
            },
            reset: {
              placement: Ie
            }
          };
        let De = (Xe = he.filter((de) => de.overflows[0] <= 0).sort((de, Se) => de.overflows[1] - Se.overflows[1])[0]) == null ? void 0 : Xe.placement;
        if (!De)
          switch (T) {
            case "bestFit": {
              var fe;
              const de = (fe = he.filter((Se) => {
                if (ne) {
                  const se = ji(Se.placement);
                  return se === F || // Create a bias to the `y` side axis due to horizontal
                  // reading directions favoring greater width.
                  se === "y";
                }
                return !0;
              }).map((Se) => [Se.placement, Se.overflows.filter((se) => se > 0).reduce((se, Ke) => se + Ke, 0)]).sort((Se, se) => Se[1] - se[1])[0]) == null ? void 0 : fe[0];
              de && (De = de);
              break;
            }
            case "initialPlacement":
              De = g;
              break;
          }
        if (d !== De)
          return {
            reset: {
              placement: De
            }
          };
      }
      return {};
    }
  };
};
function jR(a, o) {
  return {
    top: a.top - o.height,
    right: a.right - o.width,
    bottom: a.bottom - o.height,
    left: a.left - o.width
  };
}
function FR(a) {
  return EP.some((o) => a[o] >= 0);
}
const LP = function(a) {
  return a === void 0 && (a = {}), {
    name: "hide",
    options: a,
    async fn(o) {
      const {
        rects: u
      } = o, {
        strategy: s = "referenceHidden",
        ...d
      } = qa(a, o);
      switch (s) {
        case "referenceHidden": {
          const v = await Vs(o, {
            ...d,
            elementContext: "reference"
          }), c = jR(v, u.reference);
          return {
            data: {
              referenceHiddenOffsets: c,
              referenceHidden: FR(c)
            }
          };
        }
        case "escaped": {
          const v = await Vs(o, {
            ...d,
            altBoundary: !0
          }), c = jR(v, u.floating);
          return {
            data: {
              escapedOffsets: c,
              escaped: FR(c)
            }
          };
        }
        default:
          return {};
      }
    }
  };
};
async function kP(a, o) {
  const {
    placement: u,
    platform: s,
    elements: d
  } = a, v = await (s.isRTL == null ? void 0 : s.isRTL(d.floating)), c = Qa(u), g = Hl(u), b = ji(u) === "y", S = ["left", "top"].includes(c) ? -1 : 1, R = v && b ? -1 : 1, E = qa(o, a);
  let {
    mainAxis: x,
    crossAxis: T,
    alignmentAxis: M
  } = typeof E == "number" ? {
    mainAxis: E,
    crossAxis: 0,
    alignmentAxis: null
  } : {
    mainAxis: E.mainAxis || 0,
    crossAxis: E.crossAxis || 0,
    alignmentAxis: E.alignmentAxis
  };
  return g && typeof M == "number" && (T = g === "end" ? M * -1 : M), b ? {
    x: T * R,
    y: x * S
  } : {
    x: x * S,
    y: T * R
  };
}
const PP = function(a) {
  return a === void 0 && (a = 0), {
    name: "offset",
    options: a,
    async fn(o) {
      var u, s;
      const {
        x: d,
        y: v,
        placement: c,
        middlewareData: g
      } = o, b = await kP(o, a);
      return c === ((u = g.offset) == null ? void 0 : u.placement) && (s = g.arrow) != null && s.alignmentOffset ? {} : {
        x: d + b.x,
        y: v + b.y,
        data: {
          ...b,
          placement: c
        }
      };
    }
  };
}, UP = function(a) {
  return a === void 0 && (a = {}), {
    name: "shift",
    options: a,
    async fn(o) {
      const {
        x: u,
        y: s,
        placement: d
      } = o, {
        mainAxis: v = !0,
        crossAxis: c = !1,
        limiter: g = {
          fn: ($) => {
            let {
              x: U,
              y: F
            } = $;
            return {
              x: U,
              y: F
            };
          }
        },
        ...b
      } = qa(a, o), S = {
        x: u,
        y: s
      }, R = await Vs(o, b), E = ji(Qa(d)), x = Hy(E);
      let T = S[x], M = S[E];
      if (v) {
        const $ = x === "y" ? "top" : "left", U = x === "y" ? "bottom" : "right", F = T + R[$], Y = T - R[U];
        T = Ey(F, T, Y);
      }
      if (c) {
        const $ = E === "y" ? "top" : "left", U = E === "y" ? "bottom" : "right", F = M + R[$], Y = M - R[U];
        M = Ey(F, M, Y);
      }
      const L = g.fn({
        ...o,
        [x]: T,
        [E]: M
      });
      return {
        ...L,
        data: {
          x: L.x - u,
          y: L.y - s,
          enabled: {
            [x]: v,
            [E]: c
          }
        }
      };
    }
  };
}, jP = function(a) {
  return a === void 0 && (a = {}), {
    options: a,
    fn(o) {
      const {
        x: u,
        y: s,
        placement: d,
        rects: v,
        middlewareData: c
      } = o, {
        offset: g = 0,
        mainAxis: b = !0,
        crossAxis: S = !0
      } = qa(a, o), R = {
        x: u,
        y: s
      }, E = ji(d), x = Hy(E);
      let T = R[x], M = R[E];
      const L = qa(g, o), $ = typeof L == "number" ? {
        mainAxis: L,
        crossAxis: 0
      } : {
        mainAxis: 0,
        crossAxis: 0,
        ...L
      };
      if (b) {
        const Y = x === "y" ? "height" : "width", X = v.reference[x] - v.floating[Y] + $.mainAxis, W = v.reference[x] + v.reference[Y] - $.mainAxis;
        T < X ? T = X : T > W && (T = W);
      }
      if (S) {
        var U, F;
        const Y = x === "y" ? "width" : "height", X = ["top", "left"].includes(Qa(d)), W = v.reference[E] - v.floating[Y] + (X && ((U = c.offset) == null ? void 0 : U[E]) || 0) + (X ? 0 : $.crossAxis), ne = v.reference[E] + v.reference[Y] + (X ? 0 : ((F = c.offset) == null ? void 0 : F[E]) || 0) - (X ? $.crossAxis : 0);
        M < W ? M = W : M > ne && (M = ne);
      }
      return {
        [x]: T,
        [E]: M
      };
    }
  };
}, FP = function(a) {
  return a === void 0 && (a = {}), {
    name: "size",
    options: a,
    async fn(o) {
      var u, s;
      const {
        placement: d,
        rects: v,
        platform: c,
        elements: g
      } = o, {
        apply: b = () => {
        },
        ...S
      } = qa(a, o), R = await Vs(o, S), E = Qa(d), x = Hl(d), T = ji(d) === "y", {
        width: M,
        height: L
      } = v.floating;
      let $, U;
      E === "top" || E === "bottom" ? ($ = E, U = x === (await (c.isRTL == null ? void 0 : c.isRTL(g.floating)) ? "start" : "end") ? "left" : "right") : (U = E, $ = x === "end" ? "top" : "bottom");
      const F = L - R.top - R.bottom, Y = M - R.left - R.right, X = Pi(L - R[$], F), W = Pi(M - R[U], Y), ne = !o.middlewareData.shift;
      let Z = X, ve = W;
      if ((u = o.middlewareData.shift) != null && u.enabled.x && (ve = Y), (s = o.middlewareData.shift) != null && s.enabled.y && (Z = F), ne && !x) {
        const he = hr(R.left, 0), Ee = hr(R.right, 0), Xe = hr(R.top, 0), fe = hr(R.bottom, 0);
        T ? ve = M - 2 * (he !== 0 || Ee !== 0 ? he + Ee : hr(R.left, R.right)) : Z = L - 2 * (Xe !== 0 || fe !== 0 ? Xe + fe : hr(R.top, R.bottom));
      }
      await b({
        ...o,
        availableWidth: ve,
        availableHeight: Z
      });
      const me = await c.getDimensions(g.floating);
      return M !== me.width || L !== me.height ? {
        reset: {
          rects: !0
        }
      } : {};
    }
  };
};
function zd() {
  return typeof window < "u";
}
function $l(a) {
  return C0(a) ? (a.nodeName || "").toLowerCase() : "#document";
}
function mr(a) {
  var o;
  return (a == null || (o = a.ownerDocument) == null ? void 0 : o.defaultView) || window;
}
function ba(a) {
  var o;
  return (o = (C0(a) ? a.ownerDocument : a.document) || window.document) == null ? void 0 : o.documentElement;
}
function C0(a) {
  return zd() ? a instanceof Node || a instanceof mr(a).Node : !1;
}
function Kr(a) {
  return zd() ? a instanceof Element || a instanceof mr(a).Element : !1;
}
function ga(a) {
  return zd() ? a instanceof HTMLElement || a instanceof mr(a).HTMLElement : !1;
}
function zR(a) {
  return !zd() || typeof ShadowRoot > "u" ? !1 : a instanceof ShadowRoot || a instanceof mr(a).ShadowRoot;
}
function Qs(a) {
  const {
    overflow: o,
    overflowX: u,
    overflowY: s,
    display: d
  } = qr(a);
  return /auto|scroll|overlay|hidden|clip/.test(o + s + u) && !["inline", "contents"].includes(d);
}
function zP(a) {
  return ["table", "td", "th"].includes($l(a));
}
function Hd(a) {
  return [":popover-open", ":modal"].some((o) => {
    try {
      return a.matches(o);
    } catch {
      return !1;
    }
  });
}
function By(a) {
  const o = Vy(), u = Kr(a) ? qr(a) : a;
  return u.transform !== "none" || u.perspective !== "none" || (u.containerType ? u.containerType !== "normal" : !1) || !o && (u.backdropFilter ? u.backdropFilter !== "none" : !1) || !o && (u.filter ? u.filter !== "none" : !1) || ["transform", "perspective", "filter"].some((s) => (u.willChange || "").includes(s)) || ["paint", "layout", "strict", "content"].some((s) => (u.contain || "").includes(s));
}
function HP(a) {
  let o = Fi(a);
  for (; ga(o) && !jl(o); ) {
    if (By(o))
      return o;
    if (Hd(o))
      return null;
    o = Fi(o);
  }
  return null;
}
function Vy() {
  return typeof CSS > "u" || !CSS.supports ? !1 : CSS.supports("-webkit-backdrop-filter", "none");
}
function jl(a) {
  return ["html", "body", "#document"].includes($l(a));
}
function qr(a) {
  return mr(a).getComputedStyle(a);
}
function $d(a) {
  return Kr(a) ? {
    scrollLeft: a.scrollLeft,
    scrollTop: a.scrollTop
  } : {
    scrollLeft: a.scrollX,
    scrollTop: a.scrollY
  };
}
function Fi(a) {
  if ($l(a) === "html")
    return a;
  const o = (
    // Step into the shadow DOM of the parent of a slotted node.
    a.assignedSlot || // DOM Element detected.
    a.parentNode || // ShadowRoot detected.
    zR(a) && a.host || // Fallback.
    ba(a)
  );
  return zR(o) ? o.host : o;
}
function E0(a) {
  const o = Fi(a);
  return jl(o) ? a.ownerDocument ? a.ownerDocument.body : a.body : ga(o) && Qs(o) ? o : E0(o);
}
function Ys(a, o, u) {
  var s;
  o === void 0 && (o = []), u === void 0 && (u = !0);
  const d = E0(a), v = d === ((s = a.ownerDocument) == null ? void 0 : s.body), c = mr(d);
  if (v) {
    const g = wy(c);
    return o.concat(c, c.visualViewport || [], Qs(d) ? d : [], g && u ? Ys(g) : []);
  }
  return o.concat(d, Ys(d, [], u));
}
function wy(a) {
  return a.parent && Object.getPrototypeOf(a.parent) ? a.frameElement : null;
}
function R0(a) {
  const o = qr(a);
  let u = parseFloat(o.width) || 0, s = parseFloat(o.height) || 0;
  const d = ga(a), v = d ? a.offsetWidth : u, c = d ? a.offsetHeight : s, g = _d(u) !== v || _d(s) !== c;
  return g && (u = v, s = c), {
    width: u,
    height: s,
    $: g
  };
}
function Yy(a) {
  return Kr(a) ? a : a.contextElement;
}
function Ul(a) {
  const o = Yy(a);
  if (!ga(o))
    return Ui(1);
  const u = o.getBoundingClientRect(), {
    width: s,
    height: d,
    $: v
  } = R0(o);
  let c = (v ? _d(u.width) : u.width) / s, g = (v ? _d(u.height) : u.height) / d;
  return (!c || !Number.isFinite(c)) && (c = 1), (!g || !Number.isFinite(g)) && (g = 1), {
    x: c,
    y: g
  };
}
const $P = /* @__PURE__ */ Ui(0);
function w0(a) {
  const o = mr(a);
  return !Vy() || !o.visualViewport ? $P : {
    x: o.visualViewport.offsetLeft,
    y: o.visualViewport.offsetTop
  };
}
function IP(a, o, u) {
  return o === void 0 && (o = !1), !u || o && u !== mr(a) ? !1 : o;
}
function To(a, o, u, s) {
  o === void 0 && (o = !1), u === void 0 && (u = !1);
  const d = a.getBoundingClientRect(), v = Yy(a);
  let c = Ui(1);
  o && (s ? Kr(s) && (c = Ul(s)) : c = Ul(a));
  const g = IP(v, u, s) ? w0(v) : Ui(0);
  let b = (d.left + g.x) / c.x, S = (d.top + g.y) / c.y, R = d.width / c.x, E = d.height / c.y;
  if (v) {
    const x = mr(v), T = s && Kr(s) ? mr(s) : s;
    let M = x, L = wy(M);
    for (; L && s && T !== M; ) {
      const $ = Ul(L), U = L.getBoundingClientRect(), F = qr(L), Y = U.left + (L.clientLeft + parseFloat(F.paddingLeft)) * $.x, X = U.top + (L.clientTop + parseFloat(F.paddingTop)) * $.y;
      b *= $.x, S *= $.y, R *= $.x, E *= $.y, b += Y, S += X, M = mr(L), L = wy(M);
    }
  }
  return Od({
    width: R,
    height: E,
    x: b,
    y: S
  });
}
function BP(a) {
  let {
    elements: o,
    rect: u,
    offsetParent: s,
    strategy: d
  } = a;
  const v = d === "fixed", c = ba(s), g = o ? Hd(o.floating) : !1;
  if (s === c || g && v)
    return u;
  let b = {
    scrollLeft: 0,
    scrollTop: 0
  }, S = Ui(1);
  const R = Ui(0), E = ga(s);
  if ((E || !E && !v) && (($l(s) !== "body" || Qs(c)) && (b = $d(s)), ga(s))) {
    const x = To(s);
    S = Ul(s), R.x = x.x + s.clientLeft, R.y = x.y + s.clientTop;
  }
  return {
    width: u.width * S.x,
    height: u.height * S.y,
    x: u.x * S.x - b.scrollLeft * S.x + R.x,
    y: u.y * S.y - b.scrollTop * S.y + R.y
  };
}
function VP(a) {
  return Array.from(a.getClientRects());
}
function xy(a, o) {
  const u = $d(a).scrollLeft;
  return o ? o.left + u : To(ba(a)).left + u;
}
function YP(a) {
  const o = ba(a), u = $d(a), s = a.ownerDocument.body, d = hr(o.scrollWidth, o.clientWidth, s.scrollWidth, s.clientWidth), v = hr(o.scrollHeight, o.clientHeight, s.scrollHeight, s.clientHeight);
  let c = -u.scrollLeft + xy(a);
  const g = -u.scrollTop;
  return qr(s).direction === "rtl" && (c += hr(o.clientWidth, s.clientWidth) - d), {
    width: d,
    height: v,
    x: c,
    y: g
  };
}
function WP(a, o) {
  const u = mr(a), s = ba(a), d = u.visualViewport;
  let v = s.clientWidth, c = s.clientHeight, g = 0, b = 0;
  if (d) {
    v = d.width, c = d.height;
    const S = Vy();
    (!S || S && o === "fixed") && (g = d.offsetLeft, b = d.offsetTop);
  }
  return {
    width: v,
    height: c,
    x: g,
    y: b
  };
}
function GP(a, o) {
  const u = To(a, !0, o === "fixed"), s = u.top + a.clientTop, d = u.left + a.clientLeft, v = ga(a) ? Ul(a) : Ui(1), c = a.clientWidth * v.x, g = a.clientHeight * v.y, b = d * v.x, S = s * v.y;
  return {
    width: c,
    height: g,
    x: b,
    y: S
  };
}
function HR(a, o, u) {
  let s;
  if (o === "viewport")
    s = WP(a, u);
  else if (o === "document")
    s = YP(ba(a));
  else if (Kr(o))
    s = GP(o, u);
  else {
    const d = w0(a);
    s = {
      ...o,
      x: o.x - d.x,
      y: o.y - d.y
    };
  }
  return Od(s);
}
function x0(a, o) {
  const u = Fi(a);
  return u === o || !Kr(u) || jl(u) ? !1 : qr(u).position === "fixed" || x0(u, o);
}
function XP(a, o) {
  const u = o.get(a);
  if (u)
    return u;
  let s = Ys(a, [], !1).filter((g) => Kr(g) && $l(g) !== "body"), d = null;
  const v = qr(a).position === "fixed";
  let c = v ? Fi(a) : a;
  for (; Kr(c) && !jl(c); ) {
    const g = qr(c), b = By(c);
    !b && g.position === "fixed" && (d = null), (v ? !b && !d : !b && g.position === "static" && !!d && ["absolute", "fixed"].includes(d.position) || Qs(c) && !b && x0(a, c)) ? s = s.filter((R) => R !== c) : d = g, c = Fi(c);
  }
  return o.set(a, s), s;
}
function KP(a) {
  let {
    element: o,
    boundary: u,
    rootBoundary: s,
    strategy: d
  } = a;
  const c = [...u === "clippingAncestors" ? Hd(o) ? [] : XP(o, this._c) : [].concat(u), s], g = c[0], b = c.reduce((S, R) => {
    const E = HR(o, R, d);
    return S.top = hr(E.top, S.top), S.right = Pi(E.right, S.right), S.bottom = Pi(E.bottom, S.bottom), S.left = hr(E.left, S.left), S;
  }, HR(o, g, d));
  return {
    width: b.right - b.left,
    height: b.bottom - b.top,
    x: b.left,
    y: b.top
  };
}
function qP(a) {
  const {
    width: o,
    height: u
  } = R0(a);
  return {
    width: o,
    height: u
  };
}
function QP(a, o, u) {
  const s = ga(o), d = ba(o), v = u === "fixed", c = To(a, !0, v, o);
  let g = {
    scrollLeft: 0,
    scrollTop: 0
  };
  const b = Ui(0);
  if (s || !s && !v)
    if (($l(o) !== "body" || Qs(d)) && (g = $d(o)), s) {
      const T = To(o, !0, v, o);
      b.x = T.x + o.clientLeft, b.y = T.y + o.clientTop;
    } else
      d && (b.x = xy(d));
  let S = 0, R = 0;
  if (d && !s && !v) {
    const T = d.getBoundingClientRect();
    R = T.top + g.scrollTop, S = T.left + g.scrollLeft - // RTL <body> scrollbar.
    xy(d, T);
  }
  const E = c.left + g.scrollLeft - b.x - S, x = c.top + g.scrollTop - b.y - R;
  return {
    x: E,
    y: x,
    width: c.width,
    height: c.height
  };
}
function dy(a) {
  return qr(a).position === "static";
}
function $R(a, o) {
  if (!ga(a) || qr(a).position === "fixed")
    return null;
  if (o)
    return o(a);
  let u = a.offsetParent;
  return ba(a) === u && (u = u.ownerDocument.body), u;
}
function T0(a, o) {
  const u = mr(a);
  if (Hd(a))
    return u;
  if (!ga(a)) {
    let d = Fi(a);
    for (; d && !jl(d); ) {
      if (Kr(d) && !dy(d))
        return d;
      d = Fi(d);
    }
    return u;
  }
  let s = $R(a, o);
  for (; s && zP(s) && dy(s); )
    s = $R(s, o);
  return s && jl(s) && dy(s) && !By(s) ? u : s || HP(a) || u;
}
const ZP = async function(a) {
  const o = this.getOffsetParent || T0, u = this.getDimensions, s = await u(a.floating);
  return {
    reference: QP(a.reference, await o(a.floating), a.strategy),
    floating: {
      x: 0,
      y: 0,
      width: s.width,
      height: s.height
    }
  };
};
function JP(a) {
  return qr(a).direction === "rtl";
}
const eU = {
  convertOffsetParentRelativeRectToViewportRelativeRect: BP,
  getDocumentElement: ba,
  getClippingRect: KP,
  getOffsetParent: T0,
  getElementRects: ZP,
  getClientRects: VP,
  getDimensions: qP,
  getScale: Ul,
  isElement: Kr,
  isRTL: JP
};
function tU(a, o) {
  let u = null, s;
  const d = ba(a);
  function v() {
    var g;
    clearTimeout(s), (g = u) == null || g.disconnect(), u = null;
  }
  function c(g, b) {
    g === void 0 && (g = !1), b === void 0 && (b = 1), v();
    const {
      left: S,
      top: R,
      width: E,
      height: x
    } = a.getBoundingClientRect();
    if (g || o(), !E || !x)
      return;
    const T = bd(R), M = bd(d.clientWidth - (S + E)), L = bd(d.clientHeight - (R + x)), $ = bd(S), F = {
      rootMargin: -T + "px " + -M + "px " + -L + "px " + -$ + "px",
      threshold: hr(0, Pi(1, b)) || 1
    };
    let Y = !0;
    function X(W) {
      const ne = W[0].intersectionRatio;
      if (ne !== b) {
        if (!Y)
          return c();
        ne ? c(!1, ne) : s = setTimeout(() => {
          c(!1, 1e-7);
        }, 1e3);
      }
      Y = !1;
    }
    try {
      u = new IntersectionObserver(X, {
        ...F,
        // Handle <iframe>s
        root: d.ownerDocument
      });
    } catch {
      u = new IntersectionObserver(X, F);
    }
    u.observe(a);
  }
  return c(!0), v;
}
function nU(a, o, u, s) {
  s === void 0 && (s = {});
  const {
    ancestorScroll: d = !0,
    ancestorResize: v = !0,
    elementResize: c = typeof ResizeObserver == "function",
    layoutShift: g = typeof IntersectionObserver == "function",
    animationFrame: b = !1
  } = s, S = Yy(a), R = d || v ? [...S ? Ys(S) : [], ...Ys(o)] : [];
  R.forEach((U) => {
    d && U.addEventListener("scroll", u, {
      passive: !0
    }), v && U.addEventListener("resize", u);
  });
  const E = S && g ? tU(S, u) : null;
  let x = -1, T = null;
  c && (T = new ResizeObserver((U) => {
    let [F] = U;
    F && F.target === S && T && (T.unobserve(o), cancelAnimationFrame(x), x = requestAnimationFrame(() => {
      var Y;
      (Y = T) == null || Y.observe(o);
    })), u();
  }), S && !b && T.observe(S), T.observe(o));
  let M, L = b ? To(a) : null;
  b && $();
  function $() {
    const U = To(a);
    L && (U.x !== L.x || U.y !== L.y || U.width !== L.width || U.height !== L.height) && u(), L = U, M = requestAnimationFrame($);
  }
  return u(), () => {
    var U;
    R.forEach((F) => {
      d && F.removeEventListener("scroll", u), v && F.removeEventListener("resize", u);
    }), E == null || E(), (U = T) == null || U.disconnect(), T = null, b && cancelAnimationFrame(M);
  };
}
const rU = PP, aU = UP, iU = NP, oU = FP, lU = LP, IR = AP, uU = jP, sU = (a, o, u) => {
  const s = /* @__PURE__ */ new Map(), d = {
    platform: eU,
    ...u
  }, v = {
    ...d.platform,
    _c: s
  };
  return OP(a, o, {
    ...d,
    platform: v
  });
};
var Rd = typeof document < "u" ? h.useLayoutEffect : h.useEffect;
function Ad(a, o) {
  if (a === o)
    return !0;
  if (typeof a != typeof o)
    return !1;
  if (typeof a == "function" && a.toString() === o.toString())
    return !0;
  let u, s, d;
  if (a && o && typeof a == "object") {
    if (Array.isArray(a)) {
      if (u = a.length, u !== o.length)
        return !1;
      for (s = u; s-- !== 0; )
        if (!Ad(a[s], o[s]))
          return !1;
      return !0;
    }
    if (d = Object.keys(a), u = d.length, u !== Object.keys(o).length)
      return !1;
    for (s = u; s-- !== 0; )
      if (!{}.hasOwnProperty.call(o, d[s]))
        return !1;
    for (s = u; s-- !== 0; ) {
      const v = d[s];
      if (!(v === "_owner" && a.$$typeof) && !Ad(a[v], o[v]))
        return !1;
    }
    return !0;
  }
  return a !== a && o !== o;
}
function D0(a) {
  return typeof window > "u" ? 1 : (a.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function BR(a, o) {
  const u = D0(a);
  return Math.round(o * u) / u;
}
function py(a) {
  const o = h.useRef(a);
  return Rd(() => {
    o.current = a;
  }), o;
}
function cU(a) {
  a === void 0 && (a = {});
  const {
    placement: o = "bottom",
    strategy: u = "absolute",
    middleware: s = [],
    platform: d,
    elements: {
      reference: v,
      floating: c
    } = {},
    transform: g = !0,
    whileElementsMounted: b,
    open: S
  } = a, [R, E] = h.useState({
    x: 0,
    y: 0,
    strategy: u,
    placement: o,
    middlewareData: {},
    isPositioned: !1
  }), [x, T] = h.useState(s);
  Ad(x, s) || T(s);
  const [M, L] = h.useState(null), [$, U] = h.useState(null), F = h.useCallback((Se) => {
    Se !== ne.current && (ne.current = Se, L(Se));
  }, []), Y = h.useCallback((Se) => {
    Se !== Z.current && (Z.current = Se, U(Se));
  }, []), X = v || M, W = c || $, ne = h.useRef(null), Z = h.useRef(null), ve = h.useRef(R), me = b != null, he = py(b), Ee = py(d), Xe = py(S), fe = h.useCallback(() => {
    if (!ne.current || !Z.current)
      return;
    const Se = {
      placement: o,
      strategy: u,
      middleware: x
    };
    Ee.current && (Se.platform = Ee.current), sU(ne.current, Z.current, Se).then((se) => {
      const Ke = {
        ...se,
        // The floating element's position may be recomputed while it's closed
        // but still mounted (such as when transitioning out). To ensure
        // `isPositioned` will be `false` initially on the next open, avoid
        // setting it to `true` when `open === false` (must be specified).
        isPositioned: Xe.current !== !1
      };
      ge.current && !Ad(ve.current, Ke) && (ve.current = Ke, Ks.flushSync(() => {
        E(Ke);
      }));
    });
  }, [x, o, u, Ee, Xe]);
  Rd(() => {
    S === !1 && ve.current.isPositioned && (ve.current.isPositioned = !1, E((Se) => ({
      ...Se,
      isPositioned: !1
    })));
  }, [S]);
  const ge = h.useRef(!1);
  Rd(() => (ge.current = !0, () => {
    ge.current = !1;
  }), []), Rd(() => {
    if (X && (ne.current = X), W && (Z.current = W), X && W) {
      if (he.current)
        return he.current(X, W, fe);
      fe();
    }
  }, [X, W, fe, he, me]);
  const Ie = h.useMemo(() => ({
    reference: ne,
    floating: Z,
    setReference: F,
    setFloating: Y
  }), [F, Y]), De = h.useMemo(() => ({
    reference: X,
    floating: W
  }), [X, W]), de = h.useMemo(() => {
    const Se = {
      position: u,
      left: 0,
      top: 0
    };
    if (!De.floating)
      return Se;
    const se = BR(De.floating, R.x), Ke = BR(De.floating, R.y);
    return g ? {
      ...Se,
      transform: "translate(" + se + "px, " + Ke + "px)",
      ...D0(De.floating) >= 1.5 && {
        willChange: "transform"
      }
    } : {
      position: u,
      left: se,
      top: Ke
    };
  }, [u, g, De.floating, R.x, R.y]);
  return h.useMemo(() => ({
    ...R,
    update: fe,
    refs: Ie,
    elements: De,
    floatingStyles: de
  }), [R, fe, Ie, De, de]);
}
const fU = (a) => {
  function o(u) {
    return {}.hasOwnProperty.call(u, "current");
  }
  return {
    name: "arrow",
    options: a,
    fn(u) {
      const {
        element: s,
        padding: d
      } = typeof a == "function" ? a(u) : a;
      return s && o(s) ? s.current != null ? IR({
        element: s.current,
        padding: d
      }).fn(u) : {} : s ? IR({
        element: s,
        padding: d
      }).fn(u) : {};
    }
  };
}, dU = (a, o) => ({
  ...rU(a),
  options: [a, o]
}), pU = (a, o) => ({
  ...aU(a),
  options: [a, o]
}), vU = (a, o) => ({
  ...uU(a),
  options: [a, o]
}), hU = (a, o) => ({
  ...iU(a),
  options: [a, o]
}), mU = (a, o) => ({
  ...oU(a),
  options: [a, o]
}), yU = (a, o) => ({
  ...lU(a),
  options: [a, o]
}), gU = (a, o) => ({
  ...fU(a),
  options: [a, o]
});
var bU = "Arrow", _0 = h.forwardRef((a, o) => {
  const { children: u, width: s = 10, height: d = 5, ...v } = a;
  return /* @__PURE__ */ O.jsx(
    St.svg,
    {
      ...v,
      ref: o,
      width: s,
      height: d,
      viewBox: "0 0 30 10",
      preserveAspectRatio: "none",
      children: a.asChild ? u : /* @__PURE__ */ O.jsx("polygon", { points: "0,0 30,0 15,10" })
    }
  );
});
_0.displayName = bU;
var SU = _0;
function CU(a) {
  const [o, u] = h.useState(void 0);
  return ki(() => {
    if (a) {
      u({ width: a.offsetWidth, height: a.offsetHeight });
      const s = new ResizeObserver((d) => {
        if (!Array.isArray(d) || !d.length)
          return;
        const v = d[0];
        let c, g;
        if ("borderBoxSize" in v) {
          const b = v.borderBoxSize, S = Array.isArray(b) ? b[0] : b;
          c = S.inlineSize, g = S.blockSize;
        } else
          c = a.offsetWidth, g = a.offsetHeight;
        u({ width: c, height: g });
      });
      return s.observe(a, { box: "border-box" }), () => s.unobserve(a);
    } else
      u(void 0);
  }, [a]), o;
}
var Wy = "Popper", [M0, Id] = zi(Wy), [EU, O0] = M0(Wy), A0 = (a) => {
  const { __scopePopper: o, children: u } = a, [s, d] = h.useState(null);
  return /* @__PURE__ */ O.jsx(EU, { scope: o, anchor: s, onAnchorChange: d, children: u });
};
A0.displayName = Wy;
var N0 = "PopperAnchor", L0 = h.forwardRef(
  (a, o) => {
    const { __scopePopper: u, virtualRef: s, ...d } = a, v = O0(N0, u), c = h.useRef(null), g = At(o, c);
    return h.useEffect(() => {
      v.onAnchorChange((s == null ? void 0 : s.current) || c.current);
    }), s ? null : /* @__PURE__ */ O.jsx(St.div, { ...d, ref: g });
  }
);
L0.displayName = N0;
var Gy = "PopperContent", [RU, wU] = M0(Gy), k0 = h.forwardRef(
  (a, o) => {
    var Nt, an, at, zt, wn, xn;
    const {
      __scopePopper: u,
      side: s = "bottom",
      sideOffset: d = 0,
      align: v = "center",
      alignOffset: c = 0,
      arrowPadding: g = 0,
      avoidCollisions: b = !0,
      collisionBoundary: S = [],
      collisionPadding: R = 0,
      sticky: E = "partial",
      hideWhenDetached: x = !1,
      updatePositionStrategy: T = "optimized",
      onPlaced: M,
      ...L
    } = a, $ = O0(Gy, u), [U, F] = h.useState(null), Y = At(o, (yt) => F(yt)), [X, W] = h.useState(null), ne = CU(X), Z = (ne == null ? void 0 : ne.width) ?? 0, ve = (ne == null ? void 0 : ne.height) ?? 0, me = s + (v !== "center" ? "-" + v : ""), he = typeof R == "number" ? R : { top: 0, right: 0, bottom: 0, left: 0, ...R }, Ee = Array.isArray(S) ? S : [S], Xe = Ee.length > 0, fe = {
      padding: he,
      boundary: Ee.filter(TU),
      // with `strategy: 'fixed'`, this is the only way to get it to respect boundaries
      altBoundary: Xe
    }, { refs: ge, floatingStyles: Ie, placement: De, isPositioned: de, middlewareData: Se } = cU({
      // default to `fixed` strategy so users don't have to pick and we also avoid focus scroll issues
      strategy: "fixed",
      placement: me,
      whileElementsMounted: (...yt) => nU(...yt, {
        animationFrame: T === "always"
      }),
      elements: {
        reference: $.anchor
      },
      middleware: [
        dU({ mainAxis: d + ve, alignmentAxis: c }),
        b && pU({
          mainAxis: !0,
          crossAxis: !1,
          limiter: E === "partial" ? vU() : void 0,
          ...fe
        }),
        b && hU({ ...fe }),
        mU({
          ...fe,
          apply: ({ elements: yt, rects: Gt, availableWidth: Ht, availableHeight: Lt }) => {
            const { width: kt, height: Un } = Gt.reference, pn = yt.floating.style;
            pn.setProperty("--radix-popper-available-width", `${Ht}px`), pn.setProperty("--radix-popper-available-height", `${Lt}px`), pn.setProperty("--radix-popper-anchor-width", `${kt}px`), pn.setProperty("--radix-popper-anchor-height", `${Un}px`);
          }
        }),
        X && gU({ element: X, padding: g }),
        DU({ arrowWidth: Z, arrowHeight: ve }),
        x && yU({ strategy: "referenceHidden", ...fe })
      ]
    }), [se, Ke] = j0(De), dt = dn(M);
    ki(() => {
      de && (dt == null || dt());
    }, [de, dt]);
    const ft = (Nt = Se.arrow) == null ? void 0 : Nt.x, Ft = (an = Se.arrow) == null ? void 0 : an.y, Yt = ((at = Se.arrow) == null ? void 0 : at.centerOffset) !== 0, [Pn, Wt] = h.useState();
    return ki(() => {
      U && Wt(window.getComputedStyle(U).zIndex);
    }, [U]), /* @__PURE__ */ O.jsx(
      "div",
      {
        ref: ge.setFloating,
        "data-radix-popper-content-wrapper": "",
        style: {
          ...Ie,
          transform: de ? Ie.transform : "translate(0, -200%)",
          // keep off the page when measuring
          minWidth: "max-content",
          zIndex: Pn,
          "--radix-popper-transform-origin": [
            (zt = Se.transformOrigin) == null ? void 0 : zt.x,
            (wn = Se.transformOrigin) == null ? void 0 : wn.y
          ].join(" "),
          // hide the content if using the hide middleware and should be hidden
          // set visibility to hidden and disable pointer events so the UI behaves
          // as if the PopperContent isn't there at all
          ...((xn = Se.hide) == null ? void 0 : xn.referenceHidden) && {
            visibility: "hidden",
            pointerEvents: "none"
          }
        },
        dir: a.dir,
        children: /* @__PURE__ */ O.jsx(
          RU,
          {
            scope: u,
            placedSide: se,
            onArrowChange: W,
            arrowX: ft,
            arrowY: Ft,
            shouldHideArrow: Yt,
            children: /* @__PURE__ */ O.jsx(
              St.div,
              {
                "data-side": se,
                "data-align": Ke,
                ...L,
                ref: Y,
                style: {
                  ...L.style,
                  // if the PopperContent hasn't been placed yet (not all measurements done)
                  // we prevent animations so that users's animation don't kick in too early referring wrong sides
                  animation: de ? void 0 : "none"
                }
              }
            )
          }
        )
      }
    );
  }
);
k0.displayName = Gy;
var P0 = "PopperArrow", xU = {
  top: "bottom",
  right: "left",
  bottom: "top",
  left: "right"
}, U0 = h.forwardRef(function(o, u) {
  const { __scopePopper: s, ...d } = o, v = wU(P0, s), c = xU[v.placedSide];
  return (
    // we have to use an extra wrapper because `ResizeObserver` (used by `useSize`)
    // doesn't report size as we'd expect on SVG elements.
    // it reports their bounding box which is effectively the largest path inside the SVG.
    /* @__PURE__ */ O.jsx(
      "span",
      {
        ref: v.onArrowChange,
        style: {
          position: "absolute",
          left: v.arrowX,
          top: v.arrowY,
          [c]: 0,
          transformOrigin: {
            top: "",
            right: "0 0",
            bottom: "center 0",
            left: "100% 0"
          }[v.placedSide],
          transform: {
            top: "translateY(100%)",
            right: "translateY(50%) rotate(90deg) translateX(-50%)",
            bottom: "rotate(180deg)",
            left: "translateY(50%) rotate(-90deg) translateX(50%)"
          }[v.placedSide],
          visibility: v.shouldHideArrow ? "hidden" : void 0
        },
        children: /* @__PURE__ */ O.jsx(
          SU,
          {
            ...d,
            ref: u,
            style: {
              ...d.style,
              // ensures the element can be measured correctly (mostly for if SVG)
              display: "block"
            }
          }
        )
      }
    )
  );
});
U0.displayName = P0;
function TU(a) {
  return a !== null;
}
var DU = (a) => ({
  name: "transformOrigin",
  options: a,
  fn(o) {
    var $, U, F;
    const { placement: u, rects: s, middlewareData: d } = o, c = (($ = d.arrow) == null ? void 0 : $.centerOffset) !== 0, g = c ? 0 : a.arrowWidth, b = c ? 0 : a.arrowHeight, [S, R] = j0(u), E = { start: "0%", center: "50%", end: "100%" }[R], x = (((U = d.arrow) == null ? void 0 : U.x) ?? 0) + g / 2, T = (((F = d.arrow) == null ? void 0 : F.y) ?? 0) + b / 2;
    let M = "", L = "";
    return S === "bottom" ? (M = c ? E : `${x}px`, L = `${-b}px`) : S === "top" ? (M = c ? E : `${x}px`, L = `${s.floating.height + b}px`) : S === "right" ? (M = `${-b}px`, L = c ? E : `${T}px`) : S === "left" && (M = `${s.floating.width + b}px`, L = c ? E : `${T}px`), { data: { x: M, y: L } };
  }
});
function j0(a) {
  const [o, u = "center"] = a.split("-");
  return [o, u];
}
var _U = A0, F0 = L0, z0 = k0, H0 = U0, [Bd, E3] = zi("Tooltip", [
  Id
]), Xy = Id(), $0 = "TooltipProvider", MU = 700, VR = "tooltip.open", [OU, I0] = Bd($0), B0 = (a) => {
  const {
    __scopeTooltip: o,
    delayDuration: u = MU,
    skipDelayDuration: s = 300,
    disableHoverableContent: d = !1,
    children: v
  } = a, [c, g] = h.useState(!0), b = h.useRef(!1), S = h.useRef(0);
  return h.useEffect(() => {
    const R = S.current;
    return () => window.clearTimeout(R);
  }, []), /* @__PURE__ */ O.jsx(
    OU,
    {
      scope: o,
      isOpenDelayed: c,
      delayDuration: u,
      onOpen: h.useCallback(() => {
        window.clearTimeout(S.current), g(!1);
      }, []),
      onClose: h.useCallback(() => {
        window.clearTimeout(S.current), S.current = window.setTimeout(
          () => g(!0),
          s
        );
      }, [s]),
      isPointerInTransitRef: b,
      onPointerInTransitChange: h.useCallback((R) => {
        b.current = R;
      }, []),
      disableHoverableContent: d,
      children: v
    }
  );
};
B0.displayName = $0;
var V0 = "Tooltip", [R3, Vd] = Bd(V0), Ty = "TooltipTrigger", AU = h.forwardRef(
  (a, o) => {
    const { __scopeTooltip: u, ...s } = a, d = Vd(Ty, u), v = I0(Ty, u), c = Xy(u), g = h.useRef(null), b = At(o, g, d.onTriggerChange), S = h.useRef(!1), R = h.useRef(!1), E = h.useCallback(() => S.current = !1, []);
    return h.useEffect(() => () => document.removeEventListener("pointerup", E), [E]), /* @__PURE__ */ O.jsx(F0, { asChild: !0, ...c, children: /* @__PURE__ */ O.jsx(
      St.button,
      {
        "aria-describedby": d.open ? d.contentId : void 0,
        "data-state": d.stateAttribute,
        ...s,
        ref: b,
        onPointerMove: Oe(a.onPointerMove, (x) => {
          x.pointerType !== "touch" && !R.current && !v.isPointerInTransitRef.current && (d.onTriggerEnter(), R.current = !0);
        }),
        onPointerLeave: Oe(a.onPointerLeave, () => {
          d.onTriggerLeave(), R.current = !1;
        }),
        onPointerDown: Oe(a.onPointerDown, () => {
          S.current = !0, document.addEventListener("pointerup", E, { once: !0 });
        }),
        onFocus: Oe(a.onFocus, () => {
          S.current || d.onOpen();
        }),
        onBlur: Oe(a.onBlur, d.onClose),
        onClick: Oe(a.onClick, d.onClose)
      }
    ) });
  }
);
AU.displayName = Ty;
var NU = "TooltipPortal", [w3, LU] = Bd(NU, {
  forceMount: void 0
}), Fl = "TooltipContent", kU = h.forwardRef(
  (a, o) => {
    const u = LU(Fl, a.__scopeTooltip), { forceMount: s = u.forceMount, side: d = "top", ...v } = a, c = Vd(Fl, a.__scopeTooltip);
    return /* @__PURE__ */ O.jsx(Qr, { present: s || c.open, children: c.disableHoverableContent ? /* @__PURE__ */ O.jsx(Y0, { side: d, ...v, ref: o }) : /* @__PURE__ */ O.jsx(PU, { side: d, ...v, ref: o }) });
  }
), PU = h.forwardRef((a, o) => {
  const u = Vd(Fl, a.__scopeTooltip), s = I0(Fl, a.__scopeTooltip), d = h.useRef(null), v = At(o, d), [c, g] = h.useState(null), { trigger: b, onClose: S } = u, R = d.current, { onPointerInTransitChange: E } = s, x = h.useCallback(() => {
    g(null), E(!1);
  }, [E]), T = h.useCallback(
    (M, L) => {
      const $ = M.currentTarget, U = { x: M.clientX, y: M.clientY }, F = zU(U, $.getBoundingClientRect()), Y = HU(U, F), X = $U(L.getBoundingClientRect()), W = BU([...Y, ...X]);
      g(W), E(!0);
    },
    [E]
  );
  return h.useEffect(() => () => x(), [x]), h.useEffect(() => {
    if (b && R) {
      const M = ($) => T($, R), L = ($) => T($, b);
      return b.addEventListener("pointerleave", M), R.addEventListener("pointerleave", L), () => {
        b.removeEventListener("pointerleave", M), R.removeEventListener("pointerleave", L);
      };
    }
  }, [b, R, T, x]), h.useEffect(() => {
    if (c) {
      const M = (L) => {
        const $ = L.target, U = { x: L.clientX, y: L.clientY }, F = (b == null ? void 0 : b.contains($)) || (R == null ? void 0 : R.contains($)), Y = !IU(U, c);
        F ? x() : Y && (x(), S());
      };
      return document.addEventListener("pointermove", M), () => document.removeEventListener("pointermove", M);
    }
  }, [b, R, c, S, x]), /* @__PURE__ */ O.jsx(Y0, { ...a, ref: v });
}), [UU, jU] = Bd(V0, { isInside: !1 }), Y0 = h.forwardRef(
  (a, o) => {
    const {
      __scopeTooltip: u,
      children: s,
      "aria-label": d,
      onEscapeKeyDown: v,
      onPointerDownOutside: c,
      ...g
    } = a, b = Vd(Fl, u), S = Xy(u), { onClose: R } = b;
    return h.useEffect(() => (document.addEventListener(VR, R), () => document.removeEventListener(VR, R)), [R]), h.useEffect(() => {
      if (b.trigger) {
        const E = (x) => {
          const T = x.target;
          T != null && T.contains(b.trigger) && R();
        };
        return window.addEventListener("scroll", E, { capture: !0 }), () => window.removeEventListener("scroll", E, { capture: !0 });
      }
    }, [b.trigger, R]), /* @__PURE__ */ O.jsx(
      Uy,
      {
        asChild: !0,
        disableOutsidePointerEvents: !1,
        onEscapeKeyDown: v,
        onPointerDownOutside: c,
        onFocusOutside: (E) => E.preventDefault(),
        onDismiss: R,
        children: /* @__PURE__ */ O.jsxs(
          z0,
          {
            "data-state": b.stateAttribute,
            ...S,
            ...g,
            ref: o,
            style: {
              ...g.style,
              "--radix-tooltip-content-transform-origin": "var(--radix-popper-transform-origin)",
              "--radix-tooltip-content-available-width": "var(--radix-popper-available-width)",
              "--radix-tooltip-content-available-height": "var(--radix-popper-available-height)",
              "--radix-tooltip-trigger-width": "var(--radix-popper-anchor-width)",
              "--radix-tooltip-trigger-height": "var(--radix-popper-anchor-height)"
            },
            children: [
              /* @__PURE__ */ O.jsx(Ly, { children: s }),
              /* @__PURE__ */ O.jsx(UU, { scope: u, isInside: !0, children: /* @__PURE__ */ O.jsx(ok, { id: b.contentId, role: "tooltip", children: d || s }) })
            ]
          }
        )
      }
    );
  }
);
kU.displayName = Fl;
var W0 = "TooltipArrow", FU = h.forwardRef(
  (a, o) => {
    const { __scopeTooltip: u, ...s } = a, d = Xy(u);
    return jU(
      W0,
      u
    ).isInside ? null : /* @__PURE__ */ O.jsx(H0, { ...d, ...s, ref: o });
  }
);
FU.displayName = W0;
function zU(a, o) {
  const u = Math.abs(o.top - a.y), s = Math.abs(o.bottom - a.y), d = Math.abs(o.right - a.x), v = Math.abs(o.left - a.x);
  switch (Math.min(u, s, d, v)) {
    case v:
      return "left";
    case d:
      return "right";
    case u:
      return "top";
    case s:
      return "bottom";
    default:
      throw new Error("unreachable");
  }
}
function HU(a, o, u = 5) {
  const s = [];
  switch (o) {
    case "top":
      s.push(
        { x: a.x - u, y: a.y + u },
        { x: a.x + u, y: a.y + u }
      );
      break;
    case "bottom":
      s.push(
        { x: a.x - u, y: a.y - u },
        { x: a.x + u, y: a.y - u }
      );
      break;
    case "left":
      s.push(
        { x: a.x + u, y: a.y - u },
        { x: a.x + u, y: a.y + u }
      );
      break;
    case "right":
      s.push(
        { x: a.x - u, y: a.y - u },
        { x: a.x - u, y: a.y + u }
      );
      break;
  }
  return s;
}
function $U(a) {
  const { top: o, right: u, bottom: s, left: d } = a;
  return [
    { x: d, y: o },
    { x: u, y: o },
    { x: u, y: s },
    { x: d, y: s }
  ];
}
function IU(a, o) {
  const { x: u, y: s } = a;
  let d = !1;
  for (let v = 0, c = o.length - 1; v < o.length; c = v++) {
    const g = o[v].x, b = o[v].y, S = o[c].x, R = o[c].y;
    b > s != R > s && u < (S - g) * (s - b) / (R - b) + g && (d = !d);
  }
  return d;
}
function BU(a) {
  const o = a.slice();
  return o.sort((u, s) => u.x < s.x ? -1 : u.x > s.x ? 1 : u.y < s.y ? -1 : u.y > s.y ? 1 : 0), VU(o);
}
function VU(a) {
  if (a.length <= 1)
    return a.slice();
  const o = [];
  for (let s = 0; s < a.length; s++) {
    const d = a[s];
    for (; o.length >= 2; ) {
      const v = o[o.length - 1], c = o[o.length - 2];
      if ((v.x - c.x) * (d.y - c.y) >= (v.y - c.y) * (d.x - c.x))
        o.pop();
      else
        break;
    }
    o.push(d);
  }
  o.pop();
  const u = [];
  for (let s = a.length - 1; s >= 0; s--) {
    const d = a[s];
    for (; u.length >= 2; ) {
      const v = u[u.length - 1], c = u[u.length - 2];
      if ((v.x - c.x) * (d.y - c.y) >= (v.y - c.y) * (d.x - c.x))
        u.pop();
      else
        break;
    }
    u.push(d);
  }
  return u.pop(), o.length === 1 && u.length === 1 && o[0].x === u[0].x && o[0].y === u[0].y ? o : o.concat(u);
}
var YU = B0, G0 = h.createContext(void 0), WU = (a) => {
  const { dir: o, children: u } = a;
  return /* @__PURE__ */ O.jsx(G0.Provider, { value: o, children: u });
};
function Yd(a) {
  const o = h.useContext(G0);
  return a || o || "ltr";
}
function GU(a) {
  switch (a) {
    case "tomato":
    case "red":
    case "ruby":
    case "crimson":
    case "pink":
    case "plum":
    case "purple":
    case "violet":
      return "mauve";
    case "iris":
    case "indigo":
    case "blue":
    case "sky":
    case "cyan":
      return "slate";
    case "teal":
    case "jade":
    case "mint":
    case "green":
      return "sage";
    case "grass":
    case "lime":
      return "olive";
    case "yellow":
    case "amber":
    case "orange":
    case "brown":
    case "gold":
    case "bronze":
      return "sand";
    case "gray":
      return "gray";
  }
}
const X0 = ["none", "small", "medium", "large", "full"], Ky = { radius: { type: "enum", values: X0, default: void 0 } }, XU = ["inherit", "light", "dark"], KU = ["solid", "translucent"], qU = ["90%", "95%", "100%", "105%", "110%"], vr = { ...Do, hasBackground: { type: "boolean", default: !0 }, appearance: { type: "enum", values: XU, default: "inherit" }, accentColor: { type: "enum", values: jy, default: "indigo" }, grayColor: { type: "enum", values: gP, default: "auto" }, panelBackground: { type: "enum", values: KU, default: "translucent" }, radius: { type: "enum", values: X0, default: "medium" }, scaling: { type: "enum", values: qU, default: "100%" } }, kl = () => {
}, Nd = h.createContext(void 0);
function QU() {
  const a = h.useContext(Nd);
  if (a === void 0)
    throw new Error("`useThemeContext` must be used within a `Theme`");
  return a;
}
const Wd = h.forwardRef((a, o) => h.useContext(Nd) === void 0 ? h.createElement(YU, { delayDuration: 200 }, h.createElement(WU, { dir: "ltr" }, h.createElement(K0, { ...a, ref: o }))) : h.createElement(qy, { ...a, ref: o }));
Wd.displayName = "Theme";
const K0 = h.forwardRef((a, o) => {
  const { appearance: u = vr.appearance.default, accentColor: s = vr.accentColor.default, grayColor: d = vr.grayColor.default, panelBackground: v = vr.panelBackground.default, radius: c = vr.radius.default, scaling: g = vr.scaling.default, hasBackground: b = vr.hasBackground.default, ...S } = a, [R, E] = h.useState(u);
  h.useEffect(() => E(u), [u]);
  const [x, T] = h.useState(s);
  h.useEffect(() => T(s), [s]);
  const [M, L] = h.useState(d);
  h.useEffect(() => L(d), [d]);
  const [$, U] = h.useState(v);
  h.useEffect(() => U(v), [v]);
  const [F, Y] = h.useState(c);
  h.useEffect(() => Y(c), [c]);
  const [X, W] = h.useState(g);
  return h.useEffect(() => W(g), [g]), h.createElement(qy, { ...S, ref: o, isRoot: !0, hasBackground: b, appearance: R, accentColor: x, grayColor: M, panelBackground: $, radius: F, scaling: X, onAppearanceChange: E, onAccentColorChange: T, onGrayColorChange: L, onPanelBackgroundChange: U, onRadiusChange: Y, onScalingChange: W });
});
K0.displayName = "ThemeRoot";
const qy = h.forwardRef((a, o) => {
  const u = h.useContext(Nd), { asChild: s, isRoot: d, hasBackground: v, appearance: c = (u == null ? void 0 : u.appearance) ?? vr.appearance.default, accentColor: g = (u == null ? void 0 : u.accentColor) ?? vr.accentColor.default, grayColor: b = (u == null ? void 0 : u.resolvedGrayColor) ?? vr.grayColor.default, panelBackground: S = (u == null ? void 0 : u.panelBackground) ?? vr.panelBackground.default, radius: R = (u == null ? void 0 : u.radius) ?? vr.radius.default, scaling: E = (u == null ? void 0 : u.scaling) ?? vr.scaling.default, onAppearanceChange: x = kl, onAccentColorChange: T = kl, onGrayColorChange: M = kl, onPanelBackgroundChange: L = kl, onRadiusChange: $ = kl, onScalingChange: U = kl, ...F } = a, Y = s ? ya : "div", X = b === "auto" ? GU(g) : b, W = a.appearance === "light" || a.appearance === "dark", ne = v === void 0 ? d || W : v;
  return h.createElement(Nd.Provider, { value: h.useMemo(() => ({ appearance: c, accentColor: g, grayColor: b, resolvedGrayColor: X, panelBackground: S, radius: R, scaling: E, onAppearanceChange: x, onAccentColorChange: T, onGrayColorChange: M, onPanelBackgroundChange: L, onRadiusChange: $, onScalingChange: U }), [c, g, b, X, S, R, E, x, T, M, L, $, U]) }, h.createElement(Y, { "data-is-root-theme": d ? "true" : "false", "data-accent-color": g, "data-gray-color": X, "data-has-background": ne ? "true" : "false", "data-panel-background": S, "data-radius": R, "data-scaling": E, ref: o, ...F, className: je("radix-themes", { light: c === "light", dark: c === "dark" }, F.className) }));
});
qy.displayName = "ThemeImpl";
const ZU = (a) => {
  if (!h.isValidElement(a))
    throw Error(`Expected a single React Element child, but got: ${h.Children.toArray(a).map((o) => typeof o == "object" && "type" in o && typeof o.type == "string" ? o.type : typeof o).join(", ")}`);
  return a;
};
function JU(a, o) {
  const { asChild: u, children: s } = a;
  if (!u)
    return typeof o == "function" ? o(s) : o;
  const d = h.Children.only(s);
  return h.cloneElement(d, { children: typeof o == "function" ? o(d.props.children) : o });
}
const ej = ["div", "span"], tj = ["none", "inline", "inline-block", "block"], nj = { as: { type: "enum", values: ej, default: "div" }, ...Do, display: { type: "enum", className: "rt-r-display", values: tj, responsive: !0 } }, wo = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"], $s = { p: { type: "enum | string", className: "rt-r-p", customProperties: ["--p"], values: wo, responsive: !0 }, px: { type: "enum | string", className: "rt-r-px", customProperties: ["--pl", "--pr"], values: wo, responsive: !0 }, py: { type: "enum | string", className: "rt-r-py", customProperties: ["--pt", "--pb"], values: wo, responsive: !0 }, pt: { type: "enum | string", className: "rt-r-pt", customProperties: ["--pt"], values: wo, responsive: !0 }, pr: { type: "enum | string", className: "rt-r-pr", customProperties: ["--pr"], values: wo, responsive: !0 }, pb: { type: "enum | string", className: "rt-r-pb", customProperties: ["--pb"], values: wo, responsive: !0 }, pl: { type: "enum | string", className: "rt-r-pl", customProperties: ["--pl"], values: wo, responsive: !0 } }, vy = ["visible", "hidden", "clip", "scroll", "auto"], rj = ["static", "relative", "absolute", "fixed", "sticky"], Ps = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "-1", "-2", "-3", "-4", "-5", "-6", "-7", "-8", "-9"], aj = ["0", "1"], ij = ["0", "1"], Qy = { ...$s, ...g0, ...yP, position: { type: "enum", className: "rt-r-position", values: rj, responsive: !0 }, inset: { type: "enum | string", className: "rt-r-inset", customProperties: ["--inset"], values: Ps, responsive: !0 }, top: { type: "enum | string", className: "rt-r-top", customProperties: ["--top"], values: Ps, responsive: !0 }, right: { type: "enum | string", className: "rt-r-right", customProperties: ["--right"], values: Ps, responsive: !0 }, bottom: { type: "enum | string", className: "rt-r-bottom", customProperties: ["--bottom"], values: Ps, responsive: !0 }, left: { type: "enum | string", className: "rt-r-left", customProperties: ["--left"], values: Ps, responsive: !0 }, overflow: { type: "enum", className: "rt-r-overflow", values: vy, responsive: !0 }, overflowX: { type: "enum", className: "rt-r-ox", values: vy, responsive: !0 }, overflowY: { type: "enum", className: "rt-r-oy", values: vy, responsive: !0 }, flexBasis: { type: "string", className: "rt-r-fb", customProperties: ["--flex-basis"], responsive: !0 }, flexShrink: { type: "enum | string", className: "rt-r-fs", customProperties: ["--flex-shrink"], values: aj, responsive: !0 }, flexGrow: { type: "enum | string", className: "rt-r-fg", customProperties: ["--flex-grow"], values: ij, responsive: !0 }, gridArea: { type: "string", className: "rt-r-ga", customProperties: ["--grid-area"], responsive: !0 }, gridColumn: { type: "string", className: "rt-r-gc", customProperties: ["--grid-column"], responsive: !0 }, gridColumnStart: { type: "string", className: "rt-r-gcs", customProperties: ["--grid-column-start"], responsive: !0 }, gridColumnEnd: { type: "string", className: "rt-r-gce", customProperties: ["--grid-column-end"], responsive: !0 }, gridRow: { type: "string", className: "rt-r-gr", customProperties: ["--grid-row"], responsive: !0 }, gridRowStart: { type: "string", className: "rt-r-grs", customProperties: ["--grid-row-start"], responsive: !0 }, gridRowEnd: { type: "string", className: "rt-r-gre", customProperties: ["--grid-row-end"], responsive: !0 } }, q0 = h.forwardRef((a, o) => {
  const { className: u, asChild: s, as: d = "div", ...v } = Rn(a, nj, Qy, Zr);
  return h.createElement(s ? ya : d, { ...v, ref: o, className: je("rt-Box", u) });
});
q0.displayName = "Box";
const oj = ["1", "2", "3", "4"], lj = ["classic", "solid", "soft", "surface", "outline", "ghost"], YR = { ...Do, size: { type: "enum", className: "rt-r-size", values: oj, default: "2", responsive: !0 }, variant: { type: "enum", className: "rt-variant", values: lj, default: "solid" }, ...bP, ...Fy, ...Ky, loading: { type: "boolean", className: "rt-loading", default: !1 } }, hy = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"], Q0 = { gap: { type: "enum | string", className: "rt-r-gap", customProperties: ["--gap"], values: hy, responsive: !0 }, gapX: { type: "enum | string", className: "rt-r-cg", customProperties: ["--column-gap"], values: hy, responsive: !0 }, gapY: { type: "enum | string", className: "rt-r-rg", customProperties: ["--row-gap"], values: hy, responsive: !0 } }, uj = ["div", "span"], sj = ["none", "inline-flex", "flex"], cj = ["row", "column", "row-reverse", "column-reverse"], fj = ["start", "center", "end", "baseline", "stretch"], dj = ["start", "center", "end", "between"], pj = ["nowrap", "wrap", "wrap-reverse"], Z0 = { as: { type: "enum", values: uj, default: "div" }, ...Do, display: { type: "enum", className: "rt-r-display", values: sj, responsive: !0 }, direction: { type: "enum", className: "rt-r-fd", values: cj, responsive: !0 }, align: { type: "enum", className: "rt-r-ai", values: fj, responsive: !0 }, justify: { type: "enum", className: "rt-r-jc", values: dj, parseValue: vj, responsive: !0 }, wrap: { type: "enum", className: "rt-r-fw", values: pj, responsive: !0 }, ...Q0 };
function vj(a) {
  return a === "between" ? "space-between" : a;
}
const Ld = h.forwardRef((a, o) => {
  const { className: u, asChild: s, as: d = "div", ...v } = Rn(a, Z0, Qy, Zr);
  return h.createElement(s ? ya : d, { ...v, ref: o, className: je("rt-Flex", u) });
});
Ld.displayName = "Flex";
const hj = ["1", "2", "3"], mj = { size: { type: "enum", className: "rt-r-size", values: hj, default: "2", responsive: !0 }, loading: { type: "boolean", default: !0 } }, J0 = h.forwardRef((a, o) => {
  const { className: u, children: s, loading: d, ...v } = Rn(a, mj, Zr);
  if (!d)
    return s;
  const c = h.createElement("span", { ...v, ref: o, className: je("rt-Spinner", u) }, h.createElement("span", { className: "rt-SpinnerLeaf" }), h.createElement("span", { className: "rt-SpinnerLeaf" }), h.createElement("span", { className: "rt-SpinnerLeaf" }), h.createElement("span", { className: "rt-SpinnerLeaf" }), h.createElement("span", { className: "rt-SpinnerLeaf" }), h.createElement("span", { className: "rt-SpinnerLeaf" }), h.createElement("span", { className: "rt-SpinnerLeaf" }), h.createElement("span", { className: "rt-SpinnerLeaf" }));
  return s === void 0 ? c : h.createElement(Ld, { asChild: !0, position: "relative", align: "center", justify: "center" }, h.createElement("span", null, h.createElement("span", { "aria-hidden": !0, style: { display: "contents", visibility: "hidden" }, inert: void 0 }, s), h.createElement(Ld, { asChild: !0, align: "center", justify: "center", position: "absolute", inset: "0" }, h.createElement("span", null, c))));
});
J0.displayName = "Spinner";
function yj(a, o) {
  if (a !== void 0)
    return typeof a == "string" ? o(a) : Object.fromEntries(Object.entries(a).map(([u, s]) => [u, o(s)]));
}
function gj(a) {
  switch (a) {
    case "1":
      return "1";
    case "2":
    case "3":
      return "2";
    case "4":
      return "3";
  }
}
const ew = h.forwardRef((a, o) => {
  const { size: u = YR.size.default } = a, { className: s, children: d, asChild: v, color: c, radius: g, disabled: b = a.loading, ...S } = Rn(a, YR, Zr);
  return h.createElement(v ? ya : "button", { "data-disabled": b || void 0, "data-accent-color": c, "data-radius": g, ...S, ref: o, className: je("rt-reset", "rt-BaseButton", s), disabled: b }, a.loading ? h.createElement(h.Fragment, null, h.createElement("span", { style: { display: "contents", visibility: "hidden" }, "aria-hidden": !0 }, d), h.createElement(ky, null, d), h.createElement(Ld, { asChild: !0, align: "center", justify: "center", position: "absolute", inset: "0" }, h.createElement("span", null, h.createElement(J0, { size: yj(u, gj) })))) : d);
});
ew.displayName = "BaseButton";
const Ws = h.forwardRef(({ className: a, ...o }, u) => h.createElement(ew, { ...o, ref: u, className: je("rt-Button", a) }));
Ws.displayName = "Button";
function tw(a) {
  const o = a + "CollectionProvider", [u, s] = zi(o), [d, v] = u(
    o,
    { collectionRef: { current: null }, itemMap: /* @__PURE__ */ new Map() }
  ), c = (T) => {
    const { scope: M, children: L } = T, $ = Vt.useRef(null), U = Vt.useRef(/* @__PURE__ */ new Map()).current;
    return /* @__PURE__ */ O.jsx(d, { scope: M, itemMap: U, collectionRef: $, children: L });
  };
  c.displayName = o;
  const g = a + "CollectionSlot", b = Vt.forwardRef(
    (T, M) => {
      const { scope: L, children: $ } = T, U = v(g, L), F = At(M, U.collectionRef);
      return /* @__PURE__ */ O.jsx(ya, { ref: F, children: $ });
    }
  );
  b.displayName = g;
  const S = a + "CollectionItemSlot", R = "data-radix-collection-item", E = Vt.forwardRef(
    (T, M) => {
      const { scope: L, children: $, ...U } = T, F = Vt.useRef(null), Y = At(M, F), X = v(S, L);
      return Vt.useEffect(() => (X.itemMap.set(F, { ref: F, ...U }), () => void X.itemMap.delete(F))), /* @__PURE__ */ O.jsx(ya, { [R]: "", ref: Y, children: $ });
    }
  );
  E.displayName = S;
  function x(T) {
    const M = v(a + "CollectionConsumer", T);
    return Vt.useCallback(() => {
      const $ = M.collectionRef.current;
      if (!$)
        return [];
      const U = Array.from($.querySelectorAll(`[${R}]`));
      return Array.from(M.itemMap.values()).sort(
        (X, W) => U.indexOf(X.ref.current) - U.indexOf(W.ref.current)
      );
    }, [M.collectionRef, M.itemMap]);
  }
  return [
    { Provider: c, Slot: b, ItemSlot: E },
    x,
    s
  ];
}
var my = "rovingFocusGroup.onEntryFocus", bj = { bubbles: !1, cancelable: !0 }, Gd = "RovingFocusGroup", [Dy, nw, Sj] = tw(Gd), [Cj, Xd] = zi(
  Gd,
  [Sj]
), [Ej, Rj] = Cj(Gd), rw = h.forwardRef(
  (a, o) => /* @__PURE__ */ O.jsx(Dy.Provider, { scope: a.__scopeRovingFocusGroup, children: /* @__PURE__ */ O.jsx(Dy.Slot, { scope: a.__scopeRovingFocusGroup, children: /* @__PURE__ */ O.jsx(wj, { ...a, ref: o }) }) })
);
rw.displayName = Gd;
var wj = h.forwardRef((a, o) => {
  const {
    __scopeRovingFocusGroup: u,
    orientation: s,
    loop: d = !1,
    dir: v,
    currentTabStopId: c,
    defaultCurrentTabStopId: g,
    onCurrentTabStopIdChange: b,
    onEntryFocus: S,
    preventScrollOnEntryFocus: R = !1,
    ...E
  } = a, x = h.useRef(null), T = At(o, x), M = Yd(v), [L = null, $] = Py({
    prop: c,
    defaultProp: g,
    onChange: b
  }), [U, F] = h.useState(!1), Y = dn(S), X = nw(u), W = h.useRef(!1), [ne, Z] = h.useState(0);
  return h.useEffect(() => {
    const ve = x.current;
    if (ve)
      return ve.addEventListener(my, Y), () => ve.removeEventListener(my, Y);
  }, [Y]), /* @__PURE__ */ O.jsx(
    Ej,
    {
      scope: u,
      orientation: s,
      dir: M,
      loop: d,
      currentTabStopId: L,
      onItemFocus: h.useCallback(
        (ve) => $(ve),
        [$]
      ),
      onItemShiftTab: h.useCallback(() => F(!0), []),
      onFocusableItemAdd: h.useCallback(
        () => Z((ve) => ve + 1),
        []
      ),
      onFocusableItemRemove: h.useCallback(
        () => Z((ve) => ve - 1),
        []
      ),
      children: /* @__PURE__ */ O.jsx(
        St.div,
        {
          tabIndex: U || ne === 0 ? -1 : 0,
          "data-orientation": s,
          ...E,
          ref: T,
          style: { outline: "none", ...a.style },
          onMouseDown: Oe(a.onMouseDown, () => {
            W.current = !0;
          }),
          onFocus: Oe(a.onFocus, (ve) => {
            const me = !W.current;
            if (ve.target === ve.currentTarget && me && !U) {
              const he = new CustomEvent(my, bj);
              if (ve.currentTarget.dispatchEvent(he), !he.defaultPrevented) {
                const Ee = X().filter((De) => De.focusable), Xe = Ee.find((De) => De.active), fe = Ee.find((De) => De.id === L), Ie = [Xe, fe, ...Ee].filter(
                  Boolean
                ).map((De) => De.ref.current);
                ow(Ie, R);
              }
            }
            W.current = !1;
          }),
          onBlur: Oe(a.onBlur, () => F(!1))
        }
      )
    }
  );
}), aw = "RovingFocusGroupItem", iw = h.forwardRef(
  (a, o) => {
    const {
      __scopeRovingFocusGroup: u,
      focusable: s = !0,
      active: d = !1,
      tabStopId: v,
      ...c
    } = a, g = Td(), b = v || g, S = Rj(aw, u), R = S.currentTabStopId === b, E = nw(u), { onFocusableItemAdd: x, onFocusableItemRemove: T } = S;
    return h.useEffect(() => {
      if (s)
        return x(), () => T();
    }, [s, x, T]), /* @__PURE__ */ O.jsx(
      Dy.ItemSlot,
      {
        scope: u,
        id: b,
        focusable: s,
        active: d,
        children: /* @__PURE__ */ O.jsx(
          St.span,
          {
            tabIndex: R ? 0 : -1,
            "data-orientation": S.orientation,
            ...c,
            ref: o,
            onMouseDown: Oe(a.onMouseDown, (M) => {
              s ? S.onItemFocus(b) : M.preventDefault();
            }),
            onFocus: Oe(a.onFocus, () => S.onItemFocus(b)),
            onKeyDown: Oe(a.onKeyDown, (M) => {
              if (M.key === "Tab" && M.shiftKey) {
                S.onItemShiftTab();
                return;
              }
              if (M.target !== M.currentTarget)
                return;
              const L = Dj(M, S.orientation, S.dir);
              if (L !== void 0) {
                if (M.metaKey || M.ctrlKey || M.altKey || M.shiftKey)
                  return;
                M.preventDefault();
                let U = E().filter((F) => F.focusable).map((F) => F.ref.current);
                if (L === "last")
                  U.reverse();
                else if (L === "prev" || L === "next") {
                  L === "prev" && U.reverse();
                  const F = U.indexOf(M.currentTarget);
                  U = S.loop ? _j(U, F + 1) : U.slice(F + 1);
                }
                setTimeout(() => ow(U));
              }
            })
          }
        )
      }
    );
  }
);
iw.displayName = aw;
var xj = {
  ArrowLeft: "prev",
  ArrowUp: "prev",
  ArrowRight: "next",
  ArrowDown: "next",
  PageUp: "first",
  Home: "first",
  PageDown: "last",
  End: "last"
};
function Tj(a, o) {
  return o !== "rtl" ? a : a === "ArrowLeft" ? "ArrowRight" : a === "ArrowRight" ? "ArrowLeft" : a;
}
function Dj(a, o, u) {
  const s = Tj(a.key, u);
  if (!(o === "vertical" && ["ArrowLeft", "ArrowRight"].includes(s)) && !(o === "horizontal" && ["ArrowUp", "ArrowDown"].includes(s)))
    return xj[s];
}
function ow(a, o = !1) {
  const u = document.activeElement;
  for (const s of a)
    if (s === u || (s.focus({ preventScroll: o }), document.activeElement !== u))
      return;
}
function _j(a, o) {
  return a.map((u, s) => a[(o + s) % a.length]);
}
var lw = rw, uw = iw;
const Mj = ["div", "span"], Oj = ["none", "inline-grid", "grid"], Aj = ["1", "2", "3", "4", "5", "6", "7", "8", "9"], Nj = ["1", "2", "3", "4", "5", "6", "7", "8", "9"], Lj = ["row", "column", "dense", "row-dense", "column-dense"], kj = ["start", "center", "end", "baseline", "stretch"], Pj = ["start", "center", "end", "between"], sw = { as: { type: "enum", values: Mj, default: "div" }, ...Do, display: { type: "enum", className: "rt-r-display", values: Oj, responsive: !0 }, areas: { type: "string", className: "rt-r-gta", customProperties: ["--grid-template-areas"], responsive: !0 }, columns: { type: "enum | string", className: "rt-r-gtc", customProperties: ["--grid-template-columns"], values: Aj, parseValue: WR, responsive: !0 }, rows: { type: "enum | string", className: "rt-r-gtr", customProperties: ["--grid-template-rows"], values: Nj, parseValue: WR, responsive: !0 }, flow: { type: "enum", className: "rt-r-gaf", values: Lj, responsive: !0 }, align: { type: "enum", className: "rt-r-ai", values: kj, responsive: !0 }, justify: { type: "enum", className: "rt-r-jc", values: Pj, parseValue: Uj, responsive: !0 }, ...Q0 };
function WR(a) {
  return sw.columns.values.includes(a) ? a : a != null && a.match(/^\d+$/) ? `repeat(${a}, minmax(0, 1fr))` : a;
}
function Uj(a) {
  return a === "between" ? "space-between" : a;
}
const Il = h.forwardRef((a, o) => {
  const { className: u, asChild: s, as: d = "div", ...v } = Rn(a, sw, Qy, Zr);
  return h.createElement(s ? ya : d, { ...v, ref: o, className: je("rt-Grid", u) });
});
Il.displayName = "Grid";
const jj = Vt.forwardRef((a, o) => Vt.createElement("svg", { width: "9", height: "9", viewBox: "0 0 9 9", fill: "currentcolor", xmlns: "http://www.w3.org/2000/svg", ...a, ref: o }, Vt.createElement("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M0.75 4.5C0.75 4.08579 1.08579 3.75 1.5 3.75H7.5C7.91421 3.75 8.25 4.08579 8.25 4.5C8.25 4.91421 7.91421 5.25 7.5 5.25H1.5C1.08579 5.25 0.75 4.91421 0.75 4.5Z" })));
jj.displayName = "ThickDividerHorizontalIcon";
const Zy = Vt.forwardRef((a, o) => Vt.createElement("svg", { width: "9", height: "9", viewBox: "0 0 9 9", fill: "currentcolor", xmlns: "http://www.w3.org/2000/svg", ...a, ref: o }, Vt.createElement("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M8.53547 0.62293C8.88226 0.849446 8.97976 1.3142 8.75325 1.66099L4.5083 8.1599C4.38833 8.34356 4.19397 8.4655 3.9764 8.49358C3.75883 8.52167 3.53987 8.45309 3.3772 8.30591L0.616113 5.80777C0.308959 5.52987 0.285246 5.05559 0.563148 4.74844C0.84105 4.44128 1.31533 4.41757 1.62249 4.69547L3.73256 6.60459L7.49741 0.840706C7.72393 0.493916 8.18868 0.396414 8.53547 0.62293Z" })));
Zy.displayName = "ThickCheckIcon";
const Fj = Vt.forwardRef((a, o) => Vt.createElement("svg", { width: "9", height: "9", viewBox: "0 0 9 9", fill: "currentcolor", xmlns: "http://www.w3.org/2000/svg", ...a, ref: o }, Vt.createElement("path", { d: "M0.135232 3.15803C0.324102 2.95657 0.640521 2.94637 0.841971 3.13523L4.5 6.56464L8.158 3.13523C8.3595 2.94637 8.6759 2.95657 8.8648 3.15803C9.0536 3.35949 9.0434 3.67591 8.842 3.86477L4.84197 7.6148C4.64964 7.7951 4.35036 7.7951 4.15803 7.6148L0.158031 3.86477C-0.0434285 3.67591 -0.0536285 3.35949 0.135232 3.15803Z" })));
Fj.displayName = "ChevronDownIcon";
const cw = Vt.forwardRef((a, o) => Vt.createElement("svg", { width: "9", height: "9", viewBox: "0 0 9 9", fill: "currentcolor", xmlns: "http://www.w3.org/2000/svg", ...a, ref: o }, Vt.createElement("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M3.23826 0.201711C3.54108 -0.0809141 4.01567 -0.0645489 4.29829 0.238264L7.79829 3.98826C8.06724 4.27642 8.06724 4.72359 7.79829 5.01174L4.29829 8.76174C4.01567 9.06455 3.54108 9.08092 3.23826 8.79829C2.93545 8.51567 2.91909 8.04108 3.20171 7.73826L6.22409 4.5L3.20171 1.26174C2.91909 0.958928 2.93545 0.484337 3.23826 0.201711Z" })));
cw.displayName = "ThickChevronRightIcon";
var _y = ["Enter", " "], zj = ["ArrowDown", "PageUp", "Home"], fw = ["ArrowUp", "PageDown", "End"], Hj = [...zj, ...fw], $j = {
  ltr: [..._y, "ArrowRight"],
  rtl: [..._y, "ArrowLeft"]
}, Ij = {
  ltr: ["ArrowLeft"],
  rtl: ["ArrowRight"]
}, Zs = "Menu", [Gs, Bj, Vj] = tw(Zs), [Mo, dw] = zi(Zs, [
  Vj,
  Id,
  Xd
]), Kd = Id(), pw = Xd(), [Yj, Oo] = Mo(Zs), [Wj, Js] = Mo(Zs), vw = (a) => {
  const { __scopeMenu: o, open: u = !1, children: s, dir: d, onOpenChange: v, modal: c = !0 } = a, g = Kd(o), [b, S] = h.useState(null), R = h.useRef(!1), E = dn(v), x = Yd(d);
  return h.useEffect(() => {
    const T = () => {
      R.current = !0, document.addEventListener("pointerdown", M, { capture: !0, once: !0 }), document.addEventListener("pointermove", M, { capture: !0, once: !0 });
    }, M = () => R.current = !1;
    return document.addEventListener("keydown", T, { capture: !0 }), () => {
      document.removeEventListener("keydown", T, { capture: !0 }), document.removeEventListener("pointerdown", M, { capture: !0 }), document.removeEventListener("pointermove", M, { capture: !0 });
    };
  }, []), /* @__PURE__ */ O.jsx(_U, { ...g, children: /* @__PURE__ */ O.jsx(
    Yj,
    {
      scope: o,
      open: u,
      onOpenChange: E,
      content: b,
      onContentChange: S,
      children: /* @__PURE__ */ O.jsx(
        Wj,
        {
          scope: o,
          onClose: h.useCallback(() => E(!1), [E]),
          isUsingKeyboardRef: R,
          dir: x,
          modal: c,
          children: s
        }
      )
    }
  ) });
};
vw.displayName = Zs;
var Gj = "MenuAnchor", Jy = h.forwardRef(
  (a, o) => {
    const { __scopeMenu: u, ...s } = a, d = Kd(u);
    return /* @__PURE__ */ O.jsx(F0, { ...d, ...s, ref: o });
  }
);
Jy.displayName = Gj;
var eg = "MenuPortal", [Xj, hw] = Mo(eg, {
  forceMount: void 0
}), mw = (a) => {
  const { __scopeMenu: o, forceMount: u, children: s, container: d } = a, v = Oo(eg, o);
  return /* @__PURE__ */ O.jsx(Xj, { scope: o, forceMount: u, children: /* @__PURE__ */ O.jsx(Qr, { present: u || v.open, children: /* @__PURE__ */ O.jsx(u0, { asChild: !0, container: d, children: s }) }) });
};
mw.displayName = eg;
var Mr = "MenuContent", [Kj, tg] = Mo(Mr), yw = h.forwardRef(
  (a, o) => {
    const u = hw(Mr, a.__scopeMenu), { forceMount: s = u.forceMount, ...d } = a, v = Oo(Mr, a.__scopeMenu), c = Js(Mr, a.__scopeMenu);
    return /* @__PURE__ */ O.jsx(Gs.Provider, { scope: a.__scopeMenu, children: /* @__PURE__ */ O.jsx(Qr, { present: s || v.open, children: /* @__PURE__ */ O.jsx(Gs.Slot, { scope: a.__scopeMenu, children: c.modal ? /* @__PURE__ */ O.jsx(qj, { ...d, ref: o }) : /* @__PURE__ */ O.jsx(Qj, { ...d, ref: o }) }) }) });
  }
), qj = h.forwardRef(
  (a, o) => {
    const u = Oo(Mr, a.__scopeMenu), s = h.useRef(null), d = At(o, s);
    return h.useEffect(() => {
      const v = s.current;
      if (v)
        return mP(v);
    }, []), /* @__PURE__ */ O.jsx(
      ng,
      {
        ...a,
        ref: d,
        trapFocus: u.open,
        disableOutsidePointerEvents: u.open,
        disableOutsideScroll: !0,
        onFocusOutside: Oe(
          a.onFocusOutside,
          (v) => v.preventDefault(),
          { checkForDefaultPrevented: !1 }
        ),
        onDismiss: () => u.onOpenChange(!1)
      }
    );
  }
), Qj = h.forwardRef((a, o) => {
  const u = Oo(Mr, a.__scopeMenu);
  return /* @__PURE__ */ O.jsx(
    ng,
    {
      ...a,
      ref: o,
      trapFocus: !1,
      disableOutsidePointerEvents: !1,
      disableOutsideScroll: !1,
      onDismiss: () => u.onOpenChange(!1)
    }
  );
}), ng = h.forwardRef(
  (a, o) => {
    const {
      __scopeMenu: u,
      loop: s = !1,
      trapFocus: d,
      onOpenAutoFocus: v,
      onCloseAutoFocus: c,
      disableOutsidePointerEvents: g,
      onEntryFocus: b,
      onEscapeKeyDown: S,
      onPointerDownOutside: R,
      onFocusOutside: E,
      onInteractOutside: x,
      onDismiss: T,
      disableOutsideScroll: M,
      ...L
    } = a, $ = Oo(Mr, u), U = Js(Mr, u), F = Kd(u), Y = pw(u), X = Bj(u), [W, ne] = h.useState(null), Z = h.useRef(null), ve = At(o, Z, $.onContentChange), me = h.useRef(0), he = h.useRef(""), Ee = h.useRef(0), Xe = h.useRef(null), fe = h.useRef("right"), ge = h.useRef(0), Ie = M ? m0 : h.Fragment, De = M ? { as: ya, allowPinchZoom: !0 } : void 0, de = (se) => {
      var Nt, an;
      const Ke = he.current + se, dt = X().filter((at) => !at.disabled), ft = document.activeElement, Ft = (Nt = dt.find((at) => at.ref.current === ft)) == null ? void 0 : Nt.textValue, Yt = dt.map((at) => at.textValue), Pn = sF(Yt, Ke, Ft), Wt = (an = dt.find((at) => at.textValue === Pn)) == null ? void 0 : an.ref.current;
      (function at(zt) {
        he.current = zt, window.clearTimeout(me.current), zt !== "" && (me.current = window.setTimeout(() => at(""), 1e3));
      })(Ke), Wt && setTimeout(() => Wt.focus());
    };
    h.useEffect(() => () => window.clearTimeout(me.current), []), Ak();
    const Se = h.useCallback((se) => {
      var dt, ft;
      return fe.current === ((dt = Xe.current) == null ? void 0 : dt.side) && fF(se, (ft = Xe.current) == null ? void 0 : ft.area);
    }, []);
    return /* @__PURE__ */ O.jsx(
      Kj,
      {
        scope: u,
        searchRef: he,
        onItemEnter: h.useCallback(
          (se) => {
            Se(se) && se.preventDefault();
          },
          [Se]
        ),
        onItemLeave: h.useCallback(
          (se) => {
            var Ke;
            Se(se) || ((Ke = Z.current) == null || Ke.focus(), ne(null));
          },
          [Se]
        ),
        onTriggerLeave: h.useCallback(
          (se) => {
            Se(se) && se.preventDefault();
          },
          [Se]
        ),
        pointerGraceTimerRef: Ee,
        onPointerGraceIntentChange: h.useCallback((se) => {
          Xe.current = se;
        }, []),
        children: /* @__PURE__ */ O.jsx(Ie, { ...De, children: /* @__PURE__ */ O.jsx(
          o0,
          {
            asChild: !0,
            trapped: d,
            onMountAutoFocus: Oe(v, (se) => {
              var Ke;
              se.preventDefault(), (Ke = Z.current) == null || Ke.focus({ preventScroll: !0 });
            }),
            onUnmountAutoFocus: c,
            children: /* @__PURE__ */ O.jsx(
              Uy,
              {
                asChild: !0,
                disableOutsidePointerEvents: g,
                onEscapeKeyDown: S,
                onPointerDownOutside: R,
                onFocusOutside: E,
                onInteractOutside: x,
                onDismiss: T,
                children: /* @__PURE__ */ O.jsx(
                  lw,
                  {
                    asChild: !0,
                    ...Y,
                    dir: U.dir,
                    orientation: "vertical",
                    loop: s,
                    currentTabStopId: W,
                    onCurrentTabStopIdChange: ne,
                    onEntryFocus: Oe(b, (se) => {
                      U.isUsingKeyboardRef.current || se.preventDefault();
                    }),
                    preventScrollOnEntryFocus: !0,
                    children: /* @__PURE__ */ O.jsx(
                      z0,
                      {
                        role: "menu",
                        "aria-orientation": "vertical",
                        "data-state": Lw($.open),
                        "data-radix-menu-content": "",
                        dir: U.dir,
                        ...F,
                        ...L,
                        ref: ve,
                        style: { outline: "none", ...L.style },
                        onKeyDown: Oe(L.onKeyDown, (se) => {
                          const dt = se.target.closest("[data-radix-menu-content]") === se.currentTarget, ft = se.ctrlKey || se.altKey || se.metaKey, Ft = se.key.length === 1;
                          dt && (se.key === "Tab" && se.preventDefault(), !ft && Ft && de(se.key));
                          const Yt = Z.current;
                          if (se.target !== Yt || !Hj.includes(se.key))
                            return;
                          se.preventDefault();
                          const Wt = X().filter((Nt) => !Nt.disabled).map((Nt) => Nt.ref.current);
                          fw.includes(se.key) && Wt.reverse(), lF(Wt);
                        }),
                        onBlur: Oe(a.onBlur, (se) => {
                          se.currentTarget.contains(se.target) || (window.clearTimeout(me.current), he.current = "");
                        }),
                        onPointerMove: Oe(
                          a.onPointerMove,
                          Xs((se) => {
                            const Ke = se.target, dt = ge.current !== se.clientX;
                            if (se.currentTarget.contains(Ke) && dt) {
                              const ft = se.clientX > ge.current ? "right" : "left";
                              fe.current = ft, ge.current = se.clientX;
                            }
                          })
                        )
                      }
                    )
                  }
                )
              }
            )
          }
        ) })
      }
    );
  }
);
yw.displayName = Mr;
var Zj = "MenuGroup", rg = h.forwardRef(
  (a, o) => {
    const { __scopeMenu: u, ...s } = a;
    return /* @__PURE__ */ O.jsx(St.div, { role: "group", ...s, ref: o });
  }
);
rg.displayName = Zj;
var Jj = "MenuLabel", gw = h.forwardRef(
  (a, o) => {
    const { __scopeMenu: u, ...s } = a;
    return /* @__PURE__ */ O.jsx(St.div, { ...s, ref: o });
  }
);
gw.displayName = Jj;
var kd = "MenuItem", GR = "menu.itemSelect", qd = h.forwardRef(
  (a, o) => {
    const { disabled: u = !1, onSelect: s, ...d } = a, v = h.useRef(null), c = Js(kd, a.__scopeMenu), g = tg(kd, a.__scopeMenu), b = At(o, v), S = h.useRef(!1), R = () => {
      const E = v.current;
      if (!u && E) {
        const x = new CustomEvent(GR, { bubbles: !0, cancelable: !0 });
        E.addEventListener(GR, (T) => s == null ? void 0 : s(T), { once: !0 }), n0(E, x), x.defaultPrevented ? S.current = !1 : c.onClose();
      }
    };
    return /* @__PURE__ */ O.jsx(
      bw,
      {
        ...d,
        ref: b,
        disabled: u,
        onClick: Oe(a.onClick, R),
        onPointerDown: (E) => {
          var x;
          (x = a.onPointerDown) == null || x.call(a, E), S.current = !0;
        },
        onPointerUp: Oe(a.onPointerUp, (E) => {
          var x;
          S.current || (x = E.currentTarget) == null || x.click();
        }),
        onKeyDown: Oe(a.onKeyDown, (E) => {
          const x = g.searchRef.current !== "";
          u || x && E.key === " " || _y.includes(E.key) && (E.currentTarget.click(), E.preventDefault());
        })
      }
    );
  }
);
qd.displayName = kd;
var bw = h.forwardRef(
  (a, o) => {
    const { __scopeMenu: u, disabled: s = !1, textValue: d, ...v } = a, c = tg(kd, u), g = pw(u), b = h.useRef(null), S = At(o, b), [R, E] = h.useState(!1), [x, T] = h.useState("");
    return h.useEffect(() => {
      const M = b.current;
      M && T((M.textContent ?? "").trim());
    }, [v.children]), /* @__PURE__ */ O.jsx(
      Gs.ItemSlot,
      {
        scope: u,
        disabled: s,
        textValue: d ?? x,
        children: /* @__PURE__ */ O.jsx(uw, { asChild: !0, ...g, focusable: !s, children: /* @__PURE__ */ O.jsx(
          St.div,
          {
            role: "menuitem",
            "data-highlighted": R ? "" : void 0,
            "aria-disabled": s || void 0,
            "data-disabled": s ? "" : void 0,
            ...v,
            ref: S,
            onPointerMove: Oe(
              a.onPointerMove,
              Xs((M) => {
                s ? c.onItemLeave(M) : (c.onItemEnter(M), M.defaultPrevented || M.currentTarget.focus({ preventScroll: !0 }));
              })
            ),
            onPointerLeave: Oe(
              a.onPointerLeave,
              Xs((M) => c.onItemLeave(M))
            ),
            onFocus: Oe(a.onFocus, () => E(!0)),
            onBlur: Oe(a.onBlur, () => E(!1))
          }
        ) })
      }
    );
  }
), eF = "MenuCheckboxItem", Sw = h.forwardRef(
  (a, o) => {
    const { checked: u = !1, onCheckedChange: s, ...d } = a;
    return /* @__PURE__ */ O.jsx(xw, { scope: a.__scopeMenu, checked: u, children: /* @__PURE__ */ O.jsx(
      qd,
      {
        role: "menuitemcheckbox",
        "aria-checked": Pd(u) ? "mixed" : u,
        ...d,
        ref: o,
        "data-state": ig(u),
        onSelect: Oe(
          d.onSelect,
          () => s == null ? void 0 : s(Pd(u) ? !0 : !u),
          { checkForDefaultPrevented: !1 }
        )
      }
    ) });
  }
);
Sw.displayName = eF;
var Cw = "MenuRadioGroup", [tF, nF] = Mo(
  Cw,
  { value: void 0, onValueChange: () => {
  } }
), Ew = h.forwardRef(
  (a, o) => {
    const { value: u, onValueChange: s, ...d } = a, v = dn(s);
    return /* @__PURE__ */ O.jsx(tF, { scope: a.__scopeMenu, value: u, onValueChange: v, children: /* @__PURE__ */ O.jsx(rg, { ...d, ref: o }) });
  }
);
Ew.displayName = Cw;
var Rw = "MenuRadioItem", ww = h.forwardRef(
  (a, o) => {
    const { value: u, ...s } = a, d = nF(Rw, a.__scopeMenu), v = u === d.value;
    return /* @__PURE__ */ O.jsx(xw, { scope: a.__scopeMenu, checked: v, children: /* @__PURE__ */ O.jsx(
      qd,
      {
        role: "menuitemradio",
        "aria-checked": v,
        ...s,
        ref: o,
        "data-state": ig(v),
        onSelect: Oe(
          s.onSelect,
          () => {
            var c;
            return (c = d.onValueChange) == null ? void 0 : c.call(d, u);
          },
          { checkForDefaultPrevented: !1 }
        )
      }
    ) });
  }
);
ww.displayName = Rw;
var ag = "MenuItemIndicator", [xw, rF] = Mo(
  ag,
  { checked: !1 }
), Tw = h.forwardRef(
  (a, o) => {
    const { __scopeMenu: u, forceMount: s, ...d } = a, v = rF(ag, u);
    return /* @__PURE__ */ O.jsx(
      Qr,
      {
        present: s || Pd(v.checked) || v.checked === !0,
        children: /* @__PURE__ */ O.jsx(
          St.span,
          {
            ...d,
            ref: o,
            "data-state": ig(v.checked)
          }
        )
      }
    );
  }
);
Tw.displayName = ag;
var aF = "MenuSeparator", Dw = h.forwardRef(
  (a, o) => {
    const { __scopeMenu: u, ...s } = a;
    return /* @__PURE__ */ O.jsx(
      St.div,
      {
        role: "separator",
        "aria-orientation": "horizontal",
        ...s,
        ref: o
      }
    );
  }
);
Dw.displayName = aF;
var iF = "MenuArrow", _w = h.forwardRef(
  (a, o) => {
    const { __scopeMenu: u, ...s } = a, d = Kd(u);
    return /* @__PURE__ */ O.jsx(H0, { ...d, ...s, ref: o });
  }
);
_w.displayName = iF;
var oF = "MenuSub", [x3, Mw] = Mo(oF), js = "MenuSubTrigger", Ow = h.forwardRef(
  (a, o) => {
    const u = Oo(js, a.__scopeMenu), s = Js(js, a.__scopeMenu), d = Mw(js, a.__scopeMenu), v = tg(js, a.__scopeMenu), c = h.useRef(null), { pointerGraceTimerRef: g, onPointerGraceIntentChange: b } = v, S = { __scopeMenu: a.__scopeMenu }, R = h.useCallback(() => {
      c.current && window.clearTimeout(c.current), c.current = null;
    }, []);
    return h.useEffect(() => R, [R]), h.useEffect(() => {
      const E = g.current;
      return () => {
        window.clearTimeout(E), b(null);
      };
    }, [g, b]), /* @__PURE__ */ O.jsx(Jy, { asChild: !0, ...S, children: /* @__PURE__ */ O.jsx(
      bw,
      {
        id: d.triggerId,
        "aria-haspopup": "menu",
        "aria-expanded": u.open,
        "aria-controls": d.contentId,
        "data-state": Lw(u.open),
        ...a,
        ref: qs(o, d.onTriggerChange),
        onClick: (E) => {
          var x;
          (x = a.onClick) == null || x.call(a, E), !(a.disabled || E.defaultPrevented) && (E.currentTarget.focus(), u.open || u.onOpenChange(!0));
        },
        onPointerMove: Oe(
          a.onPointerMove,
          Xs((E) => {
            v.onItemEnter(E), !E.defaultPrevented && !a.disabled && !u.open && !c.current && (v.onPointerGraceIntentChange(null), c.current = window.setTimeout(() => {
              u.onOpenChange(!0), R();
            }, 100));
          })
        ),
        onPointerLeave: Oe(
          a.onPointerLeave,
          Xs((E) => {
            var T, M;
            R();
            const x = (T = u.content) == null ? void 0 : T.getBoundingClientRect();
            if (x) {
              const L = (M = u.content) == null ? void 0 : M.dataset.side, $ = L === "right", U = $ ? -5 : 5, F = x[$ ? "left" : "right"], Y = x[$ ? "right" : "left"];
              v.onPointerGraceIntentChange({
                area: [
                  // Apply a bleed on clientX to ensure that our exit point is
                  // consistently within polygon bounds
                  { x: E.clientX + U, y: E.clientY },
                  { x: F, y: x.top },
                  { x: Y, y: x.top },
                  { x: Y, y: x.bottom },
                  { x: F, y: x.bottom }
                ],
                side: L
              }), window.clearTimeout(g.current), g.current = window.setTimeout(
                () => v.onPointerGraceIntentChange(null),
                300
              );
            } else {
              if (v.onTriggerLeave(E), E.defaultPrevented)
                return;
              v.onPointerGraceIntentChange(null);
            }
          })
        ),
        onKeyDown: Oe(a.onKeyDown, (E) => {
          var T;
          const x = v.searchRef.current !== "";
          a.disabled || x && E.key === " " || $j[s.dir].includes(E.key) && (u.onOpenChange(!0), (T = u.content) == null || T.focus(), E.preventDefault());
        })
      }
    ) });
  }
);
Ow.displayName = js;
var Aw = "MenuSubContent", Nw = h.forwardRef(
  (a, o) => {
    const u = hw(Mr, a.__scopeMenu), { forceMount: s = u.forceMount, ...d } = a, v = Oo(Mr, a.__scopeMenu), c = Js(Mr, a.__scopeMenu), g = Mw(Aw, a.__scopeMenu), b = h.useRef(null), S = At(o, b);
    return /* @__PURE__ */ O.jsx(Gs.Provider, { scope: a.__scopeMenu, children: /* @__PURE__ */ O.jsx(Qr, { present: s || v.open, children: /* @__PURE__ */ O.jsx(Gs.Slot, { scope: a.__scopeMenu, children: /* @__PURE__ */ O.jsx(
      ng,
      {
        id: g.contentId,
        "aria-labelledby": g.triggerId,
        ...d,
        ref: S,
        align: "start",
        side: c.dir === "rtl" ? "left" : "right",
        disableOutsidePointerEvents: !1,
        disableOutsideScroll: !1,
        trapFocus: !1,
        onOpenAutoFocus: (R) => {
          var E;
          c.isUsingKeyboardRef.current && ((E = b.current) == null || E.focus()), R.preventDefault();
        },
        onCloseAutoFocus: (R) => R.preventDefault(),
        onFocusOutside: Oe(a.onFocusOutside, (R) => {
          R.target !== g.trigger && v.onOpenChange(!1);
        }),
        onEscapeKeyDown: Oe(a.onEscapeKeyDown, (R) => {
          c.onClose(), R.preventDefault();
        }),
        onKeyDown: Oe(a.onKeyDown, (R) => {
          var T;
          const E = R.currentTarget.contains(R.target), x = Ij[c.dir].includes(R.key);
          E && x && (v.onOpenChange(!1), (T = g.trigger) == null || T.focus(), R.preventDefault());
        })
      }
    ) }) }) });
  }
);
Nw.displayName = Aw;
function Lw(a) {
  return a ? "open" : "closed";
}
function Pd(a) {
  return a === "indeterminate";
}
function ig(a) {
  return Pd(a) ? "indeterminate" : a ? "checked" : "unchecked";
}
function lF(a) {
  const o = document.activeElement;
  for (const u of a)
    if (u === o || (u.focus(), document.activeElement !== o))
      return;
}
function uF(a, o) {
  return a.map((u, s) => a[(o + s) % a.length]);
}
function sF(a, o, u) {
  const d = o.length > 1 && Array.from(o).every((S) => S === o[0]) ? o[0] : o, v = u ? a.indexOf(u) : -1;
  let c = uF(a, Math.max(v, 0));
  d.length === 1 && (c = c.filter((S) => S !== u));
  const b = c.find(
    (S) => S.toLowerCase().startsWith(d.toLowerCase())
  );
  return b !== u ? b : void 0;
}
function cF(a, o) {
  const { x: u, y: s } = a;
  let d = !1;
  for (let v = 0, c = o.length - 1; v < o.length; c = v++) {
    const g = o[v].x, b = o[v].y, S = o[c].x, R = o[c].y;
    b > s != R > s && u < (S - g) * (s - b) / (R - b) + g && (d = !d);
  }
  return d;
}
function fF(a, o) {
  if (!o)
    return !1;
  const u = { x: a.clientX, y: a.clientY };
  return cF(u, o);
}
function Xs(a) {
  return (o) => o.pointerType === "mouse" ? a(o) : void 0;
}
var dF = vw, pF = Jy, vF = mw, hF = yw, mF = rg, yF = gw, gF = qd, bF = Sw, SF = Ew, CF = ww, EF = Tw, RF = Dw, wF = _w, xF = Ow, TF = Nw;
function DF(a, [o, u]) {
  return Math.min(u, Math.max(o, a));
}
function _F(a, o) {
  return h.useReducer((u, s) => o[u][s] ?? u, a);
}
var og = "ScrollArea", [kw, T3] = zi(og), [MF, Or] = kw(og), Pw = h.forwardRef(
  (a, o) => {
    const {
      __scopeScrollArea: u,
      type: s = "hover",
      dir: d,
      scrollHideDelay: v = 600,
      ...c
    } = a, [g, b] = h.useState(null), [S, R] = h.useState(null), [E, x] = h.useState(null), [T, M] = h.useState(null), [L, $] = h.useState(null), [U, F] = h.useState(0), [Y, X] = h.useState(0), [W, ne] = h.useState(!1), [Z, ve] = h.useState(!1), me = At(o, (Ee) => b(Ee)), he = Yd(d);
    return /* @__PURE__ */ O.jsx(
      MF,
      {
        scope: u,
        type: s,
        dir: he,
        scrollHideDelay: v,
        scrollArea: g,
        viewport: S,
        onViewportChange: R,
        content: E,
        onContentChange: x,
        scrollbarX: T,
        onScrollbarXChange: M,
        scrollbarXEnabled: W,
        onScrollbarXEnabledChange: ne,
        scrollbarY: L,
        onScrollbarYChange: $,
        scrollbarYEnabled: Z,
        onScrollbarYEnabledChange: ve,
        onCornerWidthChange: F,
        onCornerHeightChange: X,
        children: /* @__PURE__ */ O.jsx(
          St.div,
          {
            dir: he,
            ...c,
            ref: me,
            style: {
              position: "relative",
              // Pass corner sizes as CSS vars to reduce re-renders of context consumers
              "--radix-scroll-area-corner-width": U + "px",
              "--radix-scroll-area-corner-height": Y + "px",
              ...a.style
            }
          }
        )
      }
    );
  }
);
Pw.displayName = og;
var Uw = "ScrollAreaViewport", jw = h.forwardRef(
  (a, o) => {
    const { __scopeScrollArea: u, children: s, nonce: d, ...v } = a, c = Or(Uw, u), g = h.useRef(null), b = At(o, g, c.onViewportChange);
    return /* @__PURE__ */ O.jsxs(O.Fragment, { children: [
      /* @__PURE__ */ O.jsx(
        "style",
        {
          dangerouslySetInnerHTML: {
            __html: "[data-radix-scroll-area-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-scroll-area-viewport]::-webkit-scrollbar{display:none}"
          },
          nonce: d
        }
      ),
      /* @__PURE__ */ O.jsx(
        St.div,
        {
          "data-radix-scroll-area-viewport": "",
          ...v,
          ref: b,
          style: {
            /**
             * We don't support `visible` because the intention is to have at least one scrollbar
             * if this component is used and `visible` will behave like `auto` in that case
             * https://developer.mozilla.org/en-US/docs/Web/CSS/overflowed#description
             *
             * We don't handle `auto` because the intention is for the native implementation
             * to be hidden if using this component. We just want to ensure the node is scrollable
             * so could have used either `scroll` or `auto` here. We picked `scroll` to prevent
             * the browser from having to work out whether to render native scrollbars or not,
             * we tell it to with the intention of hiding them in CSS.
             */
            overflowX: c.scrollbarXEnabled ? "scroll" : "hidden",
            overflowY: c.scrollbarYEnabled ? "scroll" : "hidden",
            ...a.style
          },
          children: /* @__PURE__ */ O.jsx("div", { ref: c.onContentChange, style: { minWidth: "100%", display: "table" }, children: s })
        }
      )
    ] });
  }
);
jw.displayName = Uw;
var Sa = "ScrollAreaScrollbar", Fw = h.forwardRef(
  (a, o) => {
    const { forceMount: u, ...s } = a, d = Or(Sa, a.__scopeScrollArea), { onScrollbarXEnabledChange: v, onScrollbarYEnabledChange: c } = d, g = a.orientation === "horizontal";
    return h.useEffect(() => (g ? v(!0) : c(!0), () => {
      g ? v(!1) : c(!1);
    }), [g, v, c]), d.type === "hover" ? /* @__PURE__ */ O.jsx(OF, { ...s, ref: o, forceMount: u }) : d.type === "scroll" ? /* @__PURE__ */ O.jsx(AF, { ...s, ref: o, forceMount: u }) : d.type === "auto" ? /* @__PURE__ */ O.jsx(zw, { ...s, ref: o, forceMount: u }) : d.type === "always" ? /* @__PURE__ */ O.jsx(lg, { ...s, ref: o }) : null;
  }
);
Fw.displayName = Sa;
var OF = h.forwardRef((a, o) => {
  const { forceMount: u, ...s } = a, d = Or(Sa, a.__scopeScrollArea), [v, c] = h.useState(!1);
  return h.useEffect(() => {
    const g = d.scrollArea;
    let b = 0;
    if (g) {
      const S = () => {
        window.clearTimeout(b), c(!0);
      }, R = () => {
        b = window.setTimeout(() => c(!1), d.scrollHideDelay);
      };
      return g.addEventListener("pointerenter", S), g.addEventListener("pointerleave", R), () => {
        window.clearTimeout(b), g.removeEventListener("pointerenter", S), g.removeEventListener("pointerleave", R);
      };
    }
  }, [d.scrollArea, d.scrollHideDelay]), /* @__PURE__ */ O.jsx(Qr, { present: u || v, children: /* @__PURE__ */ O.jsx(
    zw,
    {
      "data-state": v ? "visible" : "hidden",
      ...s,
      ref: o
    }
  ) });
}), AF = h.forwardRef((a, o) => {
  const { forceMount: u, ...s } = a, d = Or(Sa, a.__scopeScrollArea), v = a.orientation === "horizontal", c = Zd(() => b("SCROLL_END"), 100), [g, b] = _F("hidden", {
    hidden: {
      SCROLL: "scrolling"
    },
    scrolling: {
      SCROLL_END: "idle",
      POINTER_ENTER: "interacting"
    },
    interacting: {
      SCROLL: "interacting",
      POINTER_LEAVE: "idle"
    },
    idle: {
      HIDE: "hidden",
      SCROLL: "scrolling",
      POINTER_ENTER: "interacting"
    }
  });
  return h.useEffect(() => {
    if (g === "idle") {
      const S = window.setTimeout(() => b("HIDE"), d.scrollHideDelay);
      return () => window.clearTimeout(S);
    }
  }, [g, d.scrollHideDelay, b]), h.useEffect(() => {
    const S = d.viewport, R = v ? "scrollLeft" : "scrollTop";
    if (S) {
      let E = S[R];
      const x = () => {
        const T = S[R];
        E !== T && (b("SCROLL"), c()), E = T;
      };
      return S.addEventListener("scroll", x), () => S.removeEventListener("scroll", x);
    }
  }, [d.viewport, v, b, c]), /* @__PURE__ */ O.jsx(Qr, { present: u || g !== "hidden", children: /* @__PURE__ */ O.jsx(
    lg,
    {
      "data-state": g === "hidden" ? "hidden" : "visible",
      ...s,
      ref: o,
      onPointerEnter: Oe(a.onPointerEnter, () => b("POINTER_ENTER")),
      onPointerLeave: Oe(a.onPointerLeave, () => b("POINTER_LEAVE"))
    }
  ) });
}), zw = h.forwardRef((a, o) => {
  const u = Or(Sa, a.__scopeScrollArea), { forceMount: s, ...d } = a, [v, c] = h.useState(!1), g = a.orientation === "horizontal", b = Zd(() => {
    if (u.viewport) {
      const S = u.viewport.offsetWidth < u.viewport.scrollWidth, R = u.viewport.offsetHeight < u.viewport.scrollHeight;
      c(g ? S : R);
    }
  }, 10);
  return zl(u.viewport, b), zl(u.content, b), /* @__PURE__ */ O.jsx(Qr, { present: s || v, children: /* @__PURE__ */ O.jsx(
    lg,
    {
      "data-state": v ? "visible" : "hidden",
      ...d,
      ref: o
    }
  ) });
}), lg = h.forwardRef((a, o) => {
  const { orientation: u = "vertical", ...s } = a, d = Or(Sa, a.__scopeScrollArea), v = h.useRef(null), c = h.useRef(0), [g, b] = h.useState({
    content: 0,
    viewport: 0,
    scrollbar: { size: 0, paddingStart: 0, paddingEnd: 0 }
  }), S = Vw(g.viewport, g.content), R = {
    ...s,
    sizes: g,
    onSizesChange: b,
    hasThumb: S > 0 && S < 1,
    onThumbChange: (x) => v.current = x,
    onThumbPointerUp: () => c.current = 0,
    onThumbPointerDown: (x) => c.current = x
  };
  function E(x, T) {
    return jF(x, c.current, g, T);
  }
  return u === "horizontal" ? /* @__PURE__ */ O.jsx(
    NF,
    {
      ...R,
      ref: o,
      onThumbPositionChange: () => {
        if (d.viewport && v.current) {
          const x = d.viewport.scrollLeft, T = XR(x, g, d.dir);
          v.current.style.transform = `translate3d(${T}px, 0, 0)`;
        }
      },
      onWheelScroll: (x) => {
        d.viewport && (d.viewport.scrollLeft = x);
      },
      onDragScroll: (x) => {
        d.viewport && (d.viewport.scrollLeft = E(x, d.dir));
      }
    }
  ) : u === "vertical" ? /* @__PURE__ */ O.jsx(
    LF,
    {
      ...R,
      ref: o,
      onThumbPositionChange: () => {
        if (d.viewport && v.current) {
          const x = d.viewport.scrollTop, T = XR(x, g);
          v.current.style.transform = `translate3d(0, ${T}px, 0)`;
        }
      },
      onWheelScroll: (x) => {
        d.viewport && (d.viewport.scrollTop = x);
      },
      onDragScroll: (x) => {
        d.viewport && (d.viewport.scrollTop = E(x));
      }
    }
  ) : null;
}), NF = h.forwardRef((a, o) => {
  const { sizes: u, onSizesChange: s, ...d } = a, v = Or(Sa, a.__scopeScrollArea), [c, g] = h.useState(), b = h.useRef(null), S = At(o, b, v.onScrollbarXChange);
  return h.useEffect(() => {
    b.current && g(getComputedStyle(b.current));
  }, [b]), /* @__PURE__ */ O.jsx(
    $w,
    {
      "data-orientation": "horizontal",
      ...d,
      ref: S,
      sizes: u,
      style: {
        bottom: 0,
        left: v.dir === "rtl" ? "var(--radix-scroll-area-corner-width)" : 0,
        right: v.dir === "ltr" ? "var(--radix-scroll-area-corner-width)" : 0,
        "--radix-scroll-area-thumb-width": Qd(u) + "px",
        ...a.style
      },
      onThumbPointerDown: (R) => a.onThumbPointerDown(R.x),
      onDragScroll: (R) => a.onDragScroll(R.x),
      onWheelScroll: (R, E) => {
        if (v.viewport) {
          const x = v.viewport.scrollLeft + R.deltaX;
          a.onWheelScroll(x), Ww(x, E) && R.preventDefault();
        }
      },
      onResize: () => {
        b.current && v.viewport && c && s({
          content: v.viewport.scrollWidth,
          viewport: v.viewport.offsetWidth,
          scrollbar: {
            size: b.current.clientWidth,
            paddingStart: jd(c.paddingLeft),
            paddingEnd: jd(c.paddingRight)
          }
        });
      }
    }
  );
}), LF = h.forwardRef((a, o) => {
  const { sizes: u, onSizesChange: s, ...d } = a, v = Or(Sa, a.__scopeScrollArea), [c, g] = h.useState(), b = h.useRef(null), S = At(o, b, v.onScrollbarYChange);
  return h.useEffect(() => {
    b.current && g(getComputedStyle(b.current));
  }, [b]), /* @__PURE__ */ O.jsx(
    $w,
    {
      "data-orientation": "vertical",
      ...d,
      ref: S,
      sizes: u,
      style: {
        top: 0,
        right: v.dir === "ltr" ? 0 : void 0,
        left: v.dir === "rtl" ? 0 : void 0,
        bottom: "var(--radix-scroll-area-corner-height)",
        "--radix-scroll-area-thumb-height": Qd(u) + "px",
        ...a.style
      },
      onThumbPointerDown: (R) => a.onThumbPointerDown(R.y),
      onDragScroll: (R) => a.onDragScroll(R.y),
      onWheelScroll: (R, E) => {
        if (v.viewport) {
          const x = v.viewport.scrollTop + R.deltaY;
          a.onWheelScroll(x), Ww(x, E) && R.preventDefault();
        }
      },
      onResize: () => {
        b.current && v.viewport && c && s({
          content: v.viewport.scrollHeight,
          viewport: v.viewport.offsetHeight,
          scrollbar: {
            size: b.current.clientHeight,
            paddingStart: jd(c.paddingTop),
            paddingEnd: jd(c.paddingBottom)
          }
        });
      }
    }
  );
}), [kF, Hw] = kw(Sa), $w = h.forwardRef((a, o) => {
  const {
    __scopeScrollArea: u,
    sizes: s,
    hasThumb: d,
    onThumbChange: v,
    onThumbPointerUp: c,
    onThumbPointerDown: g,
    onThumbPositionChange: b,
    onDragScroll: S,
    onWheelScroll: R,
    onResize: E,
    ...x
  } = a, T = Or(Sa, u), [M, L] = h.useState(null), $ = At(o, (me) => L(me)), U = h.useRef(null), F = h.useRef(""), Y = T.viewport, X = s.content - s.viewport, W = dn(R), ne = dn(b), Z = Zd(E, 10);
  function ve(me) {
    if (U.current) {
      const he = me.clientX - U.current.left, Ee = me.clientY - U.current.top;
      S({ x: he, y: Ee });
    }
  }
  return h.useEffect(() => {
    const me = (he) => {
      const Ee = he.target;
      (M == null ? void 0 : M.contains(Ee)) && W(he, X);
    };
    return document.addEventListener("wheel", me, { passive: !1 }), () => document.removeEventListener("wheel", me, { passive: !1 });
  }, [Y, M, X, W]), h.useEffect(ne, [s, ne]), zl(M, Z), zl(T.content, Z), /* @__PURE__ */ O.jsx(
    kF,
    {
      scope: u,
      scrollbar: M,
      hasThumb: d,
      onThumbChange: dn(v),
      onThumbPointerUp: dn(c),
      onThumbPositionChange: ne,
      onThumbPointerDown: dn(g),
      children: /* @__PURE__ */ O.jsx(
        St.div,
        {
          ...x,
          ref: $,
          style: { position: "absolute", ...x.style },
          onPointerDown: Oe(a.onPointerDown, (me) => {
            me.button === 0 && (me.target.setPointerCapture(me.pointerId), U.current = M.getBoundingClientRect(), F.current = document.body.style.webkitUserSelect, document.body.style.webkitUserSelect = "none", T.viewport && (T.viewport.style.scrollBehavior = "auto"), ve(me));
          }),
          onPointerMove: Oe(a.onPointerMove, ve),
          onPointerUp: Oe(a.onPointerUp, (me) => {
            const he = me.target;
            he.hasPointerCapture(me.pointerId) && he.releasePointerCapture(me.pointerId), document.body.style.webkitUserSelect = F.current, T.viewport && (T.viewport.style.scrollBehavior = ""), U.current = null;
          })
        }
      )
    }
  );
}), Ud = "ScrollAreaThumb", Iw = h.forwardRef(
  (a, o) => {
    const { forceMount: u, ...s } = a, d = Hw(Ud, a.__scopeScrollArea);
    return /* @__PURE__ */ O.jsx(Qr, { present: u || d.hasThumb, children: /* @__PURE__ */ O.jsx(PF, { ref: o, ...s }) });
  }
), PF = h.forwardRef(
  (a, o) => {
    const { __scopeScrollArea: u, style: s, ...d } = a, v = Or(Ud, u), c = Hw(Ud, u), { onThumbPositionChange: g } = c, b = At(
      o,
      (E) => c.onThumbChange(E)
    ), S = h.useRef(), R = Zd(() => {
      S.current && (S.current(), S.current = void 0);
    }, 100);
    return h.useEffect(() => {
      const E = v.viewport;
      if (E) {
        const x = () => {
          if (R(), !S.current) {
            const T = FF(E, g);
            S.current = T, g();
          }
        };
        return g(), E.addEventListener("scroll", x), () => E.removeEventListener("scroll", x);
      }
    }, [v.viewport, R, g]), /* @__PURE__ */ O.jsx(
      St.div,
      {
        "data-state": c.hasThumb ? "visible" : "hidden",
        ...d,
        ref: b,
        style: {
          width: "var(--radix-scroll-area-thumb-width)",
          height: "var(--radix-scroll-area-thumb-height)",
          ...s
        },
        onPointerDownCapture: Oe(a.onPointerDownCapture, (E) => {
          const T = E.target.getBoundingClientRect(), M = E.clientX - T.left, L = E.clientY - T.top;
          c.onThumbPointerDown({ x: M, y: L });
        }),
        onPointerUp: Oe(a.onPointerUp, c.onThumbPointerUp)
      }
    );
  }
);
Iw.displayName = Ud;
var ug = "ScrollAreaCorner", Bw = h.forwardRef(
  (a, o) => {
    const u = Or(ug, a.__scopeScrollArea), s = !!(u.scrollbarX && u.scrollbarY);
    return u.type !== "scroll" && s ? /* @__PURE__ */ O.jsx(UF, { ...a, ref: o }) : null;
  }
);
Bw.displayName = ug;
var UF = h.forwardRef((a, o) => {
  const { __scopeScrollArea: u, ...s } = a, d = Or(ug, u), [v, c] = h.useState(0), [g, b] = h.useState(0), S = !!(v && g);
  return zl(d.scrollbarX, () => {
    var E;
    const R = ((E = d.scrollbarX) == null ? void 0 : E.offsetHeight) || 0;
    d.onCornerHeightChange(R), b(R);
  }), zl(d.scrollbarY, () => {
    var E;
    const R = ((E = d.scrollbarY) == null ? void 0 : E.offsetWidth) || 0;
    d.onCornerWidthChange(R), c(R);
  }), S ? /* @__PURE__ */ O.jsx(
    St.div,
    {
      ...s,
      ref: o,
      style: {
        width: v,
        height: g,
        position: "absolute",
        right: d.dir === "ltr" ? 0 : void 0,
        left: d.dir === "rtl" ? 0 : void 0,
        bottom: 0,
        ...a.style
      }
    }
  ) : null;
});
function jd(a) {
  return a ? parseInt(a, 10) : 0;
}
function Vw(a, o) {
  const u = a / o;
  return isNaN(u) ? 0 : u;
}
function Qd(a) {
  const o = Vw(a.viewport, a.content), u = a.scrollbar.paddingStart + a.scrollbar.paddingEnd, s = (a.scrollbar.size - u) * o;
  return Math.max(s, 18);
}
function jF(a, o, u, s = "ltr") {
  const d = Qd(u), v = d / 2, c = o || v, g = d - c, b = u.scrollbar.paddingStart + c, S = u.scrollbar.size - u.scrollbar.paddingEnd - g, R = u.content - u.viewport, E = s === "ltr" ? [0, R] : [R * -1, 0];
  return Yw([b, S], E)(a);
}
function XR(a, o, u = "ltr") {
  const s = Qd(o), d = o.scrollbar.paddingStart + o.scrollbar.paddingEnd, v = o.scrollbar.size - d, c = o.content - o.viewport, g = v - s, b = u === "ltr" ? [0, c] : [c * -1, 0], S = DF(a, b);
  return Yw([0, c], [0, g])(S);
}
function Yw(a, o) {
  return (u) => {
    if (a[0] === a[1] || o[0] === o[1])
      return o[0];
    const s = (o[1] - o[0]) / (a[1] - a[0]);
    return o[0] + s * (u - a[0]);
  };
}
function Ww(a, o) {
  return a > 0 && a < o;
}
var FF = (a, o = () => {
}) => {
  let u = { left: a.scrollLeft, top: a.scrollTop }, s = 0;
  return function d() {
    const v = { left: a.scrollLeft, top: a.scrollTop }, c = u.left !== v.left, g = u.top !== v.top;
    (c || g) && o(), u = v, s = window.requestAnimationFrame(d);
  }(), () => window.cancelAnimationFrame(s);
};
function Zd(a, o) {
  const u = dn(a), s = h.useRef(0);
  return h.useEffect(() => () => window.clearTimeout(s.current), []), h.useCallback(() => {
    window.clearTimeout(s.current), s.current = window.setTimeout(u, o);
  }, [u, o]);
}
function zl(a, o) {
  const u = dn(o);
  ki(() => {
    let s = 0;
    if (a) {
      const d = new ResizeObserver(() => {
        cancelAnimationFrame(s), s = window.requestAnimationFrame(u);
      });
      return d.observe(a), () => {
        window.cancelAnimationFrame(s), d.unobserve(a);
      };
    }
  }, [a, u]);
}
var zF = Pw, HF = jw, KR = Fw, qR = Iw, $F = Bw;
const IF = ["1", "2", "3"], BF = ["vertical", "horizontal", "both"], Us = { ...Do, size: { type: "enum", className: "rt-r-size", values: IF, default: "1", responsive: !0 }, ...Ky, scrollbars: { type: "enum", values: BF, default: "both" } };
function VF(a) {
  const { m: o, mx: u, my: s, mt: d, mr: v, mb: c, ml: g, ...b } = a;
  return { m: o, mx: u, my: s, mt: d, mr: v, mb: c, ml: g, rest: b };
}
const xo = Zr.m.values;
function YF(a) {
  const [o, u] = Ni({ className: "rt-r-m", customProperties: ["--margin"], propValues: xo, value: a.m }), [s, d] = Ni({ className: "rt-r-mx", customProperties: ["--margin-left", "--margin-right"], propValues: xo, value: a.mx }), [v, c] = Ni({ className: "rt-r-my", customProperties: ["--margin-top", "--margin-bottom"], propValues: xo, value: a.my }), [g, b] = Ni({ className: "rt-r-mt", customProperties: ["--margin-top"], propValues: xo, value: a.mt }), [S, R] = Ni({ className: "rt-r-mr", customProperties: ["--margin-right"], propValues: xo, value: a.mr }), [E, x] = Ni({ className: "rt-r-mb", customProperties: ["--margin-bottom"], propValues: xo, value: a.mb }), [T, M] = Ni({ className: "rt-r-ml", customProperties: ["--margin-left"], propValues: xo, value: a.ml });
  return [je(o, s, v, g, S, E, T), Dd(u, d, c, b, R, x, M)];
}
const Jd = h.forwardRef((a, o) => {
  const { rest: u, ...s } = VF(a), [d, v] = YF(s), { asChild: c, children: g, className: b, style: S, type: R, scrollHideDelay: E = R !== "scroll" ? 0 : void 0, dir: x, size: T = Us.size.default, radius: M = Us.radius.default, scrollbars: L = Us.scrollbars.default, ...$ } = u;
  return h.createElement(zF, { type: R, scrollHideDelay: E, className: je("rt-ScrollAreaRoot", d, b), style: Dd(v, S), asChild: c }, JU({ asChild: c, children: g }, (U) => h.createElement(h.Fragment, null, h.createElement(HF, { ...$, ref: o, className: "rt-ScrollAreaViewport" }, U), h.createElement("div", { className: "rt-ScrollAreaViewportFocusRing" }), L !== "vertical" ? h.createElement(KR, { "data-radius": M, orientation: "horizontal", className: je("rt-ScrollAreaScrollbar", Bs({ className: "rt-r-size", value: T, propValues: Us.size.values })) }, h.createElement(qR, { className: "rt-ScrollAreaThumb" })) : null, L !== "horizontal" ? h.createElement(KR, { "data-radius": M, orientation: "vertical", className: je("rt-ScrollAreaScrollbar", Bs({ className: "rt-r-size", value: T, propValues: Us.size.values })) }, h.createElement(qR, { className: "rt-ScrollAreaThumb" })) : null, L === "both" ? h.createElement($F, { className: "rt-ScrollAreaCorner" }) : null)));
});
Jd.displayName = "ScrollArea";
const WF = ["1", "2"], GF = ["solid", "soft"], Fs = { size: { type: "enum", className: "rt-r-size", values: WF, default: "2", responsive: !0 }, variant: { type: "enum", className: "rt-variant", values: GF, default: "solid" }, ..._o, ...Fy }, XF = { ...Do, ..._o, shortcut: { type: "string" } }, KF = { ..._o, shortcut: { type: "string" } }, qF = { ..._o };
var sg = "DropdownMenu", [QF, D3] = zi(
  sg,
  [dw]
), Yn = dw(), [ZF, Gw] = QF(sg), Xw = (a) => {
  const {
    __scopeDropdownMenu: o,
    children: u,
    dir: s,
    open: d,
    defaultOpen: v,
    onOpenChange: c,
    modal: g = !0
  } = a, b = Yn(o), S = h.useRef(null), [R = !1, E] = Py({
    prop: d,
    defaultProp: v,
    onChange: c
  });
  return /* @__PURE__ */ O.jsx(
    ZF,
    {
      scope: o,
      triggerId: Td(),
      triggerRef: S,
      contentId: Td(),
      open: R,
      onOpenChange: E,
      onOpenToggle: h.useCallback(() => E((x) => !x), [E]),
      modal: g,
      children: /* @__PURE__ */ O.jsx(dF, { ...b, open: R, onOpenChange: E, dir: s, modal: g, children: u })
    }
  );
};
Xw.displayName = sg;
var Kw = "DropdownMenuTrigger", qw = h.forwardRef(
  (a, o) => {
    const { __scopeDropdownMenu: u, disabled: s = !1, ...d } = a, v = Gw(Kw, u), c = Yn(u);
    return /* @__PURE__ */ O.jsx(pF, { asChild: !0, ...c, children: /* @__PURE__ */ O.jsx(
      St.button,
      {
        type: "button",
        id: v.triggerId,
        "aria-haspopup": "menu",
        "aria-expanded": v.open,
        "aria-controls": v.open ? v.contentId : void 0,
        "data-state": v.open ? "open" : "closed",
        "data-disabled": s ? "" : void 0,
        disabled: s,
        ...d,
        ref: qs(o, v.triggerRef),
        onPointerDown: Oe(a.onPointerDown, (g) => {
          !s && g.button === 0 && g.ctrlKey === !1 && (v.onOpenToggle(), v.open || g.preventDefault());
        }),
        onKeyDown: Oe(a.onKeyDown, (g) => {
          s || (["Enter", " "].includes(g.key) && v.onOpenToggle(), g.key === "ArrowDown" && v.onOpenChange(!0), ["Enter", " ", "ArrowDown"].includes(g.key) && g.preventDefault());
        })
      }
    ) });
  }
);
qw.displayName = Kw;
var JF = "DropdownMenuPortal", Qw = (a) => {
  const { __scopeDropdownMenu: o, ...u } = a, s = Yn(o);
  return /* @__PURE__ */ O.jsx(vF, { ...s, ...u });
};
Qw.displayName = JF;
var Zw = "DropdownMenuContent", Jw = h.forwardRef(
  (a, o) => {
    const { __scopeDropdownMenu: u, ...s } = a, d = Gw(Zw, u), v = Yn(u), c = h.useRef(!1);
    return /* @__PURE__ */ O.jsx(
      hF,
      {
        id: d.contentId,
        "aria-labelledby": d.triggerId,
        ...v,
        ...s,
        ref: o,
        onCloseAutoFocus: Oe(a.onCloseAutoFocus, (g) => {
          var b;
          c.current || (b = d.triggerRef.current) == null || b.focus(), c.current = !1, g.preventDefault();
        }),
        onInteractOutside: Oe(a.onInteractOutside, (g) => {
          const b = g.detail.originalEvent, S = b.button === 0 && b.ctrlKey === !0, R = b.button === 2 || S;
          (!d.modal || R) && (c.current = !0);
        }),
        style: {
          ...a.style,
          "--radix-dropdown-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
          "--radix-dropdown-menu-content-available-width": "var(--radix-popper-available-width)",
          "--radix-dropdown-menu-content-available-height": "var(--radix-popper-available-height)",
          "--radix-dropdown-menu-trigger-width": "var(--radix-popper-anchor-width)",
          "--radix-dropdown-menu-trigger-height": "var(--radix-popper-anchor-height)"
        }
      }
    );
  }
);
Jw.displayName = Zw;
var ez = "DropdownMenuGroup", ex = h.forwardRef(
  (a, o) => {
    const { __scopeDropdownMenu: u, ...s } = a, d = Yn(u);
    return /* @__PURE__ */ O.jsx(mF, { ...d, ...s, ref: o });
  }
);
ex.displayName = ez;
var tz = "DropdownMenuLabel", tx = h.forwardRef(
  (a, o) => {
    const { __scopeDropdownMenu: u, ...s } = a, d = Yn(u);
    return /* @__PURE__ */ O.jsx(yF, { ...d, ...s, ref: o });
  }
);
tx.displayName = tz;
var nz = "DropdownMenuItem", nx = h.forwardRef(
  (a, o) => {
    const { __scopeDropdownMenu: u, ...s } = a, d = Yn(u);
    return /* @__PURE__ */ O.jsx(gF, { ...d, ...s, ref: o });
  }
);
nx.displayName = nz;
var rz = "DropdownMenuCheckboxItem", rx = h.forwardRef((a, o) => {
  const { __scopeDropdownMenu: u, ...s } = a, d = Yn(u);
  return /* @__PURE__ */ O.jsx(bF, { ...d, ...s, ref: o });
});
rx.displayName = rz;
var az = "DropdownMenuRadioGroup", ax = h.forwardRef((a, o) => {
  const { __scopeDropdownMenu: u, ...s } = a, d = Yn(u);
  return /* @__PURE__ */ O.jsx(SF, { ...d, ...s, ref: o });
});
ax.displayName = az;
var iz = "DropdownMenuRadioItem", ix = h.forwardRef((a, o) => {
  const { __scopeDropdownMenu: u, ...s } = a, d = Yn(u);
  return /* @__PURE__ */ O.jsx(CF, { ...d, ...s, ref: o });
});
ix.displayName = iz;
var oz = "DropdownMenuItemIndicator", ox = h.forwardRef((a, o) => {
  const { __scopeDropdownMenu: u, ...s } = a, d = Yn(u);
  return /* @__PURE__ */ O.jsx(EF, { ...d, ...s, ref: o });
});
ox.displayName = oz;
var lz = "DropdownMenuSeparator", lx = h.forwardRef((a, o) => {
  const { __scopeDropdownMenu: u, ...s } = a, d = Yn(u);
  return /* @__PURE__ */ O.jsx(RF, { ...d, ...s, ref: o });
});
lx.displayName = lz;
var uz = "DropdownMenuArrow", sz = h.forwardRef(
  (a, o) => {
    const { __scopeDropdownMenu: u, ...s } = a, d = Yn(u);
    return /* @__PURE__ */ O.jsx(wF, { ...d, ...s, ref: o });
  }
);
sz.displayName = uz;
var cz = "DropdownMenuSubTrigger", ux = h.forwardRef((a, o) => {
  const { __scopeDropdownMenu: u, ...s } = a, d = Yn(u);
  return /* @__PURE__ */ O.jsx(xF, { ...d, ...s, ref: o });
});
ux.displayName = cz;
var fz = "DropdownMenuSubContent", sx = h.forwardRef((a, o) => {
  const { __scopeDropdownMenu: u, ...s } = a, d = Yn(u);
  return /* @__PURE__ */ O.jsx(
    TF,
    {
      ...d,
      ...s,
      ref: o,
      style: {
        ...a.style,
        "--radix-dropdown-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
        "--radix-dropdown-menu-content-available-width": "var(--radix-popper-available-width)",
        "--radix-dropdown-menu-content-available-height": "var(--radix-popper-available-height)",
        "--radix-dropdown-menu-trigger-width": "var(--radix-popper-anchor-width)",
        "--radix-dropdown-menu-trigger-height": "var(--radix-popper-anchor-height)"
      }
    }
  );
});
sx.displayName = fz;
var dz = Xw, pz = qw, cx = Qw, vz = Jw, hz = ex, mz = tx, yz = nx, gz = rx, bz = ax, Sz = ix, fx = ox, Cz = lx, Ez = ux, Rz = sx;
const dx = (a) => h.createElement(dz, { ...a });
dx.displayName = "DropdownMenu.Root";
const px = h.forwardRef(({ children: a, ...o }, u) => h.createElement(pz, { ...o, ref: u, asChild: !0 }, ZU(a)));
px.displayName = "DropdownMenu.Trigger";
const vx = h.createContext({}), hx = h.forwardRef((a, o) => {
  const u = QU(), { size: s = Fs.size.default, variant: d = Fs.variant.default, highContrast: v = Fs.highContrast.default } = a, { className: c, children: g, color: b, container: S, forceMount: R, ...E } = Rn(a, Fs), x = b || u.accentColor;
  return h.createElement(cx, { container: S, forceMount: R }, h.createElement(Wd, { asChild: !0 }, h.createElement(vz, { "data-accent-color": x, align: "start", sideOffset: 4, collisionPadding: 10, ...E, asChild: !1, ref: o, className: je("rt-PopperContent", "rt-BaseMenuContent", "rt-DropdownMenuContent", c) }, h.createElement(Jd, { type: "auto" }, h.createElement("div", { className: je("rt-BaseMenuViewport", "rt-DropdownMenuViewport") }, h.createElement(vx.Provider, { value: h.useMemo(() => ({ size: s, variant: d, color: x, highContrast: v }), [s, d, x, v]) }, g))))));
});
hx.displayName = "DropdownMenu.Content";
const wz = h.forwardRef(({ className: a, ...o }, u) => h.createElement(mz, { ...o, asChild: !1, ref: u, className: je("rt-BaseMenuLabel", "rt-DropdownMenuLabel", a) }));
wz.displayName = "DropdownMenu.Label";
const My = h.forwardRef((a, o) => {
  const { className: u, children: s, color: d = XF.color.default, shortcut: v, ...c } = a;
  return h.createElement(yz, { "data-accent-color": d, ...c, ref: o, className: je("rt-reset", "rt-BaseMenuItem", "rt-DropdownMenuItem", u) }, h.createElement(Ly, null, s), v && h.createElement("div", { className: "rt-BaseMenuShortcut rt-DropdownMenuShortcut" }, v));
});
My.displayName = "DropdownMenu.Item";
const xz = h.forwardRef(({ className: a, ...o }, u) => h.createElement(hz, { ...o, asChild: !1, ref: u, className: je("rt-BaseMenuGroup", "rt-DropdownMenuGroup", a) }));
xz.displayName = "DropdownMenu.Group";
const Tz = h.forwardRef(({ className: a, ...o }, u) => h.createElement(bz, { ...o, asChild: !1, ref: u, className: je("rt-BaseMenuRadioGroup", "rt-DropdownMenuRadioGroup", a) }));
Tz.displayName = "DropdownMenu.RadioGroup";
const Dz = h.forwardRef((a, o) => {
  const { children: u, className: s, color: d = qF.color.default, ...v } = a;
  return h.createElement(Sz, { ...v, asChild: !1, ref: o, "data-accent-color": d, className: je("rt-BaseMenuItem", "rt-BaseMenuRadioItem", "rt-DropdownMenuItem", "rt-DropdownMenuRadioItem", s) }, u, h.createElement(fx, { className: "rt-BaseMenuItemIndicator rt-DropdownMenuItemIndicator" }, h.createElement(Zy, { className: "rt-BaseMenuItemIndicatorIcon rt-DropdownMenuItemIndicatorIcon" })));
});
Dz.displayName = "DropdownMenu.RadioItem";
const _z = h.forwardRef((a, o) => {
  const { children: u, className: s, shortcut: d, color: v = KF.color.default, ...c } = a;
  return h.createElement(gz, { ...c, asChild: !1, ref: o, "data-accent-color": v, className: je("rt-BaseMenuItem", "rt-BaseMenuCheckboxItem", "rt-DropdownMenuItem", "rt-DropdownMenuCheckboxItem", s) }, u, h.createElement(fx, { className: "rt-BaseMenuItemIndicator rt-DropdownMenuItemIndicator" }, h.createElement(Zy, { className: "rt-BaseMenuItemIndicatorIcon rt-ContextMenuItemIndicatorIcon" })), d && h.createElement("div", { className: "rt-BaseMenuShortcut rt-DropdownMenuShortcut" }, d));
});
_z.displayName = "DropdownMenu.CheckboxItem";
const Mz = h.forwardRef((a, o) => {
  const { className: u, children: s, ...d } = a;
  return h.createElement(Ez, { ...d, asChild: !1, ref: o, className: je("rt-BaseMenuItem", "rt-BaseMenuSubTrigger", "rt-DropdownMenuItem", "rt-DropdownMenuSubTrigger", u) }, s, h.createElement("div", { className: "rt-BaseMenuShortcut rt-DropdownMenuShortcut" }, h.createElement(cw, { className: "rt-BaseMenuSubTriggerIcon rt-DropdownMenuSubtriggerIcon" })));
});
Mz.displayName = "DropdownMenu.SubTrigger";
const Oz = h.forwardRef((a, o) => {
  const { size: u, variant: s, color: d, highContrast: v } = h.useContext(vx), { className: c, children: g, container: b, forceMount: S, ...R } = Rn({ size: u, variant: s, color: d, highContrast: v, ...a }, Fs);
  return h.createElement(cx, { container: b, forceMount: S }, h.createElement(Wd, { asChild: !0 }, h.createElement(Rz, { "data-accent-color": d, alignOffset: -Number(u) * 4, sideOffset: 1, collisionPadding: 10, ...R, asChild: !1, ref: o, className: je("rt-PopperContent", "rt-BaseMenuContent", "rt-BaseMenuSubContent", "rt-DropdownMenuContent", "rt-DropdownMenuSubContent", c) }, h.createElement(Jd, { type: "auto" }, h.createElement("div", { className: je("rt-BaseMenuViewport", "rt-DropdownMenuViewport") }, g)))));
});
Oz.displayName = "DropdownMenu.SubContent";
const Az = h.forwardRef(({ className: a, ...o }, u) => h.createElement(Cz, { ...o, asChild: !1, ref: u, className: je("rt-BaseMenuSeparator", "rt-DropdownMenuSeparator", a) }));
Az.displayName = "DropdownMenu.Separator";
const Nz = ["1", "2"], Lz = ["nowrap", "wrap", "wrap-reverse"], kz = ["start", "center", "end"], Pz = { size: { type: "enum", className: "rt-r-size", values: Nz, default: "2", responsive: !0 }, wrap: { type: "enum", className: "rt-r-fw", values: Lz, responsive: !0 }, justify: { type: "enum", className: "rt-r-jc", values: kz, responsive: !0 }, ..._o, ...Fy }, Uz = ["1", "2", "3"], jz = ["surface", "ghost"], Fz = ["auto", "fixed"], yy = { size: { type: "enum", className: "rt-r-size", values: Uz, default: "2", responsive: !0 }, variant: { type: "enum", className: "rt-variant", values: jz, default: "ghost" }, layout: { type: "enum", className: "rt-r-tl", values: Fz, responsive: !0 } }, zz = ["start", "center", "end", "baseline"], Hz = { align: { type: "enum", className: "rt-r-va", values: zz, parseValue: $z, responsive: !0 } };
function $z(a) {
  return { baseline: "baseline", start: "top", center: "middle", end: "bottom" }[a];
}
const Iz = ["start", "center", "end"], cg = { justify: { type: "enum", className: "rt-r-ta", values: Iz, parseValue: Bz, responsive: !0 }, ...g0, ...$s };
function Bz(a) {
  return { start: "left", center: "center", end: "right" }[a];
}
const mx = h.forwardRef((a, o) => {
  const { layout: u, ...s } = yy, { className: d, children: v, layout: c, ...g } = Rn(a, s, Zr), b = Bs({ value: c, className: yy.layout.className, propValues: yy.layout.values });
  return h.createElement("div", { ref: o, className: je("rt-TableRoot", d), ...g }, h.createElement(Jd, null, h.createElement("table", { className: je("rt-TableRootTable", b) }, v)));
});
mx.displayName = "Table.Root";
const yx = h.forwardRef(({ className: a, ...o }, u) => h.createElement("thead", { ...o, ref: u, className: je("rt-TableHeader", a) }));
yx.displayName = "Table.Header";
const gx = h.forwardRef(({ className: a, ...o }, u) => h.createElement("tbody", { ...o, ref: u, className: je("rt-TableBody", a) }));
gx.displayName = "Table.Body";
const Oy = h.forwardRef((a, o) => {
  const { className: u, ...s } = Rn(a, Hz);
  return h.createElement("tr", { ...s, ref: o, className: je("rt-TableRow", u) });
});
Oy.displayName = "Table.Row";
const zs = h.forwardRef((a, o) => {
  const { className: u, ...s } = Rn(a, cg);
  return h.createElement("td", { className: je("rt-TableCell", u), ref: o, ...s });
});
zs.displayName = "Table.Cell";
const Vz = h.forwardRef((a, o) => {
  const { className: u, ...s } = Rn(a, cg);
  return h.createElement("th", { className: je("rt-TableCell", "rt-TableColumnHeaderCell", u), scope: "col", ref: o, ...s });
});
Vz.displayName = "Table.ColumnHeaderCell";
const Yz = h.forwardRef((a, o) => {
  const { className: u, ...s } = Rn(a, cg);
  return h.createElement("th", { className: je("rt-TableCell", "rt-TableRowHeaderCell", u), scope: "row", ref: o, ...s });
});
Yz.displayName = "Table.RowHeaderCell";
var fg = "Tabs", [Wz, _3] = zi(fg, [
  Xd
]), bx = Xd(), [Gz, dg] = Wz(fg), Sx = h.forwardRef(
  (a, o) => {
    const {
      __scopeTabs: u,
      value: s,
      onValueChange: d,
      defaultValue: v,
      orientation: c = "horizontal",
      dir: g,
      activationMode: b = "automatic",
      ...S
    } = a, R = Yd(g), [E, x] = Py({
      prop: s,
      onChange: d,
      defaultProp: v
    });
    return /* @__PURE__ */ O.jsx(
      Gz,
      {
        scope: u,
        baseId: Td(),
        value: E,
        onValueChange: x,
        orientation: c,
        dir: R,
        activationMode: b,
        children: /* @__PURE__ */ O.jsx(
          St.div,
          {
            dir: R,
            "data-orientation": c,
            ...S,
            ref: o
          }
        )
      }
    );
  }
);
Sx.displayName = fg;
var Cx = "TabsList", Ex = h.forwardRef(
  (a, o) => {
    const { __scopeTabs: u, loop: s = !0, ...d } = a, v = dg(Cx, u), c = bx(u);
    return /* @__PURE__ */ O.jsx(
      lw,
      {
        asChild: !0,
        ...c,
        orientation: v.orientation,
        dir: v.dir,
        loop: s,
        children: /* @__PURE__ */ O.jsx(
          St.div,
          {
            role: "tablist",
            "aria-orientation": v.orientation,
            ...d,
            ref: o
          }
        )
      }
    );
  }
);
Ex.displayName = Cx;
var Rx = "TabsTrigger", wx = h.forwardRef(
  (a, o) => {
    const { __scopeTabs: u, value: s, disabled: d = !1, ...v } = a, c = dg(Rx, u), g = bx(u), b = Dx(c.baseId, s), S = _x(c.baseId, s), R = s === c.value;
    return /* @__PURE__ */ O.jsx(
      uw,
      {
        asChild: !0,
        ...g,
        focusable: !d,
        active: R,
        children: /* @__PURE__ */ O.jsx(
          St.button,
          {
            type: "button",
            role: "tab",
            "aria-selected": R,
            "aria-controls": S,
            "data-state": R ? "active" : "inactive",
            "data-disabled": d ? "" : void 0,
            disabled: d,
            id: b,
            ...v,
            ref: o,
            onMouseDown: Oe(a.onMouseDown, (E) => {
              !d && E.button === 0 && E.ctrlKey === !1 ? c.onValueChange(s) : E.preventDefault();
            }),
            onKeyDown: Oe(a.onKeyDown, (E) => {
              [" ", "Enter"].includes(E.key) && c.onValueChange(s);
            }),
            onFocus: Oe(a.onFocus, () => {
              const E = c.activationMode !== "manual";
              !R && !d && E && c.onValueChange(s);
            })
          }
        )
      }
    );
  }
);
wx.displayName = Rx;
var xx = "TabsContent", Tx = h.forwardRef(
  (a, o) => {
    const { __scopeTabs: u, value: s, forceMount: d, children: v, ...c } = a, g = dg(xx, u), b = Dx(g.baseId, s), S = _x(g.baseId, s), R = s === g.value, E = h.useRef(R);
    return h.useEffect(() => {
      const x = requestAnimationFrame(() => E.current = !1);
      return () => cancelAnimationFrame(x);
    }, []), /* @__PURE__ */ O.jsx(Qr, { present: d || R, children: ({ present: x }) => /* @__PURE__ */ O.jsx(
      St.div,
      {
        "data-state": R ? "active" : "inactive",
        "data-orientation": g.orientation,
        role: "tabpanel",
        "aria-labelledby": b,
        hidden: !x,
        id: S,
        tabIndex: 0,
        ...c,
        ref: o,
        style: {
          ...a.style,
          animationDuration: E.current ? "0s" : void 0
        },
        children: x && v
      }
    ) });
  }
);
Tx.displayName = xx;
function Dx(a, o) {
  return `${a}-trigger-${o}`;
}
function _x(a, o) {
  return `${a}-content-${o}`;
}
var Xz = Sx, Kz = Ex, qz = wx, Qz = Tx;
const Mx = h.forwardRef((a, o) => {
  const { className: u, ...s } = Rn(a, Zr);
  return h.createElement(Xz, { ...s, ref: o, className: je("rt-TabsRoot", u) });
});
Mx.displayName = "Tabs.Root";
const Ox = h.forwardRef((a, o) => {
  const { className: u, color: s, ...d } = Rn(a, Pz, Zr);
  return h.createElement(Kz, { "data-accent-color": s, ...d, asChild: !1, ref: o, className: je("rt-BaseTabList", "rt-TabsList", u) });
});
Ox.displayName = "Tabs.List";
const wd = h.forwardRef((a, o) => {
  const { className: u, children: s, ...d } = a;
  return h.createElement(qz, { ...d, asChild: !1, ref: o, className: je("rt-reset", "rt-BaseTabListTrigger", "rt-TabsTrigger", u) }, h.createElement("span", { className: "rt-BaseTabListTriggerInner rt-TabsTriggerInner" }, s), h.createElement("span", { className: "rt-BaseTabListTriggerInnerHidden rt-TabsTriggerInnerHidden" }, s));
});
wd.displayName = "Tabs.Trigger";
const Pl = h.forwardRef((a, o) => {
  const { className: u, ...s } = Rn(a, Zr);
  return h.createElement(Qz, { ...s, ref: o, className: je("rt-TabsContent", u) });
});
Pl.displayName = "Tabs.Content";
const Zz = ["1", "2", "3"], Jz = ["classic", "surface", "soft"], e3 = { size: { type: "enum", className: "rt-r-size", values: Zz, default: "2", responsive: !0 }, variant: { type: "enum", className: "rt-variant", values: Jz, default: "surface" }, ..._o, ...Ky }, t3 = ["left", "right"], n3 = { side: { type: "enum", values: t3 }, ..._o, gap: Z0.gap, px: $s.px, pl: $s.pl, pr: $s.pr }, Li = h.forwardRef((a, o) => {
  const u = h.useRef(null), { children: s, className: d, color: v, radius: c, style: g, ...b } = Rn(a, e3, Zr);
  return h.createElement("div", { "data-accent-color": v, "data-radius": c, style: g, className: je("rt-TextFieldRoot", d), onPointerDown: (S) => {
    const R = S.target;
    if (R.closest("input, button, a"))
      return;
    const E = u.current;
    if (!E)
      return;
    const x = R.closest(`
            .rt-TextFieldSlot[data-side='right'],
            .rt-TextFieldSlot:not([data-side='right']) ~ .rt-TextFieldSlot:not([data-side='left'])
          `) ? E.value.length : 0;
    requestAnimationFrame(() => {
      try {
        E.setSelectionRange(x, x);
      } catch {
      }
      E.focus();
    });
  } }, h.createElement("input", { spellCheck: "false", ...b, ref: qs(u, o), className: "rt-reset rt-TextFieldInput" }), s);
});
Li.displayName = "TextField.Root";
const Is = h.forwardRef((a, o) => {
  const { className: u, color: s, side: d, ...v } = Rn(a, n3);
  return h.createElement("div", { "data-accent-color": s, "data-side": d, ...v, ref: o, className: je("rt-TextFieldSlot", u) });
});
Is.displayName = "TextField.Slot";
function pg(a, o) {
  if (a == null)
    return {};
  var u = {}, s = Object.keys(a), d, v;
  for (v = 0; v < s.length; v++)
    d = s[v], !(o.indexOf(d) >= 0) && (u[d] = a[d]);
  return u;
}
var r3 = ["color"], a3 = /* @__PURE__ */ h.forwardRef(function(a, o) {
  var u = a.color, s = u === void 0 ? "currentColor" : u, d = pg(a, r3);
  return h.createElement("svg", Object.assign({
    width: "15",
    height: "15",
    viewBox: "0 0 15 15",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, d, {
    ref: o
  }), h.createElement("path", {
    d: "M7.1813 1.68179C7.35704 1.50605 7.64196 1.50605 7.8177 1.68179L10.3177 4.18179C10.4934 4.35753 10.4934 4.64245 10.3177 4.81819C10.142 4.99392 9.85704 4.99392 9.6813 4.81819L7.9495 3.08638L7.9495 11.9136L9.6813 10.1818C9.85704 10.0061 10.142 10.0061 10.3177 10.1818C10.4934 10.3575 10.4934 10.6424 10.3177 10.8182L7.8177 13.3182C7.73331 13.4026 7.61885 13.45 7.4995 13.45C7.38015 13.45 7.26569 13.4026 7.1813 13.3182L4.6813 10.8182C4.50557 10.6424 4.50557 10.3575 4.6813 10.1818C4.85704 10.0061 5.14196 10.0061 5.3177 10.1818L7.0495 11.9136L7.0495 3.08638L5.3177 4.81819C5.14196 4.99392 4.85704 4.99392 4.6813 4.81819C4.50557 4.64245 4.50557 4.35753 4.6813 4.18179L7.1813 1.68179Z",
    fill: s,
    fillRule: "evenodd",
    clipRule: "evenodd"
  }));
}), i3 = ["color"], Ax = /* @__PURE__ */ h.forwardRef(function(a, o) {
  var u = a.color, s = u === void 0 ? "currentColor" : u, d = pg(a, i3);
  return h.createElement("svg", Object.assign({
    width: "15",
    height: "15",
    viewBox: "0 0 15 15",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, d, {
    ref: o
  }), h.createElement("path", {
    d: "M4.62471 4.00001L4.56402 4.00001C4.04134 3.99993 3.70687 3.99988 3.4182 4.055C2.2379 4.28039 1.29846 5.17053 1.05815 6.33035C0.999538 6.61321 0.999604 6.93998 0.999703 7.43689L0.999711 7.50001L0.999703 7.56313C0.999604 8.06004 0.999538 8.38681 1.05815 8.66967C1.29846 9.8295 2.2379 10.7196 3.4182 10.945C3.70688 11.0001 4.04135 11.0001 4.56403 11L4.62471 11H5.49971C5.77585 11 5.99971 10.7762 5.99971 10.5C5.99971 10.2239 5.77585 10 5.49971 10H4.62471C4.02084 10 3.78907 9.99777 3.60577 9.96277C2.80262 9.8094 2.19157 9.21108 2.03735 8.46678C2.00233 8.29778 1.99971 8.08251 1.99971 7.50001C1.99971 6.91752 2.00233 6.70225 2.03735 6.53324C2.19157 5.78895 2.80262 5.19062 3.60577 5.03725C3.78907 5.00225 4.02084 5.00001 4.62471 5.00001H5.49971C5.77585 5.00001 5.99971 4.77615 5.99971 4.50001C5.99971 4.22387 5.77585 4.00001 5.49971 4.00001H4.62471ZM10.3747 5.00001C10.9786 5.00001 11.2104 5.00225 11.3937 5.03725C12.1968 5.19062 12.8079 5.78895 12.9621 6.53324C12.9971 6.70225 12.9997 6.91752 12.9997 7.50001C12.9997 8.08251 12.9971 8.29778 12.9621 8.46678C12.8079 9.21108 12.1968 9.8094 11.3937 9.96277C11.2104 9.99777 10.9786 10 10.3747 10H9.49971C9.22357 10 8.99971 10.2239 8.99971 10.5C8.99971 10.7762 9.22357 11 9.49971 11H10.3747L10.4354 11C10.9581 11.0001 11.2925 11.0001 11.5812 10.945C12.7615 10.7196 13.701 9.8295 13.9413 8.66967C13.9999 8.38681 13.9998 8.06005 13.9997 7.56314L13.9997 7.50001L13.9997 7.43688C13.9998 6.93998 13.9999 6.61321 13.9413 6.33035C13.701 5.17053 12.7615 4.28039 11.5812 4.055C11.2925 3.99988 10.9581 3.99993 10.4354 4.00001L10.3747 4.00001H9.49971C9.22357 4.00001 8.99971 4.22387 8.99971 4.50001C8.99971 4.77615 9.22357 5.00001 9.49971 5.00001H10.3747ZM5.00038 7C4.72424 7 4.50038 7.22386 4.50038 7.5C4.50038 7.77614 4.72424 8 5.00038 8H10.0004C10.2765 8 10.5004 7.77614 10.5004 7.5C10.5004 7.22386 10.2765 7 10.0004 7H5.00038Z",
    fill: s,
    fillRule: "evenodd",
    clipRule: "evenodd"
  }));
}), o3 = ["color"], l3 = /* @__PURE__ */ h.forwardRef(function(a, o) {
  var u = a.color, s = u === void 0 ? "currentColor" : u, d = pg(a, o3);
  return h.createElement("svg", Object.assign({
    width: "15",
    height: "15",
    viewBox: "0 0 15 15",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, d, {
    ref: o
  }), h.createElement("path", {
    d: "M4.81812 4.68161C4.99386 4.85734 4.99386 5.14227 4.81812 5.318L3.08632 7.0498H11.9135L10.1817 5.318C10.006 5.14227 10.006 4.85734 10.1817 4.68161C10.3575 4.50587 10.6424 4.50587 10.8181 4.68161L13.3181 7.18161C13.4939 7.35734 13.4939 7.64227 13.3181 7.818L10.8181 10.318C10.6424 10.4937 10.3575 10.4937 10.1817 10.318C10.006 10.1423 10.006 9.85734 10.1817 9.68161L11.9135 7.9498H3.08632L4.81812 9.68161C4.99386 9.85734 4.99386 10.1423 4.81812 10.318C4.64239 10.4937 4.35746 10.4937 4.18173 10.318L1.68173 7.818C1.50599 7.64227 1.50599 7.35734 1.68173 7.18161L4.18173 4.68161C4.35746 4.50587 4.64239 4.50587 4.81812 4.68161Z",
    fill: s,
    fillRule: "evenodd",
    clipRule: "evenodd"
  }));
});
const u3 = ({ caido: a }) => {
  const [o, u] = h.useState("https://i.pinimg.com/originals/56/7a/09/567a0964671de5b98b70583fe81ae5b0.gif"), [s, d] = h.useState("150"), [v, c] = h.useState("100");
  h.useEffect(() => {
    (() => {
      var R, E;
      const S = a.storage.get();
      typeof S == "object" && S && (u(S.gif_url || ""), d(((R = S.gif_width) == null ? void 0 : R.toString()) || "150"), c(((E = S.gif_height) == null ? void 0 : E.toString()) || "100"));
    })();
  }, [a]);
  const g = () => {
    const b = a.storage.get();
    a.storage.set({
      ...b,
      gif_url: o,
      gif_width: Number(s),
      gif_height: Number(v)
    });
  };
  return /* @__PURE__ */ O.jsxs(Il, { columns: "1", gap: "3", rows: "5", width: "200px", style: { margin: "auto" }, children: [
    /* @__PURE__ */ O.jsx("h1", { style: { margin: "auto" }, children: "Pets" }),
    /* @__PURE__ */ O.jsx(
      Li,
      {
        placeholder: "Enter your GIF url...",
        value: o,
        onChange: (b) => u(b.target.value),
        id: "gif_url_input",
        children: /* @__PURE__ */ O.jsx(Is, { children: /* @__PURE__ */ O.jsx(Ax, {}) })
      }
    ),
    /* @__PURE__ */ O.jsx(
      Li,
      {
        placeholder: "Enter GIF width...",
        value: s,
        onChange: (b) => d(b.target.value),
        id: "gif_width",
        children: /* @__PURE__ */ O.jsx(Is, { children: /* @__PURE__ */ O.jsx(l3, {}) })
      }
    ),
    /* @__PURE__ */ O.jsx(
      Li,
      {
        placeholder: "Enter GIF height...",
        value: v,
        onChange: (b) => c(b.target.value),
        id: "gif_height",
        children: /* @__PURE__ */ O.jsx(Is, { children: /* @__PURE__ */ O.jsx(a3, {}) })
      }
    ),
    /* @__PURE__ */ O.jsx(Ws, { variant: "outline", onClick: g, children: "Save Changes" })
  ] });
}, s3 = ({ caido: a }) => {
  var v, c;
  const o = a.storage.get(), u = (o == null ? void 0 : o.gif_url) || "https://i.pinimg.com/originals/56/7a/09/567a0964671de5b98b70583fe81ae5b0.gif", s = ((v = o == null ? void 0 : o.gif_width) == null ? void 0 : v.toString()) || "150", d = ((c = o == null ? void 0 : o.gif_height) == null ? void 0 : c.toString()) || "100";
  return /* @__PURE__ */ O.jsxs(Il, { columns: "1", gap: "1", rows: "2", width: "200px", style: { margin: "auto" }, children: [
    /* @__PURE__ */ O.jsx(u3, { caido: a }),
    /* @__PURE__ */ O.jsx(q0, { children: /* @__PURE__ */ O.jsx(
      "img",
      {
        src: u,
        alt: "Custom GIF",
        height: d,
        width: s
      }
    ) })
  ] });
}, c3 = ({ caido: a }) => {
  var T, M, L, $;
  const o = a.storage.get(), [u, s] = h.useState(((M = (T = o == null ? void 0 : o.webhooks) == null ? void 0 : T[0]) == null ? void 0 : M.name) || ""), [d, v] = h.useState((($ = (L = o == null ? void 0 : o.webhooks) == null ? void 0 : L[0]) == null ? void 0 : $.url) || ""), [c, g] = h.useState((o == null ? void 0 : o.webhooks) || []), [b, S] = h.useState(null);
  h.useEffect(() => {
    (() => {
      const F = a.storage.get();
      if (typeof F == "object" && F !== null) {
        const Y = F.webhooks || [];
        g(Y);
      }
    })();
  }, [a]);
  const R = () => {
    if (u.trim() === "" || d.trim() === "") {
      alert("Webhook name and URL cannot be empty.");
      return;
    }
    const U = { name: u, url: d }, F = b !== null ? c.map((Y, X) => X === b ? U : Y) : [...c, U];
    g(F), a.storage.set({ ...o, webhooks: F }), S(null), s(""), v(""), console.log("Webhook saved:", U);
  }, E = (U) => {
    const F = c.filter((Y, X) => X !== U);
    g(F), a.storage.set({ ...o, webhooks: F });
  }, x = (U) => {
    const F = c[U];
    F && (s(F.name), v(F.url), S(U));
  };
  return /* @__PURE__ */ O.jsxs(Il, { columns: "1", gap: "2", rows: "4", width: "300px", style: { margin: "auto" }, children: [
    /* @__PURE__ */ O.jsx("h1", { style: { margin: "auto" }, children: "Nerd Sniper" }),
    /* @__PURE__ */ O.jsx(
      Li,
      {
        placeholder: "Enter webhook name...",
        value: u,
        onChange: (U) => s(U.target.value),
        id: "webhook_name_input",
        style: { width: "300px" }
      }
    ),
    /* @__PURE__ */ O.jsx(
      Li,
      {
        placeholder: "Enter your webhook URL...",
        value: d,
        onChange: (U) => v(U.target.value),
        id: "webhook_url_input",
        style: { width: "300px" }
      }
    ),
    /* @__PURE__ */ O.jsx(Ws, { variant: "outline", onClick: R, children: b !== null ? "Update Webhook" : "Save Webhook" }),
    /* @__PURE__ */ O.jsxs(mx, { style: { margin: "auto" }, children: [
      /* @__PURE__ */ O.jsx(yx, { children: /* @__PURE__ */ O.jsxs(Oy, { children: [
        /* @__PURE__ */ O.jsx(zs, { style: { overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }, children: "Name" }),
        /* @__PURE__ */ O.jsx(zs, { children: "Actions" })
      ] }) }),
      /* @__PURE__ */ O.jsx(gx, { children: c.map((U, F) => /* @__PURE__ */ O.jsxs(Oy, { children: [
        /* @__PURE__ */ O.jsx(zs, { style: { overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }, children: U.name }),
        /* @__PURE__ */ O.jsx(zs, { children: /* @__PURE__ */ O.jsxs(dx, { children: [
          /* @__PURE__ */ O.jsx(px, { children: /* @__PURE__ */ O.jsx(Ws, { variant: "outline", children: "Actions" }) }),
          /* @__PURE__ */ O.jsxs(hx, { children: [
            /* @__PURE__ */ O.jsx(My, { onClick: () => x(F), children: "Update" }),
            /* @__PURE__ */ O.jsx(My, { onClick: () => E(F), children: "Delete" })
          ] })
        ] }) })
      ] }, F)) })
    ] })
  ] });
}, f3 = ({ caido: a }) => {
  const [o, u] = h.useState(() => {
    const c = a.storage.get();
    return (c == null ? void 0 : c.embed_title) || "Embedder";
  }), [s, d] = h.useState(() => {
    const c = a.storage.get();
    return (c == null ? void 0 : c.embed_url) || "https://www.example.com";
  });
  h.useEffect(() => {
    const c = a.storage.get();
    c && (u(c.embed_title || "Embedder"), d(c.embed_url || "https://www.example.com"));
  }, [a]);
  const v = () => {
    const c = a.storage.get();
    a.storage.set({
      ...c,
      embed_title: o,
      embed_url: s
    });
  };
  return /* @__PURE__ */ O.jsxs(Il, { columns: "1", gap: "3", rows: "3", width: "200px", style: { margin: "auto" }, children: [
    /* @__PURE__ */ O.jsx("h1", { style: { margin: "auto" }, children: "Embedder" }),
    /* @__PURE__ */ O.jsx(
      Li,
      {
        placeholder: "Enter your embed title...",
        value: o,
        onChange: (c) => u(c.target.value),
        id: "embed_title_input"
      }
    ),
    /* @__PURE__ */ O.jsx(
      Li,
      {
        placeholder: "Enter your embed URL...",
        value: s,
        onChange: (c) => d(c.target.value),
        id: "embed_url_input",
        children: /* @__PURE__ */ O.jsx(Is, { children: /* @__PURE__ */ O.jsx(Ax, {}) })
      }
    ),
    /* @__PURE__ */ O.jsx(Ws, { variant: "outline", onClick: v, children: "Save Changes" })
  ] });
}, d3 = ({ caido: a }) => /* @__PURE__ */ O.jsx(Il, { columns: "1", gap: "3", rows: "2", width: "200px", style: { margin: "auto" }, children: /* @__PURE__ */ O.jsx(f3, { caido: a }) }), p3 = ({ caido: a }) => {
  const o = a.storage.get(), u = o && o.embed_url || "https://www.example.com";
  return /* @__PURE__ */ O.jsx(
    "iframe",
    {
      src: u,
      style: { width: "100%", height: "100vh", border: "none" },
      title: "Embedded Content"
    }
  );
}, v3 = ({ caido: a }) => /* @__PURE__ */ O.jsx(Wd, { appearance: "dark", accentColor: "crimson", children: /* @__PURE__ */ O.jsxs(Mx, { defaultValue: "pets", children: [
  /* @__PURE__ */ O.jsxs(Ox, { children: [
    /* @__PURE__ */ O.jsx(wd, { value: "pets", children: "Pets" }),
    /* @__PURE__ */ O.jsx(wd, { value: "nerdsniper", children: "Nerd Sniper" }),
    /* @__PURE__ */ O.jsx(wd, { value: "embedder", children: "Embedder" })
  ] }),
  /* @__PURE__ */ O.jsx(Pl, { value: "pets", style: { margin: "30px" }, children: /* @__PURE__ */ O.jsx(s3, { caido: a }) }),
  /* @__PURE__ */ O.jsx(Pl, { value: "nerdsniper", children: /* @__PURE__ */ O.jsx(Pl, { value: "nerdsniper", style: { margin: "30px" }, children: /* @__PURE__ */ O.jsx(c3, { caido: a }) }) }),
  /* @__PURE__ */ O.jsx(Pl, { value: "embedder", children: /* @__PURE__ */ O.jsx(Pl, { value: "embedder", style: { margin: "30px" }, children: /* @__PURE__ */ O.jsx(d3, { caido: a }) }) })
] }) }), h3 = (a) => {
  const o = document.createElement("div");
  o.className = "primatepack-settings", o.innerHTML = '<div id="settings-root"></div>', document.body.appendChild(o);
  const u = document.getElementById("settings-root");
  u && Ny(u).render(/* @__PURE__ */ O.jsx(v3, { caido: a })), a.navigation.addPage("/settings/primatepack", { body: o });
}, m3 = (a) => {
  const o = document.createElement("div");
  o.className = "primatepack-embedder", o.innerHTML = '<div id="embedder-root" width="80%" height="80%"></div>', document.body.appendChild(o);
  const u = document.getElementById("embedder-root");
  u && Ny(u).render(/* @__PURE__ */ O.jsx(p3, { caido: a })), a.navigation.addPage("/embedder", { body: o });
}, y3 = (a) => {
  const o = a.storage.get(), u = {
    embed_title: "Embedder",
    embed_url: "https://www.example.com",
    gif_url: "https://i.pinimg.com/originals/56/7a/09/567a0964671de5b98b70583fe81ae5b0.gif",
    gif_width: 150,
    gif_height: 100,
    webhooks: []
  };
  return {
    gifUrl: (o == null ? void 0 : o.gif_url) || u.gif_url,
    gifWidth: (o == null ? void 0 : o.gif_width) || u.gif_width,
    gifHeight: (o == null ? void 0 : o.gif_height) || u.gif_height,
    webhooks: (o == null ? void 0 : o.webhooks) || u.webhooks,
    embedTitle: (o == null ? void 0 : o.embed_title) || u.embed_title,
    embedUrl: (o == null ? void 0 : o.embed_url) || u.embed_url
  };
}, M3 = (a) => {
  JL(a), h3(a), m3(a), RR().menu.registerItem({
    type: "Settings",
    label: "The Primate Pack",
    path: "/settings/primatepack",
    leadingIcon: "fas fa-cat"
  });
  const { gifUrl: o, gifWidth: u, gifHeight: s, webhooks: d, embedTitle: v } = y3(a);
  RR().sidebar.registerItem("", "#", {
    icon: "",
    group: `<img id='gifImage' src='${o}' width='${u}' height='${s}'>`
  }), a.sidebar.registerItem(v, "/embedder", {
    icon: "fas fa-cat",
    group: "Primate Pack"
  });
  const c = document.getElementById("gifImage");
  if (c && (c.src = o, c.width = u, c.height = s), d.length === 0) {
    console.warn("No webhooks found.");
    return;
  }
  d.forEach((g) => {
    const b = `send_to_${g.name.toLowerCase().replace(/\s+/g, "_")}`;
    a.commands.register(b, {
      name: `Send to ${g.name}`,
      run: async () => {
        var E;
        const S = (E = a.window.getActiveEditor()) == null ? void 0 : E.getSelectedText();
        if (!S) {
          alert("Please select text");
          return;
        }
        const R = S.replace(/(?:^|\n)(?:\s*cookie:\s*.*?(\r?\n|$)|\s*Authorization:\s*.*?(\r?\n|$))/gi, "");
        try {
          const x = await fetch(g.url, {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({ content: R })
          });
          if (!x.ok)
            throw new Error(`Error: ${x.statusText}`);
          alert("Request Sent Successfully");
        } catch {
          alert("Failed to Send");
        }
      },
      group: "Custom Commands"
    }), a.menu.registerItem({
      type: "Request",
      commandId: b,
      leadingIcon: "fas fa-paper-plane"
    });
  });
};
export {
  M3 as init
};
